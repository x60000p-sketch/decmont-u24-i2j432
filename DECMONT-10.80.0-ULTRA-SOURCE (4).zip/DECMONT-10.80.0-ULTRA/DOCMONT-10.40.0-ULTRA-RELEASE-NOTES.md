# DECMONT 10.40.0 ULTRA

## Native C11 lowering expansion

This release expands the restricted native C11 backend with integer comparisons,
boolean negation, logical operators, and equality/inequality for integer and
string values. The backend continues to validate control-flow targets and
operand-stack depth before emitting C.

### Added native operations
- `BoolNot`
- `Equal` and `NotEqual` (integer and string values; differing value kinds compare unequal)
- `Less`, `LessEqual`, `Greater`, `GreaterEqual` (integer operands)
- `LogicalAnd` and `LogicalOr` (integer truthiness; result normalized to 0 or 1)

### Runtime checks
- Type checks for boolean and ordered comparison operands
- Existing checked integer arithmetic and divide-by-zero handling retained
- Existing instruction and operand-stack safety limits retained

### Compatibility
- Language compatibility: 3.4.0
- DVM bytecode: v1
- Native C11 remains a supported opcode subset, not full-language parity.

### Validation scope
Release validation is performed on the available Linux x86_64 host. Other
operating systems, hardware GPU execution, and console SDK targets are not
claimed as validated by this release.
