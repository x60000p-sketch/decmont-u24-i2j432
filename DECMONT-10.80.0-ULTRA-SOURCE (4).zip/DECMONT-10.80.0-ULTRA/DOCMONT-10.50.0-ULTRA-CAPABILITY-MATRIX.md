# DECMONT 10.50.0 capability matrix

| Area | Status | Verified scope |
|---|---|---|
| Language compatibility | Available | 3.4.0 grammar/runtime compatibility retained |
| DVM | Available | Bytecode v1; existing VM tests |
| Native C11 lowering | Expanded subset | Arithmetic, branches, boolean/comparison/logical operations, integer/string equality, core arrays |
| Native arrays | Available in lowered subset | Create, get, set, length, push, pop; type/index checks; bounded process-lifetime storage |
| Native verifier | Available | Jump bounds, reachable stack dataflow, merge-depth consistency, underflow, 4096-slot stack cap, 1,000,000-instruction cap |
| Native array resource cap | Available | 1,000,000 reserved `Value` slots across arrays per process |
| Native compiler parity | Not complete | Objects, functions, closures, cells and other unlowered opcodes remain unsupported by C11 backend |
| CPU backend | Available | Portable C11 output compiled and executed with host Clang |
| GLES | Existing limited backend | Host runtime detected; this environment uses software rendering, not hardware acceleration |
| Vulkan | Probe/loader scope | No device/queue available in this environment; not a complete renderer |
| D3D12 / Metal | Platform adapters/probes | Not validated on this Linux host; do not infer full renderer support |
| ONNX | Bounded CPU operator subset | General GPU ONNX provider not implemented |
| Game engine | Host-side systems | Production renderer/audio adapters remain platform-dependent/incomplete |
| Windows/macOS/mobile | Not validated here | Separate platform toolchains and CI required |
| PS5/Xbox | Not validated here | Vendor SDK and authorized devkit required |

## Native array semantics

- `MakeArray`: consumes N stack values and pushes one array value.
- `ArrayGet`: consumes array and integer index, then pushes the selected value.
- `ArraySet`: consumes array, integer index and value; updates the selected slot.
- `ArrayLength`: replaces an array or string with its length.
- `ArrayPush`: appends a value and replaces the array operand with its new length.
- `ArrayPop`: replaces the array operand with the removed last value; empty arrays fail.

The generated C11 backend reserves at most 1,000,000 array `Value` slots per
process. Storage is retained until process exit; a tracing/reference-counted
native heap is not yet implemented. DVM remains the portable execution fallback
for unsupported native operations.
