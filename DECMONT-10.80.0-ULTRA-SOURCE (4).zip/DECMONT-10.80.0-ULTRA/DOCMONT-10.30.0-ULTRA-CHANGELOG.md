# Changelog — 10.30.0
- Hardened native-C preflight verification with deterministic instruction-count and operand-stack limits.
- Added regression coverage for pathological stack growth and minimal valid stack allocation.
- Updated CLI/compiler version reporting and release metadata to 10.30.0.
