# DECMONT 10.20.0 ULTRA — Release Notes

## Release focus

10.20.0 hardens the restricted Native C source backend by validating control flow and operand-stack behavior before code emission. It preserves language compatibility 3.4.0 and DVM bytecode v1.

## Implemented

- Reachability-based stack-depth dataflow over the native backend's supported opcode subset.
- Validation of negative and out-of-range branch targets.
- Detection of stack underflow before C source is emitted.
- Detection of inconsistent stack depth at control-flow merge points.
- Detection of positive-growth loops that would make fixed stack sizing unsafe.
- Exact fixed-size native stack allocation based on the verified maximum stack depth.
- Explicit unsupported-opcode diagnostics; no partial C source is returned on rejection.
- Dedicated regression tests for valid arithmetic, stack sizing, underflow, invalid targets, merge mismatches, growth loops and unsupported opcodes.

## Verification

- Linux x86_64, GNU C/C++ 14.2.0, CMake + Ninja, Release build: PASS.
- CTest: 81/81 PASS.
- VS Code extension JavaScript syntax checks: PASS.
- `docmont --version`: reports 10.20.0 with language compatibility 3.4.0.
- `docmont doctor --json`: output parsed successfully by Python's JSON parser.

## Limitations

This release does not make the Native C backend a full-language compiler. It still rejects arrays, objects, functions, closures and unsupported VM instructions. Vulkan/D3D12/Metal production rendering, general ONNX GPU execution, and cross-platform target validation remain incomplete. Console builds require licensed vendor SDKs and devkits.
