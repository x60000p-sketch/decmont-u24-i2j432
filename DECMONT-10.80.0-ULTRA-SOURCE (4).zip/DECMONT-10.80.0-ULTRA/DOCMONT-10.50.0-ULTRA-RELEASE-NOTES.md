# DECMONT 10.50.0 ULTRA

## Native C11 array lowering

DECMONT 10.50.0 expands the restricted Native C11 AOT backend with the core
array operations already represented by the language IR. The backend emits
portable C11 and validates stack effects before emission.

### Newly lowered operations
- `MakeArray`: creates an array from the top N operand-stack values.
- `ArrayGet`: reads an element after integer-index and bounds validation.
- `ArraySet`: mutates an existing element after type and bounds validation.
- `ArrayLength`: obtains array length; UTF-8 strings currently use byte length,
  matching the existing runtime's string storage length.
- `ArrayPush`: appends an element and returns the new array length.
- `ArrayPop`: removes and returns the last element; empty arrays are rejected.
- Array values can be printed recursively by the generated C11 runtime helper.

### Resource and safety rules
- The generated native runtime caps total reserved array element capacity at
  1,000,000 `Value` slots across all arrays in one process.
- Array allocation/growth failures, invalid indices, wrong operand kinds,
  empty-pop operations and stack underflow return explicit nonzero statuses.
- The existing 4,096-slot verified operand stack and 1,000,000-instruction
  source limit remain active.
- Generated array storage is process-lifetime storage in this release; it is
  bounded, but this is not yet a tracing or reference-counted garbage collector.

### Compatibility
- Language compatibility: 3.4.0.
- DVM bytecode: v1.
- DVM remains the portable fallback for native opcodes not yet lowered.

### Validation
- Linux x86_64 Release build with CMake/Ninja.
- CTest suite: 83 tests passed.
- Native array source emitted, compiled with Clang C11 (`-Wall -Wextra -Werror`),
  linked, and executed with output matching the DVM result for indexing, length,
  push and pop.
- Windows, macOS, mobile, GPU hardware and console SDK targets are not claimed
  as validated by this release.
