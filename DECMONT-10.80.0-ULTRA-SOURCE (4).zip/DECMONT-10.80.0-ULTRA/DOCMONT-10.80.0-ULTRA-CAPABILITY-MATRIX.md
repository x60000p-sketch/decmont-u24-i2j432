# DECMONT 10.80.0 — Capability Matrix

| Area | 10.80.0 status |
|---|---|
| DVM portable runtime | Available |
| Native C11 backend | Restricted supported-opcode subset |
| Native arrays | Supported within documented limits |
| Native array heap registry | Available; process-lifetime cleanup |
| Aggregate array payload budget | 64 MiB per generated process |
| Native object operations | NewObject, ObjectSet, ObjectGet, ObjectHas supported |
| Native object field storage | 64 MiB aggregate field-capacity budget |
| Object field capacity | 1,000,000 aggregate capacity slots |
| Registered native objects | 65,536 |
| Native object ABI / classes / inheritance | Not implemented |
| Reference counting / tracing garbage collector | Not implemented |
| Native functions / closures | Not complete |
| Vulkan/D3D12/Metal production renderers | Not complete |
| General ONNX GPU provider | Not implemented |
| PS5/Xbox deployment | Requires official SDK and devkit; not validated here |
| Tested host | Linux x86_64 |
