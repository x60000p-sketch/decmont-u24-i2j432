# DOCMONT 8.80.0 ULTRA — Release Notes

## Summary

8.80.0 extends DOCMONT ULTRA with five tested integration areas and a browser-based local Studio. Existing 8.70.0 language/compiler/game systems remain included.

## Added

1. **Skeletal Animation** — validated parent-before-child skeletons, translation/rotation/scale tracks, key interpolation, quaternion SLERP, looping/clamped clips, pose blending, global/skin matrices and CPU linear blend skinning with four influences.
2. **Networking** — framed TCP transport with magic/length/CRC, sequenced UDP packets with length/CRC, connect by IPv4 hostname/address, and bind to a requested IPv4 address or all IPv4 interfaces. Current implementation is POSIX-only.
3. **Neural Inference** — a bounded ONNX ModelProto loader and CPU float32 inference subset: Add, Gemm, Identity, MatMul (2D), Mul, Relu, Sigmoid, Softmax and Tanh. CLI supports one input and one output; the C++ API can bind named inputs.
4. **GPU capability probe** — dynamically loads Vulkan and attempts instance, physical-device, logical-device and queue initialization. D3D12/Metal are reported according to host/platform adapter availability. No complete renderer or GPU compute queue submission is claimed.
5. **Visual Game Studio** — dependency-free Python local web server, project explorer, text editor, safe save with backups, compiler validation/run, scene JSON preview, asset metadata catalog, render graph plan and metrics panel.
6. **Console SDK manifest validation** — checks vendor SDK root, compiler, toolchain file, headers and license acknowledgement. Example templates contain placeholders only.

## Verification

- CTest: **71/71 passed**.
- VS Code LSP integration: **8/8 passed**.
- `npm run check`: passed.
- ONNX CLI smoke: model metadata loaded and inference output `[2, 0]` verified.
- Studio smoke: localhost web UI, file listing/read/save, automatic backup, binary asset listing, path traversal rejection, cross-origin POST rejection and compiler validation passed.
- TCP and UDP loopback exchange tests passed; bind-any and IPv4 API paths exercised.
- Skeletal animation, pose interpolation/blending, matrix build and CPU skinning tests passed.
- Console manifest tests use a mock SDK tree and verify readiness structure only; they do not certify either console.

## Compatibility

- Language compatibility remains 3.4.0.
- DVM bytecode remains v1.
- Native compiler executable built on Linux x86_64.

## Known limitations

- Vulkan loader probing only; no physical GPU/ICD was exposed on this host. No Vulkan render passes, swapchain, command buffer submission or compute dispatch are included.
- D3D12 and Metal require their native platform SDKs and implementations; this Linux build does not provide them.
- ONNX support is a deliberately limited CPU implementation, not the full ONNX Runtime. Only FLOAT tensors and the listed operators are handled; no Conv, recurrent operators, quantization, custom ops or GPU execution.
- Animation shaders are references only; not compiled or dispatched. No import pipeline for FBX/glTF is included.
- TCP/UDP transport is POSIX IPv4. It is not a complete multiplayer stack: no encryption/authentication, NAT traversal, retransmission for UDP, congestion control, session service, rollback or state replication.
- Studio preview is JSON/canvas inspection, not a full 3D editor or GPU renderer. Binary assets are catalogued but not decoded/imported.
- PlayStation/Xbox vendor SDKs, keys, devkits and certification access cannot be distributed or fabricated. The templates require a licensed vendor SDK installation and hardware validation by the authorized developer.
