# DOCMONT 8.70.0 ULTRA — Changelog

The public compiler/language version remains `8.70.0`; this package is the ULTRA game-systems expansion build on the existing 8.70.0 source.

## Added
- Native `docmont::game` SDK in `include/docmont/game_engine.hpp` and `src/game_engine.cpp`.
- Asset catalog with stable IDs, dependencies, asset state and dependency cycle detection.
- World partition grid with Active, SimulationOnly and Dormant tiers and transition budget.
- Fixed-step AABB rigid-body integration and collision resolution.
- Weighted deterministic four-neighbour A* navigation.
- Utility AI decision selection and BehaviorTree Sequence/Selector/Condition/Action nodes.
- Animation blend-weight validation/normalization foundation.
- Deterministic day clock and bounded weather configuration.
- Spatial audio gain calculation and priority-based voice budget selection.
- Versioned network transform snapshot codec with CRC32, stable ordering and strict input validation.
- Hardware capability-profile graphics API selection with explicit software fallback policy.
- Forward and Deferred RenderGraph pass planning.
- CPU reference Cook–Torrance GGX PBR shading and ACES tone mapping.
- Bounded frame metrics history and project configuration/asset validation.
- CLI commands `game-info` and `game-demo`, plus the `docmont_game_ultra_example` target.
- Automated ULTRA engine, sample and CLI tests.

## Preserved
- DOCMONT source-language compatibility `3.4.0`.
- DVM bytecode format `v1`.
- Previous compiler, SSA, DPM, JNI, Assembly and native-MIR foundations.

## Not added in this release
- Production Vulkan/D3D12/Metal devices or GPU compute backend.
- GLTF/FBX/audio importers, visual game editor or full asset hot-reload pipeline.
- Production-grade rigid body engine, navmesh/crowd stack, skeletal animation runtime, audio playback or network transport.
- ONNX inference, async/await source syntax, console SDK target or non-Linux native game-runtime package.
