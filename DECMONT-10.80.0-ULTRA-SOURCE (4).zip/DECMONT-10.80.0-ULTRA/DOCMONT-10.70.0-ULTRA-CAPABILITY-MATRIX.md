# DECMONT 10.70.0 — Capability Matrix

| Area | 10.70.0 status |
|---|---|
| DVM portable runtime | Available |
| Native C11 backend | Restricted supported-opcode subset |
| Native arrays | Supported within documented limits |
| Native heap registry | Available; process-lifetime ownership |
| Aggregate array payload budget | 64 MiB per generated process |
| Array capacity slots | 1,000,000 aggregate capacity slots |
| Registered array objects | 65,536 |
| Tracing garbage collector | Not implemented |
| Native object/function lowering | Not complete |
| Vulkan/D3D12/Metal production renderers | Not complete |
| General ONNX GPU provider | Not implemented |
| PS5/Xbox deployment | Requires official SDK and devkit; not validated here |
| Tested host | Linux x86_64 |
