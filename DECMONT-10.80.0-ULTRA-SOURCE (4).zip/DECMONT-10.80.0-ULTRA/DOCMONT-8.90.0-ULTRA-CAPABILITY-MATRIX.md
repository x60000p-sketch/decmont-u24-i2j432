# DOCMONT 8.90.0 ULTRA — Capability Matrix

Status labels: **Implemented & tested**, **Partial**, **Profile/template only**, **Not implemented**.

| Area | Status | Verified scope |
|---|---|---|
| Lexer/parser, semantic validation | Implemented & tested | DOCMONT language compatibility 3.4.0 |
| SSA / Memory SSA / optimizer | Implemented & tested | Existing tested compiler paths retained |
| Typed HIR / MIR | Partial | Source lowering and restricted direct LLVM subset |
| Portable DVM | Implemented & tested | DVM v1, project entry compilation and VM smoke run |
| Native LLVM | Partial | Restricted MIR subset; not a general game-code backend |
| Generics / Traits / Ownership | Partial | Existing limited compiler analysis documented in 8.60–8.80 matrices |
| Java/JNI and C FFI | Partial | Binding/toolchain path exists; not a universal runtime bridge |
| Project manifest | Implemented & tested | TOML `docmont.toml` |
| Project scaffolding | Implemented & tested | `docmont-project new` |
| Project validation | Implemented & tested | Manifest, source, scene JSON, path containment and stale asset hashes |
| Asset inventory | Implemented & tested | Classification, size and SHA-256; not full import/cooking |
| Project build | Implemented & tested | `.docm` → DVM v1 → verifier → smoke execution |
| Project packaging | Implemented & tested | Deterministic source/assets ZIP |
| DPM package resolver | Partial | Local dependency resolution; remote registry fetch not included |
| Studio project actions | Implemented & tested | Localhost UI: check, asset manifest, build and package |
| ECS / world cells | Partial | CPU-side host APIs and basic simulation tiers |
| Physics | Partial | Fixed-step CPU AABB rigid body reference |
| Graphics | Partial | Render-graph plan and CPU PBR/ACES reference |
| Vulkan | Probe only | Loader/device/queue capability probe; no production GPU renderer validated |
| Direct3D 12 / Metal | Profile/template only | Native backend not built in this Linux release |
| Skeletal animation | Partial | CPU keyframe sampling, blending and skinning |
| Neural AI | Partial | CPU-only ONNX operator subset; no GPU provider |
| Audio | Partial | Voice scheduling/spatial gain foundations; no full device playback pipeline |
| Networking | Partial | POSIX TCP/UDP transport and packet/snapshot utilities; no TLS/auth/NAT congestion layer |
| Console | Profile/template only | Manifest checks; licensed SDK/devkit and vendor approval required |
| Visual Game Studio | Partial | Project workspace, text editor, scene preview and project lifecycle; not full realtime 3D editor |
| x86_64 Linux | Implemented & tested | Release binary built and tested locally |
| Windows / macOS / Android / consoles | Not certified | Need per-platform toolchains, SDKs and real device/CI validation |

## 8.90.0 acceptance

- CMake Release build: passed.
- CTest: 72/72 passed.
- VS Code LSP: 8/8 passed.
- JavaScript check: passed.
- Install-prefix compiler/tool/Studio smoke test: passed.
- Project lifecycle end-to-end: passed.
- Deterministic project ZIP check: passed.
