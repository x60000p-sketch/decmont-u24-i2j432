# Animation and Network API Notes — DOCMONT 8.80.0 ULTRA

## Skeletal animation C++ API

Header: `include/docmont/skeletal_animation.hpp`

Core steps:

1. Add bones to `docmont::animation::Skeleton` in parent-before-child order.
2. Validate the hierarchy.
3. Build an `AnimationClip` with per-bone translation, quaternion rotation and scale keys.
4. Call `Animator::validate_clip` and `Animator::sample`.
5. Optionally blend two poses with `Animator::blend`.
6. Build matrices and skin vertices with four `BoneInfluence` indices/weights.

The runtime is a CPU reference implementation. Shader source under `shaders/` is a future GPU path and is not dispatched by this build.

## TCP

Use `TcpListener::bind_any(port)` for an all-IPv4 listener or `bind({"127.0.0.1", port})` for loopback. A client uses `TcpConnection::connect({host, port}, timeout)`. Frames are length-prefixed and CRC checked. TCP itself provides ordered reliable delivery.

## UDP

Use `UdpSocket::bind_any(port)` or bind a specific address, then `send_to({host, port}, sequence, payload)` and `receive(timeout)`. Sequence numbers let the application identify/reorder datagrams; UDP is still unreliable and the runtime does not retransmit or encrypt packets.

The network adapter currently targets POSIX IPv4. It is not yet a complete session/replication/rollback stack.
