# DECMONT 10.80.0 — Changelog

- Added bounded native object storage to the C11 source backend.
- Added lowering for NewObject, ObjectSet, ObjectGet and ObjectHas.
- Added property replacement, checked lookup, missing-property diagnostics and object property-count support through ArrayLength.
- Added per-process object registry and deterministic exit cleanup.
- Added aggregate object field-capacity accounting, field-count/object-count limits and safe growth checks.
- Added native object unit tests and Clang compile-link-run integration coverage.
- Updated CLI, CMake package version, VS Code metadata and release documentation to 10.80.0.
- Preserved language compatibility 3.4.0 and DVM bytecode compatibility.
