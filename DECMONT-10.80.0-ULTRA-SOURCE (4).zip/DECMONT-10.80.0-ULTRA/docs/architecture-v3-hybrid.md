# DOCMONT — Hybrid Architecture Blueprint

**Architecture revision:** 3.0 (design baseline)  
**Implementation baseline:** 2.3.0  
**Status:** Architecture specification; not a claim that every subsystem is implemented.

## 1. Product identity

DOCMONT is a **hybrid programming platform** with two execution paths sharing one language front-end and one typed intermediate representation (IR):

- **Native:** compile to target object code, then link an executable or library.
- **VM:** compile to portable DOCMONT bytecode and execute it in a managed virtual machine.

Both paths must preserve identical language semantics. One source language, one type model, one verified IR contract, multiple backends.

## 2. Layered architecture

```mermaid
flowchart TD
  SRC[".docm source"] --> LEX["DLEX: lexer"]
  LEX --> GRAM["DGRAM: parser"]
  GRAM --> AST["AST + source map"]
  AST --> SEM["DSEM: scopes and types"]
  SEM --> LOGIC["DLOGIC: contracts and effects"]
  LOGIC --> TIR["Typed DOCMONT IR"]
  TIR --> VERIFY["IR verifier + optimizer"]
  VERIFY --> SELECT{"Execution target"}
  SELECT --> NATIVE["Native backend"]
  SELECT --> BYTE["Bytecode backend"]
  NATIVE --> OBJ["Object files"]
  OBJ --> LINK["Platform linker"]
  LINK --> EXE["Native executable/library"]
  BYTE --> VM["DVM runtime"]
  EXE --> SYS["Capability-gated platform services"]
  VM --> SYS
```

| Layer | Responsibility | Output |
|---|---|---|
| DLEX | Tokens, spans, escapes, identifier normalization | Token stream |
| DGRAM | Grammar, precedence, declarations, recovery | AST |
| DSEM | Symbol tables, scopes, types, imports, overloads | Typed AST |
| DLOGIC | Contracts, invariants, effects and capability checks | Verified semantic model |
| DIR | Typed operations, control flow and serialization | Versioned IR |
| DOPT | Verified optimization with source/debug mapping | Optimized IR |
| DCC | Native instruction selection and object emission | Object file |
| DBC | Portable bytecode encoding and metadata | `.dcb` |
| DVM | Bytecode verification, execution, memory and exceptions | Runtime behavior |
| Platform layer | Files, sockets, clocks, threads, graphics and OS APIs | Permission-gated services |

## 3. Canonical module contracts

### Compiler and execution core
- **DCORE:** compiler context, configuration, module registry and stable interfaces.
- **DLEX:** lexical analysis and identifier decomposition; never guesses semantics from a word's appearance.
- **DGRAM:** versioned grammar and parser with source-span diagnostics.
- **DSEM:** symbol tables, lexical scopes, type system, imports, function signatures and overload resolution.
- **DLOGIC:** contracts, invariants, effect rules and static validation.
- **DIR:** typed intermediate representation, verifier and serialization.
- **DOPT:** ordered optimization passes with validity checks and source mapping.
- **DVM:** portable bytecode virtual machine.
- **DABI:** foreign-function interface and calling-convention definitions.
- **DCC:** native code-generation and object-emission interface.

### Domain and platform modules
- **SELKON:** algorithms, numeric primitives and compute kernels.
- **PINMACK:** input abstraction and network I/O APIs.
- **SEKROD:** binary data model, byte inspection and educational micro-operation simulation.
- **SEVALOD:** executable/package loading with signature, format and permission checks.
- **DEMODELS:** UI, scene graph and rendering abstractions.
- **SICER:** transparent system telemetry and diagnostics, subject to OS permissions.
- **SAVEMODLAN:** storage APIs, serialization and migrations.
- **SIER:** network inspection and diagnostics for networks the operator may assess.
- **SOMPA:** capability and permission policy engine.
- **SEVA_EDIT:** project and configuration transformation tools.
- **SAVE_DAT_PLONT:** data persistence workflows and schema mapping.
- **COMA:** numerical and physical simulation libraries.
- **LIGHT / SHADOW / UPLAST:** rendering, lighting, materials and shadows.
- **SYSCAILL_O:** platform entry points and host integration.

Domain modules depend on DCORE/DIR/platform contracts. The compiler core must not depend on a particular game engine or operating system. These are planned contracts, not claims that modules are already implemented.

## 4. Hybrid execution contract

### Native mode
Example future command:
`docmont build --backend=native --target=x86_64-unknown-linux-gnu`

Pipeline: parse/type-check → typed IR → IR verification → deterministic optimization → target selection → object/debug emission → link against explicit SDK/sysroot → executable/library plus build manifest.

Initial target order: x86-64 Linux, x86-64 Windows, AArch64 Linux, AArch64 Android (NDK), then Apple targets after toolchain and CI support are demonstrated.

### VM mode
Example future command: `docmont build --backend=vm`.

Produces versioned `.dcb` bytecode. DVM must validate magic/version/section bounds/opcodes, verify operand types and control-flow joins, enforce memory/fuel/time/capability limits, map exceptions to source locations, and reject unknown bytecode versions.

### Semantic parity
The language specification must define overflow, division, string encoding, evaluation order, exceptions, memory visibility and concurrency. VM and native backends must pass the same conformance suite.

## 5. Type and memory model

Initial type families: `bool`; signed/unsigned 8/16/32/64-bit integers; `f32`/`f64`; `string`; `bytes`; arrays, tuples, records, enums, optional/result types, function and user-defined types.

Memory modes:
- **Managed:** VM-owned allocation and collection/reference management.
- **Native-safe:** explicit ownership/borrowing rules and checked APIs.
- **Interop:** unsafe/foreign boundary isolated behind declared ABI contracts.

Unrestricted pointers or kernel access are not default language capabilities.

## 6. Security and trust model

SOMPA capabilities include scoped `fs.read`, `fs.write`, `net.connect`, allow-listed `process.spawn`, `graphics.device` and `compute.device`. Default is deny. Packages declare permissions; VM execution is sandboxed; packages are signed and hash-verified; dependencies are locked and provenance recorded. No covert persistence, hidden execution or security-tool evasion. Kernel drivers require documented OS interfaces, signing and administrator authorization.

Privacy means local-first storage, data minimization, encryption and transparent telemetry controls.

## 7. Artifact formats

| Extension | Purpose | Status |
|---|---|---|
| `.docm` | UTF-8 source | Current |
| `.dcb` | Portable bytecode | Planned |
| `.dco` | Native object/container metadata | Planned |
| `.docir` | Versioned textual IR | Planned |
| `.docast` | AST interchange | Planned |
| `.docpkg` | Signed package, manifest and dependencies | Planned |
| `.docdbg` | Debug/source mapping | Planned |

Binary formats require magic bytes, version, endianness rules, length limits, integrity checks and compatibility policy.

## 8. Nine technology integration policy

- C++: compiler, IR, optimizer and VM implementation.
- C: stable host ABI and native interoperability.
- Assembly: narrowly scoped target-specific ABI stubs and backend tests.
- Rust: memory-safe platform/protocol components through explicit FFI.
- C#: IDE, project manager and debugger front-end.
- Java: JVM interoperability and tooling; not a mandatory compiler dependency.
- JavaScript: editor services, visualizers and web tooling.
- JSON: manifests, schemas and machine-readable configuration.
- Hex: binary inspection/debug representation, not a programming language.

An adapter counts as implemented only when it has a working interface, integration test, version policy and documented limitations.

## 9. Release and quality gates

Required: compiler unit tests; shared VM/native conformance tests; parser and bytecode-reader fuzzing; ASan/UBSan where supported; pinned dependencies; reproducible builds; ABI tests; measured benchmarks; signed artifacts, checksums, SBOM and release notes. A platform is not supported until CI actually passes on a named runner/toolchain and a target smoke test is recorded.

## 10. Phased implementation

1. **Language completeness:** functions, scopes, control flow, modules/imports and diagnostics.
2. **Typed IR:** basic blocks, control-flow graph, typed operations, verifier, serialization and source maps.
3. **DVM:** bytecode format, verifier, interpreter, memory policy, exceptions, fuel limits and conformance suite.
4. **Native backend:** evaluate/pin LLVM as the first route; start x86-64 Linux, add targets only with CI evidence.
5. **Standard library/platform APIs:** filesystem, process, networking, concurrency, storage, cryptography and graphics with capability enforcement.
6. **Developer ecosystem:** package manager, language server, debugger, formatter and documentation generator.
7. **Domain engines:** DEMODELS, COMA, LIGHT/SHADOW/UPLAST, circuit simulation and authorized network diagnostics.

## 11. Acceptance criteria

- Same `.docm` program has equivalent observable behavior in VM and native modes.
- Bytecode is verified before execution.
- Native targets are explicit and toolchain-backed.
- Every system API is capability-gated.
- Unsupported features fail with actionable diagnostics.
- Claimed adapters have integration tests.
- CI evidence exists for every claimed supported platform.
