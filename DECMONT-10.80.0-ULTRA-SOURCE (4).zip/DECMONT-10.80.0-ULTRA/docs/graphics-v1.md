# DOCMONT Software Graphics v1

The first graphics module is a headless CPU rasterizer. It supports RGB pixel storage, clipped pixel writes, filled rectangles, Bresenham lines, midpoint circles and binary PPM export. It is useful for deterministic rendering tests and as a base for a future renderer.

It does not yet provide a window, input system, GPU acceleration, Vulkan/OpenGL/Direct3D, textures, sprites, fonts, audio, animation, scene graphs, physics or a full game loop.
