# DOCMONT 5.20.0 — DVM Function Control-Flow Verification

DOCMONT 5.20.0 extends bytecode verification to analyze the top-level instruction stream and every declared function body independently.

## Verification rules

- Each function analysis begins with its declared argument count on the operand stack.
- Every reachable path must maintain a consistent stack depth at control-flow merge points.
- A function return must have exactly one result value on the operand stack.
- Function bodies may not jump outside their own instruction region.
- Reachable fallthrough from a function body is rejected.
- The top-level program must finish with an empty operand stack.

This is static bytecode validation; it does not add closures, lambda lowering, garbage collection, or native backend parity.
