# DOCMONT Native Source Backend v1

Command:

```sh
docmont native-c examples/arithmetic.docm build/program.c
cc -std=c11 -O2 build/program.c -o build/program
./build/program
```

The backend lowers the current linear stack IR to portable C11 statements and a small checked arithmetic helper. The host C compiler then emits the platform-native executable for its configured target.

This is a functioning C-source ahead-of-time path. It is not a direct x86-64/AArch64 machine-code emitter, LLVM backend, JIT, linker or cross-platform SDK toolchain. The output inherits the target and ABI of the C compiler used to compile it.
