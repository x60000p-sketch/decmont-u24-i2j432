# Nine-technology integration plan

- **C++20:** primary compiler/runtime implementation.
- **C:** stable C ABI for plugins, OS adapters and embedded integrations.
- **Assembly:** ABI bridges, context-switch experiments in controlled environments, instruction tests.
- **C#:** desktop IDE, project explorer, debugger and build orchestration.
- **JSON:** project manifests, package metadata, schema validation and tool interchange.
- **JavaScript:** editor services, syntax highlighting, AST/IR visualizations and web tooling.
- **Java:** JVM bridge and build/test integrations.
- **Rust:** safe binary parsers, device protocol modules and selected runtime components.
- **Hex:** byte-level representation, disassembly fixtures and object inspection. It is not a programming language.

Each adapter must have a documented API, versioning and conformance tests. A repository containing adapter folders is not equivalent to having all adapters implemented.
