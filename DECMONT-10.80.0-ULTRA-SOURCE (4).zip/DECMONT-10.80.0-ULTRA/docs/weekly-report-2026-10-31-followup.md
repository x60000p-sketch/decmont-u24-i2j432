# DOCMONT 2.1.0 — Engineering follow-up (2026-10-31)

## Implemented in this increment
- Added semantic duplicate-block detection at application scope.
- Added duplicate-property detection inside each block.
- Added strict allowed-property validation for the implemented `memory` and `compute` blocks.
- Added validation for optional `memory.bounds` (`enforced` or `unbounded`), preserving the existing `hello.docm` example.
- Added regression assertions for duplicate blocks, duplicate properties, unknown properties, and invalid bounds.
- Updated project version to 2.1.0 and documented the implemented subset.

## Verification
- CMake configure: passed.
- C++ build: passed.
- CTest: 1/1 test executable passed; its assertions cover the positive and negative semantic cases.
- `docmont check examples/hello.docm`: passed.
- `docmont run examples/hello.docm`: printed `DOCMONT NATIVE ENGINE`.
- `docmont ir examples/hello.docm`: emitted the expected minimal IR module and x86_64 target.

## Boundaries
This is a semantic-validation increment, not a complete language. The parser still accepts scalar property values rather than typed expressions. There is no full symbol table, user-defined functions/types, nested lexical scopes, advanced semantic graph, native code generation, LLVM backend, graphics engine, Android backend, or real adapters for all nine technologies.

## Next engineering priority
Implement expression AST nodes and precedence parsing for numeric/string literals and `+`, then add a typed IR value model. Do this before claiming general-purpose DSEM or native compilation.
