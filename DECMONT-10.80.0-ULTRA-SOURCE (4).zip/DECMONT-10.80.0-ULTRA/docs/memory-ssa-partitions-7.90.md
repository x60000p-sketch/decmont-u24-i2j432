# DOCMONT 7.90.0 — Partitioned Memory SSA

## Concrete partitions

DOCMONT now tracks two independent memory-version chains:

- `HeapAggregate`: arrays, objects, and aggregate heap allocations.
- `ClosureCell`: captured-variable cell reads (`LoadCell`).

Every `SSAMemoryDefinition`, `SSAMemoryUse`, and `SSAMemoryPhi` carries an explicit `SSAAliasRegion`. Version identifiers are unique across the complete SSA program, while each version belongs to exactly one concrete partition. Version `0` is the entry state for either partition.

## Unknown effects

An unknown or indirect call is modeled as reading and writing both concrete partitions. The abstract `Unknown` alias bit is not made into a third disjoint memory chain; it widens an access to every concrete partition. Missing alias metadata also fails closed and is treated as touching both.

## Verification

The SSA verifier checks:

- definitions and uses are attached to a concrete partition;
- instruction/partition use and definition pairs are unique;
- a definition's region matches the alias mask of its instruction;
- a use references a version from the same region;
- Memory Phi nodes have complete reachable predecessor edges and same-partition inputs;
- non-entry versions dominate their uses and are available on Phi predecessor edges;
- every reachable memory operation has one use per affected partition and every write has one definition per affected partition.

## Optimizer integration

The alias-aware memory-read CSE pass now requires a valid heap Memory SSA use for each candidate memory read before it applies the allocation-site and field/index checks. Existing site-level invalidation continues to preserve disjoint-object opportunities while invalidating same-object writes and unknown effects conservatively.

## Deliberate limits

The partitions are still coarse: all arrays and objects share `HeapAggregate`; named object fields and array elements are not separate Memory SSA partitions. `ClosureCell` is read-only in the current bytecode opcode model; there is no distinct captured-cell write opcode represented here. Unknown calls update both partitions. This release does not add heap-store dead-store elimination, CFG-wide memory-read CSE, per-field/per-element Memory SSA, or a complete interprocedural mod/ref solver. The existing optimization pass stays block-local and only uses singleton allocation-site facts for eligible reads.
