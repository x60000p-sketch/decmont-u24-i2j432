# VLOTDEVICEMANT — Hybrid Engine Foundation (DOCMONT 3.3.0)

VLOTDEVICEMANT is a separately layered engine integrated with DOCMONT through public C++ interfaces. The language/compiler remains responsible for source semantics and program compilation; VLOT owns project configuration, device profiles, scene validation, asset descriptors, renderer selection and target build planning.

## Implemented in this increment

- `ProjectConfig` and a strict `VLOT 1` line-oriented project descriptor loader.
- Target profiles for PC, Android and PS5.
- Toolchain-aware build planning. PC is marked planned when a host C compiler is available because VLOT project-to-artifact orchestration is not implemented yet. Android requires both SDK and NDK. PS5 is blocked unless an authorized SDK is reported; even then the plan requires vendor-specific build and hardware validation.
- Scene graph validation for duplicate IDs, missing parents, invalid transforms and parent cycles.
- Asset descriptor validation that rejects absolute paths and traversal components.
- A deterministic CPU triangle rasterizer with barycentric color interpolation and a depth buffer, plus rectangle and PPM output.
- CLI commands `vlot inspect`, `vlot plan` and `vlot-render-demo`.

## Project descriptor

```ini
VLOT 1
name = "VLOT_SAMPLE_GAME"
targets = pc, android, ps5
renderer = auto
quality = high
assets = assets
```

Run:

```sh
docmont vlot inspect projects/vlot-sample/project.vlot
docmont vlot plan projects/vlot-sample/project.vlot
docmont vlot-render-demo build/vlot-demo.ppm
```

## Platform truth table

| Target | Current integration | What remains |
|---|---|---|
| PC | Host C11 backend build plan and CPU software renderer | Direct GPU backend (Vulkan/DirectX), platform packaging and broad device tests |
| Android | Gradle/NDK/JNI scaffold; VLOT source is included in Android CMake target | SDK/NDK build, APK install, GPU surface/swapchain and device validation |
| PS5 | Target profile and gated build-plan entry only | Authorized Sony developer access, official SDK, signing, platform adapter and hardware validation |

A `PLANNED` state means the platform is identified but VLOT build orchestration or its platform adapter is incomplete. `REQUIRES_TOOLCHAIN` means SDK/compiler prerequisites are missing. `BLOCKED` means a required authorized platform SDK is unavailable. No state claims an artifact was built, signed, installed or certified.

## Renderer status

The software renderer is a CPU rasterization reference backend. It is useful for deterministic tests, headless previews and validating scene/render command behavior. It is not a Vulkan, DirectX 12, OpenGL ES or production 3D renderer. The `renderer` field currently expresses project intent and validation, not a GPU backend that has already been linked.

## Safety and deployment

The build planner does not bypass platform security, console signing, sandboxing or vendor SDK requirements. Device discovery and future deployment actions must use explicit developer authorization and documented platform APIs.
