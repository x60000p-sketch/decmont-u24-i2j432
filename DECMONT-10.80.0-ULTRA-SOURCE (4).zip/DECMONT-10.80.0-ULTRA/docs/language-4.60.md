# DOCMONT 4.60.0 — Closures and Lambda Expressions

DOCMONT 4.60.0 adds anonymous function expressions to the `.docm` AST interpreter.

## Syntax

```docmont
let factor = 4
let scale = fn(value: Int): Int {
  return value * factor
}
output = scale(6)
```

Lambda parameters require explicit types. Optional parameters may use defaults and follow the same trailing-default rule as named functions. Lambda values can be stored in local variables and invoked by variable name. `type(lambdaValue)` returns `function`.

## Capture model and limits

- A lambda captures the current lexical environment when the lambda expression is evaluated.
- Captured scalar values are copied into the closure environment.
- Arrays and objects are reference-backed runtime values, so their underlying containers remain shared.
- Calls use the existing interpreter recursion and execution-step limits.
- The current invocation syntax supports a named variable holding a lambda, e.g. `handler(x)`. Arbitrary callee expressions, returned/nested closure pipelines, recursive closures, and mutable lexical cells are not yet supported.
- Closures and lambda expressions are currently AST-interpreter features. DVM bytecode serialization/verifier and Native-C backend do not yet encode or execute closure values.
- Static semantic checking recognizes lambda values as functions and validates the current basic call shape conservatively; it is not a complete higher-order type system.
