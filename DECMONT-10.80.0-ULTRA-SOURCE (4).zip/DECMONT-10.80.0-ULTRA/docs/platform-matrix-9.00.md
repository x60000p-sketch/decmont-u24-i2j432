# DOCMONT 9.00.0 platform matrix

| Target | Build path | State in this release |
|---|---|---|
| Linux x86_64 | native CMake Release | Built and tested |
| Windows x64 | `windows-msvc-release` | Preset; requires Windows + VS 2022 |
| macOS Universal | `macos-universal-release` | Preset; requires macOS + Xcode |
| Android arm64-v8a | `android-arm64-release` | Preset/toolchain wrapper; requires Android NDK |
| PS5 | `docmont-console-build ps5 ...` | Official SDK adapter; local licensed SDK required; no SDK/devkit in this build environment |
| Xbox Series | `docmont-console-build xbox ...` | Official GDK adapter; local licensed GDK required; no SDK/devkit in this build environment |
| Vulkan | dynamic loader/device/queue probe + shader compiler driver | no ICD/device exposed in this build environment; full renderer is not claimed |
| D3D12 | native device/direct queue probe | gated Windows source; not built on Linux |
| Metal | native device/command queue probe | gated Apple Objective-C++ source; not built on Linux |

Sony SDKs are not redistributed. A user-provided `.dcsdk` manifest points to the SDK-root-contained compiler, linker (optional), include directory, and official CMake toolchain. `docmont-console-build` validates those paths, requires explicit license acknowledgement and invokes CMake with that exact toolchain. Vendor signing, packaging, deployment, and certification remain vendor-controlled.
