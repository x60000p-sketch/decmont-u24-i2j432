# DOCMONT 5.40.0 — DVM non-capturing lambda functions

DOCMONT 5.40.0 lowers lambda expressions (`fn(...) { ... }`) into synthetic DVM
function entries. The lambda expression produces a normal DVM function value;
calling the variable uses the existing indirect-call path and its arity/frame
checks. Lambda bodies are included in the bytecode function table and pass the
same bytecode verifier as named functions.

Example: `examples/language_5_40.docm`.

## Current boundary

This release supports **non-capturing** lambdas. It does not implement lexical
closure environments or capture-by-value/reference. A lambda that references a
name outside its parameters may resolve only through the VM's existing global
frame behavior; that is not a lexical closure guarantee. Nested lambdas are
lowered as separate synthetic functions. Default lambda parameters and native-C
lambda lowering are not included.
