# DOCMONT Language 4.40.0

## Implemented in this milestone

DOCMONT 4.40.0 extends the independent `.docm` language surface with mutable object properties and a small set of runtime introspection built-ins.

### Object property assignment

```docmont
let person = object { name = "Ada", age = 37 }
person.age = 38
output = person.age
```

A property assignment evaluates the right-hand expression, resolves the object expression on the left, and inserts or replaces the named property. The current assignment grammar supports a simple identifier followed by one or more dot-separated member names; nested member writes are parsed, while the interpreter currently commits the final property against the resolved parent object.

### Built-ins

- `len(value)`: returns the element count for arrays, property count for objects, or byte length for strings.
- `type(value)`: returns `integer`, `boolean`, `string`, `array`, or `object`.
- `has(object, name)`: tests whether an object has a string-named property.
- `keys(object)`: returns an array of property names in deterministic map order.
- `print(...)`: existing output helper remains available.

## Compatibility

The compiler reports DOCMONT 4.40.0 and preserves the existing language compatibility marker 3.4.0. Existing parser, interpreter, VM, heap, object-runtime and LSP tests remain in the test suite.

## Explicit limitations

This is a language expansion milestone, not a claim that every feature of a modern general-purpose language is complete. In particular, this release does not yet implement class declarations, inheritance, constructors, closures, modules with linked import resolution, exceptions, async/await, generics, a complete static type system, garbage collection, or full native-backend coverage for all VM opcodes. The new built-ins are currently interpreter capabilities; they are not yet uniformly lowered to DVM bytecode or native code.
