# DOCMONT 4.4.0 — Engine Core

## Scope

DOCMONT 4.4.0 is a compatibility-preserving C++ engine-library increment. It retains the DOCMONT 3.4.0 language grammar/runtime and all 4.3.0 math APIs. It does not add new `.docm` syntax.

## Implemented

- Generation-checked entity handles. Destroyed entities invalidate old handles, including after index reuse.
- Typed component pools with `emplace`, `get`, `has`, `remove`, and `view<T...>` operations.
- Registry destruction removes all components belonging to the entity.
- Transform scene graph with local position/scale matrices, parent assignment, parent removal, and hierarchical world-matrix resolution.
- Reparenting rejects invalid nodes, self-parenting, and cycles.
- Capacity checks for entity and scene-node identifiers.
- 4.3.0 vector/matrix APIs and existing VLOT functionality retained.

## Public C++ API

Include `docmont/engine.hpp` and use `docmont::engine::Registry`, `Entity`, `Transform`, and `SceneGraph`.

```cpp
struct Position { float x, y, z; };
docmont::engine::Registry world;
auto entity = world.create();
world.emplace<Position>(entity, Position{1, 2, 3});
for (auto e : world.view<Position>()) {
    auto* position = world.get<Position>(e);
    // update simulation state
}

docmont::engine::SceneGraph scene;
auto root = scene.create({{10, 0, 0}, {2, 2, 2}});
auto child = scene.create({{1, 0, 0}, {1, 1, 1}});
scene.set_parent(child, root);
auto world_matrix = scene.world_matrix(child);
```

## Explicit limitations

- ECS component pools use host-side `unordered_map` storage; this is not yet a cache-optimized sparse-set/chunk archetype implementation.
- `view<T...>` currently scans alive entity slots; it is correct but not an optimized query planner.
- Transform currently supports position and scale only; rotation, quaternion interpolation, and transform decomposition are not implemented.
- Scene graph nodes are append-only in this increment; node destruction and stable external handles are future work.
- No GPU backend, render graph, PBR pipeline, skeletal animation, or console SDK backend is added by this release.
- Engine interfaces are C++ APIs, not new DOCMONT language constructs.

## Validation

The release test suite covers component lifecycle, multi-component views, stale handle rejection, entity slot reuse, parent-child transform composition, cycle rejection, and invalid node handling, alongside all retained 4.3.0 tests.
