# DOCMONT 4.2.0 release report

## Scope

4.2.0 is a compatibility-preserving compiler tooling increment. The DOCMONT 3.4.0 source grammar, AST, interpreter, DVM bytecode, C11 source backend and VLOT host-side behavior remain unchanged.

## Implemented

- Versioned machine-readable diagnostics schema (`version: 4.2.0`).
- Stable diagnostic identifiers for lexical, parser and semantic diagnostic families (`DLEX*`, `DPAR*`, `DSEM*`, `DDOC*`).
- End positions (`endLine`, `endColumn`) derived from the actual source line, with safe clamping for end-of-line and out-of-range locations.
- VS Code LSP maps diagnostic identifiers and end positions into native LSP diagnostic objects; older compiler output remains supported as fallback.
- Project manifest, CMake project version, compiler `--version`, `language-info.compilerVersion`, extension package and server version advanced.

## Compatibility and limits

- Source language compatibility remains 3.4.0. No new language syntax, functions, modules, loops, comparison operators, or GPU backends are claimed.
- Diagnostic identifiers are stable public categories for 4.2.0. They classify existing diagnostics; they do not yet provide parser-native token spans for every recovery case.
- End positions are best-effort token spans inferred from source text at the diagnostic start. Multiline ranges and exact AST/token provenance are not yet implemented.
- LSP cross-file symbols remain unavailable because the language has no import/module declarations.
- VS Code GUI/Extension Development Host testing requires VS Code and is not represented by Node LSP integration tests.

## Verification

Run a clean CMake Release configure/build, `ctest --output-on-failure`, `npm run check`, and `npm test`. The CLI contract test includes a negative semantic case that checks stable code and end position fields.
