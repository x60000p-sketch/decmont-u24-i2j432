# Per-Function SSA and Memory Effects — DOCMONT 7.30.0

## Analysis regions

The top-level `ProgramIR` is analyzed as before. Each `Function` marker also defines a separate region through the instruction immediately preceding the next function marker (or end of program). The region records its original absolute range, name and arity. A sliced body remaps in-range branches to local instruction indexes and prevents branches from escaping the function region.

The function's declared arity seeds its entry operand stack with symbolic argument values. The ordinary SSA builder then computes a function-local CFG, dominators, variable SSA, operand-stack Value SSA and Memory SSA. Each nested analysis is independently verifiable.

## Memory token model

DOCMONT 7.30.0 uses one unified memory token for managed heap and closure-cell effects. `m0` is the incoming state. Every modeled write creates a new token; each memory read or write records the token it observes. A reachable CFG join with more than one predecessor receives a Memory Phi node, whose incoming values are the predecessor exit tokens.

Current classification:

| Operation family | Effect |
|---|---|
| `LoadCell`, array/object reads | Read |
| Array/object mutation | Read + write |
| Object/array/closure construction | Write |
| Direct/indirect calls in memory SSA | Unknown |

This is intentionally conservative. It does not distinguish individual objects, array regions, object fields or alias sets.

## Function effect summaries

Named direct calls contribute call-graph edges. A fixed-point pass propagates `may_read_memory`, `may_write_memory` and `has_unknown_effects` flags from callees to callers. Indirect calls and unresolved direct targets are unknown. The summaries are available in `docmont ssa` output and are verified as part of the function analysis contract.

These summaries are descriptive metadata in this release. They are not yet used to reorder, eliminate or specialize calls or memory operations.

## Verification

`verify_ssa` checks each function marker, range and arity; then validates its nested SSA graph. Memory checks include unique nonzero definition IDs, instruction/block correspondence, valid use versions, dominance and Memory Phi predecessor coverage.

Run:

```sh
docmont ssa examples/hello.docm
docmont ssa-verify examples/hello.docm
```

## Non-goals

This implementation is not alias analysis, Memory SSA partitioned by object, escape analysis, a full mod/ref engine, interprocedural GVN or memory DCE. SSA remains an analysis view; executable IR and bytecode are unchanged.
