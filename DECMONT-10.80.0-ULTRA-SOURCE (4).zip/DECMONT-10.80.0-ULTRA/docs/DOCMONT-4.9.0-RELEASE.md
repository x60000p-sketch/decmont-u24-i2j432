# DOCMONT 4.9.0 — Module Resolution Foundation

## Implemented
- Added a filesystem-backed module import resolver for line-oriented `import dotted.name` declarations.
- Maps dotted module names to paths under a configured module root (`decom.math` -> `decom/math.docm`).
- Resolves dependencies in post-order and detects missing modules, invalid module names, unreadable source files, and cyclic imports.
- Added integration tests for successful resolution, missing modules, and cycles.
- Bumped the CMake project version to 4.9.0.

## Current import syntax
```docmont
module app
import decom.math
```

## Important boundary
This release adds a resolver foundation, not complete language-level module semantics. The existing lexer/parser do not yet produce module/import AST nodes; imported declarations are not merged into semantic scopes, DECOM functions are not linked through this resolver, and package manifests, caching, dynamic loading, JIT, GC and WASM remain future work. The resolver currently recognizes imports as standalone source lines and uses `.docm` files beneath the supplied module root.
