# Value SSA in DOCMONT 7.20.0

DOCMONT 7.20.0 supplements named-variable SSA with a value graph for the operand stack.

## Public data model

- `SSAValueDefinition`: a stable value ID, defining instruction and block, opcode, immediate/text payload, optional variable version, and operand value IDs.
- `SSAValueUse`: the consuming instruction, value ID and operand index.
- `SSAValuePhi`: CFG block, stack slot, result value ID and `(predecessor block, incoming value ID)` edges.
- `SSAProgram::stack_ssa_valid` and `stack_ssa_errors`: stack analysis status and diagnostics.

## Construction model

The builder first propagates stack heights across reachable CFG edges. A height mismatch at a join or an operand-stack underflow makes stack SSA invalid. It then assigns definitions to stack-producing instructions and records value dependencies. At multi-predecessor blocks, incoming values are represented by stack Phi nodes, whose edge operands are filled from predecessor exit states.

The representation is analysis-only; bytecode and executable IR formats remain unchanged.

## Verification

`verify_ssa` checks value IDs, defining instructions, use references, operand-use correspondence, dominance, stack-phi predecessor coverage and edge availability. The CLI exposes the result through `docmont ssa-verify <file.docm>`.

## Current boundary

This pass analyzes the entry-reachable top-level region. Function bodies need independent entry-depth and CFG analysis in a later release. Heap mutations are represented as uses/effectful operations, not as Memory SSA versions.
