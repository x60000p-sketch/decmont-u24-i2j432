# DOCMONT 9.00.0 — Release Engineering

## New in 9.00.0

- ONNX CPU inference expanded from 9 to 23 documented operators, including broadcast Sub/Div/Pow/Min/Max, Flatten, Transpose, ReduceMean, Concat, Clip, LeakyRelu, Elu, Softplus and HardSigmoid.
- `docmont-native-build` links a native Linux x86_64 executable from the verified direct-MIR backend subset, and emits target object files for supported cross targets. Unsupported source constructs are rejected by the compiler.
- `docmont-console-build` validates a local licensed PS5/Xbox SDK manifest and calls the vendor's CMake toolchain to configure/build an existing vendor-compatible CMake project. It does not sign, package, deploy, or certify console binaries.
- Windows D3D12 and Apple Metal build variants now perform native device and command-queue initialization probes. Linux still reports them as unsupported.
- `docmont-shader-build` routes GLSL/HLSL/Metal shader sources to glslc/glslangValidator, DXC, or Xcode `metal`, respectively. It validates generated artifacts.
- CMake presets added for Windows MSVC, macOS Universal, and Android arm64 NDK.

## Verified in the release environment

- Linux x86_64 Release build.
- ONNX operator tests with generated protobuf models.
- Native x86_64 executable link/run (exit status 42) and AArch64 object generation.
- Console SDK adapter manifest validation and CMake configure/build command dispatch using a test fixture (not a real vendor SDK).
- Shader tool command construction and output validation using a test compiler fixture (not real shader compilation).

## Not certified in this environment

- No Sony/Microsoft SDK or devkit is mounted here; no console target build/deployment/signing was run.
- No Vulkan ICD or GPU device is exposed in the environment; Vulkan instance/device initialization is availability-dependent. D3D12 and Metal native source files are gated to Windows/macOS and are not built on Linux.
- No Android NDK, Windows MSVC environment or Apple Xcode SDK is present. Their presets are configuration entry points, not tested artifacts.
- ONNX supports FLOAT tensors and the listed operator subset, not the full ONNX specification or GPU providers.
- Native object/executable generation remains limited to the direct LLVM MIR integer subset.
