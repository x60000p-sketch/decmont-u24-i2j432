# DOCMONT Architecture Decision Records

## ADR-001 — Hybrid identity
**Status:** Accepted. DOCMONT combines high-level programming and controlled low-level interoperability in one language/type model. This requires explicit safe/unsafe boundaries, ownership, ABI and capabilities.

## ADR-002 — Native + VM execution
**Status:** Accepted. Both backends consume one verified typed IR. A shared conformance suite enforces semantic parity; bytecode is versioned and verified.

## ADR-003 — Explicit targets and ABI
**Status:** Accepted. Each native build specifies architecture, OS, ABI and toolchain/sysroot. Support claims require build, runtime and CI evidence.

## ADR-004 — Capability-based access
**Status:** Accepted. Filesystem, network, process, graphics and device access require explicit capabilities. Default policy is deny.

## ADR-005 — Shared typed IR
**Status:** Accepted. VM and native backends consume common typed IR with source maps and verifier rules. IR versioning and validation are foundational.
