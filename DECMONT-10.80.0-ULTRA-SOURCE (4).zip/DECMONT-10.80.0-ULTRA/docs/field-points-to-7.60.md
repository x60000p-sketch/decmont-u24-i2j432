# DOCMONT 7.60.0 — Field-sensitive and interprocedural points-to foundations

## Implemented

- Field-sensitive object-property slots keyed by `(allocation-site, static-field-name)`.
- `ObjectSet` propagates the assigned value's allocation-site and symbolic parameter provenance into each known base allocation's field slot.
- `ObjectGet` propagates matching field provenance to the result SSA value.
- Phi nodes merge both allocation-site and symbolic function-parameter origins.
- Function return summaries record argument indices, returned allocation sites, and an explicit unknown bit. Direct top-level `Call` result sets substitute returned argument origins with the caller's actual SSA operands.
- Factory-style returns translate the callee-local allocation instruction index back to the source program's absolute IR index.
- Unknown bases and dynamic/unnamed field writes fail closed and remain conservative.
- The SSA verifier checks field-slot uniqueness, allocation references, sorted/unique field provenance, and function return summary bounds.

## Deliberate limitations

This is a flow-insensitive, allocation-site abstraction for statically named object properties. It is not a full heap graph or a context-sensitive solver. Dynamic property names, array element indices, loads from variables/cells, indirect calls, and calls nested inside analyzed function bodies may remain unknown. Function return substitution is currently applied to direct call sites in the root program; it is not a full recursive/context-sensitive interprocedural fixed point. No optimizer transformation consumes these results yet. There is no full Andersen/Steensgaard solver, escape analysis, object-layout-aware field typing, or field-partitioned Memory SSA. Runtime semantics and bytecode encoding are unchanged.

## Compatibility

Compiler release: 7.60.0. Language compatibility: 3.4.0.
