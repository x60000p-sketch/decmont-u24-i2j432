# DOCMONT 4.90.0 — DVM function calls and call frames

DOCMONT 4.90 adds first-class function entry/call/return operations to the DVM instruction stream.

## Supported subset

- Named functions declared with `fn name(parameter: Type, ...): ReturnType { ... }`.
- Positional arguments and exact arity validation at runtime.
- Function-local variable frames; global variables are readable as fallback from function frames.
- Nested calls and recursive calls, bounded to 1,024 active frames.
- Explicit `return expression`; implicit fall-through returns integer zero.
- DVM bytecode encode, verify, decode, and execute for these operations.

## Example

```docmont
!docmont[3]
application = {
 name = dvm_function_frames
 fn add(left: Int, right: Int): Int {
   return left + right
 }
 output = add(19, 23)
 complete
}
```

## New IR operations

- `FUNCTION`: function entry marker with name and arity metadata.
- `CALL`: invokes a named function with an argument count.
- `RETURN`: returns the top stack value to the caller.

The compiler emits a jump over function bodies in the top-level instruction stream. Call frames preserve the caller program counter and operand-stack base. Parameters are initialized by generated `STORE` instructions at function entry.

## Boundaries

- DVM named functions only; anonymous lambdas and captured closures are not lowered to DVM.
- Default parameter expressions are not applied by the DVM call path; calls require exact arity.
- Function values, indirect calls, methods, variadic parameters, and tail-call optimization are not implemented.
- Function locals are isolated; only global values are visible as fallback. Mutable lexical captures are not supported.
- Native-C backend does not implement the new function opcodes.
- The bytecode verifier checks ordinary reachable control-flow paths and call argument stack effects, but does not perform whole-program interprocedural type or call-target verification. Unknown targets and arity mismatches are rejected by the runtime.
