# DOCMONT 5.50.0 — DVM Closure Capture

DOCMONT 5.50.0 adds value-captured lexical environments for anonymous functions lowered to DVM.

- Lambda lowering identifies free identifiers in the lambda body.
- `MakeClosure` packages the function identity and captured values.
- `CallIndirect` installs the captured values into the new call frame before parameter stores.
- Bytecode verification checks closure target resolution and capture-count consistency.

## Example

```docmont
!docmont[3]
application = {
 name = dvm_closure_capture_5_50
 let factor = 10
 let scale = fn(value: Int): Int {
   return value * factor
 }
 output = scale(5)
 complete
}
```

Expected output: `50`.

## Current semantics and limitations

Captures are snapshots (by value) at closure creation. Mutating a captured scalar inside the closure does not mutate the outer binding. This release does not implement shared mutable capture cells, nested closure lifetime analysis, cycle collection, or Native-C closure lowering. Capture discovery is conservative and currently handles identifier references in the lambda AST; shadowing analysis is limited.
