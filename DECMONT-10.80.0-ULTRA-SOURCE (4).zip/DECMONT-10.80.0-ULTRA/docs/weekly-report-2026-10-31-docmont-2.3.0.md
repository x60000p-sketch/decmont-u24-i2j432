# DOCMONT 2.3.0 — Portability Baseline

## Implemented
- Replaced compiler-specific overflow intrinsics and an unsafe fallback with portable checked signed 64-bit add/subtract/multiply/divide logic.
- Added `docmont --version` and `docmont --help`.
- Added CMake install rules for the executable, core library, public headers and language specification.
- Added a GitHub Actions build/test matrix for Ubuntu, Windows and macOS. The workflow is configured but has not been executed by this local build.

## Local verification
The local environment can verify the current host build and test suite. It cannot certify Windows/macOS builds; those require the hosted CI runners.

## Not implemented
No native machine-code backend, LLVM integration, function system, complete type system, graphics engine, Android package, kernel integration or CPU microcode writer is included in this release. The target list in the project manifest is a roadmap declaration, not proof of tested binaries on every target.
