# DOCMONT 5.30.0 — DVM Call-Frame Integrity

DOCMONT 5.30.0 strengthens runtime boundaries for direct and indirect DVM calls.

- A call's function reference and arguments must be wholly inside the caller's operand-stack window.
- A function return must leave exactly one result value above that function frame's stack base.
- Malformed runtime IR is rejected with a frame-specific diagnostic rather than having stray values silently discarded during return.
- The existing 1024-frame and 65,536-value operand-stack limits remain in force.

These checks complement static Bytecode verification. They do not add lambda/closure support, garbage collection, or Native-C function parity.
