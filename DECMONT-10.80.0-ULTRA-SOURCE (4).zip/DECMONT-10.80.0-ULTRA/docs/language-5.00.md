# DOCMONT 5.00.0 — DVM Function Values

DOCMONT 5.00.0 adds first-class references to top-level named functions in DVM bytecode.

## Syntax

```docmont
fn add(left: Int, right: Int): Int {
  return left + right
}
let operation = add
output = operation(19, 23)
```

## Runtime additions

- `load_function`: pushes a validated reference to a top-level DVM function.
- `call_indirect`: resolves a function reference from the operand stack and invokes it.
- Indirect calls enforce the declared arity and the existing 1024-frame limit.
- Bytecode verification accounts for the function-reference and argument stack effects.

## Scope and limitations

This release supports first-class references to top-level named functions. It does not yet compile lambda expressions into DVM functions, capture lexical environments, support mutable closures, or add indirect-call support to Native-C. Those are separate follow-up features. Function references are runtime values; they are not serializable outside the DVM bytecode's instruction stream as independent persisted objects.
