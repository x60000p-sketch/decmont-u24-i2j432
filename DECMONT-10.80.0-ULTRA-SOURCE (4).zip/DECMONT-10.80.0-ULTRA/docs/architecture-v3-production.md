# DOCMONT 3.0 Production Architecture Baseline

## Product identity
DOCMONT is designed as a hybrid programming platform: one language frontend and typed intermediate representation feeding (eventually) a DOCMONT VM and native compiler backends. The present implementation is a foundation, not a production-complete compiler.

## Architectural layers

1. Language frontend: DLEX lexer, DGRAM parser, AST, DSEM semantic checks, DRESOLVE name resolution, DLOGIC contracts.
2. Core IR: typed values, explicit control flow, memory effects, source/debug locations and target-independent operations.
3. Verification and optimization: DVERIFY validates invariants; DOPT runs deterministic, individually testable passes.
4. Execution paths: DVM bytecode + interpreter/JIT; native path via LLVM initially.
5. Platform/domain services: DABI, SOMPA, memory, scheduler, networking, storage, graphics, compute and OS adapters.
6. Toolchain: CLI, package manager, build system, debugger, profiler, documentation and conformance suite.

## Production rules

- One frontend and shared IR; domain modules must not create competing language parsers.
- Every target is a tuple of ISA, ABI, object format, OS APIs, linker and runtime profile.
- Native support is claimed only after a real backend build and execution test on that target.
- VM bytecode is versioned and verified before execution.
- Permissions are capability-based and deny-by-default. No covert persistence, security-product evasion or privilege bypass.
- Graphics APIs are adapters over documented platform APIs; GPU features are capability-probed.
- CPU microcode is vendor-controlled firmware; DOCMONT may generate ISA machine code and simulate micro-operations, not claim universal microcode control.

## Current implementation at 3.0.0

Implemented: C++20 frontend, current AST and semantic subset, integer/string expressions, stack IR/interpreter, AST inspector, DVM container encoder and structural/stack verifier.

Not implemented yet: bytecode execution, JIT, LLVM backend, native executable generation, complete function/module/type system, ownership/borrowing, scheduler, GPU renderer, package manager, Android integration.

## Proposed component ownership

- DOCMONT-owned: language grammar, AST, semantic rules, core IR contract, DVM bytecode format/runtime, package metadata, SOMPA policy model and developer CLI.
- Reuse/integrate: LLVM for native code generation, Vulkan/Direct3D/Metal through adapters, WASI/WebAssembly for portable sandboxed modules, SQLite for embedded storage where appropriate.
- Interoperability: C ABI first; C++ and Rust bindings; C#/Java/JavaScript tooling adapters. Hex is a binary representation/inspection facility, not a language backend.
