# DOCMONT 4.7.0 — Master Engineering Specification

Status: **Architecture contract + incremental implementation baseline**  
Language compatibility: **3.4.0**  
Implementation language for the compiler/runtime: **C++20**  
Primary design: **modern independent language, hybrid runtime, hybrid memory, dual INPLOT domains**

## 1. Normative decisions

| Area | Decision | Contract |
|---|---|---|
| Syntax | Modern independent syntax | DOCMONT owns its grammar, AST, type rules and diagnostics; C/C++ are FFI targets, not the language definition. |
| Runtime | Hybrid | VM is the portable reference execution engine; JIT and native backends are optional capabilities; WASM is a separate target. |
| Memory | Hybrid | Safe ownership is the default; tracing GC is opt-in for GC-managed regions; manual allocation is an explicitly unsafe/low-level escape hatch. |
| INPLOT | Both domains | Runtime kernel tasks run in user space. System-kernel projects are a separate build domain and require platform toolchains, privileged interfaces and validation. |
| Modules | Native module system | `import decom.selea` resolves a versioned module manifest and links an implementation through the module ABI. |
| Compatibility | Additive | Existing 3.4.0 source grammar and 4.6/4.7 C++ APIs remain compatible unless a documented migration says otherwise. |

## 2. Language contract

### 2.1 Source unit

- Extension: `.docm`.
- Encoding: UTF-8; invalid sequences are diagnostics.
- A source unit contains optional module declaration, imports, declarations and a required entry point for executable programs.
- Imports are resolved before semantic analysis; duplicate aliases and cyclic initialization are diagnosed.
- The grammar is versioned independently from the compiler release.

### 2.2 Core syntax target

```docmont
module science.compute
import decom.selea as num
import decom.matrix as mat

fn mean(values: Array<f64>) -> f64 {
    return num.mean(values)
}

fn main() -> i32 {
    let samples: Array<f64> = [1.0, 2.0, 3.0]
    print(mean(samples))
    return 0
}
```

This is the target language contract. `import` and the shown type syntax are not considered implemented until lexer, parser, resolver, type checker, bytecode, runtime and end-to-end tests all accept and execute this program.

### 2.3 Type system

- Primitive: `bool`, signed/unsigned fixed-width integers, `f32`, `f64`, `char`, `string`, `void`.
- Composite: tuples, arrays, slices, structs, enums, option/result types, function types.
- Advanced: generics, traits/interfaces, bounded type parameters, compile-time constants.
- Numeric conversions are explicit unless lossless and specified by the language rules.
- Nullability is explicit; uninitialized reads are rejected.
- ABI layout is specified for exported types; private layout is compiler-owned.

### 2.4 Memory and safety

- Default references follow ownership/borrowing rules and are checked statically where possible.
- `gc` regions are explicit and cannot silently capture borrowed references beyond their lifetime.
- Manual allocation requires an `unsafe` scope and explicit allocator handle.
- Bounds checks, integer overflow policy and FFI pointer validation are configurable only through explicit project/runtime policy.
- Runtime configuration rejects unsafe combinations unless unsafe permission is explicit.

### 2.5 Concurrency

- Tasks, threads, channels, atomics and async operations have defined ownership transfer rules.
- Shared mutable state requires synchronization primitives.
- Cancellation and task failure propagation are explicit.
- Deterministic mode constrains scheduling-visible nondeterminism where feasible; it does not promise deterministic results for every external device or network operation.

## 3. Compiler contract

Pipeline:

`UTF-8 -> Lexer -> Parser -> AST -> Import Resolver -> Semantic Analysis -> Type Checker -> HIR -> MIR -> DOCMONT IR -> Optimizer -> Backend -> Linker -> Runtime Loader`

Required invariants:

1. Every diagnostic carries stable code, severity, source span and optional fix-it.
2. IR is typed, validated and versioned; malformed IR cannot reach code generation.
3. Optimization passes declare preconditions and preserve observable language semantics.
4. Bytecode has magic, format version, target/features, bounded section lengths and verifier checks.
5. Native artifacts record compiler version, target triple, ABI and linked module versions.
6. Backend absence is reported as unsupported; no backend is simulated by relabeling output.

Backend sequence:

- Reference VM: first-class, deterministic correctness baseline.
- Native C11 backend: current compatibility backend; native executable requires an external C compiler/linker.
- JIT: planned backend with executable-memory policy, W^X and platform-specific implementation.
- WASM: planned backend with WASI/browser capability profiles.

## 4. Runtime contract

`RuntimeConfig` defines execution mode, memory mode, bounds policy, determinism and heap limit.

- `Auto`: choose the best installed and validated backend; report the chosen backend.
- `VM`: portable bytecode execution.
- `JIT`: fail clearly if a compatible JIT is not installed.
- `Native`: compile/link for the selected target; fail if toolchain is unavailable.
- `WebAssembly`: require a WASM backend and declared WASI/browser profile.

Memory modes:

- `Ownership`: safe default; deterministic destruction/borrowing contract.
- `OwnershipWithGC`: ownership plus explicit tracing-managed regions.
- `Manual`: unsafe allocator-level control; opt-in only.
- `Hybrid`: ownership default, optional GC regions, explicit manual unsafe scopes.

## 5. DECOM module ABI contract

Every module manifest must declare:

- canonical module name (`decom.<name>`), semantic version and ABI major;
- exported symbols, types, generic constraints and error behavior;
- dependencies and minimum runtime version;
- determinism, thread-safety and memory ownership annotations;
- supported targets and optional accelerator backends;
- license, provenance and test/benchmark status.

ABI rules:

- ABI major changes only for incompatible binary changes.
- Public structs use explicit layout/versioning; opaque handles are preferred across ABI boundaries.
- Errors cross FFI as structured status/result values, not uncaught C++ exceptions.
- Array and tensor APIs carry element type, rank, shape, strides, byte length and ownership/lifetime metadata.
- No raw pointer is accepted without length and lifetime contract.

### 5.1 Library families

**Numeric:** `selea`, `numeric`, `precision`, `bigint`, `decimal`, `complex`, `statistics`, `probability`, `optimize`, `autodiff`, `signal`, `interpolate`.

**Data and linear algebra:** `arrays`, `matrix`, `vectors`, `tensor`, `sparse`, `linalg`, `dataflow`, `graph`, `serialization`, `compression`, `hashing`, `database`.

**Execution and systems:** `inplot`, `memory`, `scheduler`, `threading`, `atomic`, `process`, `filesystem`, `network`, `abi`, `device`, `virtualization`, `security`.

**Media and simulation:** `geometry`, `units`, `physics`, `image`, `audio`, `graphics`, `compute`, `neural`.

The list is a target catalog. A module is “implemented” only when it has exported code, contract tests and documentation. Existing 4.7.0 DECOM header currently implements 31 CPU-oriented namespaces and advertises 177 capability slots; those counts do not mean all future modules exist.

## 6. INPLOT dual-domain contract

### 6.1 RuntimeTask domain

- Executes as an ordinary user-space task inside DOCMONT Runtime.
- Uses validated `KernelConfig`, scheduler policy, worker count and bounded memory reservations.
- Cannot claim ring-0 privilege, device control, boot capability or OS-kernel replacement.

### 6.2 SystemKernelBuildSpec domain

- Describes a future OS-kernel build: architecture, entry symbol, subsystem requirements and toolchain profile.
- Separate target graph, linker script, startup code, boot protocol, drivers and hardware validation are required.
- 4.7.0 defines metadata/validation only; it does not emit a bootable kernel image.
- Platform-specific signing, secure boot and vendor SDK requirements must be respected.

## 7. Platform contract

Initial validation order:

1. Linux x86-64 host build and tests.
2. Windows x86-64 CI/toolchain validation.
3. macOS arm64 with Apple toolchain.
4. Android arm64 with NDK and physical/emulated device tests.
5. iOS arm64 with Xcode, signing and device/simulator validation.
6. WebAssembly with browser/WASI conformance.
7. RISC-V and other architectures after backend and CI availability.
8. Consoles only through authorized vendor SDKs and documented platform access.

A platform is “supported” only when compile, link, runtime smoke tests and documented feature matrix pass. Merely listing a target triple is not support.

## 8. Build, package and repository contract

- Monorepo contains compiler/runtime/spec/tests and core libraries; optional platform SDKs and large datasets are separate versioned packages.
- Git stores source and small fixtures; large binary datasets, toolchains and generated caches are external artifacts, not committed into source history.
- Reproducible builds pin compiler/toolchain versions and dependency hashes.
- Release artifacts include SBOM, checksums, license inventory, build provenance and test report.
- 20 GB is a full-distribution budget target, not a source-code size target. Source Edition remains independently cloneable.

## 9. Acceptance gates

A feature is complete only if it has: implementation, public API contract, unit tests, integration tests, negative/error tests, documentation, compatibility review and benchmark where performance is relevant.

Release gates: clean configure/build, all CTest and LSP tests, VM execution tests, bytecode verifier fuzz/negative tests, module ABI compatibility tests, and per-platform CI. Unavailable platform SDKs must be reported as unvalidated rather than passed.

## 10. Immediate 4.7.x implementation sequence

1. Publish these contracts and add typed runtime/platform policy structures.
2. Separate INPLOT runtime-task descriptors from system-kernel build specifications.
3. Add a stable module manifest format and resolver.
4. Implement DOCMONT `module`/`import` syntax end-to-end.
5. Bind selected DECOM functions into the language runtime with explicit value/array ownership.
6. Add backend capability discovery and truthful `Auto` selection.
7. Expand library coverage by vertical slices, not empty module stubs.

## 11. First implementation slice in this source tree

The 4.7.0 source now includes:

- `include/docmont/platform_contract.hpp`: typed runtime/memory policy, unsafe-mode validation, target readiness descriptors, and separate INPLOT system-kernel build-spec validation.
- `include/docmont/module_registry.hpp`: in-process versioned module manifests, ABI-major dependency checks, export validation and duplicate-registration rejection.
- Tests covering hybrid memory safety gates, target lookup, INPLOT domain separation, module registration and missing dependencies.

This slice is infrastructure, not the complete language module loader. It does not yet parse `.docm` imports, load shared libraries, link DECOM symbols into bytecode, implement GC/JIT/WASM, or emit bootable system-kernel images. Those are subsequent implementation gates.
