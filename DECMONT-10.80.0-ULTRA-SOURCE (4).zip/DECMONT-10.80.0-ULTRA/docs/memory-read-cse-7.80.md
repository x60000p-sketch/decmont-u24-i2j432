# Alias-aware memory-read CSE (7.80.0)

DOCMONT 7.80.0 adds a conservative memory-read common-subexpression pass to the O3 + SSA optimizer. It consumes allocation-site provenance produced by Points-to Analysis, along with direct-call parameter effect summaries.

## Supported read forms

The pass recognizes these stack-balanced patterns within one basic block:

- `Load name; ObjectGet field`
- `Load name; ObjectHas field`
- `Load name; ArrayLength`
- `Load name; PushInt constant; ArrayGet`

A read is eligible only when the base's reaching Value SSA value has exactly one known allocation site, no `unknown` component, and no symbolic parameter component. The allocation kind must match the read (object versus array).

## Forwarding and invalidation

The first eligible read is kept and its result is spilled to a generated compiler-private local only when a later equivalent read reuses it. The repeated read idiom becomes a single `Load` of that temporary, preserving the expression's one-value stack result. Temporary names are checked against existing Load/Store names.

The pass invalidates cached facts conservatively:

- An `ObjectSet` invalidates reads of the same named property on the same known object. A dynamic/empty property name invalidates all cached object-property reads for that object.
- `ArraySet`, `ArrayPush`, and `ArrayPop` invalidate cached array reads for the same allocation site.
- A write with unknown or symbolic base provenance clears the cache.
- A direct call with a known callee and known parameter effects invalidates the actual argument allocation sites corresponding to the callee's writes/escapes. Unknown/global/nested effects clear the cache.
- Indirect, unresolved, or otherwise unknown calls clear the cache.

Points-to provenance is propagated through variable Store/Load versions and Variable Phi nodes so a reference stored in a local can still be recognized at a later read. The alias helper treats symbolic parameter provenance as possibly aliasing any known allocation, preventing a formal parameter from being incorrectly treated as disjoint.

## Safety scope and limitations

This is a block-local read CSE pass, not a general memory optimizer:

- No memory-read CSE crosses basic-block or function boundaries.
- Only singleton, statically known allocation sites are eligible; unknown, multi-site, or symbolic-parameter bases are skipped.
- `ArrayGet` requires a literal integer index. Writes conservatively invalidate the full cached read set for that array allocation.
- The pass does not eliminate heap writes, split Memory SSA, perform full field-/element-sensitive points-to analysis, infer object layouts, or optimize read results across calls.
- Alias/parameter summaries are used to invalidate cached reads around direct calls; unresolved effects fail closed.
- No bytecode opcode or encoding change is introduced. The rewrite uses existing `Store` and `Load` operations.

The regression suite checks positive reuse, disjoint allocation preservation, same-field invalidation, distinct-field preservation, unknown-base invalidation, array read behavior, direct-call mutation invalidation, and runtime output parity for representative object and array reads.
