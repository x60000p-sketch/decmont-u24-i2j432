# DOCMONT 8.90.0 Project Lifecycle

DOCMONT 8.90 adds a standard project layout and a deterministic lifecycle tool. It does not claim that all graphics APIs, console SDKs, or hardware backends are production-complete.

## Project layout

```text
MyGame/
  docmont.toml
  README.md
  .gitignore
  src/main.docm
  assets/
    asset-manifest.json
    scenes/main.dscene
    models/
    textures/
    audio/
    shaders/
  tests/
  build/                 # generated; excluded from packages
  dist/                  # generated; excluded from packages
```

## Manifest

`docmont.toml` uses TOML:

```toml
[project]
name = "MyGame"
version = "0.1.0"
entry = "src/main.docm"
scene = "assets/scenes/main.dscene"

[engine]
profile = "ultra"
renderer = "auto"
physics = "cpu-reference"
network = "disabled"

[assets]
root = "assets"
```

Paths must be relative, remain inside the project root, and must not traverse `..` or symlinks outside the workspace. Scene files are JSON with an optional `entities` array.

## Lifecycle commands

- `docmont-project new NAME [PATH]`: creates the complete starter tree and first asset hash manifest.
- `docmont-project check PATH`: validates TOML, entry, scene JSON, asset integrity, and compiler diagnostics. `--no-compiler` disables only the compiler pass.
- `docmont-project assets PATH`: refreshes `assets/asset-manifest.json` with file size, kind, extension, and SHA-256. Re-run after changing assets.
- `docmont-project build PATH`: checks the project, emits DVM v1 bytecode, verifies it, smoke-runs it, and writes `build/build-manifest.json` with artifact hash and captured output.
- `docmont-project package PATH`: writes a deterministic ZIP of source/config/assets. Build, dist, VCS, and cache directories are omitted.

Set `DOCMONT_EXECUTABLE=/absolute/path/to/docmont` or provide `--compiler` for compiler-dependent commands.

## Build guarantees and limits

The 8.90 build workflow emits and verifies portable DVM bytecode. It does not claim that arbitrary game scenes are compiled to native GPU commands. Native LLVM support remains restricted to its documented MIR subset. Asset inventory hashes files; it does not decode or validate every media format. Project packaging is source/assets packaging, not platform certification or a signed game release.

## Studio integration

Studio exposes `/api/project` plus POST actions `/api/project/check`, `/api/project/assets`, `/api/project/build`, and `/api/project/package`. These actions use fixed command arguments, no shell, a fixed workspace root, the same project path validation, and localhost-only binding.
