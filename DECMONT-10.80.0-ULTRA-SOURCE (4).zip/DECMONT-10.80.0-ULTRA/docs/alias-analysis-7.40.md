# Alias Analysis Metadata (7.40.0)

`SSAProgram::alias_accesses` stores one record for every reachable instruction with a modeled memory effect.

| Abstract region | Current instructions | Mask |
|---|---|---:|
| `HeapAggregate` | Array/object operations, `NewObject`, `MakeArray`, `MakeClosure` | `0x1` |
| `ClosureCell` | `LoadCell` | `0x2` |
| `Unknown` | `Call`, `CallIndirect` at local instruction scope | `0x7` |

Arrays and objects intentionally share the aggregate heap partition. The implementation does not track object identity, array indices, object fields, pointer provenance, or escaped allocations.

`SSAFunctionRegion::alias_read_mask` and `alias_write_mask` summarize regions touched by a function. Direct calls propagate callee masks through a bounded fixed-point pass. Unknown or unresolved calls conservatively contribute `0x7` to both masks.

`alias_regions_may_alias(a, b)` returns true when either operand is `Unknown` or both abstract regions are equal. This is a coarse storage-class relation, not a points-to query.

The current Memory SSA is still a single conservative token chain. The new alias metadata is not used by optimizer transformations. It is available for diagnostics, validation, and future alias-aware optimization work.
