# DOCMONT 4.1.0 release report

## Release intent

DOCMONT 4.1.0 is a tooling/compiler increment over the supplied 3.4.0 codebase. It intentionally preserves the 3.4.0 source grammar and runtime behavior; it does not claim new source-language syntax or a feature-complete LSP implementation.

## Implemented

- Product, CMake and project-manifest version updated to 4.1.0.
- `docmont --version` reports 4.1.0 and explicitly states 3.4.0 language compatibility.
- `docmont check --json <file.docm>` runs the real lexer, parser and semantic validator and emits JSON diagnostics with severity, line, column and message, plus an `ok` status.
- `docmont language-info` emits JSON metadata for the implemented header, top-level declarations, statements, expressions, block names, properties, accepted values and token spellings. Token spellings are read from the compiler's `token_name` implementation.
- CTest CLI contract test covers version, language metadata and valid-source JSON diagnostics.
- Integrated VS Code extension/LSP package 0.5.0. The server uses `check --json` for compiler diagnostics and `language-info` for completion and hover metadata.
- LSP supports in-memory buffer validation, stale-version rejection, context-aware completion, local `let` definition navigation and hover documentation.
- Android scaffold version metadata updated to 4.1.0; Android SDK/NDK build and device execution were not available/claimed.

## Verification performed

- CMake configure and Release build: passed with GNU C/C++ 14.2.0.
- CTest: 3/3 passed (`docmont_tests`, `docmont_cli_contract`, `docmont_lsp_integration`).
- `language-info` output parsed with Python's JSON parser.
- Valid `hello.docm` JSON check returned `ok: true` and no diagnostics.
- Malformed source JSON check returned exit code 1, `ok: false`, and four parser/lexer/semantic diagnostics; JSON parsed successfully.
- All four DOCMONT examples passed `check`; arithmetic example executed and printed 120.
- VLOT sample project inspected and planned; PC marked ready, Android correctly requires SDK/NDK, PS5 correctly blocked pending official authorized SDK/signing/hardware.
- VPAK built and verified (3 files, 514 payload bytes).
- VSHADER compiled to VSM1 and VSM1 verification passed.
- VSCENE loaded (4 nodes) and rendered to a 320x180 PPM image.

## Not implemented / not verified

- The supplied project archive did not contain the separate 0.4.0 extension artifact. The earlier 0.4.0 source was separately available in this conversation and was reviewed, integrated as `ide/vscode-docmont`, updated to 0.5.0 and tested against the actual 4.1.0 compiler.
- No incremental parser, stable diagnostic codes, direct machine-code backend, GPU renderer, Android APK/device test, or PS5 SDK build is claimed. Diagnostic ranges currently infer a one-character span from compiler line/column positions because the compiler does not yet report end positions.
- VLOT rendering remains CPU/software; VSM1 remains CPU material bytecode; VPAK remains a content package, not an executable.

## Next engineering step

Add stable diagnostic codes and end positions to the compiler diagnostic API, then implement incremental document updates and richer symbol navigation. Test the extension in a real VS Code Extension Development Host; this environment has no VS Code executable, so that final GUI check remains outstanding.
