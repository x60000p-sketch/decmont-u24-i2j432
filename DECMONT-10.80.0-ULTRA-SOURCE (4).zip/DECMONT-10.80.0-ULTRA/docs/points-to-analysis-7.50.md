# Points-to Analysis (7.50.0)

DOCMONT 7.50.0 adds a conservative allocation-site points-to layer on top of the existing Value SSA and Alias Analysis metadata.

## Allocation sites

Each reachable `NewObject`, `MakeArray`, and `MakeClosure` Value SSA definition contributes an allocation site identified by its IR instruction index. The analysis records the corresponding allocation kind (`object`, `array`, or `closure`).

## Value provenance

- Allocation results point to their own allocation site.
- Stack `Dup` preserves identity because both stack positions refer to the same Value SSA ID.
- Stack Phi nodes receive the union of their incoming allocation-site sets. Cyclic Phi relationships are solved with a monotone fixed-point iteration bounded by the number of Value SSA definitions.
- In 7.60.0, variable-version propagation connects `Store`/`Load` and Variable Phi nodes to allocation-site sets. Loads with no known reaching reference remain unknown. Aggregate reads, closure-cell loads, and call results remain unknown unless a separately modeled summary provides provenance.
- Entry values (function arguments) retain symbolic parameter indices. Because a formal parameter can alias a caller allocation, `points_to_sets_may_alias` treats a set containing symbolic parameters as potentially aliasing any known allocation. In 7.70.0, parameter read/write/escape summaries are propagated through direct call edges.
- Scalar and other values without modeled reference provenance have an empty, non-unknown set.

`points_to_sets_may_alias(a, b)` returns true when either side is unknown or the two sets share at least one allocation site. An exact singleton set with no unknown component can be marked `must_alias_singleton` on a memory access.

## Access metadata

Each Alias Analysis access now includes its base object's allocation-site set, an unknown flag, and a singleton flag. Aggregate allocations themselves are tagged with their own site. Existing coarse Alias Regions and unified Memory SSA remain unchanged, preserving conservative behavior and bytecode/runtime compatibility.

## Verification

The SSA verifier checks allocation-site instruction/kind correspondence, unique site identities, points-to set references and ordering, points-to coverage for Value SSA definitions, access-site validity, and singleton-flag consistency. `dump_ssa` prints allocation-site inventory, per-value points-to sets, and access provenance.

## Limits

This is a bounded, allocation-site-based provenance analysis, not a full context-sensitive, field-sensitive Andersen/Steensgaard solver. Variable stores/loads and variable Phi nodes are modeled, but object fields, array elements, closure-cell contents, and general return-value provenance are not. Symbolic parameter indices are summaries, not context-specialized concrete sets. The 7.80.0 optimizer consumes only singleton, known allocation-site facts for a restricted set of memory-read transformations; unresolved cases are skipped or invalidated conservatively. Escape analysis remains summary-oriented and is not a complete heap lifetime or ownership analysis.

Language compatibility remains 3.4.0; the bytecode format and runtime semantics are unchanged.
