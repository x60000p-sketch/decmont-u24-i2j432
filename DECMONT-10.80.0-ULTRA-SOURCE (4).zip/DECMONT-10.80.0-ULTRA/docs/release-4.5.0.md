# DOCMONT 4.5.0 — Runtime and Render-Graph Foundation

## Added
- Quaternion math: normalized quaternion operations and quaternion-to-matrix rotation.
- Transform rotation: local matrices now compose translation × rotation × scale.
- `memory::LinearArena`: aligned transient allocation, typed construction, capacity checks, reset and usage counters. Reset invalidates all outstanding allocations; individual frees and destructor tracking are intentionally not provided.
- `render::RenderGraph`: named resources, imported-resource declarations, pass read/write declarations, explicit dependencies, hazard edges, deterministic topological scheduling, read-before-write diagnostics and cycle detection.

## Compatibility
- DOCMONT source-language compatibility remains 3.4.0.
- Existing ECS, SceneGraph, math, compiler, DVM, native-C and VLOT interfaces are retained.
- These are host-side C++ runtime facilities. The render graph is a scheduler model, not a Vulkan/Direct3D/OpenGL command backend.

## Validation
The release is accepted only after CMake build, CTest, VS Code extension checks/tests, CLI version check, JSON validation and source archive integrity checks pass.
