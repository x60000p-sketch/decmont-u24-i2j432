# DOCMONT 4.10.0 — Module Resolution Hardening

## Implemented
- Module import aliases: `import decom.math as dm`.
- Alias validation using the same dotted-name identifier rules.
- Resolver root canonicalization and path-escape rejection, including symlink-resolved paths.
- Stable module dependency traversal, cycle and missing-module diagnostics retained.
- Project/CLI/compiler version bumped to 4.10.0; language compatibility remains 3.4.0.

## Scope
This release hardens the resolver API. It does **not** claim full parser/AST integration, semantic symbol imports, DECOM function binding, JIT, WASM, or garbage collection. Import scanning remains a resolver-stage source scan.

## Verification
Release build and CTest are required; see `DOCMONT-4.10.0-IMPLEMENTATION-REPORT.md`.
