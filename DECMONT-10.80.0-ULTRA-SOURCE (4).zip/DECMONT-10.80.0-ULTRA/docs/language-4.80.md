# DOCMONT 4.80.0 — DVM execution safety

## DVM operand stack ceiling

The DVM now enforces a hard ceiling of **65,536 values** on its evaluation/operand stack. The runtime checks the limit during instruction dispatch and immediately after instructions that may grow the stack. Exceeding it produces a deterministic runtime diagnostic:

`DVM operand stack limit exceeded (65536 values)`

This is separate from the existing one-million-instruction execution budget and the existing array element cap. The limit protects VM execution from malformed or adversarial bytecode that attempts to grow the operand stack without bound.

## Compatibility

- Source language compatibility remains `3.4.0`.
- DVM bytecode container format remains version `1`; no opcode values or serialized fields changed.
- Existing valid programs that keep their temporary operand stack at or below the ceiling are unaffected.
- This is a VM runtime guard, not a general process-memory limit. It does not cap all C++ allocations, object graph size, or AST interpreter memory.
