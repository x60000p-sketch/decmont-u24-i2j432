# DOCMONT 4.3.0 — Math and 3D Foundation

## Release intent

4.3.0 is a compatibility-preserving engineering increment. It retains the DOCMONT 3.4.0 source grammar, AST, interpreter, DVM bytecode, C11 source backend, structured diagnostics, and existing VLOT behavior.

## Implemented in this source tree

- Header-only C++ math API at `include/docmont/math.hpp`.
- `Vec2`, `Vec3`, and `Vec4` data types.
- `Vec3` addition, subtraction, scalar multiplication/division, dot product, cross product, length, and checked normalization.
- Row-major `Mat4` with column-vector convention, identity, translation, scale, matrix multiplication, homogeneous vector multiplication, and perspective projection.
- Checked point transformation rejects a zero homogeneous `w`.
- Unit tests cover vector algebra, transform composition, perspective parameters, and zero-vector normalization failure.
- Compiler/CMake/manifest/Android bridge metadata advanced to 4.3.0 while retaining source-language compatibility 3.4.0.

## Explicit limits

- These math primitives are a host C++ library API; no new `.docm` syntax or automatic language bindings are introduced.
- This is not yet a complete 3D game engine, GPU renderer, SIMD implementation, tensor runtime, or hardware synthesis pipeline.
- VLOT's existing renderer remains CPU/software. GPU backends and device/console validation require later work and appropriate SDKs/toolchains.
- No claim is made that PS5/Xbox platform builds have been executed.

## Verification

Build with CMake and run CTest. The 4.3.0 math tests are part of `docmont_tests`.
