# DOCMONT Optimizer: SSA Integration (7.00.0)

## Pipeline placement

DOCMONT retains its existing CFG cleanup, constant-branch folding, constant propagation, constant folding, and local algebraic simplification passes. After those passes produce a compact instruction stream, the optimizer builds the non-mutating SSA view and requires `verify_ssa` to accept it before running the 7.00.0 SSA-assisted passes.

## Block-local GVN

For each basic block, the pass recognizes this restricted shape:

```text
PushInt | Load
PushInt | Load
pure-integer-binary-op
```

Operand identity is exact: integer literals use their literal value; named loads use `(variable, SSA version)`. The key also includes the opcode. Commutative operations canonicalize operand order. The table is local to a single basic block and is cleared at call, closure/cell, return, and supported mutable array/object operation boundaries.

On the first occurrence, the pass inserts a generated `Store` and `Load` pair after the expression. The store temporarily materializes the result; the immediate reload restores the original expression stack effect. On a later matching occurrence, the three-instruction expression is replaced by a single `Load` of that temporary. Branch targets into candidate instructions prevent rewriting, and all surviving branch destinations are remapped after compaction/expansion.

## Dead literal-store elimination

SSA uses and Phi incoming edges define liveness. A `Store` is eligible only when its result version has no SSA uses, the instruction immediately before it is a `PushInt` or `PushString`, and neither instruction is a branch target. Both the producer and Store are removed together, preserving stack height. Non-literal producers are intentionally left intact.

## Invariants and tests

- SSA verification must pass before either SSA-assisted pass runs.
- The resulting instruction stream is checked by bytecode-encoding regression tests.
- GVN does not reuse values across block boundaries or SSA redefinitions.
- Phi incoming definitions remain live when used by a live Phi.
- Targeted instructions are not removed or rewritten.

The regression suite is `tests/ssa_optimizer_7_00.cpp` (`docmont_ssa_optimizer_7_00`).
