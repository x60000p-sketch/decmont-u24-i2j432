# DOCMONT 8.90.0 Release Engineering

## Reproducible local configuration

Use the CMake presets:

```bash
cmake --preset linux-release
cmake --build --preset release
ctest --preset release
cmake --install build/release
```

The source also supports direct CMake configuration with CMake 3.20+ and a C++20 compiler.

## Test coverage added in 8.90.0

- Project scaffold generation.
- TOML manifest validation.
- Safe relative path validation and path traversal rejection.
- Scene JSON validation.
- SHA-256 asset inventory and stale-manifest detection.
- Compiler source check.
- DVM compilation, bytecode verification, and VM smoke run.
- Reproducible source/assets ZIP packaging.
- Studio project dashboard, project check/build/package endpoints.

## Artifact contract

Every release artifact should be accompanied by SHA-256 checksums. ZIP packages use deterministic file order and timestamps. `build/`, `dist/`, `.git/`, caches, and local backups are not part of a source package.

## Platform honesty

The checked compiler binary in this release is Linux x86_64. Other target profiles are not declared stable without a matching native toolchain and execution tests. Console profiles require vendor-issued SDKs, licensed access, authorized devkits, and platform approval.
