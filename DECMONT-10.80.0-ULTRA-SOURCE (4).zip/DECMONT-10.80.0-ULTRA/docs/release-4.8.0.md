# DOCMONT 4.8.0 — Tensor & Numerical Core

## Implemented
- Project version promoted to 4.8.0.
- `docmont/tensor.hpp`: contiguous row-major N-dimensional tensor, checked shape construction and indexing, flat access, element-count-preserving reshape.
- `tensor::describe`: mean, population variance, minimum and maximum for arithmetic vectors.
- Regression tests for rank, shape, indexing, bounds rejection, reshape and numerical results.

## Validation
- GNU C/C++ 14.2.0, CMake Release build.
- CTest: 3/3 passed (`docmont_tests`, `docmont_cli_contract`, `docmont_lsp_integration`).

## Limitations
Tensor APIs are currently C++ runtime/library APIs, not DOCMONT source-language built-ins. This release does not claim JIT, GC, WASM code generation or a bootable INPLOT kernel.
