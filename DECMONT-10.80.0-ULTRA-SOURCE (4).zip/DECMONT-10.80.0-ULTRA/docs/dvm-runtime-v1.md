# DVM Runtime v1 (DOCMONT 3.1.0)

`docmont vm-run program.dvm` loads a DVM v1 container, verifies it, decodes the instruction stream into the typed stack IR representation, then executes it through the runtime.

Supported instructions: `PushInt`, `PushString`, `Load`, `Store`, `Add`, `Sub`, `Mul`, `Div`, and `Print`.

Runtime properties:
- malformed/truncated containers are rejected before execution;
- unknown opcodes and invalid stack effects are rejected by the verifier;
- integer arithmetic checks signed 64-bit overflow and division by zero;
- variable storage is per-program and process-local.

Limitations: no branches, loops, function calls, module linking, external calls, garbage collection, JIT, sandboxed syscalls or persistent heap objects. The runtime is a working first VM, not a complete general-purpose VM.

## DOCMONT 4.27.0 heap integration

DVM array payloads use `std::pmr::vector<Value>` backed by `memory::HeapResource`. Each `execute()` invocation owns a 64 MiB bounded heap. Array shared-ownership control blocks are also allocated from that heap. Allocation failures during array creation or growth become runtime diagnostics. This does not yet account for the VM stack, variable map, string payloads, compiler data, or all process allocations; it is bounded array storage, not a tracing garbage collector.
