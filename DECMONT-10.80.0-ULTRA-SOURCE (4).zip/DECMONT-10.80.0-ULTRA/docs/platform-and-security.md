# Platform, hardware and security model

## CPU targets
x86-64 and AArch64 are separate instruction-set targets. An executable must be built for the target ABI and operating system. A single binary does not run natively on every Intel, AMD and Android device.

## Android
Initial Android support means AArch64/ARM64 output, Android NDK integration, Android ABI packaging and app sandbox compatibility. It does not mean unrestricted execution inside the Android kernel.

## Kernel and system integration
Kernel drivers are OS-specific, require documented interfaces, signing and user authorization. DOCMONT will not silently bypass access controls or conceal processes from system security tools. Privacy features include local-first storage, encryption, minimal telemetry and transparent permissions.

## Microcode
CPU microcode is processor-vendor firmware. DOCMONT can:
- generate ordinary ISA machine code through a backend,
- model selected micro-operations in an educational simulator,
- inspect documented performance counters where permitted.
It cannot promise arbitrary microcode writes or universal control over processor internals.
