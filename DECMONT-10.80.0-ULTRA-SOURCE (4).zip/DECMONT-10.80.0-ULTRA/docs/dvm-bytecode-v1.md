# DOCMONT DVM Bytecode Container v1

Status: implemented encoder and structural/stack verifier; no bytecode interpreter or JIT yet.

## Binary layout

All integer fields are little-endian.

1. Four-byte magic: `DVMB`.
2. `u32` format version (currently `1`).
3. `u32` byte length + UTF-8 application name.
4. `u32` byte length + UTF-8 target label.
5. `u32` instruction count (maximum 1,000,000).
6. Repeated instruction records: `u8` opcode, `u32` source line, `u64` integer payload, `u32` operand byte length, operand bytes.

Opcode values follow `docmont::OpCode` in `include/docmont/ir.hpp`. The verifier checks magic, version, record boundaries, opcode range, trailing data, and evaluation-stack underflow/final depth. It rejects malformed files; it does not execute them and is not yet a cryptographic authenticity mechanism.

## CLI

```sh
docmont bytecode examples/arithmetic.docm build/arithmetic.dvm
docmont verify build/arithmetic.dvm
```

## Security and compatibility

Treat `.dvm` files as untrusted input. Verification is structural validation only; future execution must add resource limits, type verification, control-flow validation, capability checks and a versioned compatibility policy. Do not treat a valid container as a trusted or signed package.
