# DOCMONT AST Inspector (2.4.0)

The `ast` CLI command prints the parsed abstract syntax tree after lexical and syntactic parsing and semantic validation. It is intended for compiler development, debugging grammar changes, and inspecting expression precedence.

Usage:

```sh
docmont ast examples/arithmetic.docm
```

The inspector is a diagnostic view, not a serializer or a stable interchange format. The AST currently models application blocks, properties, `let` declarations, output expressions, and integer/string/binary expressions.
