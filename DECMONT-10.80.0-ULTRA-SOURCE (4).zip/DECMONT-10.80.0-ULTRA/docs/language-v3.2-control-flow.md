# DOCMONT Language 3.2 — Structured Control Flow

## Syntax

```docmont
!docmont[3]
select architecture = x86_64
application = {
    name = "BRANCH_EXAMPLE"
    let status = 1
    if (status) {
        output = "active"
    } else {
        output = "inactive"
    }
    complete
}
```

`if` accepts an integer expression. Zero is false; any nonzero value is true. `else` is optional. Blocks can contain `let`, `output`, and nested `if/else` statements.

## Scope rules

Each branch is checked with a child symbol environment. Variables declared inside a branch are not visible after that branch or in the sibling branch. The current release does not support assignment to an existing variable, functions, loops, or user-defined types.

## Lowering

- `JumpIfZero`: consumes one integer condition and branches when it is zero.
- `Jump`: unconditional branch.
- Branch targets are absolute instruction indices in the current function/program stream.
- Compiler-generated targets may equal the instruction count, representing normal program exit.

## Verification

DVM v1 validates opcodes, container boundaries, branch destinations, and stack depth along reachable control-flow paths. Control-flow merge points must have identical stack depth. Every reachable program exit must have an empty evaluation stack.

## Runtime behavior

The host interpreter and DVM runtime execute the same branch-aware IR. The C11 AOT source backend emits C labels and `goto` branches for the same instructions.
