# DOCMONT 4.50 — Default function parameters

DOCMONT 4.50 adds default values to typed function parameters in the AST interpreter.

```docmont
fn greet(name: String = "world", punctuation: String = "!") : String {
  return name + punctuation
}
output = greet()
output = greet("Ada")
```

Rules:
- A parameter default is an expression evaluated at call time.
- Defaults are evaluated left-to-right in the new function's local environment, so a later default can refer to an earlier parameter.
- Required parameters cannot follow a parameter with a default.
- Calls may omit only trailing defaulted parameters.
- Static function-contract validation checks the minimum and maximum arity.

Scope: defaults currently execute through the AST interpreter. DVM bytecode and native-C lowering do not yet have complete parity for this feature. Defaults do not introduce named arguments, overloads, or variadic parameters.
