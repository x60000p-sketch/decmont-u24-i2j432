# VLOTDEVICEMANT 3.4.0 — Advanced Functional Modules

This release turns the previously partial VLOT subsystems into working, testable host-side modules. “Implemented” here means the documented functions and CLI paths exist and are exercised by tests; it does not mean a commercial-grade GPU game engine or vendor-console SDK integration is complete.

## Modules

### VLOT_BUILD — VPAK package pipeline

`docmont vlot build <project.vlot> <output.vpak>` creates a versioned VPAK v1 bundle. It includes the project manifest and all regular files beneath the configured asset root, in deterministic path order. Each entry carries a path, byte length and FNV-1a 64-bit integrity value. `docmont vlot verify-package <file.vpak>` checks bounds, duplicate/traversal paths, checksums, truncation and trailing bytes. FNV-1a detects accidental corruption; it is not a cryptographic signature or authenticity mechanism. VPAK is a portable content package, not an executable.

### VLOT_ASSET — asset catalog

Scans the configured asset tree, rejects symlinks and unsafe paths, limits each asset to 64 MiB, total payload to 256 MiB and count to 10,000, and emits a sorted catalog with size and content hash.

### VLOT_SCENE — scene graph

Loads `VSCENE 1` files, validates IDs, parent references, finite transforms, positive scales, dimensions and cycles. Resolves hierarchical world position/scale and renders supported 2D rectangular scene nodes through the software renderer.

Scene syntax:

```text
VSCENE 1
# node id parent px py pz sx sy sz width height red green blue
node ground - 20 180 0 1 1 1 400 24 60 80 100
node crate ground 12 -40 0 1 1 1 32 32 220 140 70
```

### VLOT_RENDER — software rasterizer

Uses a color framebuffer and depth buffer, triangle rasterization, interpolated vertex colors and rectangle drawing. Scene output is exported as PPM. It is a CPU reference renderer, not a GPU renderer; Vulkan, DirectX 12 and OpenGL ES backends are not included in this release.

### VLOT_SHADER — VSHADER compiler

Parses `VSHADER 1` source, validates `lambert`/`unlit` model, normalized base color, roughness, metallic and emission, and compiles a compact VSM1 material file. The current runtime evaluates CPU material shading and can shade software-rendered triangles. This is not SPIR-V, DXIL or a GPU shader compiler.

Example:

```text
VSHADER 1
name = VLOT_Standard
model = lambert
base_color = 0.82, 0.76, 0.64
roughness = 0.48
metallic = 0.05
emission = 0.0
```

### VLOT_PHYSICS — rigid-body baseline

Provides finite-value and ID validation, gravity integration, fixed substeps, 3D axis-aligned box overlap detection, positional correction and a basic restitution impulse. It does not yet include rotations, joints, continuous collision detection, mesh collision, broadphase acceleration or a production solver.

## CLI

```bash
# Project and assets
docmont vlot inspect projects/vlot-sample/project.vlot
docmont vlot assets projects/vlot-sample/project.vlot
docmont vlot plan projects/vlot-sample/project.vlot

# Build and verify portable content package
docmont vlot build projects/vlot-sample/project.vlot build/sample.vpak
docmont vlot verify-package build/sample.vpak

# Shader source to material
docmont vlot shader-check projects/vlot-sample/assets/shaders/standard.vshader
docmont vlot shader-build projects/vlot-sample/assets/shaders/standard.vshader build/standard.vsm
docmont vlot verify-material build/standard.vsm

# Scene validation and rendering
docmont vlot scene-check projects/vlot-sample/assets/scenes/demo.vscene
docmont vlot scene-render projects/vlot-sample/assets/scenes/demo.vscene build/scene.ppm 640 360
```

## Platform status

- PC: VPAK content package generation is implemented. Native executable/game packaging from a complete VLOT game project is not yet implemented by this VLOT builder.
- Android: Gradle/NDK/JNI scaffold remains; APK generation and device testing require an installed Android SDK/NDK and were not claimed by these tests.
- PS5: profile/planning only; a real package requires authorized Sony SDK access, signing and target hardware.

## Build and tests

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j2
ctest --test-dir build --output-on-failure
```
