# DOCMONT 4.6.0 — Mesh, Camera and CPU 3D Rendering

## Compatibility
DOCMONT 4.6.0 preserves DOCMONT 3.4.0 source-language compatibility and retains the compiler, AST, interpreter, DVM bytecode, C11 source backend, VLOT host-side behavior, 4.3 math, 4.4 ECS/scene graph, and 4.5 memory/render-graph APIs. No new `.docm` syntax is introduced.

## Implemented
- `include/docmont/rendering.hpp`: validated indexed `MeshData`, finite vertex-attribute checks, and local-space AABB bounds.
- `Camera`: right-handed view matrix and validated perspective or orthographic projection.
- `MeshCatalog`: CPU-side mesh storage, unique-name lookup, duplicate-name rejection, and generation-checked handles.
- `include/docmont/renderer3d.hpp`: CPU triangle rasterizer consuming the shared `MeshData` and `Camera` APIs.
- Barycentric triangle coverage, viewport mapping, floating-point depth testing, render counters, and PPM output.
- A buildable rendering-core example in `examples/rendering_core.cpp`.
- Regression tests for valid/invalid meshes, bounds, catalog lifecycle, stale handles, camera matrices, depth ordering, and PPM output.

## Verification
- CMake Release configure/build with GNU C/C++ 14.2.0: passed.
- CTest: 3/3 passed (`docmont_tests`, `docmont_cli_contract`, `docmont_lsp_integration`).
- VS Code `npm run check`: passed.
- VS Code `npm test`: 8/8 passed.
- `docmont_rendering_example` and `docmont_engine_example`: built; examples executed successfully.
- `docmont --version`: `DOCMONT 4.6.0 (language compatibility: 3.4.0)`.
- `docmont language-info` and `project.docmont.json`: valid JSON; compiler version 4.6.0.

## Boundaries
The mesh catalog stores CPU-side data and does not allocate GPU buffers. The 3D rasterizer is CPU/software only. Triangles with a vertex behind the camera are skipped rather than clipped. Texture mapping, lighting/PBR, MSAA, multithreaded rasterization, Vulkan/DirectX/OpenGL command submission, glTF/FBX import, Android device validation, and console SDK support are not claimed.
