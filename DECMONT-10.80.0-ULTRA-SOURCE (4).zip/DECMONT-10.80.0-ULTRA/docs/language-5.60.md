# DOCMONT language/runtime 5.60.0

## Mutable closure bindings in DVM

A lambda's free variables are captured as shared binding cells. Creating another lambda over the same binding reuses the same cell, so both closures observe subsequent writes.

```docmont
!docmont[3]
application = {
 name = mutable_closure_cells
 let count = 0
 let next = fn(): Int {
   count = count + 1
   return count
 }
 let another = fn(): Int {
   count = count + 1
   return count
 }
 output = next()
 output = another()
 output = next()
 output = count
 complete
}
```

Expected DVM output:

```text
1
2
3
3
```

## Runtime model

- `LoadCell` pushes a reference to an existing variable cell.
- `MakeClosure` consumes named cell references and stores them in a closure environment.
- `CallIndirect` installs those shared cells in the callee frame.
- `Load` reads the current cell value; `Store` updates the existing cell when present.

## Scope and limitations

This behavior is currently implemented in DVM only. The AST interpreter still uses its previous environment-copy behavior, and Native-C does not lower closure cells. Free-variable analysis is not yet a complete lexical scope resolver for every nested block/shadowing case. Shared ownership can retain cycles; there is no cycle collector or tracing GC.
