# DOCMONT Roadmap

## Historical milestones: 3.0 and 3.1
- DVM v1 binary container encoder.
- Structural and stack-effect verifier.
- CLI `bytecode` and `verify`.
- Production architecture and honest capability boundaries documented.

## Planned 3.3 — Language semantics and functions
- Source spans and stable diagnostic codes.
- Explicit declaration and scope model.
- Function declarations/calls and module imports.
- Type inference rules, explicit conversions, generic constraints.
- Parser recovery and grammar conformance tests.

## Planned 3.4 — DVM hardening
- Bytecode loader and verified interpreter.
- Typed stack/register model and control-flow validation.
- Runtime limits, sandbox capabilities, deterministic errors.
- Debug metadata and bytecode disassembler.

## Planned 3.5 — Native backend
- LLVM integration behind DCC interface.
- First verified x86-64 Linux native executable.
- ABI, linker and debug-symbol tests.

## Planned 3.6 — Systems runtime
- Ownership/borrowing design, memory APIs, async/task scheduler.
- C ABI and platform service adapters.

## Planned 3.7+ — Platform and domains
- Windows and ARM64 targets, then Android integration.
- Networking, storage, GPU compute and graphics backends.
- IDE, package manager, debugger, profiler and release engineering.

A milestone is complete only when its code, documentation, tests and target-specific verification exist.

## DOCMONT 3.1.0 implementation update

Implemented in this increment:
- DVM bytecode decoding and execution (`vm-run`), in addition to encoding and verification.
- Portable C11 source backend (`native-c`) for the current stack IR. The emitted C source can be compiled by a host C compiler into a native executable. This is a C-source AOT backend, not an LLVM backend or direct object-file emitter.
- CPU software 2D rasterizer with pixel, rectangle, line, circle and PPM output.
- Android Gradle/NDK project scaffold with JNI bridge and `arm64-v8a` / `x86_64` ABI filters.

Not claimed as complete:
- DVM still has a small opcode set and no functions, branches, modules, garbage collector, debugger or JIT.
- Native backend currently targets portable C11 output; no LLVM IR/object emitter or register allocator.
- Graphics is a minimal headless CPU rasterizer, not a full game engine, GPU/Vulkan renderer, audio engine, scene graph or physics engine.
- Android source integration is present, but APK build/device testing requires an installed Android SDK/NDK and has not been performed in this environment.
- PlayStation/Xbox integration requires approved developer access and official platform SDKs. The repository does not claim console support.

## DOCMONT 3.2.0 — structured language core

Implemented and locally verified: nested `if/else` blocks, branch-local semantic scopes, branch-aware IR (`jump_if_zero` / `jump`), DVM v1 control-flow graph stack verification, DVM runtime execution of branches, and C11 AOT branch emission. The control-flow verifier checks target bounds and stack-depth agreement at reachable merge points. See `docs/language-v3.2-control-flow.md`.

Next high-priority language milestones: comparison and boolean operators, mutable assignment, function declarations/calls with typed parameters and return values, modules/imports, then loops with explicit fuel/termination safeguards. Do not advertise these as implemented until parser, semantic analysis, IR, runtime, bytecode, native backend, and tests all support them.


## VLOTDEVICEMANT hybrid engine — 3.3.0 status

Implemented foundation: strict project descriptor loading, PC/Android/PS5 target profiles, toolchain-aware planning, scene graph validation, safe asset descriptor validation, and CPU triangle rasterization with depth testing. Next: project asset import, camera/scene serialization, renderer abstraction, Vulkan desktop backend, Android Vulkan/OpenGL ES surface integration, physics/animation, then authorized console SDK adapters.


## DOCMONT 3.4.0 — VLOT advanced host modules (implemented)

- VLOT_BUILD: VPAK v1 package creation and verification with bounded, deterministic entries.
- VLOT_ASSET: sorted asset catalog, size/count limits, symlink and path traversal rejection.
- VLOT_SCENE: VSCENE 1 loader, hierarchy validation, world transforms and software 2D scene rendering.
- VLOT_RENDER: CPU triangle rasterizer with depth buffering and PPM output.
- VLOT_SHADER: VSHADER 1 parser/compiler to VSM1 CPU material format, verifier, Lambert/unlit shading.
- VLOT_PHYSICS: gravity, fixed substeps, AABB collision correction and basic restitution response.

The above are functional host-side implementations, not production-complete GPU/3D systems. VPAK is a content package, not an executable. Android APK builds remain SDK/NDK-dependent; PS5 remains dependent on authorized Sony SDKs and hardware.


## DOCMONT 4.1.0 implemented tooling increment

The 4.1.0 release preserves the 3.4.0 language/runtime behavior and adds `check --json` plus `language-info` for editor integration. The JSON diagnostics path invokes the same lexer, parser and semantic validator as the human-readable CLI. `language-info` exposes the current token spellings and implemented grammar surface. An LSP server, richer source ranges/diagnostic codes, incremental parsing and a real GPU backend remain separate future work.

## DOCMONT 4.2.0 implemented tooling increment

- Structured diagnostics now carry stable category codes and best-effort source end positions in `check --json`.
- VS Code LSP maps codes and end positions into LSP diagnostics while retaining compatibility with legacy text diagnostics.
- Compiler, CMake, manifest, Android metadata, extension and server release versions are aligned at 4.2.0 / 0.6.0.
- Language syntax/runtime remains 3.4.0 compatible. Exact parser-owned spans, cross-file module symbols, incremental parsing, and GPU backends remain future work.

## DOCMONT 4.3.0 implemented foundation

- Added `include/docmont/math.hpp`: Vec2/Vec3/Vec4, vector algebra, row-major Mat4, transforms, homogeneous point conversion, and perspective projection.
- Added regression tests for vector operations, composed transforms, projection setup, and invalid zero-vector normalization.
- Advanced compiler/CMake/project manifest/Android bridge metadata to 4.3.0 while retaining DOCMONT 3.4.0 language compatibility.

## DOCMONT 4.4.0 implemented engine core

- Added `include/docmont/engine.hpp` with generation-safe ECS entity lifecycle, typed component pools, and multi-component views.
- Added component cleanup on entity destruction and stale-handle rejection after entity-slot reuse.
- Added transform scene graph with cycle-safe reparenting and hierarchical world-matrix resolution.
- Added regression coverage for ECS lifecycle, queries, stale handles, transform composition, cycles, and invalid nodes.
- Retained the 4.3.0 math foundation and DOCMONT 3.4.0 source-language compatibility.
- This increment does not claim new `.docm` syntax, GPU execution, optimized archetype storage, rotation transforms, or console device support.


## Delivered: 4.5.0
- Quaternion transforms, aligned transient arena allocation, and backend-neutral render dependency scheduling.
- GPU API execution, full mesh pipeline, SIMD dispatch and console integrations remain future work.


## Delivered: 4.6.0

- CPU 3D camera and perspective projection.
- Indexed triangle mesh validation.
- Barycentric triangle rasterization with perspective-correct vertex-colour interpolation.
- Floating-point depth buffer and render statistics.
- PPM image output and regression test for overlapping near/far geometry.
- GPU execution, clipping, textures, PBR and platform-specific graphics APIs remain future work.


## Delivered: 4.6.0
- CPU mesh validation/catalog, local bounds, perspective/orthographic camera matrices, and rendering-core example.
- GPU command submission, shader compilation, model importers, and device-specific backends remain future work.
