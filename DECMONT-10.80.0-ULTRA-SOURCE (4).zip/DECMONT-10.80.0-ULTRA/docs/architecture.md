# DOCMONT system architecture

```text
.docm source
  -> DLEX tokenizer
  -> DGRAM parser
  -> AST
  -> DSEM type/name/meaning analysis
  -> DLOGIC constraints
  -> DOCMONT IR
  -> optimization passes
  -> backend (LLVM / target-specific)
  -> linker + platform runtime
  -> executable/package
```

The current repository implements the tokenizer, a bounded parser, AST, semantic checks, a small IR lowering pass and interpreter for `output`. The later stages are interfaces and roadmap, not silently simulated native compilation.

## Semantic model
An identifier is not understood by guessing from English alone. It is resolved through:
- token class and spelling,
- grammar position,
- declared symbol and scope,
- expected type,
- operation signature,
- constraints and target capabilities.

Ambiguous or undefined expressions must produce diagnostics rather than invented meanings.
