# DOCMONT 4.7.0 — DECOM Compute & Systems Libraries

## Compatibility

DOCMONT 4.7.0 retains the 3.4.0 `.docm` language compatibility level and all previously tested compiler, interpreter, DVM, native-C backend, ECS, scene graph, math, render graph, VLOT and CPU renderer components.

## DECOM standard library pack

The new `include/docmont/decom.hpp` exposes 31 module namespaces through the C++20 host API. The module registry is discoverable with `docmont decom-info`.

- `decom.selea`: numeric algorithms, reductions, vector arithmetic, statistics helpers and finite-value validation.
- `decom.inplot`: validated *user-space* kernel plans, worker configuration, scheduler/memory policy, bounded memory reservations and safe-mode inspection. It does not build, patch, or replace a bootable operating-system kernel.
- `arrays`, `matrix`, `vectors`, `stats`, `signal`, `interpolate`, `probability`, `random`, `optimize`, `linalg`, `tensor`, `sparse`, `graph`, `text`, `time`, `memory`, `scheduler`, `atomic_ops`, `serialization`, `hashing`, `compression`, `geometry`, `units`, `physics`, `image`, `autodiff`, `dataflow`, `numeric`, and `abi`.

The API includes bounds-checked tensor indexing, matrix operations and Gaussian elimination, moving averages and integration/differentiation, seeded PRNG, golden-section minimization, sparse COO multiplication, BFS, forward-mode automatic differentiation, region allocation, atomic counters, portable little-endian scalar serialization, FNV-1a/CRC32, and bounded RLE decompression.

## Honest implementation boundary

- 31 modules are registered; capability-slot counts are descriptive registry metadata, not a claim of 1,000 implemented algorithms.
- The new APIs are C++20 header APIs. The `.docm` parser/type system does not yet support source-level `import decom.selea` or direct calls into these modules.
- `decom.inplot` constructs a validated runtime plan in user space; it is not an OS kernel generator, driver builder, hypervisor, or hardware microcode tool.
- The current compute implementation is CPU-side. No GPU kernel execution, JIT, distributed runtime, cryptographic library, or native console SDK support is claimed.
- Hashing functions are checksums/non-cryptographic hashes and must not be used for password storage or security signatures.

## Verification

The release is built with CMake/C++20. Tests cover numeric reductions, statistics, matrix multiplication, Gaussian elimination, kernel-plan validation/reservation, ABI discovery, RLE round-trip, serialization round-trip, autodiff, graph BFS, tensors, sparse multiplication, optimization, image inversion and text trimming, alongside the existing DOCMONT tests.
