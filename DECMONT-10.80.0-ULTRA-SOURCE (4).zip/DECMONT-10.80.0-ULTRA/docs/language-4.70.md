# DOCMONT 4.70.0 — Shared Mutable Closure Captures

DOCMONT lambda closures now capture lexical variable cells by shared ownership rather than copying each captured value. A closure can therefore update a captured binding, and the updated value remains visible to the surrounding scope and to other closures that captured the same binding.

```docmont
!docmont[3]
application = {
 name = counter
 let count = 0
 let next = fn(): Int {
   count = count + 1
   return count
 }
 output = next()
 output = next()
 output = count
 complete
}
```

Expected output:

```text
1
2
2
```

The change is implemented in the AST interpreter's environment representation using shared value cells. It does not claim DVM bytecode or native backend parity. Closure lifetime is managed by `std::shared_ptr`; cyclic closure/environment references are not collected by a tracing GC. Capture semantics are by shared binding cell, not by deep-copying captured arrays/objects.
