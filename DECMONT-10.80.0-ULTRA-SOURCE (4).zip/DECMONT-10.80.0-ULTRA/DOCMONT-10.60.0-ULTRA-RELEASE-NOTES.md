# DECMONT 10.60.0 ULTRA — Release Notes

## Native heap lifecycle expansion

- Generated C11 programs now register each successfully allocated native array in a bounded process-local registry.
- Registry limit: 65,536 array objects per generated program.
- Existing aggregate array capacity limit remains 1,000,000 `Value` slots.
- Every registered array payload and header is released by a single `atexit` cleanup routine. This also runs when generated code returns early after a runtime error.
- Registration is transactional: a failed registry growth releases the just-created array and does not consume operand-stack entries.
- Arrays are registered once, so aliases in variables/stack do not cause duplicate frees.
- Existing native array bounds/type checks and stack/CFG verifier remain enabled.

## Compatibility

- Language compatibility: 3.4.0.
- DVM bytecode compatibility: v1.
- Native C11 remains a documented opcode subset, not full-language parity.

## Verification scope

Build and tests are performed on the current Linux x86_64 environment. Other platforms require their own toolchains and CI validation.
