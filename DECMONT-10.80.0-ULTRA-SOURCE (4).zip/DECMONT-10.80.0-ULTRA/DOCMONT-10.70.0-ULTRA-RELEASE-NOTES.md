# DECMONT 10.70.0 ULTRA — Release Notes

## Native array heap budget and accounting

This release extends the restricted Native C11 array backend with deterministic payload-byte accounting and a hard 64 MiB aggregate array-payload budget per generated program. Array creation checks the remaining byte budget before allocation. Dynamic growth checks both the remaining element budget and byte budget, guards capacity multiplication, and commits accounting only after successful `realloc`. Cleanup releases array payloads and headers and resets counters.

Existing limits remain: 1,000,000 array capacity slots and 65,536 registered array objects. This is bounded allocation accounting, not a tracing garbage collector. Arrays remain process-lifetime allocations and are reclaimed at process exit via `atexit`.

Language compatibility remains 3.4.0. Native C11 lowering remains a restricted opcode subset; DVM remains the portable execution path.
