# DOCMONT 10.00.0 ULTRA — Capability Matrix

| Area | 10.00.0 status | Scope |
|---|---|---|
| Frontend / parser | Implemented | Existing supported grammar; compatibility 3.4.0 |
| Typed HIR / MIR / SSA | Implemented | Existing typed and SSA pipeline |
| Optimizer | Implemented | Existing optimization passes and analyses |
| DVM | Implemented | Bytecode v1 and portable VM |
| Native CPU | Partial | Restricted integer MIR to LLVM IR/object; Clang target/toolchain required |
| x86-64 Linux | Host build | Current source build target; validate on host |
| AArch64 / RISC-V / WASM | Partial | Object emission depends on Clang targets; runtime/link validation separate |
| GLES | Partial | Offscreen rendering and tensor compute APIs; hardware acceleration is runtime-dependent |
| Vulkan | Probe only / partial | Loader/device/queue probe; no complete renderer or command submission path |
| D3D12 / Metal | Platform adapter/probe | No complete renderer claim |
| Render graph | Implemented foundation | Scheduling, lifetimes, transient alias plan and barriers |
| Game engine | Foundation | ECS/scene, AABB physics, navigation and animation foundations; not a full AAA engine |
| AI / ONNX | Partial | Bounded CPU operator subset; GLES tensor APIs are separate; no general GPU ONNX provider |
| System doctor | Implemented | Reports actual host/backend availability and known implementation limits |
| Windows / macOS / Android / iOS | Requires toolchain/device validation | Cross-build and runtime testing required |
| PS5 / Xbox | Requires official vendor SDK | No SDK/devkit validation claimed |

A status of `implemented` applies only to the stated scope. Backend probes and source-level adapters are not evidence of a complete renderer or hardware-tested platform release.
