# DOCMONT 9.30.0 ULTRA — Platform Matrix

| Target | Build/Runtime status in this release | Notes |
|---|---|---|
| Linux x86_64 | Built and tested | GNU C/C++, CMake/Ninja |
| Linux GLES | Executed and tested | OpenGL ES 3.2 Mesa llvmpipe software renderer |
| Linux physical GPU | Not verified | No hardware acceleration claim |
| Vulkan | Probe only | No full renderer/presentation path |
| Windows x64 | Preset/toolchain | Native Windows build not run here |
| macOS universal | Preset/toolchain | Xcode/Metal build not run here |
| Android ARM64 | NDK toolchain preset | Native Android build/device test not run here |
| PS5 | Licensed SDK adapter | Requires private official SDK and devkit; not tested here |
| Xbox Series | GDK adapter | Requires private official SDK and devkit; not tested here |
| WebAssembly | Existing target/object foundations | Not a complete game runtime target |

A target is not production-supported solely because a preset or adapter exists. Require successful native compile, link, runtime, packaging and platform validation.
