# DOCMONT 4.15.0

## Implemented
- New AST interpreter used by `docmont run`.
- `main()` function entry point; top-level statements remain supported when no `main` exists.
- Function declarations, positional arguments, local environments, nested calls and `return`.
- Integer and string values, array literals and array display.
- Integer arithmetic with signed 64-bit overflow checks and division-by-zero diagnostics.
- `if`/`else` execution and `output` statements.
- Runtime limits: 1,000,000 evaluation/statement steps and 128 nested function calls.
- End-to-end source program: `examples/runtime_4_15.docm`.

## Verified
- GNU C/C++ 14.2.0, CMake Release build.
- CTest: 3/3 tests passed, including CLI execution of the new `.docm` example and VS Code LSP integration.
- Example output:
  DOCMONT 4.15.0
  20
  [10, 20, 30, 40]

## Not implemented in this release
- Array indexing or mutation, loops, closures, floating-point runtime values, user-defined objects.
- Function/array support in DVM bytecode or the C11 native backend. `docmont run` currently uses the AST interpreter for these source-language features.
- Direct DOCMONT bindings to all DECOM numerical library APIs.
