# DOCMONT 4.16.0

## Runtime and language additions
- `for item in array { ... }` foreach iteration over array values.
- Array index reads with `array[index]`.
- Array element writes with `array[index] = value`.
- Variable reassignment with `name = expression`.
- Runtime checks for non-array iteration, invalid index types, and out-of-range indices.
- Compiler version and language-info metadata updated to 4.16.0.

## Compatibility
- Keeps the 4.15.0 function-call and interpreter runtime behavior.
- Language header compatibility remains `!docmont[3]`.
- Does not claim while-loops, break/continue, multidimensional array type checking, or DVM bytecode execution of these new constructs.
