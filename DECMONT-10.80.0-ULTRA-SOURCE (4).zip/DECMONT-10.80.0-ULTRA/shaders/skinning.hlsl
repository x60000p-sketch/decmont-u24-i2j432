struct VSIn { float3 position:POSITION; float3 normal:NORMAL; uint4 joints:BLENDINDICES; float4 weights:BLENDWEIGHT; };
StructuredBuffer<float4x4> Bones:register(t0);
cbuffer Camera:register(b0){float4x4 ViewProjection;}
struct VSOut { float4 position:SV_Position; float3 normal:NORMAL; };
VSOut main(VSIn v){float4x4 s=Bones[v.joints.x]*v.weights.x+Bones[v.joints.y]*v.weights.y+Bones[v.joints.z]*v.weights.z+Bones[v.joints.w]*v.weights.w;float4 p=mul(s,float4(v.position,1));VSOut o;o.position=mul(ViewProjection,p);o.normal=normalize(mul((float3x3)s,v.normal));return o;}
