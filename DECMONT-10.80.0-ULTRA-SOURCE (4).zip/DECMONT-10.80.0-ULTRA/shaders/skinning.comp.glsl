#version 450
layout(local_size_x=64) in;
struct Vertex { vec4 position; vec4 normal; uvec4 joints; vec4 weights; };
layout(set=0,binding=0,std430) readonly buffer InputVertices { Vertex src[]; } inputVertices;
layout(set=0,binding=1,std430) writeonly buffer OutputVertices { Vertex dst[]; } outputVertices;
layout(set=0,binding=2,std430) readonly buffer SkinPalette { mat4 bones[]; } palette;
layout(push_constant) uniform Params { uint vertexCount; } params;
void main(){uint i=gl_GlobalInvocationID.x;if(i>=params.vertexCount)return;Vertex v=inputVertices.src[i];mat4 m=palette.bones[v.joints.x]*v.weights.x+palette.bones[v.joints.y]*v.weights.y+palette.bones[v.joints.z]*v.weights.z+palette.bones[v.joints.w]*v.weights.w;v.position=m*v.position;v.normal=vec4(normalize(mat3(m)*v.normal.xyz),0);outputVertices.dst[i]=v;}
