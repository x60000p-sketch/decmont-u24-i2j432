#include <metal_stdlib>
using namespace metal;
struct VertexIn { float3 position; float3 normal; ushort4 joints; float4 weights; };
struct VertexOut { float4 position [[position]]; float3 normal; };
struct Camera { float4x4 viewProjection; };
vertex VertexOut docmont_skin_vertex(const device VertexIn* vertices [[buffer(0)]],
                                     const device float4x4* bones [[buffer(1)]],
                                     constant Camera& camera [[buffer(2)]],
                                     uint id [[vertex_id]]) {
    VertexIn v=vertices[id];float4x4 skin=bones[v.joints.x]*v.weights.x+bones[v.joints.y]*v.weights.y+bones[v.joints.z]*v.weights.z+bones[v.joints.w]*v.weights.w;
    float4 world=skin*float4(v.position,1);VertexOut o;o.position=camera.viewProjection*world;o.normal=normalize((float3x3)skin*v.normal);return o;
}
