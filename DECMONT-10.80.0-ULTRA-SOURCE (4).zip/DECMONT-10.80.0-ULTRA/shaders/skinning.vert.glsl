#version 450
layout(location=0) in vec3 inPosition;
layout(location=1) in vec3 inNormal;
layout(location=2) in uvec4 inJoints;
layout(location=3) in vec4 inWeights;
layout(set=0,binding=0) uniform Camera { mat4 viewProjection; } camera;
layout(set=0,binding=1,std430) readonly buffer SkinPalette { mat4 bones[]; } palette;
layout(location=0) out vec3 worldNormal;
void main(){
    mat4 skin = palette.bones[inJoints.x]*inWeights.x + palette.bones[inJoints.y]*inWeights.y +
                palette.bones[inJoints.z]*inWeights.z + palette.bones[inJoints.w]*inWeights.w;
    vec4 world = skin * vec4(inPosition,1.0);
    worldNormal = normalize(mat3(skin)*inNormal);
    gl_Position = camera.viewProjection * world;
}
