#version 450
layout(location=0) in vec3 worldNormal;
layout(location=0) out vec4 outColor;
layout(push_constant) uniform Material { vec4 baseColor; float metallic; float roughness; } material;
void main(){vec3 N=normalize(worldNormal),V=vec3(0,0,1),L=normalize(vec3(0.5,0.8,0.3)),H=normalize(V+L);float ndl=max(dot(N,L),0),ndv=max(dot(N,V),0),ndh=max(dot(N,H),0),vdh=max(dot(V,H),0);float a=max(material.roughness*material.roughness,0.002),a2=a*a;float den=ndh*ndh*(a2-1)+1;float D=a2/(3.14159265*den*den);float k=(material.roughness+1)*(material.roughness+1)/8;float G=(ndv/(ndv*(1-k)+k))*(ndl/(ndl*(1-k)+k));vec3 F0=mix(vec3(0.04),material.baseColor.rgb,material.metallic);vec3 F=F0+(1-F0)*pow(1-vdh,5);vec3 spec=D*G*F/max(4*ndv*ndl,0.001);vec3 diff=(1-F)*(1-material.metallic)*material.baseColor.rgb/3.14159265;vec3 hdr=(diff+spec)*ndl*3.0;vec3 x=max(hdr,vec3(0));vec3 mapped=clamp((x*(2.51*x+0.03))/(x*(2.43*x+0.59)+0.14),0,1);outColor=vec4(mapped,material.baseColor.a);}
