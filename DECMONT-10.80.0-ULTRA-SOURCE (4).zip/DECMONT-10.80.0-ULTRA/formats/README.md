Source: `.docm` (UTF-8). Planned compiled package: `.dco`. Planned AST: `.docast`. Planned IR: `.docir`. Binary/hex dumps are inspection formats and are not source-language substitutes.
