# DOCMONT 8.90.0 ULTRA — Implementation Report

## Release identity
- Compiler: 8.90.0
- Language compatibility: 3.4.0
- DVM bytecode: v1 (unchanged)
- Verified host: Linux x86_64

## Implemented in 8.90.0

### Project format and template
- `docmont.toml` with `[project]`, `[engine]`, and `[assets]` sections.
- Standard `src/`, `assets/scenes`, `assets/models`, `assets/textures`, `assets/audio`, `assets/shaders`, and `tests/` layout.
- Starter `.docm` entry and valid JSON `.dscene` file.

### Project lifecycle tool
- `new`: safe identifier validation and complete workspace scaffolding.
- `check`: TOML decoding, mandatory fields, entry existence/type, safe path resolution, symlink containment, scene JSON validation, asset-manifest freshness, and compiler source checks.
- `assets`: recursive inventory with asset type, extension, byte size and SHA-256.
- `build`: compiler `check`, DVM emission, bytecode verifier, DVM smoke execution, and `build/build-manifest.json`.
- `package`: reproducible ZIP with sorted entries and fixed timestamps; generated build, dist, install, cache, VCS and backup paths excluded.
- subprocess calls use argument arrays and `shell=False`; timeouts and nonzero exits are surfaced as errors.

### Studio integration
- `/api/project` returns project/scene/source/asset metadata.
- `/api/project/check`, `/api/project/assets`, `/api/project/build`, `/api/project/package` invoke fixed project-tool operations.
- Studio header includes Project Check, Build and Package buttons.
- The editor continues to bind to localhost only and sandbox paths under its workspace.

### Build and release engineering
- CMake Release/Debug presets.
- Installation of compiler, static library, public headers, project tool, Studio, shaders, platform manifests, docs and starter template.
- CI config sets Python 3.11 to guarantee the standard-library TOML parser.
- End-to-end test covers scaffold, project check, asset hashing, stale asset rejection, bytecode build/verify/run, deterministic package, invalid scene rejection and path traversal rejection.

## Test evidence
- CMake Release build completed successfully.
- CTest: 72/72 passed.
- LSP integration CTest passed.
- Standalone VS Code tests: 8/8 passed.
- `npm run check`: passed.
- Studio smoke test: project dashboard/check/build/package endpoints passed.
- Installed-prefix test: installed `docmont`, `docmont-project`, and `docmont-studio` launched; a generated project was checked, built, verified, executed, and packaged.
- `examples/game-starter` passed project check and DVM build/verification/run.
- Reproducible package check: two packages from the same project produced matching SHA-256.

## Retained foundations from 8.80.0
- Existing compiler, parser, optimizer, SSA and DVM implementation.
- CPU game systems: ECS/scene, asset catalog, world cells, AABB physics, navigation, AI behavior foundations, CPU PBR/ACES reference, skeletal animation/CPU skinning.
- TCP/UDP transport and snapshot codec.
- Limited CPU ONNX inference.
- Vulkan capability probe, console SDK manifest validation and local Visual Game Studio.

## Explicit limits
- The project builder currently compiles the entry `.docm` to portable DVM v1. It does not compile full game projects to a native executable or process all assets/shaders into runtime-ready formats.
- Asset validation inventories bytes and verifies hashes; it does not parse every image/model/audio container or perform complete import/cooking.
- Studio is a local workspace and project manager, not a fully featured realtime 3D editor.
- Graphics backends, GPU execution, full ONNX, audio device playback, TLS/authenticated multiplayer, production physics and console SDK integration remain incomplete as documented in the capability matrix.
- Only Linux x86_64 was built and exercised in this release. Windows/macOS CI jobs are configured but not executed from this environment.

## Build warnings
The Release build succeeds. The pre-existing C++ sources still emit non-fatal warnings in `function_semantics.cpp` and `bytecode.cpp`; no warning-free claim is made.
