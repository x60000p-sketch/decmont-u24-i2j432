# DECMONT 10.40.0 changelog

- Expanded native C11 opcode lowering with BoolNot, Equal, NotEqual, ordered integer comparisons, LogicalAnd and LogicalOr.
- Added C string-content equality via `strcmp`; unlike pointer comparison, equal string contents compare equal.
- Added runtime type guards for boolean and ordered integer operations.
- Preserved checked arithmetic, branch verification and stack/instruction safety caps from 10.20/10.30.
- Added dedicated native-backend regression tests.
- Updated compiler CLI metadata, CMake project version and VS Code integration metadata to 10.40.0.
- Preserved language compatibility 3.4.0 and DVM bytecode v1.
