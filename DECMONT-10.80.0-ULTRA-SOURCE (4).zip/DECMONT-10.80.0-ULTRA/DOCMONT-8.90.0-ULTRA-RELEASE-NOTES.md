# DOCMONT 8.90.0 ULTRA — Release Notes

DOCMONT 8.90.0 focuses on project integration and day-to-day usability. It takes the 8.80.0 ULTRA systems and adds a standard project format, a safe project lifecycle tool, deterministic packaging, and first-class Studio project actions.

## Main deliverable

The new `docmont-project` utility provides a consistent workflow from project creation through verification and packaging:

1. `new` creates a full starter game project.
2. `check` validates the project manifest, entry source, scene JSON, asset manifest and compiler diagnostics.
3. `assets` creates or refreshes a SHA-256 asset inventory.
4. `build` emits DVM v1, verifies the bytecode, runs a smoke test, and records the artifact hash.
5. `package` creates a deterministic source/assets ZIP.

Visual Game Studio uses these same operations through Project Check, Build and Package actions. Path traversal and symlink escapes are rejected; the server remains localhost-only.

## Build

```bash
cmake --preset linux-release
cmake --build --preset release
ctest --preset release
cmake --install build/release
```

Requirements: CMake 3.20+, C++20 compiler, Python 3.11+ for project tooling and Studio, and Node.js for VS Code extension tests.

## Try a project

```bash
export DOCMONT_EXECUTABLE="$PWD/build/release/docmont"
tools/docmont-project new MyGame
cd MyGame
docmont-project check .
docmont-project assets .
docmont-project build .
docmont-project package .
```

A starter project is also included at `examples/game-starter`.

## Verified results

- 72/72 CTest passed.
- 8/8 VS Code LSP tests passed.
- JavaScript syntax checks passed.
- Installed compiler, project tool and Studio smoke tests passed.
- DVM project artifact compiled, verified and smoke-ran.
- Two packages generated from the same project had identical SHA-256 hashes.

## What this release does not claim

The project build emits portable DVM bytecode. It is not yet a complete native game compiler, asset cooker, shader compiler or platform release packager. GPU render backends for Vulkan, Direct3D 12 and Metal are not production implementations; ONNX is a CPU operator subset; audio playback, secured production multiplayer, and console certification remain incomplete. The tested binary is Linux x86_64 only.
