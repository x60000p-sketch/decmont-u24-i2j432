# DOCMONT 9.00.0 ULTRA — Implementation Report

## Summary

DOCMONT 9.00.0 builds on 8.90.0 and focuses on operationalizing the Native, AI, shader, cross-platform and licensed-console integration routes without claiming unavailable platform certification.

## Implemented changes

### 1. ONNX CPU runtime expansion

Added bounded float32 CPU implementations for:
- broadcast Sub, Div, Pow, Max and Min (division-by-zero is rejected);
- Flatten, Transpose, ReduceMean and Concat;
- Clip, LeakyRelu, Elu, Softplus and HardSigmoid.

Attribute decoding now retains packed integer attributes such as Transpose `perm` and ReduceMean `axes`. Existing loader checks for protobuf validity, output definitions, finite tensors and allocation limits remain in force. The supported catalogue is 23 operators, not the full ONNX standard.

### 2. Native build workflow

Added `tools/docmont-native-build`. It calls the verified direct-MIR LLVM object path, then links a host executable for `x86_64-unknown-linux-gnu`. Cross targets can request object-only output. Tests compile/link/run the x86_64 example (exit status 42) and generate an AArch64 object. The direct MIR subset is still restricted to the currently supported integer main-function operations.

### 3. Shader toolchain integration

Added `tools/docmont-shader-build`:
- Vulkan GLSL via glslc or glslangValidator;
- D3D12 HLSL via DXC;
- Metal source via Xcode `xcrun metal`.

The wrapper validates tool availability, target flags and nonempty output. The test uses a fixture compiler; this release environment did not have a real shader compiler, so no SPIR-V/DXIL/AIR artifact is claimed.

### 4. GPU platform probes

Vulkan's existing loader/instance/device/queue probe is retained. The environment exposes `libvulkan.so.1`, but no working ICD or physical device. Windows builds now have a native D3D12 device/direct-queue probe; Apple builds have a native Metal device/command-queue probe in Objective-C++. These are device-initialization probes, not renderers or compute submission backends. Linux builds use explicit platform stubs for D3D12/Metal.

### 5. Licensed console SDK adapter

Added `tools/docmont-console-build` plus PS5/Xbox manifest templates. The manifest identifies an SDK root, version, compiler, optional linker, include directory and official CMake toolchain. The tool:
- verifies required keys and platform identity;
- requires explicit `license_acknowledged=true`;
- checks compiler/toolchain/header paths remain inside the SDK root;
- configures and builds an existing vendor-compatible CMake project with the vendor's toolchain;
- supports dry-run.

The tool does not copy vendor files, sign binaries, deploy to devkits, or bypass platform checks. Tests use a fake SDK fixture and fake CMake dispatcher. The actual user's licensed Sony SDK was not mounted in this build environment, so no real PS5 build or certification is claimed.

### 6. Platform configuration

Added CMake presets for Windows MSVC x64, macOS Universal (arm64+x86_64) and Android arm64-v8a. Added Android NDK and console toolchain bridge files. These are configuration entries only until built on the corresponding OS/SDK.

### 7. SDK installation package

CMake now installs a package config and exported `DOCMONT::docmont_core` target, in addition to compiler, headers, static library, Studio and build tools.

## Validation

- CMake Release build: passed on Linux x86_64.
- CTest: 76/76 passed.
- VS Code LSP integration: 8/8 passed independently.
- `npm run check`: passed.
- Installed prefix smoke test: compiler and tools available after independent install.
- ONNX extended operator fixture suite: passed.
- Native builder: host executable linked and ran with the expected process status; AArch64 object emitted.
- Console driver: manifest validation, license gate, dry-run and CMake configure/build dispatch tested with fake SDK fixtures.
- Shader router: compiler selection, target flags, dry-run and generated artifact validation tested with a fake compiler.

## Compatibility

- Compiler version: 9.00.0.
- Language compatibility: 3.4.0.
- DVM bytecode version: v1 unchanged.

## Not complete

- Full Vulkan, D3D12 and Metal renderers/compute pipelines.
- GPU ONNX provider.
- Full ONNX operator set and dtypes.
- Full direct-native compilation of all DOCMONT/game-engine source.
- Real shader toolchain compilation in this environment.
- Real PlayStation build, packaging, signing or devkit execution (SDK absent from this environment).
- Windows, macOS and Android builds/devices.
- Console certification.

### Additional release-package validation

- The installed CMake package was consumed by an independent external C++ project using `find_package(DOCMONT 9.0 CONFIG REQUIRED)` and `DOCMONT::docmont_core`; that consumer compiled and ran successfully.
- The installed `docmont-project` tool completed a fresh starter lifecycle: `new`, `check`, `assets`, `build`, DVM verification/smoke execution, and deterministic `package`.
- The installed native, console and shader tool entrypoints returned their expected help/usage output.
