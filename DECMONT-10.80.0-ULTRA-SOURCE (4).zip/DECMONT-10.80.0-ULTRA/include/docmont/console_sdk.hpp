#pragma once
#include <string>

namespace docmont::platform {
enum class ConsolePlatform { PlayStation5, XboxSeries };
struct ConsoleSdkProbe {
    ConsolePlatform platform{ConsolePlatform::PlayStation5};
    bool manifest_found{false};
    bool sdk_root_found{false};
    bool compiler_found{false};
    bool cmake_toolchain_found{false};
    bool headers_found{false};
    bool license_acknowledged{false};
    bool adapter_configured{false};
    bool hardware_validated{false}; // deliberately false until vendor/hardware validation occurs
    std::string sdk_version;
    std::string detail;
};
ConsoleSdkProbe probe_console_sdk(ConsolePlatform platform,const std::string& manifest_path);
std::string to_string(ConsolePlatform platform);
} // namespace docmont::platform
