#pragma once
#include "docmont/ast.hpp"
#include <cstdint>
#include <string>
#include <vector>
namespace docmont {
enum class OpCode { PushInt, PushString, Load, Store, Add, Sub, Mul, Div, Print, Jump, JumpIfZero, BoolNot, Equal, NotEqual, Less, LessEqual, Greater, GreaterEqual, LogicalAnd, LogicalOr, MakeArray, ArrayGet, ArraySet, ArrayLength, ArrayPush, ArrayPop, Dup, NewObject, ObjectGet, ObjectSet, ObjectHas, Function, Call, Return, LoadFunction, CallIndirect, MakeClosure, LoadCell };
struct Instruction { OpCode op; std::string operand; std::int64_t integer{0}; int line{1}; };
struct ProgramIR { std::string name; std::string target; std::vector<Instruction> code; };
ProgramIR lower_to_ir(const Application& app);
std::string dump_ir(const ProgramIR& ir);
}
