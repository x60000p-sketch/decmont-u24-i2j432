#pragma once
#include <algorithm>
#include <cstddef>
#include <optional>
#include <queue>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace docmont::render {
using ResourceId = std::size_t;
using PassId = std::size_t;
struct PassDesc {
    std::string name;
    std::vector<ResourceId> reads;
    std::vector<ResourceId> writes;
    std::vector<PassId> depends_on;
};
struct CompileResult {
    bool ok{false};
    std::vector<PassId> order;
    std::string error;
};
struct ResourceDesc {
    std::string name;
    std::size_t bytes{0};
    std::size_t alignment{256};
    bool imported{false};
    bool transient{true};
};
struct ResourceLifetime {
    ResourceId resource{};
    std::size_t first_pass{}, last_pass{};
    std::size_t alias_slot{static_cast<std::size_t>(-1)};
};
struct ResourceBarrier {
    ResourceId resource{};
    PassId source{}, destination{};
};
struct AllocationSlot { std::size_t id{}, capacity{}, alignment{}; std::size_t last_use{}; };
struct DetailedCompileResult {
    bool ok{false};
    std::vector<PassId> order;
    std::vector<ResourceLifetime> lifetimes;
    std::vector<AllocationSlot> transient_allocations;
    std::vector<ResourceBarrier> barriers;
    std::string error;
};

// Backend-neutral render/compute dependency graph. It schedules work only;
// it does not claim to submit GPU commands or allocate API resources.
class RenderGraph {
public:
    ResourceId resource(std::string name, bool imported = false) {
        if (name.empty() || resource_names_.count(name)) throw std::invalid_argument("resource name is empty or duplicated");
        const auto id = resource_names_.size();
        resource_names_.emplace(name, id);
        imported_.insert(id);
        if (!imported) imported_.erase(id);
        resource_descs_.push_back(ResourceDesc{std::move(name), 0, 256, imported, !imported});
        return id;
    }
    ResourceId resource(ResourceDesc desc) {
        if (desc.name.empty() || resource_names_.count(desc.name)) throw std::invalid_argument("resource name is empty or duplicated");
        if (desc.alignment == 0 || (desc.alignment & (desc.alignment - 1)) != 0)
            throw std::invalid_argument("resource alignment must be a nonzero power of two");
        if (desc.imported && desc.transient) throw std::invalid_argument("imported resources cannot be transient allocations");
        const auto id = resource_names_.size();
        resource_names_.emplace(desc.name, id);
        if (desc.imported) imported_.insert(id);
        resource_descs_.push_back(std::move(desc));
        return id;
    }
    PassId pass(PassDesc desc) {
        if (desc.name.empty()) throw std::invalid_argument("pass name must not be empty");
        for (const auto& p : passes_) if (p.name == desc.name) throw std::invalid_argument("pass name is duplicated");
        validate_ids(desc.reads); validate_ids(desc.writes);
        for (auto dep : desc.depends_on) if (dep >= passes_.size()) throw std::invalid_argument("pass dependency is invalid or forward-referenced");
        const auto id = passes_.size();
        passes_.push_back(std::move(desc));
        return id;
    }
    std::size_t pass_count() const noexcept { return passes_.size(); }
    std::size_t resource_count() const noexcept { return resource_names_.size(); }

    CompileResult compile() const {
        const std::size_t n = passes_.size();
        std::vector<std::unordered_set<PassId>> edges(n);
        std::vector<std::size_t> indegree(n, 0);
        auto edge = [&](PassId from, PassId to) {
            if (from != to && edges[from].insert(to).second) ++indegree[to];
        };
        std::unordered_map<ResourceId, PassId> last_writer;
        std::unordered_map<ResourceId, std::vector<PassId>> readers;
        for (PassId i = 0; i < n; ++i) {
            const auto& p = passes_[i];
            for (auto dep : p.depends_on) edge(dep, i);
            for (auto r : p.reads) {
                auto w = last_writer.find(r);
                if (w == last_writer.end() && !imported_.count(r))
                    return {false, {}, "resource read before first write: " + resource_name(r)};
                if (w != last_writer.end()) edge(w->second, i);
                readers[r].push_back(i);
            }
            for (auto w : p.writes) {
                auto previous = last_writer.find(w);
                if (previous != last_writer.end()) edge(previous->second, i);
                for (auto reader : readers[w]) edge(reader, i);
                readers[w].clear();
                last_writer[w] = i;
            }
        }
        // A min-heap makes the topological result deterministic for independent passes.
        std::priority_queue<PassId, std::vector<PassId>, std::greater<PassId>> ready;
        for (PassId i = 0; i < n; ++i) if (indegree[i] == 0) ready.push(i);
        std::vector<PassId> order; order.reserve(n);
        while (!ready.empty()) {
            auto current = ready.top(); ready.pop(); order.push_back(current);
            for (auto next : edges[current]) if (--indegree[next] == 0) ready.push(next);
        }
        if (order.size() != n) return {false, {}, "render graph contains a dependency cycle"};
        return {true, std::move(order), {}};
    }
    DetailedCompileResult compile_detailed() const {
        const auto base = compile();
        if (!base.ok) return {false, {}, {}, {}, {}, base.error};
        DetailedCompileResult result;
        result.ok = true;
        result.order = base.order;
        const auto unused = static_cast<std::size_t>(-1);
        std::vector<std::size_t> position(passes_.size(), unused);
        for (std::size_t i = 0; i < base.order.size(); ++i) position[base.order[i]] = i;
        std::vector<ResourceLifetime> lives(resource_descs_.size());
        for (std::size_t r = 0; r < resource_descs_.size(); ++r) lives[r] = {r, unused, 0, unused};
        for (std::size_t p = 0; p < passes_.size(); ++p) {
            const auto order_pos = position[p];
            for (auto r : passes_[p].reads) { auto& l = lives[r]; l.first_pass = std::min(l.first_pass, order_pos); l.last_pass = std::max(l.last_pass, order_pos); }
            for (auto r : passes_[p].writes) { auto& l = lives[r]; l.first_pass = std::min(l.first_pass, order_pos); l.last_pass = std::max(l.last_pass, order_pos); }
        }
        std::vector<ResourceLifetime> transient;
        for (const auto& life : lives) {
            if (life.first_pass == unused) continue; // unused resource consumes no allocation
            result.lifetimes.push_back(life);
            const auto& desc = resource_descs_[life.resource];
            if (desc.transient && !desc.imported && desc.bytes) transient.push_back(life);
        }
        std::sort(transient.begin(), transient.end(), [](const auto& a, const auto& b) {
            if (a.first_pass != b.first_pass) return a.first_pass < b.first_pass;
            return a.resource < b.resource;
        });
        for (auto life : transient) {
            const auto& desc = resource_descs_[life.resource];
            std::size_t chosen = unused;
            for (auto& slot : result.transient_allocations) {
                if (slot.last_use < life.first_pass && slot.capacity >= desc.bytes && slot.alignment >= desc.alignment) { chosen = slot.id; break; }
            }
            if (chosen == unused) {
                chosen = result.transient_allocations.size();
                result.transient_allocations.push_back({chosen, desc.bytes, desc.alignment, life.last_pass});
            } else {
                auto& slot = result.transient_allocations[chosen];
                slot.last_use = life.last_pass;
            }
            for (auto& stored : result.lifetimes) if (stored.resource == life.resource) { stored.alias_slot = chosen; break; }
        }
        std::vector<std::optional<PassId>> last_writer(resource_descs_.size());
        std::vector<std::vector<PassId>> readers_since_write(resource_descs_.size());
        for (auto pid : base.order) {
            const auto& pass = passes_[pid];
            for (auto r : pass.reads) {
                if (last_writer[r] && *last_writer[r] != pid) result.barriers.push_back({r, *last_writer[r], pid});
                readers_since_write[r].push_back(pid);
            }
            for (auto r : pass.writes) {
                if (last_writer[r] && *last_writer[r] != pid) result.barriers.push_back({r, *last_writer[r], pid});
                for (auto reader : readers_since_write[r]) if (reader != pid) result.barriers.push_back({r, reader, pid});
                readers_since_write[r].clear();
                last_writer[r] = pid;
            }
        }
        std::sort(result.barriers.begin(), result.barriers.end(), [](const auto& a, const auto& b) {
            if (a.destination != b.destination) return a.destination < b.destination;
            if (a.resource != b.resource) return a.resource < b.resource;
            return a.source < b.source;
        });
        result.barriers.erase(std::unique(result.barriers.begin(), result.barriers.end(), [](const auto& a, const auto& b) {
            return a.resource == b.resource && a.source == b.source && a.destination == b.destination;
        }), result.barriers.end());
        return result;
    }
private:
    void validate_ids(const std::vector<ResourceId>& ids) const {
        for (auto id : ids) if (id >= resource_names_.size()) throw std::invalid_argument("pass references an unknown resource");
    }
    std::string resource_name(ResourceId id) const {
        for (const auto& item : resource_names_) if (item.second == id) return item.first;
        return "<unknown>";
    }
    std::unordered_map<std::string, ResourceId> resource_names_;
    std::unordered_set<ResourceId> imported_;
    std::vector<ResourceDesc> resource_descs_;
    std::vector<PassDesc> passes_;
};
} // namespace docmont::render
