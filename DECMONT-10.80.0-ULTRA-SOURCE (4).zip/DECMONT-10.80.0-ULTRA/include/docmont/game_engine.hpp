#pragma once

#include "docmont/math.hpp"
#include "docmont/render_graph.hpp"
#include <cstdint>
#include <functional>
#include <optional>
#include <span>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

namespace docmont::game {

// Game-runtime foundations for DOCMONT ULTRA. These APIs are CPU-side and
// backend-neutral unless explicitly documented otherwise.

enum class AssetKind { Mesh, Texture, Material, Shader, Audio, Animation, Scene, Script, Other };
enum class AssetState { Registered, Ready, Failed };
using AssetId = std::uint64_t;

struct AssetRecord {
    AssetId id{};
    std::string name;
    AssetKind kind{AssetKind::Other};
    std::string source_path;
    std::string content_hash;
    AssetState state{AssetState::Registered};
    std::vector<AssetId> dependencies;
};
struct AssetIssue { std::string code; std::string message; };

class AssetCatalog {
public:
    AssetId register_asset(std::string name, AssetKind kind, std::string source_path,
                           std::string content_hash = {});
    bool add_dependency(AssetId asset, AssetId dependency);
    bool set_state(AssetId asset, AssetState state);
    const AssetRecord* find(AssetId id) const noexcept;
    const AssetRecord* find(std::string_view name) const;
    std::vector<AssetIssue> validate() const;
    std::size_t size() const noexcept { return by_id_.size(); }
private:
    std::unordered_map<AssetId, AssetRecord> by_id_;
    std::unordered_map<std::string, AssetId> by_name_;
};

// Cell streaming policy: Active cells receive full simulation; SimulationOnly
// cells may update low-frequency world state; Dormant cells are not scheduled.
enum class CellState { Unloaded, Dormant, SimulationOnly, Active };
struct CellCoord { std::int32_t x{}, y{}, z{}; friend bool operator==(CellCoord, CellCoord) = default; };
struct CellInfo { CellCoord coord{}; CellState state{CellState::Unloaded}; std::uint64_t last_transition_frame{}; std::size_t asset_count{}; };
struct CellTransition { CellCoord coord{}; CellState before{}, after{}; };

class WorldPartition {
public:
    explicit WorldPartition(float cell_size = 128.0f);
    bool define_cell(CellCoord coord, std::size_t asset_count = 0);
    std::vector<CellTransition> update_focus(math::Vec3 focus, std::int32_t active_radius,
                                             std::int32_t simulation_radius,
                                             std::size_t transition_budget,
                                             std::uint64_t frame);
    const CellInfo* find(CellCoord coord) const noexcept;
    std::size_t size() const noexcept { return cells_.size(); }
    float cell_size() const noexcept { return cell_size_; }
private:
    struct CoordHash { std::size_t operator()(CellCoord c) const noexcept; };
    float cell_size_;
    std::unordered_map<CellCoord, CellInfo, CoordHash> cells_;
};

using BodyId = std::uint32_t;
struct RigidBodyDesc {
    math::Vec3 position{};
    math::Vec3 velocity{};
    math::Vec3 half_extents{0.5f, 0.5f, 0.5f};
    float mass{1.0f}; // zero means static
    float restitution{0.0f};
};
struct PhysicsStepResult { std::size_t bodies_integrated{}; std::size_t broadphase_pairs{}; std::size_t contacts{}; };

class PhysicsWorld {
public:
    BodyId add_body(RigidBodyDesc desc);
    bool remove_body(BodyId id);
    const RigidBodyDesc* body(BodyId id) const noexcept;
    RigidBodyDesc* body(BodyId id) noexcept;
    PhysicsStepResult step(float dt, math::Vec3 gravity = {0.0f, -9.81f, 0.0f});
    std::size_t size() const noexcept { return bodies_.size(); }
private:
    BodyId next_id_{1};
    std::unordered_map<BodyId, RigidBodyDesc> bodies_;
};

struct GridPoint { std::int32_t x{}, y{}; friend bool operator==(GridPoint, GridPoint) = default; };
class NavigationGrid {
public:
    NavigationGrid(std::uint32_t width, std::uint32_t height, float cell_size = 1.0f);
    bool set_blocked(GridPoint point, bool blocked = true);
    bool set_cost(GridPoint point, float cost);
    bool walkable(GridPoint point) const noexcept;
    std::optional<std::vector<GridPoint>> find_path(GridPoint start, GridPoint goal) const;
    std::uint32_t width() const noexcept { return width_; }
    std::uint32_t height() const noexcept { return height_; }
private:
    std::optional<std::size_t> index(GridPoint point) const noexcept;
    std::uint32_t width_, height_;
    float cell_size_;
    std::vector<bool> blocked_;
    std::vector<float> costs_;
};

struct UtilityOption { std::string name; float score{}; };
struct UtilityChoice { std::size_t index{}; std::string name; float score{}; };
std::optional<UtilityChoice> choose_utility(std::span<const UtilityOption> options);

enum class BehaviorStatus { Success, Failure, Running };
enum class BehaviorKind { Sequence, Selector, Condition, Action };
using BehaviorNodeId = std::uint32_t;
class BehaviorTree {
public:
    BehaviorNodeId sequence(std::vector<BehaviorNodeId> children);
    BehaviorNodeId selector(std::vector<BehaviorNodeId> children);
    BehaviorNodeId condition(std::string name, std::function<BehaviorStatus()> test);
    BehaviorNodeId action(std::string name, std::function<BehaviorStatus()> execute);
    std::optional<std::string> validate(BehaviorNodeId root) const;
    BehaviorStatus tick(BehaviorNodeId root) const;
    std::size_t size() const noexcept { return nodes_.size(); }
private:
    struct Node { BehaviorKind kind; std::string name; std::vector<BehaviorNodeId> children; std::function<BehaviorStatus()> callback; };
    BehaviorNodeId add_composite(BehaviorKind kind, std::vector<BehaviorNodeId> children);
    BehaviorStatus evaluate(BehaviorNodeId node) const;
    std::vector<Node> nodes_;
};

struct AnimationWeight { std::string clip; float weight{}; };
std::optional<std::vector<AnimationWeight>> normalize_animation_weights(std::span<const AnimationWeight> weights);

class WorldClock {
public:
    explicit WorldClock(double seconds_per_day = 1200.0);
    void advance(double delta_seconds);
    bool set_day_fraction(double fraction) noexcept;
    bool set_weather(float temperature_c, float wind_speed, float precipitation, float cloud_cover) noexcept;
    double day_fraction() const noexcept { return day_fraction_; }
    float sunlight() const noexcept;
    float temperature_c() const noexcept { return temperature_c_; }
    float wind_speed() const noexcept { return wind_speed_; }
    float precipitation() const noexcept { return precipitation_; }
    float cloud_cover() const noexcept { return cloud_cover_; }
private:
    double seconds_per_day_;
    double day_fraction_{0.25};
    float temperature_c_{20.0f}, wind_speed_{0.0f}, precipitation_{0.0f}, cloud_cover_{0.0f};
};

struct AudioListener { math::Vec3 position{}; };
struct AudioEmitter {
    std::uint64_t id{};
    math::Vec3 position{};
    float gain{1.0f};
    float min_distance{1.0f};
    float max_distance{50.0f};
    std::int32_t priority{};
    bool looping{false};
};
struct MixedVoice { std::uint64_t id{}; float gain{}; std::int32_t priority{}; bool looping{}; };
class AudioScene {
public:
    bool upsert(AudioEmitter emitter);
    bool remove(std::uint64_t id);
    std::vector<MixedVoice> mix(const AudioListener& listener, std::size_t voice_budget) const;
    std::size_t size() const noexcept { return emitters_.size(); }
private:
    std::unordered_map<std::uint64_t, AudioEmitter> emitters_;
};

struct ReplicatedTransform { std::uint64_t entity{}; math::Vec3 position{}; };
struct Snapshot { std::uint64_t sequence{}; std::vector<ReplicatedTransform> entities; };
struct CodecResult { bool ok{false}; Snapshot snapshot; std::string error; };
class SnapshotCodec {
public:
    static std::optional<std::vector<std::uint8_t>> encode(std::uint64_t sequence,
                                                            std::span<const ReplicatedTransform> entities,
                                                            std::string* error = nullptr);
    static CodecResult decode(std::span<const std::uint8_t> bytes,
                              std::size_t max_entities = 1'000'000);
};

enum class GraphicsAPI { Vulkan, Direct3D12, Metal, OpenGL, Software };
struct DeviceCapabilities {
    std::string device_name;
    bool vulkan{}, direct3d12{}, metal{}, opengl{};
    bool compute{}, ray_tracing{}, mesh_shaders{}, timeline_sync{};
    std::uint32_t max_texture_dimension{4096};
    std::uint64_t dedicated_memory_bytes{};
};
struct GraphicsSelection { GraphicsAPI api{GraphicsAPI::Software}; bool hardware_accelerated{false}; std::string reason; };
std::optional<GraphicsSelection> select_graphics_api(const DeviceCapabilities& caps,
                                                      std::span<const GraphicsAPI> preference,
                                                      bool allow_software_fallback);

// This compiles a backend-neutral schedule only. It does not submit Vulkan,
// Direct3D 12 or Metal commands and does not allocate GPU memory.
enum class RenderPath { Forward, Deferred };
struct RenderPipelinePlan { bool ok{false}; std::vector<std::string> ordered_passes; std::string error; };
RenderPipelinePlan build_render_pipeline(RenderPath path);

struct FrameMetrics {
    double cpu_ms{}, gpu_ms{}, physics_ms{}, ai_ms{}, audio_ms{};
    std::uint64_t draw_calls{}, triangles{}, active_entities{};
    std::uint64_t memory_bytes{}, vram_bytes{};
};
class FrameProfiler {
public:
    explicit FrameProfiler(std::size_t history = 120);
    void record(FrameMetrics sample);
    std::optional<FrameMetrics> latest() const;
    std::optional<double> average_cpu_ms() const;
    std::size_t samples() const noexcept { return history_.size(); }
private:
    std::size_t capacity_;
    std::vector<FrameMetrics> history_;
};

struct GameProjectConfig {
    std::string name;
    std::string target{"linux-x86_64"};
    std::uint32_t asset_schema{1};
    bool deterministic_simulation{true};
    bool allow_unsafe_plugins{false};
};
struct ProjectValidation { bool ok{false}; std::vector<std::string> errors; };
ProjectValidation validate_project(const GameProjectConfig& config, const AssetCatalog& assets);

} // namespace docmont::game
