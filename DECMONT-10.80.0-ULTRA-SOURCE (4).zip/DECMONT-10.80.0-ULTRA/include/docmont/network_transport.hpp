#pragma once
#include <chrono>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <vector>

namespace docmont::network {
struct Endpoint { std::string host; std::uint16_t port{}; };
struct FrameResult { bool ok{false}; std::vector<std::uint8_t> payload; std::string error; };

class TcpConnection {
public:
    TcpConnection() noexcept = default;
    explicit TcpConnection(int native_handle) noexcept : handle_(native_handle) {}
    ~TcpConnection();
    TcpConnection(const TcpConnection&) = delete;
    TcpConnection& operator=(const TcpConnection&) = delete;
    TcpConnection(TcpConnection&& other) noexcept;
    TcpConnection& operator=(TcpConnection&& other) noexcept;
    bool valid() const noexcept { return handle_ >= 0; }
    void close() noexcept;
    bool send_frame(std::span<const std::uint8_t> payload, std::string* error=nullptr);
    FrameResult receive_frame(std::chrono::milliseconds timeout,
                              std::size_t max_frame_bytes=16u*1024u*1024u);
    static std::optional<TcpConnection> connect(const Endpoint& endpoint,
                                                 std::chrono::milliseconds timeout,
                                                 std::string* error=nullptr);
private:
    int handle_{-1};
};

class TcpListener {
public:
    TcpListener() noexcept = default;
    ~TcpListener();
    TcpListener(const TcpListener&) = delete;
    TcpListener& operator=(const TcpListener&) = delete;
    TcpListener(TcpListener&& other) noexcept;
    TcpListener& operator=(TcpListener&& other) noexcept;
    bool valid() const noexcept { return handle_ >= 0; }
    void close() noexcept;
    static std::optional<TcpListener> bind(const Endpoint& endpoint,
                                            std::string* error=nullptr);
    static std::optional<TcpListener> bind_any(std::uint16_t port,
                                                std::string* error=nullptr);
    static std::optional<TcpListener> bind_loopback(std::uint16_t port,
                                                     std::string* error=nullptr);
    std::optional<TcpConnection> accept(std::chrono::milliseconds timeout,
                                        std::string* error=nullptr);
    std::uint16_t local_port() const noexcept { return port_; }
private:
    int handle_{-1};
    std::uint16_t port_{};
};

struct DatagramResult { bool ok{false}; std::uint32_t sequence{}; Endpoint from; std::vector<std::uint8_t> payload; std::string error; };
class UdpSocket {
public:
    UdpSocket() noexcept = default;
    ~UdpSocket();
    UdpSocket(const UdpSocket&) = delete;
    UdpSocket& operator=(const UdpSocket&) = delete;
    UdpSocket(UdpSocket&& other) noexcept;
    UdpSocket& operator=(UdpSocket&& other) noexcept;
    bool valid() const noexcept { return handle_ >= 0; }
    void close() noexcept;
    static std::optional<UdpSocket> bind(const Endpoint& endpoint,
                                         std::string* error=nullptr);
    static std::optional<UdpSocket> bind_any(std::uint16_t port,
                                             std::string* error=nullptr);
    static std::optional<UdpSocket> bind_loopback(std::uint16_t port,
                                                  std::string* error=nullptr);
    bool send_to(const Endpoint& endpoint, std::uint32_t sequence,
                 std::span<const std::uint8_t> payload, std::string* error=nullptr);
    DatagramResult receive(std::chrono::milliseconds timeout,
                           std::size_t max_datagram_bytes=60u*1024u);
    std::uint16_t local_port() const noexcept { return port_; }
private:
    int handle_{-1};
    std::uint16_t port_{};
};

std::uint32_t crc32(std::span<const std::uint8_t> bytes) noexcept;
} // namespace docmont::network
