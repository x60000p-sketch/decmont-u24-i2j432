#pragma once

#include <cstdint>
#include <optional>
#include <set>
#include <string>
#include <unordered_map>
#include <vector>

namespace docmont::core {

using TypeId = std::uint32_t;

// Type representation used by the typed-HIR and generic solver layers.
enum class TypeKind : std::uint8_t {
    Unit, Bool, I32, I64, U32, U64, F32, F64, String,
    Named, GenericParameter, Tuple, Reference, MutableReference,
    Array, Option, Result, Function, Enum
};

struct Type {
    TypeKind kind{TypeKind::Unit};
    std::string name;
    std::vector<TypeId> arguments;
    std::uint64_t array_length{};
};

class TypeContext {
public:
    TypeContext();
    TypeId primitive(TypeKind kind) const;
    TypeId named(std::string name);
    TypeId enumeration(std::string name);
    TypeId generic_parameter(std::string name);
    TypeId tuple(std::vector<TypeId> fields);
    TypeId reference(TypeId target, bool mutable_reference = false);
    TypeId array(TypeId element, std::uint64_t length);
    TypeId option(TypeId value);
    TypeId result(TypeId ok, TypeId error);
    TypeId function(std::vector<TypeId> parameters, TypeId result);
    TypeId substitute(TypeId id, const std::unordered_map<std::string, TypeId>& substitutions);
    bool contains_generic_parameter(TypeId id) const;
    const Type* get(TypeId id) const noexcept;
    std::string display(TypeId id) const;
    std::size_t size() const noexcept { return types_.size(); }
private:
    TypeId intern(Type type);
    std::string key(const Type& type) const;
    std::vector<Type> types_;
    std::unordered_map<std::string, TypeId> ids_;
    std::unordered_map<TypeKind, TypeId> primitives_;
};

struct TraitMethod {
    std::string name;
    std::string signature;
};
struct TraitDefinition {
    std::string name;
    std::vector<TraitMethod> required_methods;
};
struct TraitImplementation {
    std::string trait_name;
    TypeId for_type{};
    std::unordered_map<std::string, std::string> methods;
};
struct SolverResult {
    bool ok{true};
    std::string message{"ok"};
};

class TraitSolver {
public:
    SolverResult define_trait(TraitDefinition trait);
    SolverResult add_implementation(TraitImplementation implementation);
    SolverResult satisfies(TypeId type, const std::string& trait_name) const;
    std::size_t implementation_count() const noexcept { return implementations_.size(); }
private:
    std::unordered_map<std::string, TraitDefinition> traits_;
    std::vector<TraitImplementation> implementations_;
};

struct GenericParameter {
    std::string name;
    std::vector<std::string> required_traits;
};
struct GenericFunction {
    std::string name;
    std::vector<GenericParameter> type_parameters;
    std::vector<TypeId> parameter_types;
    TypeId return_type{};
};
struct GenericInstantiation {
    bool ok{false};
    std::string specialization_name;
    std::vector<TypeId> concrete_parameters;
    TypeId concrete_return{};
    std::string message;
};

class GenericSolver {
public:
    GenericSolver(TypeContext& types, const TraitSolver& traits) : types_(types), traits_(traits) {}
    GenericInstantiation instantiate(const GenericFunction& function,
                                     const std::unordered_map<std::string, TypeId>& substitutions);
    std::size_t specialization_count() const noexcept { return specializations_.size(); }
private:
    TypeContext& types_;
    const TraitSolver& traits_;
    std::set<std::string> specializations_;
};

struct EnumDefinition {
    std::string name;
    std::vector<std::string> variants;
};
struct Pattern {
    enum class Kind { Variant, Wildcard } kind{Kind::Wildcard};
    std::string variant;
};
struct PatternCheck {
    bool exhaustive{false};
    std::vector<std::string> missing_variants;
    std::vector<std::string> duplicate_variants;
    std::vector<std::string> unknown_variants;
};
PatternCheck check_enum_patterns(const EnumDefinition& definition,
                                 const std::vector<Pattern>& patterns);

// A typed, source-location independent HIR contract. The parser frontend can
// populate this model without coupling the semantic core to a particular syntax.
struct HIRLocal {
    std::string name;
    TypeId type{};
    bool mutable_binding{false};
};
struct HIRFunction {
    std::string name;
    std::vector<HIRLocal> parameters;
    std::vector<HIRLocal> locals;
    TypeId return_type{};
    bool has_return_value{true};
    std::vector<std::string> generic_parameters;
    std::vector<std::string> generic_constraints;
};
struct TypedHIRModule {
    std::string name;
    std::vector<HIRFunction> functions;
};
struct CoreDiagnostic {
    std::string code;
    std::string message;
};
std::vector<CoreDiagnostic> verify_typed_hir(const TypedHIRModule& module,
                                             const TypeContext& types);

// Minimal MIR substrate: explicit places, operations and CFG edges.
enum class MIROpKind { Declare, Read, Write, Move, BorrowShared, BorrowMutable, EndBorrow, Drop, Return, ReturnReference };
struct MIROperation {
    MIROpKind kind{MIROpKind::Read};
    std::string place;
    std::string loan;
    TypeId type{};
    std::uint32_t source_region{};
    std::uint32_t target_region{};
};
struct MIRBlock {
    std::uint32_t id{};
    std::vector<MIROperation> operations;
    std::vector<std::uint32_t> successors;
};
enum class MIRValueOpKind { ConstantI64, AddI64, SubI64, MulI64, ReturnI64 };
struct MIRValueOperation {
    MIRValueOpKind kind{MIRValueOpKind::ConstantI64};
    std::string result;
    std::string lhs;
    std::string rhs;
    std::int64_t immediate{};
};
struct MIRFunction {
    std::string name;
    std::uint32_t entry{};
    std::vector<MIRBlock> blocks;
    // Verified, typed, straight-line integer MIR subset used by the direct
    // LLVM backend. It intentionally rejects unsupported source constructs.
    bool native_integer_supported{false};
    std::vector<MIRValueOperation> native_integer_ops;
};
struct MIRModule { std::string name; std::vector<MIRFunction> functions; };
std::vector<CoreDiagnostic> verify_mir(const MIRModule& module,
                                       const TypeContext& types);

} // namespace docmont::core
