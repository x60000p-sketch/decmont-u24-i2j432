#pragma once

#include <string>
#include <vector>

namespace docmont::interop {

struct Result {
    bool ok{false};
    std::string message;
};

struct JavaArtifacts {
    std::string package_name;
    std::string class_name;
    std::string library_name;
    std::string java_source;
    std::string abi_header;
    std::string jni_source;
};

struct AssemblyFunction {
    std::string name;
    std::vector<std::string> parameter_types;
    std::string return_type;
    std::vector<std::string> instructions;
};

struct AssemblyModule {
    std::string target;
    std::vector<AssemblyFunction> functions;
};

// Generates a Java wrapper, a C ABI contract header and JNI C++ glue from
// a strict DOCMONT_JAVA 1 manifest. It does not compile or load the native library.
Result generate_java_artifacts(const std::string& manifest, JavaArtifacts& out);

// Parses a deliberately restricted, register-only x86_64 System V assembly DSL.
// Memory operands, directives, macros, calls and arbitrary assembler text are rejected.
Result parse_assembly(const std::string& source, AssemblyModule& out);
Result emit_gas_x86_64(const AssemblyModule& module, std::string& output);

// File-level helpers used by the CLI.
Result generate_java_bindings_file(const std::string& manifest_path, const std::string& output_directory);
Result emit_assembly_file(const std::string& source_path, const std::string& output_path);
Result check_assembly_file(const std::string& source_path);

} // namespace docmont::interop
