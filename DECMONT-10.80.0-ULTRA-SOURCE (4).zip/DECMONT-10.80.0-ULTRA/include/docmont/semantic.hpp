#pragma once
#include "docmont/ast.hpp"
#include "docmont/diagnostic.hpp"
#include <vector>
namespace docmont {
std::vector<Diagnostic> validate(const Application& app);
}
