#pragma once
#include "docmont/ast.hpp"
#include "docmont/compiler_core.hpp"
#include <string>
#include <vector>

namespace docmont::frontend {
struct LoweredModule {
    core::TypeContext types;
    core::TypedHIRModule hir;
    core::MIRModule mir;
    std::vector<core::CoreDiagnostic> diagnostics;
};

// Lowers the parsed source AST into a typed, source-level HIR and a conservative
// one-block MIR representation. Unsupported control-flow ownership details are
// diagnosed by the dedicated ownership analysis rather than guessed here.
LoweredModule lower_to_hir_mir(const Application& app);
}
