#pragma once
#include "docmont/ir.hpp"
#include <string>
namespace docmont {
struct NativeSourceResult { bool ok{false}; std::string message; std::string source; };
// Emits portable C11 source that can be compiled by the host C toolchain.
NativeSourceResult emit_c_source(const ProgramIR& ir);
}
