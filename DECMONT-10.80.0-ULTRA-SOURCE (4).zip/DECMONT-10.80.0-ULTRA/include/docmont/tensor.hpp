#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

namespace docmont::tensor {

// Contiguous row-major N-dimensional tensor with checked shape arithmetic.
template<class T> class Tensor {
public:
    Tensor() = default;
    explicit Tensor(std::vector<std::size_t> shape, const T& value = T{}) : shape_(std::move(shape)) {
        if (shape_.empty()) throw std::invalid_argument("tensor rank must be positive");
        std::size_t n=1;
        for (auto d:shape_) { if (d==0 || n>std::numeric_limits<std::size_t>::max()/d) throw std::length_error("invalid tensor shape"); n*=d; }
        data_.assign(n,value);
    }
    const std::vector<std::size_t>& shape() const noexcept { return shape_; }
    std::size_t rank() const noexcept { return shape_.size(); }
    std::size_t size() const noexcept { return data_.size(); }
    T& flat(std::size_t i) { return data_.at(i); }
    const T& flat(std::size_t i) const { return data_.at(i); }
    T& at(const std::vector<std::size_t>& index) { return data_.at(offset(index)); }
    const T& at(const std::vector<std::size_t>& index) const { return data_.at(offset(index)); }
    const std::vector<T>& values() const noexcept { return data_; }
    std::vector<T>& values() noexcept { return data_; }
    Tensor reshape(std::vector<std::size_t> next) const {
        std::size_t n=1; if(next.empty()) throw std::invalid_argument("tensor rank must be positive");
        for(auto d:next){ if(!d || n>std::numeric_limits<std::size_t>::max()/d) throw std::length_error("invalid tensor shape"); n*=d; }
        if(n!=size()) throw std::invalid_argument("reshape changes element count");
        Tensor out; out.shape_=std::move(next); out.data_=data_; return out;
    }
private:
    std::size_t offset(const std::vector<std::size_t>& index) const {
        if(index.size()!=rank()) throw std::out_of_range("tensor index rank mismatch");
        std::size_t result=0;
        for(std::size_t i=0;i<rank();++i){ if(index[i]>=shape_[i]) throw std::out_of_range("tensor index out of bounds"); result=result*shape_[i]+index[i]; }
        return result;
    }
    std::vector<std::size_t> shape_;
    std::vector<T> data_;
};

struct Statistics { double mean{}, variance{}, minimum{}, maximum{}; };
template<class T> Statistics describe(const std::vector<T>& values) {
    static_assert(std::is_arithmetic_v<T>);
    if(values.empty()) throw std::invalid_argument("statistics require non-empty input");
    long double sum=0; T lo=values.front(), hi=values.front();
    for(T v:values){ sum+=v; lo=std::min(lo,v); hi=std::max(hi,v); }
    const long double mean=sum/values.size(); long double sq=0;
    for(T v:values){ const auto d=static_cast<long double>(v)-mean; sq+=d*d; }
    return {static_cast<double>(mean),static_cast<double>(sq/values.size()),static_cast<double>(lo),static_cast<double>(hi)};
}

} // namespace docmont::tensor
