#pragma once
#include <algorithm>
#include <cstdint>
#include <string>
#include <string_view>
#include <unordered_map>
#include <utility>
#include <vector>

namespace docmont::modules {
struct Version { uint16_t major{}, minor{}, patch{}; friend bool operator==(const Version&,const Version&)=default; };
struct Dependency { std::string name; uint16_t minimum_abi_major{1}; };
struct Export { std::string name; std::string signature; bool is_function{true}; };
struct Manifest {
    std::string name;
    Version version{};
    uint16_t abi_major{1};
    std::string minimum_runtime{"4.7.0"};
    bool deterministic{true};
    bool thread_safe{false};
    std::vector<Dependency> dependencies;
    std::vector<Export> exports;
};
struct Status { bool ok{true}; std::string message{"ok"}; };

class Registry {
public:
    Status add(Manifest manifest) {
        if (manifest.name.rfind("decom.",0)!=0) return {false,"module name must use decom.<name> namespace"};
        if (manifest.abi_major==0) return {false,"ABI major must be non-zero"};
        if (manifest.minimum_runtime.empty()) return {false,"minimum runtime is required"};
        if (manifest.exports.empty()) return {false,"module must export at least one symbol"};
        std::sort(manifest.exports.begin(),manifest.exports.end(),[](const Export&a,const Export&b){return a.name<b.name;});
        for (std::size_t i=0;i<manifest.exports.size();++i) {
            if (manifest.exports[i].name.empty() || manifest.exports[i].signature.empty()) return {false,"export name and signature are required"};
            if (i && manifest.exports[i-1].name==manifest.exports[i].name) return {false,"duplicate export symbol"};
        }
        if (entries_.contains(manifest.name)) return {false,"module already registered"};
        entries_.emplace(manifest.name,std::move(manifest));
        return {};
    }
    const Manifest* find(std::string_view name) const noexcept {
        auto it=entries_.find(std::string(name)); return it==entries_.end()?nullptr:&it->second;
    }
    Status validate_dependencies(std::string_view name) const {
        const auto* m=find(name); if(!m)return {false,"module not found"};
        for(const auto& d:m->dependencies) {
            const auto* dep=find(d.name);
            if(!dep)return {false,"missing dependency: "+d.name};
            if(dep->abi_major!=d.minimum_abi_major)return {false,"dependency ABI mismatch: "+d.name};
        }
        return {};
    }
    std::size_t size() const noexcept { return entries_.size(); }
private:
    std::unordered_map<std::string,Manifest> entries_;
};
} // namespace docmont::modules
