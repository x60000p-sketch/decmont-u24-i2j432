#pragma once
#include <cstdint>
#include <string>
#include <vector>
namespace docmont {
struct Color { std::uint8_t r{0}, g{0}, b{0}; };
class Canvas {
public:
    Canvas(int width, int height, Color background = {0,0,0});
    int width() const noexcept { return width_; }
    int height() const noexcept { return height_; }
    void pixel(int x, int y, Color color);
    void fill_rect(int x, int y, int w, int h, Color color);
    void line(int x0, int y0, int x1, int y1, Color color);
    void circle(int cx, int cy, int radius, Color color);
    bool write_ppm(const std::string& path) const;
    const std::vector<Color>& pixels() const noexcept { return pixels_; }
private:
    int width_, height_;
    std::vector<Color> pixels_;
};
}
