#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace docmont::gpu {
struct GlesDeviceInfo {
    bool available{false};
    bool compute_supported{false};
    bool hardware_accelerated{false};
    std::string vendor;
    std::string renderer;
    std::string version;
    std::string detail;
};
struct GlesFrame {
    bool ok{false};
    std::uint32_t width{}, height{};
    std::vector<std::uint8_t> rgba;
    std::string renderer;
    std::string error;
};
enum class TensorBinaryOp { Add, Subtract, Multiply, Divide, Maximum, Minimum };
struct GpuTensorResult {
    bool ok{false};
    std::vector<float> values;
    std::string renderer;
    std::string error;
};

// Creates a real surfaceless EGL/OpenGL ES context. On Mesa llvmpipe this is
// a software implementation; hardware_accelerated is derived from renderer.
GlesDeviceInfo probe_gles();
// Compiles shaders, draws a triangle to an offscreen pbuffer and reads pixels.
GlesFrame render_triangle_offscreen(std::uint32_t width=64, std::uint32_t height=64);
// Dispatches an OpenGL ES 3.1+ compute shader for row-major 2D A*B.
GpuTensorResult compute_matmul(const std::vector<float>& a, std::uint32_t m,
                               std::uint32_t k, const std::vector<float>& b,
                               std::uint32_t n, bool relu=false);
// OpenGL ES 3.1+ compute kernels. These use the active GLES implementation;
// llvmpipe/softpipe are software execution, not hardware GPU acceleration.
GpuTensorResult compute_binary(const std::vector<float>& a, const std::vector<float>& b,
                               TensorBinaryOp op);
// Numerically stable row-wise softmax for row-major [rows, columns] tensors.
GpuTensorResult compute_softmax(const std::vector<float>& input,
                                std::uint32_t rows, std::uint32_t columns);
} // namespace docmont::gpu
