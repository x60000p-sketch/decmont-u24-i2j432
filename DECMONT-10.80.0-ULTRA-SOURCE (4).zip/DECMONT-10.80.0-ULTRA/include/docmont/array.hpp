#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <functional>
#include <initializer_list>
#include <iterator>
#include <numeric>
#include <optional>
#include <stdexcept>
#include <type_traits>
#include <utility>
#include <vector>

namespace docmont::data {

// Checked, value-semantic dynamic array. The API deliberately exposes a broad
// set of deterministic operations suitable for language/runtime integration.
template<class T> class Array {
public:
    using value_type=T; using size_type=std::size_t;
    Array()=default;
    Array(std::initializer_list<T> values): data_(values) {}
    explicit Array(std::vector<T> values): data_(std::move(values)) {}

    // 01-16: storage and indexed access
    size_type size() const noexcept { return data_.size(); }                         // 01
    bool empty() const noexcept { return data_.empty(); }                             // 02
    size_type capacity() const noexcept { return data_.capacity(); }                  // 03
    void reserve(size_type n) { data_.reserve(n); }                                   // 04
    void resize(size_type n) { data_.resize(n); }                                     // 05
    void clear() noexcept { data_.clear(); }                                          // 06
    T& at(size_type i) { return data_.at(i); }                                        // 07
    const T& at(size_type i) const { return data_.at(i); }                            // 08
    T& operator[](size_type i) noexcept { return data_[i]; }                          // 09
    const T& operator[](size_type i) const noexcept { return data_[i]; }              // 10
    T& front() { return data_.at(0); }                                                // 11
    const T& front() const { return data_.at(0); }                                    // 12
    T& back() { return data_.at(data_.empty()?0:data_.size()-1); }                    // 13
    const T& back() const { return data_.at(data_.empty()?0:data_.size()-1); }        // 14
    const std::vector<T>& values() const noexcept { return data_; }                   // 15
    std::vector<T>& values() noexcept { return data_; }                               // 16

    // 17-32: mutation and lookup
    void push(const T& v) { data_.push_back(v); }                                     // 17
    void push(T&& v) { data_.push_back(std::move(v)); }                               // 18
    bool pop() { if(data_.empty()) return false; data_.pop_back(); return true; }     // 19
    void insert(size_type i,const T& v) { if(i>size()) throw std::out_of_range("array insert"); data_.insert(data_.begin()+static_cast<std::ptrdiff_t>(i),v); } // 20
    bool erase(size_type i) { if(i>=size()) return false; data_.erase(data_.begin()+static_cast<std::ptrdiff_t>(i)); return true; } // 21
    bool contains(const T& v) const { return std::find(data_.begin(),data_.end(),v)!=data_.end(); } // 22
    size_type count(const T& v) const { return static_cast<size_type>(std::count(data_.begin(),data_.end(),v)); } // 23
    std::optional<size_type> find(const T& v) const { auto i=std::find(data_.begin(),data_.end(),v); if(i==data_.end()) return {}; return static_cast<size_type>(i-data_.begin()); } // 24
    bool replace(size_type i,const T& v) { if(i>=size()) return false; data_[i]=v; return true; } // 25
    void append(const Array& other) { data_.insert(data_.end(),other.data_.begin(),other.data_.end()); } // 26
    void prepend(const Array& other) { data_.insert(data_.begin(),other.data_.begin(),other.data_.end()); } // 27
    void swap(size_type a,size_type b) { if(a>=size()||b>=size()) throw std::out_of_range("array swap"); std::swap(data_[a],data_[b]); } // 28
    void fill(const T& v) { std::fill(data_.begin(),data_.end(),v); }                 // 29
    void reverse() { std::reverse(data_.begin(),data_.end()); }                       // 30
    void rotate_left(size_type n=1) { if(!empty()) std::rotate(data_.begin(),data_.begin()+static_cast<std::ptrdiff_t>(n%size()),data_.end()); } // 31
    void rotate_right(size_type n=1) { if(!empty()) std::rotate(data_.begin(),data_.end()-static_cast<std::ptrdiff_t>(n%size()),data_.end()); } // 32

    // 33-48: ordering, selection and aggregation
    void sort() { std::sort(data_.begin(),data_.end()); }                             // 33
    template<class C> void sort(C cmp) { std::sort(data_.begin(),data_.end(),cmp); }  // 34
    void stable_sort() { std::stable_sort(data_.begin(),data_.end()); }               // 35
    size_type unique() { auto e=std::unique(data_.begin(),data_.end()); auto n=static_cast<size_type>(e-data_.begin()); data_.erase(e,data_.end()); return n; } // 36
    template<class P> Array filter(P pred) const { Array out; for(const auto& v:data_) if(pred(v)) out.push(v); return out; } // 37
    template<class F> auto map(F fn) const -> Array<std::decay_t<decltype(fn(std::declval<const T&>()))>> { using U=std::decay_t<decltype(fn(std::declval<const T&>()))>; Array<U> out; out.reserve(size()); for(const auto& v:data_) out.push(fn(v)); return out; } // 38
    template<class U,class F> U reduce(U init,F fn) const { for(const auto& v:data_) init=fn(std::move(init),v); return init; } // 39
    bool all_of(std::function<bool(const T&)> p) const { return std::all_of(data_.begin(),data_.end(),p); } // 40
    bool any_of(std::function<bool(const T&)> p) const { return std::any_of(data_.begin(),data_.end(),p); } // 41
    bool none_of(std::function<bool(const T&)> p) const { return std::none_of(data_.begin(),data_.end(),p); } // 42
    const T& min() const { if(empty()) throw std::logic_error("min of empty array"); return *std::min_element(data_.begin(),data_.end()); } // 43
    const T& max() const { if(empty()) throw std::logic_error("max of empty array"); return *std::max_element(data_.begin(),data_.end()); } // 44
    template<class U=T> auto sum() const -> decltype(std::declval<U>()+std::declval<U>()) { return std::accumulate(data_.begin(),data_.end(),U{}); } // 45
    double average() const requires std::is_arithmetic_v<T> { if(empty()) throw std::logic_error("average of empty array"); return static_cast<double>(sum())/static_cast<double>(size()); } // 46
    Array sorted() const { Array out=*this; out.sort(); return out; }                // 47
    Array reversed() const { Array out=*this; out.reverse(); return out; }            // 48

    // 49-64: structural and numerical utilities
    Array slice(size_type start,size_type length) const { if(start>size()) throw std::out_of_range("array slice"); const auto n=std::min(length,size()-start); return Array(std::vector<T>(data_.begin()+static_cast<std::ptrdiff_t>(start),data_.begin()+static_cast<std::ptrdiff_t>(start+n))); } // 49
    Array take(size_type n) const { return slice(0,std::min(n,size())); }              // 50
    Array drop(size_type n) const { return slice(std::min(n,size()),size()); }         // 51
    Array concat(const Array& b) const { Array out=*this; out.append(b); return out; } // 52
    Array distinct() const { Array out; for(const auto& v:data_) if(!out.contains(v)) out.push(v); return out; } // 53
    template<class P> std::pair<Array,Array> partition(P p) const { Array yes,no; for(const auto& v:data_) (p(v)?yes:no).push(v); return {yes,no}; } // 54
    template<class F> void for_each(F fn) const { for(const auto& v:data_) fn(v); }   // 55
    template<class F> static Array generate(size_type n,F fn) { Array out; out.reserve(n); for(size_type i=0;i<n;++i) out.push(fn(i)); return out; } // 56
    Array<std::array<T,2>> pairwise() const { Array<std::array<T,2>> out; for(size_type i=1;i<size();++i) out.push({data_[i-1],data_[i]}); return out; } // 57
    Array<Array<T>> chunks(size_type n) const { if(n==0) throw std::invalid_argument("chunk size must be positive"); Array<Array<T>> out; for(size_type i=0;i<size();i+=n) out.push(slice(i,n)); return out; } // 58
    template<class F> Array transform_copy(F fn) const { Array out; out.reserve(size()); for(const auto& v:data_) out.push(fn(v)); return out; } // 59
    bool equal(const Array& other) const { return data_==other.data_; }               // 60
    void deduplicate_sorted() { sort(); unique(); }                                   // 61
    size_type lower_bound_index(const T& v) const { return static_cast<size_type>(std::lower_bound(data_.begin(),data_.end(),v)-data_.begin()); } // 62
    size_type upper_bound_index(const T& v) const { return static_cast<size_type>(std::upper_bound(data_.begin(),data_.end(),v)-data_.begin()); } // 63
    bool binary_contains(const T& v) const { return std::binary_search(data_.begin(),data_.end(),v); } // 64
private:
    std::vector<T> data_;
};

// Fixed-shape row-major matrix for numeric kernels and multidimensional data.
template<class T,std::size_t Rows,std::size_t Cols> struct Matrix {
    static_assert(Rows>0 && Cols>0);
    std::array<T,Rows*Cols> data{};
    constexpr T& operator()(std::size_t r,std::size_t c) { return data.at(r*Cols+c); }
    constexpr const T& operator()(std::size_t r,std::size_t c) const { return data.at(r*Cols+c); }
    static constexpr Matrix zero() { return {}; }
    static constexpr Matrix identity() requires (Rows==Cols) { Matrix m{}; for(std::size_t i=0;i<Rows;++i)m(i,i)=T{1}; return m; }
    constexpr auto transpose() const -> Matrix<T,Cols,Rows> { Matrix<T,Cols,Rows> out{}; for(std::size_t r=0;r<Rows;++r)for(std::size_t c=0;c<Cols;++c)out(c,r)=(*this)(r,c); return out; }
    constexpr Matrix operator+(const Matrix& b) const { Matrix o{}; for(std::size_t i=0;i<data.size();++i)o.data[i]=data[i]+b.data[i]; return o; }
    constexpr Matrix operator-(const Matrix& b) const { Matrix o{}; for(std::size_t i=0;i<data.size();++i)o.data[i]=data[i]-b.data[i]; return o; }
    constexpr Matrix operator*(T s) const { Matrix o{}; for(std::size_t i=0;i<data.size();++i)o.data[i]=data[i]*s; return o; }
};
template<class T,std::size_t R,std::size_t K,std::size_t C>
constexpr Matrix<T,R,C> multiply(const Matrix<T,R,K>& a,const Matrix<T,K,C>& b) { Matrix<T,R,C> o{}; for(std::size_t r=0;r<R;++r)for(std::size_t c=0;c<C;++c)for(std::size_t k=0;k<K;++k)o(r,c)+=a(r,k)*b(k,c); return o; }

} // namespace docmont::data
