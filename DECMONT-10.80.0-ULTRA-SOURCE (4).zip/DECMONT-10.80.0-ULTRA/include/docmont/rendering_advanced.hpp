#pragma once
#include "docmont/rendering.hpp"
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <stdexcept>
#include <vector>

namespace docmont::render {

struct ColorF { float r{1},g{1},b{1},a{1}; };
enum class Filter { Nearest, Bilinear };

class Texture2D {
public:
    Texture2D()=default;
    Texture2D(std::uint32_t w,std::uint32_t h,std::vector<ColorF> pixels)
      : width_(w),height_(h),pixels_(std::move(pixels)) {
        if(!w||!h||pixels_.size()!=static_cast<std::size_t>(w)*h) throw std::invalid_argument("texture dimensions/pixel count mismatch");
        for(const auto& p:pixels_) if(!finite(p)) throw std::invalid_argument("texture contains non-finite color");
    }
    std::uint32_t width() const noexcept{return width_;}
    std::uint32_t height() const noexcept{return height_;}
    bool valid() const noexcept{return width_&&height_&&pixels_.size()==static_cast<std::size_t>(width_)*height_;}
    ColorF sample(float u,float v,Filter filter=Filter::Nearest) const {
        if(!valid()) throw std::logic_error("sampling an empty texture");
        u=std::clamp(u,0.0f,1.0f); v=std::clamp(v,0.0f,1.0f);
        if(filter==Filter::Nearest) return pixel(static_cast<std::uint32_t>(std::lround(u*(width_-1))),static_cast<std::uint32_t>(std::lround(v*(height_-1))));
        const float x=u*(width_-1),y=v*(height_-1); const auto x0=static_cast<std::uint32_t>(x),y0=static_cast<std::uint32_t>(y);
        const auto x1=std::min(x0+1,width_-1),y1=std::min(y0+1,height_-1); const float tx=x-x0,ty=y-y0;
        return lerp(lerp(pixel(x0,y0),pixel(x1,y0),tx),lerp(pixel(x0,y1),pixel(x1,y1),tx),ty);
    }
private:
    static bool finite(ColorF c){return std::isfinite(c.r)&&std::isfinite(c.g)&&std::isfinite(c.b)&&std::isfinite(c.a);}
    static ColorF lerp(ColorF a,ColorF b,float t){return {a.r+(b.r-a.r)*t,a.g+(b.g-a.g)*t,a.b+(b.b-a.b)*t,a.a+(b.a-a.a)*t};}
    ColorF pixel(std::uint32_t x,std::uint32_t y) const{return pixels_[static_cast<std::size_t>(y)*width_+x];}
    std::uint32_t width_{0},height_{0}; std::vector<ColorF> pixels_;
};

struct Material {
    ColorF base_color{};
    ColorF emissive{0,0,0,1};
    float metallic{0.0f};
    float roughness{1.0f};
    float opacity{1.0f};
    const Texture2D* base_color_texture{nullptr};
    bool validate() const noexcept {
        const auto ok=[](ColorF c){return std::isfinite(c.r)&&std::isfinite(c.g)&&std::isfinite(c.b)&&std::isfinite(c.a);};
        return ok(base_color)&&ok(emissive)&&std::isfinite(metallic)&&std::isfinite(roughness)&&std::isfinite(opacity)&&metallic>=0&&metallic<=1&&roughness>=0&&roughness<=1&&opacity>=0&&opacity<=1;
    }
};

struct ClipVertex { math::Vec4 clip{}; math::Vec3 normal{}; math::Vec2 uv{}; };
inline ClipVertex interpolate(const ClipVertex& a,const ClipVertex& b,float t) {
    auto f=[t](float x,float y){return x+(y-x)*t;};
    return {{f(a.clip.x,b.clip.x),f(a.clip.y,b.clip.y),f(a.clip.z,b.clip.z),f(a.clip.w,b.clip.w)},
            {f(a.normal.x,b.normal.x),f(a.normal.y,b.normal.y),f(a.normal.z,b.normal.z)},
            {f(a.uv.x,b.uv.x),f(a.uv.y,b.uv.y)}};
}
// Sutherland-Hodgman clipping in homogeneous OpenGL-style clip coordinates.
inline std::vector<ClipVertex> clip_polygon(std::vector<ClipVertex> polygon) {
    using Plane=std::function<float(const math::Vec4&)>;
    const std::array<Plane,6> planes={
      [](const math::Vec4& p){return p.x+p.w;},[](const math::Vec4& p){return p.w-p.x;},
      [](const math::Vec4& p){return p.y+p.w;},[](const math::Vec4& p){return p.w-p.y;},
      [](const math::Vec4& p){return p.z+p.w;},[](const math::Vec4& p){return p.w-p.z;}};
    for(const auto& distance:planes) {
        if(polygon.empty()) break;
        std::vector<ClipVertex> output; output.reserve(polygon.size()+1);
        ClipVertex previous=polygon.back(); float dp=distance(previous.clip); bool prev_inside=dp>=0;
        for(const auto& current:polygon) {
            const float dc=distance(current.clip); const bool cur_inside=dc>=0;
            if(cur_inside!=prev_inside) { const float denom=dp-dc; if(std::abs(denom)>1e-20f) output.push_back(interpolate(previous,current,dp/denom)); }
            if(cur_inside) output.push_back(current);
            previous=current; dp=dc; prev_inside=cur_inside;
        }
        polygon=std::move(output);
    }
    return polygon;
}
inline std::vector<ClipVertex> clip_triangle(const ClipVertex& a,const ClipVertex& b,const ClipVertex& c) {
    return clip_polygon({a,b,c});
}

inline ColorF shade_lambert(ColorF base,math::Vec3 normal,math::Vec3 light_direction,
                            ColorF light_color={1,1,1,1},ColorF ambient={0.08f,0.08f,0.08f,1}) {
    const auto n=math::normalize(normal),l=math::normalize(light_direction);
    const float diffuse=std::max(0.0f,math::dot(n,l));
    return {base.r*(ambient.r+light_color.r*diffuse),base.g*(ambient.g+light_color.g*diffuse),
            base.b*(ambient.b+light_color.b*diffuse),base.a};
}

// Cook-Torrance direct-light BRDF with GGX normal distribution, Smith-Schlick
// geometry and Schlick Fresnel. This is a CPU reference implementation for
// validating material/shader behavior; it is not a GPU renderer backend.
inline ColorF evaluate_pbr_ggx(ColorF albedo,float metallic,float roughness,
                              math::Vec3 normal,math::Vec3 view_direction,
                              math::Vec3 light_direction,ColorF radiance={1,1,1,1}) {
    const auto valid_color=[](ColorF c){return std::isfinite(c.r)&&std::isfinite(c.g)&&std::isfinite(c.b)&&std::isfinite(c.a)&&c.r>=0&&c.g>=0&&c.b>=0;};
    if(!valid_color(albedo)||!valid_color(radiance)||!std::isfinite(metallic)||!std::isfinite(roughness)||metallic<0||metallic>1||roughness<0||roughness>1)
        throw std::invalid_argument("invalid PBR material or light parameters");
    const auto n=math::normalize(normal),v=math::normalize(view_direction),l=math::normalize(light_direction);
    const auto h=math::normalize(v+l);
    const float ndotv=std::max(0.0f,math::dot(n,v)),ndotl=std::max(0.0f,math::dot(n,l));
    if(ndotv<=1e-6f||ndotl<=1e-6f)return {0,0,0,albedo.a};
    const float ndoth=std::max(0.0f,math::dot(n,h)),vdoth=std::max(0.0f,math::dot(v,h));
    constexpr float pi=3.14159265358979323846f;
    const float alpha=std::max(roughness*roughness,0.002025f),alpha2=alpha*alpha;
    const float dterm=ndoth*ndoth*(alpha2-1.0f)+1.0f;
    const float distribution=alpha2/(pi*dterm*dterm);
    const float k=(roughness+1.0f)*(roughness+1.0f)/8.0f;
    const auto geometry_one=[k](float ndot){return ndot/(ndot*(1.0f-k)+k);};
    const float geometry=geometry_one(ndotv)*geometry_one(ndotl);
    const float fresnel_power=std::pow(1.0f-vdoth,5.0f);
    const ColorF f0{0.04f+(albedo.r-0.04f)*metallic,0.04f+(albedo.g-0.04f)*metallic,0.04f+(albedo.b-0.04f)*metallic,1};
    const ColorF fresnel{f0.r+(1.0f-f0.r)*fresnel_power,f0.g+(1.0f-f0.g)*fresnel_power,f0.b+(1.0f-f0.b)*fresnel_power,1};
    const float specular_scale=distribution*geometry/std::max(4.0f*ndotv*ndotl,1e-6f);
    const float diffuse_weight=1.0f-metallic;
    const float common=ndotl;
    return {
        ((1.0f-fresnel.r)*diffuse_weight*albedo.r/pi+fresnel.r*specular_scale)*radiance.r*common,
        ((1.0f-fresnel.g)*diffuse_weight*albedo.g/pi+fresnel.g*specular_scale)*radiance.g*common,
        ((1.0f-fresnel.b)*diffuse_weight*albedo.b/pi+fresnel.b*specular_scale)*radiance.b*common,
        albedo.a
    };
}

inline ColorF tonemap_aces(ColorF hdr,float exposure=1.0f) {
    if(!std::isfinite(exposure)||exposure<0||!std::isfinite(hdr.r)||!std::isfinite(hdr.g)||!std::isfinite(hdr.b)||!std::isfinite(hdr.a)||hdr.r<0||hdr.g<0||hdr.b<0)
        throw std::invalid_argument("invalid HDR color or exposure");
    const auto curve=[exposure](float x){x*=exposure;return std::clamp((x*(2.51f*x+0.03f))/(x*(2.43f*x+0.59f)+0.14f),0.0f,1.0f);};
    return {curve(hdr.r),curve(hdr.g),curve(hdr.b),std::clamp(hdr.a,0.0f,1.0f)};
}

inline math::Vec2 perspective_correct_uv(math::Vec2 a,math::Vec2 b,math::Vec2 c,
                                          float wa,float wb,float wc,float ia,float ib,float ic) {
    const float denominator=wa*ia+wb*ib+wc*ic;
    if(std::abs(denominator)<=1e-20f) throw std::domain_error("invalid perspective interpolation denominator");
    return {(wa*a.x*ia+wb*b.x*ib+wc*c.x*ic)/denominator,
            (wa*a.y*ia+wb*b.y*ib+wc*c.y*ic)/denominator};
}

} // namespace docmont::render
