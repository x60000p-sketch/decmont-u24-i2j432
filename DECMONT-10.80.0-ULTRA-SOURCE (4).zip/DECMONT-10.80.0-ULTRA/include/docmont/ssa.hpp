#pragma once
#include "docmont/ir.hpp"
#include <cstddef>
#include <memory>
#include <string>
#include <vector>

namespace docmont {
struct SSAUse { std::size_t instruction{}; std::string variable; std::size_t version{}; };
enum class SSAValueKind { Instruction, Phi, Entry };
struct SSAValueDefinition {
 std::size_t id{};
 std::size_t instruction{static_cast<std::size_t>(-1)};
 std::size_t block{static_cast<std::size_t>(-1)};
 OpCode op{OpCode::PushInt};
 SSAValueKind kind{SSAValueKind::Instruction};
 std::int64_t integer{};
 std::string text;
 std::size_t variable_version{};
 std::vector<std::size_t> operands;
};
struct SSAValueUse { std::size_t instruction{}; std::size_t value{}; std::size_t operand_index{}; };
// A proven closed interval for an integer-valued SSA definition. Definitions
// without a sound finite interval are omitted rather than widened unsafely.
struct SSAIntegerRange {
 std::size_t value{};
 std::int64_t minimum{}, maximum{};
};
struct SSAValuePhi {
 std::size_t block{};
 std::size_t stack_slot{};
 std::size_t result{};
 std::vector<std::pair<std::size_t,std::size_t>> incoming;
};
struct SSADef { std::size_t instruction{}; std::string variable; std::size_t version{}; };
struct SSAPhi { std::string variable; std::size_t result_version{}; std::vector<std::pair<std::size_t,std::size_t>> incoming; };
struct SSABlock {
 std::size_t id{}, begin{}, end{};
 std::vector<std::size_t> predecessors, successors, dominators, dominator_children, dominance_frontier;
 std::size_t immediate_dominator{static_cast<std::size_t>(-1)};
 std::vector<SSAPhi> phis;
};
enum class SSAMemoryEffect { Read, Write, ReadWrite, Unknown };
// Coarse alias partitions used by 7.40.0. HeapAggregate intentionally combines
// arrays and objects; ClosureCell is separate; Unknown aliases every partition.
enum class SSAAliasRegion { HeapAggregate, ClosureCell, Unknown };
enum class SSAAllocationKind { Array, Object, Closure };
struct SSAAllocationSite {
 std::size_t instruction{};
 SSAAllocationKind kind{SSAAllocationKind::Object};
};
struct SSAPointsToSet {
 std::size_t value{};
 std::vector<std::size_t> allocation_sites;
 // Symbolic origins identify function-entry arguments that may flow here.
 std::vector<std::size_t> parameter_indices;
 bool unknown{false};
};
struct SSAFieldPointsTo {
 std::size_t allocation_site{};
 std::string field;
 std::vector<std::size_t> allocation_sites;
 std::vector<std::size_t> parameter_indices;
 bool unknown{false};
};
struct SSAAliasAccess {
 std::size_t instruction{};
 SSAAliasRegion region{SSAAliasRegion::Unknown};
 bool read{false};
 bool write{false};
 // Bit 0 = HeapAggregate, bit 1 = ClosureCell, bit 2 = Unknown.
 std::uint8_t may_alias_mask{0x7};
 // Allocation-site provenance for the accessed base. Empty + unknown means
 // no statically recoverable allocation provenance is available.
 std::vector<std::size_t> points_to_sites;
 bool points_to_unknown{true};
 bool must_alias_singleton{false};
};
struct SSAMemoryDefinition {
 std::size_t id{};
 std::size_t instruction{static_cast<std::size_t>(-1)};
 std::size_t block{static_cast<std::size_t>(-1)};
 SSAMemoryEffect effect{SSAMemoryEffect::Write};
 bool phi{false};
 SSAAliasRegion region{SSAAliasRegion::HeapAggregate};
 // Empty identifies the coarse region token; non-empty keys identify a
 // field-sensitive heap partition such as object:<allocation-site>:<field>.
 std::string partition_key;
};
struct SSAMemoryUse {
 std::size_t instruction{};
 std::size_t version{};
 SSAMemoryEffect effect{SSAMemoryEffect::Read};
 SSAAliasRegion region{SSAAliasRegion::HeapAggregate};
 std::string partition_key;
};
struct SSAMemoryPhi {
 std::size_t block{};
 std::size_t result{};
 std::vector<std::pair<std::size_t,std::size_t>> incoming;
 SSAAliasRegion region{SSAAliasRegion::HeapAggregate};
 std::string partition_key;
};
struct SSAParameterEffect {
 std::size_t parameter_index{};
 bool may_read_memory{false};
 bool may_write_memory{false};
 bool may_escape{false};
};
struct SSAProgram;
struct SSAFunctionRegion {
 std::string name;
 std::size_t begin{}, end{}, arity{}; // absolute IR range; begin is first body instruction
 std::shared_ptr<SSAProgram> analysis;
 bool may_read_memory{false};
 bool may_write_memory{false};
 bool has_unknown_effects{false};
 // Region summaries: bit 0 = HeapAggregate, bit 1 = ClosureCell, bit 2 = Unknown.
 std::uint8_t alias_read_mask{0};
 std::uint8_t alias_write_mask{0};
 std::vector<std::string> callees;
 // Conservative return summary: the result may alias these parameters/sites.
 std::vector<std::size_t> return_parameter_indices;
 std::vector<std::size_t> return_allocation_sites;
 bool return_unknown{false};
 // Interprocedural argument effects, indexed by the callee's formal parameter.
 // These summaries are conservative and are propagated through direct calls.
 std::vector<SSAParameterEffect> parameter_effects;
};
struct SSAProgram {
 std::vector<SSABlock> blocks;
 std::vector<SSADef> definitions;
 std::vector<SSAUse> uses;
 std::size_t variable_count{}, phi_count{};
 bool stack_ssa_valid{true};
 std::vector<std::string> stack_ssa_errors;
 std::vector<SSAValueDefinition> value_definitions;
 std::vector<SSAValueUse> value_uses;
 std::vector<SSAIntegerRange> integer_ranges;
 std::vector<SSAValuePhi> stack_phis;
 // Conservative, unified heap/cell memory token SSA. Version 0 is the entry memory state.
 std::vector<SSAMemoryDefinition> memory_definitions;
 std::vector<SSAMemoryUse> memory_uses;
 std::vector<SSAMemoryPhi> memory_phis;
 std::vector<SSAAliasAccess> alias_accesses;
 std::vector<SSAAllocationSite> allocation_sites;
 std::vector<SSAPointsToSet> points_to_sets;
 std::vector<SSAFieldPointsTo> field_points_to;
 // Every function body is analyzed independently with its own CFG, variable SSA,
 // operand-stack SSA and memory SSA. The shared_ptr keeps this aggregate acyclic.
 std::vector<SSAFunctionRegion> functions;
};
struct SSAVerificationResult { bool ok{true}; std::vector<std::string> errors; };
SSAProgram build_ssa(const ProgramIR& program);
SSAVerificationResult verify_ssa(const SSAProgram& ssa, const ProgramIR& program);
std::string dump_ssa(const SSAProgram& program);
const char* to_string(SSAMemoryEffect effect);
const char* to_string(SSAAliasRegion region);
bool alias_regions_may_alias(SSAAliasRegion a, SSAAliasRegion b);
bool points_to_sets_may_alias(const SSAPointsToSet& a, const SSAPointsToSet& b);
const char* to_string(SSAAllocationKind kind);
}
