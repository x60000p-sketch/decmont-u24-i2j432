#pragma once
#include "docmont/ast.hpp"
#include "docmont/diagnostic.hpp"
#include <vector>
namespace docmont {
// Static checks for the 4.13 function-call contract. This does not execute functions.
std::vector<Diagnostic> validate_function_contracts(const Application& app);
}
