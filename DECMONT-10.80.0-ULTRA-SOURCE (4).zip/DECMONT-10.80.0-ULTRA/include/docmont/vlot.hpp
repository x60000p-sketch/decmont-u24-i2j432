#pragma once

#include "docmont/graphics.hpp"
#include <cstdint>
#include <string>
#include <vector>

namespace docmont::vlot {

enum class Platform { PC, Android, PS5 };
enum class BuildState { Ready, Planned, RequiresToolchain, Blocked };
enum class Renderer { Auto, Software, Vulkan, DirectX12, OpenGLES, ConsoleSDK };

struct ProjectConfig {
    std::string name;
    std::vector<Platform> targets;
    Renderer renderer{Renderer::Auto};
    std::string quality{"high"};
    std::string asset_root{"assets"};
};

struct Result {
    bool ok{false};
    std::string message;
};

struct DeviceProfile {
    Platform platform{Platform::PC};
    std::string name;
    std::vector<std::string> graphics_backends;
    std::string package_format;
    bool requires_vendor_sdk{false};
};

struct ToolchainAvailability {
    bool host_c_compiler{true};
    bool android_sdk{false};
    bool android_ndk{false};
    bool playstation_sdk{false};
};

struct BuildTargetPlan {
    Platform platform{Platform::PC};
    BuildState state{BuildState::Blocked};
    std::string backend;
    std::string artifact;
    std::string reason;
};

struct BuildPlan {
    std::string project_name;
    std::vector<BuildTargetPlan> targets;
};

struct Vec3 { float x{0}, y{0}, z{0}; };
struct Vertex { float x{0}, y{0}, depth{0}; Color color{}; };
struct SceneNode {
    std::string id;
    std::string parent;
    Vec3 position{};
    Vec3 scale{1,1,1};
    Color color{255,255,255};
    float width{1}, height{1};
};
struct Scene { std::vector<SceneNode> nodes; };

struct Asset {
    std::string logical_name;
    std::string relative_path;
    std::string kind;
};

Result load_project(const std::string& path, ProjectConfig& out);
Result validate_project(const ProjectConfig& project);
DeviceProfile device_profile(Platform platform);
BuildPlan create_build_plan(const ProjectConfig& project, const ToolchainAvailability& tools);
std::string to_string(Platform platform);
std::string to_string(BuildState state);
std::string format_build_plan(const BuildPlan& plan);
Result validate_scene(const Scene& scene);
Result validate_asset(const Asset& asset);

class SoftwareRenderer {
public:
    SoftwareRenderer(int width, int height, Color clear = {12,16,24});
    void clear(Color color);
    void triangle(const Vertex& a, const Vertex& b, const Vertex& c);
    void rectangle(float x, float y, float width, float height, float depth, Color color);
    bool write_ppm(const std::string& path) const;
    int width() const noexcept { return canvas_.width(); }
    int height() const noexcept { return canvas_.height(); }
private:
    Canvas canvas_;
    std::vector<float> depth_;
};

} // namespace docmont::vlot
