#pragma once
#include <array>
#include <cmath>
#include <cstddef>
#include <stdexcept>

namespace docmont::math {
struct Vec2 { float x{}, y{}; };
struct Vec3 { float x{}, y{}, z{}; };
struct Vec4 { float x{}, y{}, z{}, w{}; };
struct Quat {
    float x{}, y{}, z{}, w{1.0f};
    static constexpr Quat identity() noexcept { return {}; }
};
inline float dot(Quat a, Quat b) noexcept { return a.x*b.x+a.y*b.y+a.z*b.z+a.w*b.w; }
inline Quat normalize(Quat q) {
    const float n=std::sqrt(dot(q,q));
    if(n<=1e-20f) throw std::domain_error("cannot normalize a zero-length quaternion");
    return {q.x/n,q.y/n,q.z/n,q.w/n};
}
constexpr Quat operator*(Quat a, Quat b) noexcept {
    return {a.w*b.x+a.x*b.w+a.y*b.z-a.z*b.y,
            a.w*b.y-a.x*b.z+a.y*b.w+a.z*b.x,
            a.w*b.z+a.x*b.y-a.y*b.x+a.z*b.w,
            a.w*b.w-a.x*b.x-a.y*b.y-a.z*b.z};
}

constexpr Vec3 operator+(Vec3 a, Vec3 b) noexcept { return {a.x+b.x,a.y+b.y,a.z+b.z}; }
constexpr Vec3 operator-(Vec3 a, Vec3 b) noexcept { return {a.x-b.x,a.y-b.y,a.z-b.z}; }
constexpr Vec3 operator*(Vec3 v, float s) noexcept { return {v.x*s,v.y*s,v.z*s}; }
constexpr Vec3 operator*(float s, Vec3 v) noexcept { return v*s; }
constexpr Vec3 operator/(Vec3 v, float s) { return {v.x/s,v.y/s,v.z/s}; }
constexpr float dot(Vec3 a, Vec3 b) noexcept { return a.x*b.x+a.y*b.y+a.z*b.z; }
constexpr Vec3 cross(Vec3 a, Vec3 b) noexcept { return {a.y*b.z-a.z*b.y,a.z*b.x-a.x*b.z,a.x*b.y-a.y*b.x}; }
inline float length(Vec3 v) noexcept { return std::sqrt(dot(v,v)); }
inline Vec3 normalize(Vec3 v) { const float n=length(v); if(n<=1e-20f) throw std::domain_error("cannot normalize a zero-length vector"); return v/n; }

// Row-major 4x4 matrix; vectors are treated as column vectors.
struct Mat4 {
    std::array<float,16> m{};
    constexpr float& at(std::size_t row,std::size_t col) { return m[row*4+col]; }
    constexpr float at(std::size_t row,std::size_t col) const { return m[row*4+col]; }
    static constexpr Mat4 identity() noexcept {
        Mat4 r{}; r.m={1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1}; return r;
    }
    static constexpr Mat4 translation(Vec3 v) noexcept {
        Mat4 r=identity(); r.at(0,3)=v.x; r.at(1,3)=v.y; r.at(2,3)=v.z; return r;
    }
    static constexpr Mat4 scale(Vec3 v) noexcept {
        Mat4 r{}; r.at(0,0)=v.x; r.at(1,1)=v.y; r.at(2,2)=v.z; r.at(3,3)=1; return r;
    }
    static Mat4 rotation(Quat input) {
        const Quat q=normalize(input);
        const float xx=q.x*q.x, yy=q.y*q.y, zz=q.z*q.z;
        const float xy=q.x*q.y, xz=q.x*q.z, yz=q.y*q.z;
        const float wx=q.w*q.x, wy=q.w*q.y, wz=q.w*q.z;
        Mat4 r=identity();
        r.at(0,0)=1-2*(yy+zz); r.at(0,1)=2*(xy-wz); r.at(0,2)=2*(xz+wy);
        r.at(1,0)=2*(xy+wz); r.at(1,1)=1-2*(xx+zz); r.at(1,2)=2*(yz-wx);
        r.at(2,0)=2*(xz-wy); r.at(2,1)=2*(yz+wx); r.at(2,2)=1-2*(xx+yy);
        return r;
    }
};
constexpr Mat4 operator*(const Mat4& a,const Mat4& b) noexcept {
    Mat4 r{};
    for(std::size_t i=0;i<4;++i) for(std::size_t j=0;j<4;++j)
        for(std::size_t k=0;k<4;++k) r.at(i,j)+=a.at(i,k)*b.at(k,j);
    return r;
}
constexpr Vec4 operator*(const Mat4& a,Vec4 v) noexcept {
    return {a.at(0,0)*v.x+a.at(0,1)*v.y+a.at(0,2)*v.z+a.at(0,3)*v.w,
            a.at(1,0)*v.x+a.at(1,1)*v.y+a.at(1,2)*v.z+a.at(1,3)*v.w,
            a.at(2,0)*v.x+a.at(2,1)*v.y+a.at(2,2)*v.z+a.at(2,3)*v.w,
            a.at(3,0)*v.x+a.at(3,1)*v.y+a.at(3,2)*v.z+a.at(3,3)*v.w};
}
inline Vec3 transform_point(const Mat4& m,Vec3 p) {
    const Vec4 q=m*Vec4{p.x,p.y,p.z,1};
    if(std::abs(q.w)<=1e-20f) throw std::domain_error("point transformed to zero homogeneous w");
    return {q.x/q.w,q.y/q.w,q.z/q.w};
}
inline Mat4 perspective(float vertical_fov_radians,float aspect,float near_plane,float far_plane) {
    if(!(vertical_fov_radians>0 && vertical_fov_radians<3.14159265f) || !(aspect>0) || !(near_plane>0) || !(far_plane>near_plane))
        throw std::invalid_argument("invalid perspective projection parameters");
    const float f=1.0f/std::tan(vertical_fov_radians*0.5f);
    Mat4 r{}; r.at(0,0)=f/aspect; r.at(1,1)=f;
    r.at(2,2)=(far_plane+near_plane)/(near_plane-far_plane);
    r.at(2,3)=(2.0f*far_plane*near_plane)/(near_plane-far_plane);
    r.at(3,2)=-1.0f; return r;
}
} // namespace docmont::math
