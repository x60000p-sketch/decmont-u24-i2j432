#pragma once
#include <string>
namespace docmont {
enum class Severity { Warning, Error };
struct Diagnostic {
    Severity severity{Severity::Error};
    int line{1};
    int column{1};
    std::string message;
};
}
