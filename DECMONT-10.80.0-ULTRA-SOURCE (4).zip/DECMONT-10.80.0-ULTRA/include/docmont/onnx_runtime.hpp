#pragma once
#include <cstdint>
#include <map>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace docmont::neural {
struct Tensor {
    std::vector<std::int64_t> shape;
    std::vector<float> values;
    bool valid(std::size_t max_elements=16u*1024u*1024u) const noexcept;
};
struct NodeInfo { std::string op_type; std::vector<std::string> inputs, outputs; };
struct ModelInfo {
    std::string graph_name;
    std::vector<std::string> inputs, outputs;
    std::vector<NodeInfo> nodes;
    std::vector<std::string> unsupported_operators;
    std::uint64_t initializer_bytes{};
};
struct InferenceResult { bool ok{false}; std::map<std::string,Tensor> outputs; std::string error; };

// DOCMONT's bounded CPU ONNX inference runtime. It parses ONNX ModelProto wire
// format and executes the documented operator subset; it is not a replacement
// for the complete ONNX Runtime operator catalogue.
class OnnxModel {
public:
    bool load(const std::string& path, std::string* error=nullptr,
              std::size_t max_model_bytes=256u*1024u*1024u);
    bool load_bytes(const std::vector<std::uint8_t>& bytes, std::string* error=nullptr);
    bool loaded() const noexcept { return loaded_; }
    const ModelInfo& info() const noexcept { return info_; }
    InferenceResult run(const std::map<std::string,Tensor>& inputs,
                        std::size_t max_tensor_elements=16u*1024u*1024u) const;
public: // exposed only so the bounded protobuf decoder can remain allocation-light
    struct Attribute { std::string name; std::int64_t integer{}; float real{}; std::vector<std::int64_t> integers; };
    struct Node { NodeInfo info; std::vector<Attribute> attributes; };
private:
    ModelInfo info_;
    std::vector<Node> nodes_;
    std::map<std::string,Tensor> initializers_;
    bool loaded_{false};
};

std::vector<std::string> supported_operators();
} // namespace docmont::neural
