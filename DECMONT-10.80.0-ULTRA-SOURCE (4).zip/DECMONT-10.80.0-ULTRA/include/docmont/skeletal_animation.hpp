#pragma once
#include "docmont/math.hpp"
#include <array>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace docmont::animation {

struct Transform {
    math::Vec3 translation{};
    math::Quat rotation{};
    math::Vec3 scale{1.0f,1.0f,1.0f};
};

struct Bone {
    std::string name;
    std::int32_t parent{-1}; // parent must precede child
    Transform bind_local{};
    math::Mat4 inverse_bind{math::Mat4::identity()};
};

class Skeleton {
public:
    bool add_bone(Bone bone);
    bool validate(std::string* error=nullptr) const;
    std::size_t size() const noexcept { return bones_.size(); }
    const Bone& bone(std::size_t index) const { return bones_.at(index); }
    std::optional<std::size_t> find_bone(const std::string& name) const noexcept;
private:
    std::vector<Bone> bones_;
};

struct VecKey { float time{}; math::Vec3 value{}; };
struct QuatKey { float time{}; math::Quat value{}; };
struct BoneTrack {
    std::uint32_t bone{};
    std::vector<VecKey> translations;
    std::vector<QuatKey> rotations;
    std::vector<VecKey> scales;
};
struct AnimationClip {
    std::string name;
    float duration{};
    bool looping{true};
    std::vector<BoneTrack> tracks;
};
struct Pose { std::vector<Transform> local; };
struct SkeletonMatrices {
    std::vector<math::Mat4> global;
    std::vector<math::Mat4> skin;
};

struct BoneInfluence {
    std::array<std::uint16_t,4> indices{};
    std::array<float,4> weights{};
};
struct SkinnedVertex { math::Vec3 position{}; math::Vec3 normal{0,1,0}; };

class Animator {
public:
    static bool validate_clip(const Skeleton& skeleton, const AnimationClip& clip,
                              std::string* error=nullptr);
    static Pose bind_pose(const Skeleton& skeleton);
    static Pose sample(const Skeleton& skeleton, const AnimationClip& clip, float time);
    static std::optional<Pose> blend(const Pose& a, const Pose& b, float weight,
                                     std::string* error=nullptr);
    static std::optional<SkeletonMatrices> build_matrices(const Skeleton& skeleton,
                                                           const Pose& pose,
                                                           std::string* error=nullptr);
    static std::optional<std::vector<SkinnedVertex>> skin(
        const SkeletonMatrices& matrices,
        const std::vector<SkinnedVertex>& vertices,
        const std::vector<BoneInfluence>& influences,
        std::string* error=nullptr);
};

} // namespace docmont::animation
