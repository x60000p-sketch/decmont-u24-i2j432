#pragma once
#include <filesystem>
#include <fstream>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <vector>

namespace docmont::modules {
struct Import { std::string name; std::filesystem::path source; std::size_t line{}; std::string alias; };
struct Diagnostic { std::string code, message; std::filesystem::path source; std::size_t line{}; };
struct Resolution { std::vector<Import> imports; std::vector<std::filesystem::path> order; std::vector<Diagnostic> diagnostics; bool ok() const { return diagnostics.empty(); } };
inline std::string trim(std::string s) { auto a=s.find_first_not_of(" \t\r"); if(a==s.npos)return {}; auto b=s.find_last_not_of(" \t\r"); return s.substr(a,b-a+1); }
inline bool valid_name(const std::string& n) { if(n.empty()) return false; bool segment_start=true; for(char c:n){ if(c=='.'){if(segment_start)return false;segment_start=true;continue;} if(segment_start){if(!((c>='A'&&c<='Z')||(c>='a'&&c<='z')||c=='_'))return false;segment_start=false;} else if(!((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9')||c=='_'))return false;} return !segment_start; }
inline std::vector<Import> scan_imports(const std::filesystem::path& file, std::vector<Diagnostic>& ds) {
 std::ifstream in(file); std::vector<Import> out; if(!in){ds.push_back({"MOD001","cannot open source file",file,0});return out;}
 std::string line; std::size_t no=0; while(std::getline(in,line)){++no; auto s=trim(line); if(s.rfind("import ",0)!=0)continue; auto name=trim(s.substr(7)); auto semi=name.find(';'); if(semi!=std::string::npos)name=trim(name.substr(0,semi));
  std::string alias; auto as=name.find(" as "); if(as!=std::string::npos){alias=trim(name.substr(as+4));name=trim(name.substr(0,as));if(!valid_name(alias)){ds.push_back({"MOD005","invalid import alias",file,no});continue;}}
  if(!valid_name(name)){ds.push_back({"MOD002","invalid module name in import",file,no});continue;} out.push_back({name,file,no,alias}); }
 return out;
}
class Resolver {
 std::filesystem::path root_; std::map<std::string,std::filesystem::path> paths_; std::map<std::string,int> state_; Resolution result_;
 bool visit(const std::string& name,const std::filesystem::path& from,std::size_t line){
  if(state_[name]==1){result_.diagnostics.push_back({"MOD004","cyclic import involving '"+name+"'",from,line});return false;}
  if(state_[name]==2)return true;
  auto rel=name; for(char& c:rel)if(c=='.')c=std::filesystem::path::preferred_separator;
  auto path=root_/(rel+".docm"); if(!std::filesystem::exists(path)){result_.diagnostics.push_back({"MOD003","module source not found: '"+name+"'",from,line});return false;}
  path=std::filesystem::weakly_canonical(path);
  auto root_text=root_.generic_string(), path_text=path.generic_string();
  if(path_text.compare(0,root_text.size(),root_text)!=0 || (path_text.size()>root_text.size() && path_text[root_text.size()]!='/')){result_.diagnostics.push_back({"MOD006","module path escapes resolver root",from,line});return false;}
  state_[name]=1; paths_[name]=path; auto imports=scan_imports(path,result_.diagnostics); result_.imports.insert(result_.imports.end(),imports.begin(),imports.end());
  for(const auto& i:imports)visit(i.name,path,i.line); state_[name]=2; result_.order.push_back(path); return true;
 }
public:
 explicit Resolver(std::filesystem::path root):root_(std::filesystem::weakly_canonical(std::move(root))){}
 Resolution resolve(const std::filesystem::path& entry){ result_={}; state_.clear(); auto imports=scan_imports(entry,result_.diagnostics); result_.imports=imports; for(const auto& i:imports)visit(i.name,entry,i.line); if(result_.diagnostics.empty())result_.order.push_back(entry); return result_; }
};
}
