#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory_resource>
#include <new>
#include <optional>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace docmont::memory {

// DOCMONT 4.27 budgeted heap. This is deterministic explicit allocation,
// not a tracing garbage collector. The owner must release all allocations
// before destroying the Heap or its HeapResource adapters.
class Heap {
public:
    struct Stats {
        std::size_t live_bytes{};
        std::size_t peak_bytes{};
        std::size_t live_blocks{};
        std::size_t total_allocations{};
        std::size_t total_deallocations{};
        std::size_t failed_allocations{};
        std::size_t budget_bytes{};
    };
    struct Checkpoint { std::uint64_t sequence{}; };
    struct LeakRecord {
        void* address{};
        std::size_t bytes{};
        std::size_t alignment{};
        std::string tag;
        std::uint64_t sequence{};
    };

    explicit Heap(std::size_t budget_bytes = 64U * 1024U * 1024U) : budget_(budget_bytes) {
        if (budget_ == 0) throw std::invalid_argument("heap budget must be non-zero");
    }
    Heap(const Heap&) = delete;
    Heap& operator=(const Heap&) = delete;
    Heap(Heap&&) = delete;
    Heap& operator=(Heap&&) = delete;
    ~Heap() { clear(); }

    // 1-4: bounded, zero-size-safe, aligned, overflow-safe allocation.
    void* allocate(std::size_t bytes, std::size_t alignment = alignof(std::max_align_t),
                   std::string tag = "untagged") {
        if (bytes == 0) bytes = 1;
        if (alignment == 0 || (alignment & (alignment - 1)) != 0) {
            ++stats_.failed_allocations;
            throw std::invalid_argument("alignment must be a non-zero power of two");
        }
        if (stats_.live_bytes > budget_ || bytes > budget_ - stats_.live_bytes) {
            ++stats_.failed_allocations;
            throw std::bad_alloc();
        }
        void* ptr = nullptr;
        try {
            ptr = ::operator new(bytes, std::align_val_t(alignment));
            const auto sequence = ++sequence_;
            try {
                blocks_.emplace(ptr, Block{bytes, alignment, nullptr, std::move(tag), sequence});
            } catch (...) {
                ::operator delete(ptr, std::align_val_t(alignment));
                throw;
            }
        } catch (...) {
            ++stats_.failed_allocations;
            throw;
        }
        stats_.live_bytes += bytes;
        stats_.peak_bytes = std::max(stats_.peak_bytes, stats_.live_bytes);
        ++stats_.total_allocations;
        stats_.live_blocks = blocks_.size();
        return ptr;
    }

    // 5-7: non-throwing allocation probe and typed construction helpers.
    void* try_allocate(std::size_t bytes, std::size_t alignment = alignof(std::max_align_t),
                       std::string tag = "try") noexcept {
        try { return allocate(bytes, alignment, std::move(tag)); }
        catch (...) { return nullptr; }
    }

    template<class T, class... Args> T* make(Args&&... args) {
        return make_tagged<T>("object", std::forward<Args>(args)...);
    }
    template<class T, class... Args> T* make_tagged(const std::string& tag, Args&&... args) {
        void* raw = allocate(sizeof(T), alignof(T), tag);
        try {
            T* object = ::new (raw) T(std::forward<Args>(args)...);
            blocks_.at(raw).destroy = [](void* value) { static_cast<T*>(value)->~T(); };
            return object;
        } catch (...) { (void)deallocate(raw); throw; }
    }

    // 8-12: safe release, stale/double-free rejection, typed destruction,
    // ownership and allocation metadata queries.
    bool deallocate(void* ptr) noexcept {
        if (!ptr) return true;
        const auto it = blocks_.find(ptr);
        if (it == blocks_.end()) return false;
        const Block block = it->second;
        blocks_.erase(it);
        if (block.destroy) block.destroy(ptr);
        stats_.live_bytes -= block.bytes;
        ++stats_.total_deallocations;
        stats_.live_blocks = blocks_.size();
        ::operator delete(ptr, std::align_val_t(block.alignment));
        return true;
    }
    template<class T> bool destroy(T* ptr) noexcept { return deallocate(static_cast<void*>(ptr)); }
    bool owns(const void* ptr) const noexcept { return ptr && blocks_.find(const_cast<void*>(ptr)) != blocks_.end(); }
    std::optional<std::size_t> allocation_size(const void* ptr) const noexcept {
        const auto it = blocks_.find(const_cast<void*>(ptr));
        if (it == blocks_.end()) return std::nullopt;
        return it->second.bytes;
    }
    std::optional<std::size_t> allocation_alignment(const void* ptr) const noexcept {
        const auto it = blocks_.find(const_cast<void*>(ptr));
        if (it == blocks_.end()) return std::nullopt;
        return it->second.alignment;
    }
    std::optional<std::string> allocation_tag(const void* ptr) const {
        const auto it = blocks_.find(const_cast<void*>(ptr));
        if (it == blocks_.end()) return std::nullopt;
        return it->second.tag;
    }

    // 13-18: budget management, available capacity, snapshots and peak reset.
    bool set_budget(std::size_t bytes) noexcept {
        if (bytes == 0 || bytes < stats_.live_bytes) return false;
        budget_ = bytes;
        return true;
    }
    std::size_t budget_bytes() const noexcept { return budget_; }
    std::size_t available_bytes() const noexcept { return budget_ - stats_.live_bytes; }
    bool empty() const noexcept { return blocks_.empty(); }
    const Stats& stats() const noexcept {
        snapshot_ = stats_;
        snapshot_.live_blocks = blocks_.size();
        snapshot_.budget_bytes = budget_;
        return snapshot_;
    }
    void reset_peak() noexcept { stats_.peak_bytes = stats_.live_bytes; }

    // 19-23: tagged accounting, leak inspection, invariant validation.
    std::size_t allocation_count(const std::string& tag) const noexcept {
        std::size_t count = 0;
        for (const auto& entry : blocks_) if (entry.second.tag == tag) ++count;
        return count;
    }
    std::size_t bytes_for_tag(const std::string& tag) const noexcept {
        std::size_t total = 0;
        for (const auto& entry : blocks_) if (entry.second.tag == tag) total += entry.second.bytes;
        return total;
    }
    std::vector<LeakRecord> leak_report() const {
        std::vector<LeakRecord> report;
        report.reserve(blocks_.size());
        for (const auto& entry : blocks_)
            report.push_back({entry.first, entry.second.bytes, entry.second.alignment,
                              entry.second.tag, entry.second.sequence});
        std::sort(report.begin(), report.end(), [](const auto& a, const auto& b) { return a.sequence < b.sequence; });
        return report;
    }
    bool validate() const noexcept {
        std::size_t bytes = 0;
        for (const auto& entry : blocks_) {
            if (!entry.first || entry.second.bytes == 0 || entry.second.alignment == 0) return false;
            if (entry.second.bytes > std::numeric_limits<std::size_t>::max() - bytes) return false;
            bytes += entry.second.bytes;
        }
        return bytes == stats_.live_bytes && bytes <= budget_ && blocks_.size() == stats_.live_blocks;
    }

    // 24-27: allocation checkpoints and deterministic rollback.
    Checkpoint checkpoint() const noexcept { return {sequence_}; }
    std::size_t rollback(Checkpoint point) {
        std::vector<void*> victims;
        for (const auto& entry : blocks_) if (entry.second.sequence > point.sequence) victims.push_back(entry.first);
        std::size_t released = 0;
        for (void* ptr : victims) if (deallocate(ptr)) ++released;
        return released;
    }
    std::uint64_t allocation_sequence() const noexcept { return sequence_; }
    bool clear_one(const std::string& tag) noexcept {
        for (const auto& entry : blocks_) {
            if (entry.second.tag == tag) return deallocate(entry.first);
        }
        return false;
    }

    // 28-30: clear-all, explicit destructor tracking, and PMR compatibility.
    void clear() noexcept {
        while (!blocks_.empty()) (void)deallocate(blocks_.begin()->first);
    }

private:
    struct Block {
        std::size_t bytes;
        std::size_t alignment;
        void (*destroy)(void*){};
        std::string tag;
        std::uint64_t sequence{};
    };
    std::size_t budget_;
    std::unordered_map<void*, Block> blocks_;
    Stats stats_{};
    mutable Stats snapshot_{};
    std::uint64_t sequence_{};
};

class HeapResource final : public std::pmr::memory_resource {
public:
    explicit HeapResource(Heap& heap) noexcept : heap_(heap) {}
private:
    void* do_allocate(std::size_t bytes, std::size_t alignment) override {
        return heap_.allocate(bytes, alignment, "pmr-container");
    }
    void do_deallocate(void* ptr, std::size_t, std::size_t) override {
        if (!heap_.deallocate(ptr)) std::terminate();
    }
    bool do_is_equal(const std::pmr::memory_resource& other) const noexcept override {
        return this == &other;
    }
    Heap& heap_;
};

} // namespace docmont::memory
