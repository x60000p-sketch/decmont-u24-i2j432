#pragma once
#include <string>
namespace docmont {
enum class TokenKind { Identifier, String, Number, LBrace, RBrace, LBracket, RBracket,
                       LParen, RParen, Equal, Colon, Comma, Dot, Plus, Minus, Star, Slash, Less, LessEqual, Greater, GreaterEqual, EqualEqual, BangEqual, Bang, AndAnd, OrOr, DoubleColon, Arrow, Question, Ampersand,
                       Newline, End, Invalid };
struct Token { TokenKind kind; std::string text; int line{1}; int column{1}; };
const char* token_name(TokenKind kind);
}
