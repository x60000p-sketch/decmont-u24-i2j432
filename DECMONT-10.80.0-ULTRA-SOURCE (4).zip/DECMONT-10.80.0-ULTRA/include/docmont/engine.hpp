#pragma once

#include "docmont/math.hpp"
#include <cstdint>
#include <functional>
#include <memory>
#include <limits>
#include <optional>
#include <stdexcept>
#include <typeindex>
#include <unordered_map>
#include <utility>
#include <vector>

namespace docmont::engine {

// Entity handles are generation-checked: a destroyed handle can never alias a
// later entity that reuses the same slot.
struct Entity {
    std::uint32_t index{0};
    std::uint32_t generation{0};
    friend constexpr bool operator==(Entity a, Entity b) noexcept {
        return a.index == b.index && a.generation == b.generation;
    }
    friend constexpr bool operator!=(Entity a, Entity b) noexcept { return !(a == b); }
};

struct EntityHash {
    std::size_t operator()(Entity e) const noexcept {
        const std::size_t a = std::hash<std::uint32_t>{}(e.index);
        const std::size_t b = std::hash<std::uint32_t>{}(e.generation);
        return a ^ (b + static_cast<std::size_t>(0x9e3779b9U) + (a << 6U) + (a >> 2U));
    }
};

class Registry {
    struct PoolBase {
        virtual ~PoolBase() = default;
        virtual void erase(std::uint32_t index) = 0;
    };
    template<class T> struct Pool final : PoolBase {
        std::unordered_map<std::uint32_t, T> values;
        void erase(std::uint32_t index) override { values.erase(index); }
    };
public:
    Entity create() {
        std::uint32_t index;
        if (free_.empty()) {
            if (generations_.size() >= std::numeric_limits<std::uint32_t>::max()) throw std::length_error("entity capacity exhausted");
            index = static_cast<std::uint32_t>(generations_.size());
            generations_.push_back(1);
            alive_.push_back(true);
        } else {
            index = free_.back(); free_.pop_back(); alive_[index] = true;
        }
        ++alive_count_;
        return {index, generations_[index]};
    }

    bool valid(Entity e) const noexcept {
        return e.index < generations_.size() && alive_[e.index] && generations_[e.index] == e.generation;
    }

    bool destroy(Entity e) {
        if (!valid(e)) return false;
        for (auto& item : pools_) item.second->erase(e.index);
        alive_[e.index] = false;
        if (++generations_[e.index] == 0) ++generations_[e.index];
        free_.push_back(e.index);
        --alive_count_;
        return true;
    }

    std::size_t size() const noexcept { return alive_count_; }

    template<class T, class... Args> T& emplace(Entity e, Args&&... args) {
        require(e);
        auto& values = pool<T>().values;
        auto result = values.emplace(e.index, T(std::forward<Args>(args)...));
        if (!result.second) throw std::logic_error("entity already owns this component");
        return result.first->second;
    }

    template<class T> T* get(Entity e) noexcept {
        if (!valid(e)) return nullptr;
        auto* p = find_pool<T>();
        if (!p) return nullptr;
        auto it = p->values.find(e.index);
        return it == p->values.end() ? nullptr : &it->second;
    }
    template<class T> const T* get(Entity e) const noexcept {
        if (!valid(e)) return nullptr;
        auto* p = find_pool<T>();
        if (!p) return nullptr;
        auto it = p->values.find(e.index);
        return it == p->values.end() ? nullptr : &it->second;
    }
    template<class T> bool has(Entity e) const noexcept { return get<T>(e) != nullptr; }
    template<class T> bool remove(Entity e) {
        if (!valid(e)) return false;
        auto* p = find_pool<T>();
        return p && p->values.erase(e.index) != 0;
    }

    template<class... Ts> std::vector<Entity> view() const {
        std::vector<Entity> result;
        for (std::uint32_t i = 0; i < alive_.size(); ++i) {
            if (!alive_[i]) continue;
            Entity e{i, generations_[i]};
            if ((has<Ts>(e) && ...)) result.push_back(e);
        }
        return result;
    }
private:
    void require(Entity e) const { if (!valid(e)) throw std::invalid_argument("stale or invalid entity handle"); }
    template<class T> Pool<T>& pool() {
        const std::type_index key(typeid(T));
        auto it = pools_.find(key);
        if (it == pools_.end()) it = pools_.emplace(key, std::make_unique<Pool<T>>()).first;
        return static_cast<Pool<T>&>(*it->second);
    }
    template<class T> Pool<T>* find_pool() noexcept {
        auto it = pools_.find(std::type_index(typeid(T)));
        return it == pools_.end() ? nullptr : static_cast<Pool<T>*>(it->second.get());
    }
    template<class T> const Pool<T>* find_pool() const noexcept {
        auto it = pools_.find(std::type_index(typeid(T)));
        return it == pools_.end() ? nullptr : static_cast<const Pool<T>*>(it->second.get());
    }
    std::vector<std::uint32_t> generations_;
    std::vector<bool> alive_;
    std::vector<std::uint32_t> free_;
    std::unordered_map<std::type_index, std::unique_ptr<PoolBase>> pools_;
    std::size_t alive_count_{0};
};

struct Transform {
    math::Vec3 position{};
    math::Vec3 scale{1.0f, 1.0f, 1.0f};
    math::Quat rotation{};
    math::Mat4 local_matrix() const {
        return math::Mat4::translation(position) * math::Mat4::rotation(rotation) * math::Mat4::scale(scale);
    }
};

// A deterministic transform hierarchy. Reparenting rejects cycles and stale IDs.
class SceneGraph {
public:
    using NodeId = std::uint32_t;
    NodeId create(Transform transform = {}) {
        if (nodes_.size() >= std::numeric_limits<NodeId>::max()) throw std::length_error("scene graph node capacity exhausted");
        const NodeId id = static_cast<NodeId>(nodes_.size());
        nodes_.push_back(Node{transform, std::nullopt, true});
        return id;
    }
    bool valid(NodeId id) const noexcept { return id < nodes_.size() && nodes_[id].alive; }
    bool set_transform(NodeId id, Transform transform) {
        if (!valid(id)) return false;
        nodes_[id].transform = transform; return true;
    }
    bool set_parent(NodeId child, std::optional<NodeId> parent) {
        if (!valid(child) || (parent && !valid(*parent)) || (parent && *parent == child)) return false;
        auto cursor = parent;
        while (cursor) {
            if (*cursor == child) return false;
            cursor = nodes_[*cursor].parent;
        }
        nodes_[child].parent = parent;
        return true;
    }
    std::optional<NodeId> parent(NodeId id) const noexcept {
        return valid(id) ? nodes_[id].parent : std::nullopt;
    }
    std::optional<math::Mat4> world_matrix(NodeId id) const {
        if (!valid(id)) return std::nullopt;
        math::Mat4 result = nodes_[id].transform.local_matrix();
        auto cursor = nodes_[id].parent;
        std::size_t depth = 0;
        while (cursor) {
            if (!valid(*cursor) || ++depth > nodes_.size()) return std::nullopt;
            result = nodes_[*cursor].transform.local_matrix() * result;
            cursor = nodes_[*cursor].parent;
        }
        return result;
    }
    std::size_t size() const noexcept {
        std::size_t count = 0; for (const auto& node : nodes_) if (node.alive) ++count; return count;
    }
private:
    struct Node { Transform transform; std::optional<NodeId> parent; bool alive; };
    std::vector<Node> nodes_;
};

} // namespace docmont::engine
