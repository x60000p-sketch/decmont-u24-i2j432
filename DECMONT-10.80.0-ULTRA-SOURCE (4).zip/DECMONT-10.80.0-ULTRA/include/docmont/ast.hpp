#pragma once
#include <memory>
#include <string>
#include <vector>
namespace docmont {
enum class ExprKind { Integer, Boolean, String, Identifier, Unary, Binary, ArrayLiteral, ObjectLiteral, Member, Call, Index, Lambda, Try };
struct FunctionDecl;
struct Expr {
    ExprKind kind{ExprKind::Integer};
    std::string text;
    std::string op;
    std::shared_ptr<Expr> left, right;
    std::vector<std::shared_ptr<Expr>> elements;
    std::vector<std::pair<std::string, std::shared_ptr<Expr>>> properties;
    std::string callee;
    std::shared_ptr<FunctionDecl> lambda_function;
    int line{1}, column{1};
};
struct Statement {
    enum class Kind { Let, Assign, Output, If, ForEach, While, Break, Continue, Return, Expression, Match } kind{Kind::Output};
    std::string name;
    std::shared_ptr<Expr> expression;
    std::shared_ptr<Expr> target_index;
    std::shared_ptr<Expr> target_member;
    std::vector<Statement> body;
    std::vector<Statement> else_body;
    std::vector<std::shared_ptr<struct MatchArm>> match_arms;
    int line{1};
};
struct MatchArm { std::string enum_name; std::string variant; std::string binding; bool wildcard{false}; std::vector<Statement> body; int line{1}; };
struct Parameter { std::string name; std::string type; std::shared_ptr<Expr> default_value; int line{1}; };
struct GenericTypeParameter { std::string name; std::vector<std::string> trait_bounds; int line{1}; };
struct FunctionDecl { std::string name; std::vector<GenericTypeParameter> type_parameters; std::vector<Parameter> parameters; std::string return_type; std::vector<Statement> body; int line{1}; };
struct EnumVariantDecl { std::string name; std::vector<std::string> payload_types; int line{1}; };
struct EnumDecl { std::string name; std::vector<EnumVariantDecl> variants; int line{1}; };
struct Property { std::string key, value; int line{1}; };
struct Block { std::string name; std::vector<Property> properties; int line{1}; };
struct ImportDecl { std::string module, alias; int line{1}; };
struct Application {
    std::string name;
    std::string architecture{"x86_64"};
    std::vector<Block> blocks;
    std::vector<std::string> outputs; // legacy literal output compatibility
    std::vector<Statement> statements;
    std::string module_name;
    std::vector<ImportDecl> imports;
    std::vector<FunctionDecl> functions;
    std::vector<EnumDecl> enums;
    bool complete{false};
};
}
