#pragma once
#include "docmont/ir.hpp"
#include <cstdint>
#include <vector>
#include "docmont/ast.hpp"
namespace docmont {
int execute(const ProgramIR& ir);
int execute_application(const Application& app);
int execute_bytecode(const std::vector<std::uint8_t>& bytes);
}
