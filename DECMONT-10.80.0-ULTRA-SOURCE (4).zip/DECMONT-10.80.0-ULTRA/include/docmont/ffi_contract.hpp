#pragma once
#include <string>
#include <vector>
namespace docmont::ffi {
enum class CType { Void, Bool8, I32, I64, F32, F64, Utf8Pointer, OpaquePointer, Unsupported };
struct FunctionABI {
    std::string symbol;
    std::string calling_convention{"C"};
    std::vector<CType> parameters;
    CType result{CType::Void};
    bool variadic{false};
    bool exported{false};
    bool owned_string_result{false};
};
struct Validation { bool ok{false}; std::vector<std::string> errors; };
Validation validate_c_abi(const FunctionABI& function);
const char* c_type_name(CType type) noexcept;
} // namespace docmont::ffi
