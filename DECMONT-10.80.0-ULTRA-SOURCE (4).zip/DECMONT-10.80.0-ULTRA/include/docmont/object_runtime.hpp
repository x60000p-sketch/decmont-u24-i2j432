#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <limits>
#include <memory>
#include <mutex>
#include <stdexcept>
#include <string>
#include <typeindex>
#include <typeinfo>
#include <utility>
#include <vector>

namespace docmont::objects {

// DOCMONT 4.28 object table. Handles are stable identities; object addresses are
// not exposed as identities. Handle operations are synchronized. A raw pointer
// returned by get() must not be used concurrently with release()/clear().
class ObjectRuntime {
public:
    struct Handle {
        std::uint32_t index{invalid_index};
        std::uint32_t generation{};
        static constexpr std::uint32_t invalid_index = std::numeric_limits<std::uint32_t>::max();
        explicit operator bool() const noexcept { return index != invalid_index; }
        friend bool operator==(Handle a, Handle b) noexcept {
            return a.index == b.index && a.generation == b.generation;
        }
        friend bool operator!=(Handle a, Handle b) noexcept { return !(a == b); }
    };
    struct Stats {
        std::size_t live_objects{};
        std::size_t total_created{};
        std::size_t total_destroyed{};
        std::size_t retain_operations{};
        std::size_t release_operations{};
        std::size_t stale_handle_rejections{};
        std::size_t slots{};
    };
    struct Record {
        Handle handle;
        std::size_t references{};
        std::string type_name;
    };

    class Root {
    public:
        Root() = default;
        Root(ObjectRuntime& runtime, Handle handle) : runtime_(&runtime), handle_(handle) {
            if (!runtime_->retain(handle_)) throw std::invalid_argument("cannot root a stale object handle");
        }
        Root(const Root& other) : runtime_(other.runtime_), handle_(other.handle_) {
            if (runtime_ && !runtime_->retain(handle_)) throw std::runtime_error("root copy encountered stale handle");
        }
        Root& operator=(const Root& other) {
            if (this == &other) return *this;
            Root copy(other); swap(copy); return *this;
        }
        Root(Root&& other) noexcept : runtime_(std::exchange(other.runtime_, nullptr)), handle_(other.handle_) {}
        Root& operator=(Root&& other) noexcept {
            if (this != &other) { reset(); runtime_ = std::exchange(other.runtime_, nullptr); handle_ = other.handle_; }
            return *this;
        }
        ~Root() { reset(); }
        Handle handle() const noexcept { return handle_; }
        explicit operator bool() const noexcept { return runtime_ != nullptr; }
        void reset() noexcept { if (runtime_) { (void)runtime_->release(handle_); runtime_ = nullptr; } }
        void swap(Root& other) noexcept { std::swap(runtime_, other.runtime_); std::swap(handle_, other.handle_); }
    private:
        ObjectRuntime* runtime_{};
        Handle handle_{};
    };

    ObjectRuntime() = default;
    ObjectRuntime(const ObjectRuntime&) = delete;
    ObjectRuntime& operator=(const ObjectRuntime&) = delete;
    ~ObjectRuntime() { clear(); }

    template<class T, class... Args>
    Handle create(Args&&... args) {
        static_assert(!std::is_array_v<T>, "array objects are not supported; wrap them in a struct");
        auto object = std::make_shared<T>(std::forward<Args>(args)...);
        std::lock_guard<std::mutex> lock(mutex_);
        std::uint32_t index;
        if (!free_.empty()) { index = free_.back(); free_.pop_back(); }
        else {
            if (slots_.size() >= Handle::invalid_index) throw std::length_error("object handle table exhausted");
            index = static_cast<std::uint32_t>(slots_.size());
            free_.reserve(slots_.size() + 1); // Keep release() allocation-free and noexcept.
            slots_.emplace_back();
        }
        Slot& slot = slots_[index];
        slot.object = std::move(object);
        slot.type = std::type_index(typeid(T));
        slot.type_name = typeid(T).name();
        slot.references = 1;
        slot.live = true;
        ++stats_.live_objects;
        ++stats_.total_created;
        stats_.slots = slots_.size();
        return {index, slot.generation};
    }

    template<class T> T* get(Handle handle) noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        Slot* slot = find_locked(handle);
        if (!slot || slot->type != std::type_index(typeid(T))) { reject_locked(); return nullptr; }
        return static_cast<T*>(slot->object.get());
    }
    template<class T> const T* get(Handle handle) const noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        const Slot* slot = find_locked(handle);
        if (!slot || slot->type != std::type_index(typeid(T))) { reject_locked(); return nullptr; }
        return static_cast<const T*>(slot->object.get());
    }
    bool retain(Handle handle) noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        Slot* slot = find_locked(handle);
        if (!slot || slot->references == std::numeric_limits<std::size_t>::max()) { reject_locked(); return false; }
        ++slot->references; ++stats_.retain_operations; return true;
    }
    bool release(Handle handle) noexcept {
        std::shared_ptr<void> retired;
        {
            std::lock_guard<std::mutex> lock(mutex_);
            Slot* slot = find_locked(handle);
            if (!slot || slot->references == 0) { reject_locked(); return false; }
            --slot->references; ++stats_.release_operations;
            if (slot->references != 0) return true;
            retired = std::move(slot->object); // User destructor runs after unlocking.
            slot->type = std::type_index(typeid(void));
            slot->type_name.clear();
            slot->live = false;
            ++slot->generation;
            if (slot->generation == 0) ++slot->generation;
            free_.push_back(handle.index);
            --stats_.live_objects; ++stats_.total_destroyed;
        }
        retired.reset();
        return true;
    }
    bool alive(Handle handle) const noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        return find_locked(handle) != nullptr;
    }
    std::size_t reference_count(Handle handle) const noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        const Slot* slot = find_locked(handle); return slot ? slot->references : 0;
    }
    std::string type_name(Handle handle) const {
        std::lock_guard<std::mutex> lock(mutex_);
        const Slot* slot = find_locked(handle); return slot ? slot->type_name : std::string{};
    }
    Root root(Handle handle) { return Root(*this, handle); }
    std::vector<Record> snapshot() const {
        std::lock_guard<std::mutex> lock(mutex_);
        std::vector<Record> result; result.reserve(stats_.live_objects);
        for (std::size_t i = 0; i < slots_.size(); ++i) {
            const Slot& slot = slots_[i];
            if (slot.live) result.push_back({{static_cast<std::uint32_t>(i), slot.generation}, slot.references, slot.type_name});
        }
        return result;
    }
    Stats stats() const noexcept { std::lock_guard<std::mutex> lock(mutex_); Stats s = stats_; s.slots = slots_.size(); return s; }
    bool validate() const noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        std::size_t live = 0;
        for (const auto& slot : slots_) {
            if (slot.live) { if (!slot.object || slot.references == 0) return false; ++live; }
            else if (slot.object || slot.references != 0) return false;
        }
        if (live != stats_.live_objects) return false;
        for (std::size_t i = 0; i < free_.size(); ++i) {
            const auto index = free_[i];
            if (index >= slots_.size() || slots_[index].live) return false;
            for (std::size_t j = i + 1; j < free_.size(); ++j) if (free_[j] == index) return false;
        }
        return true;
    }
    void clear() noexcept {
        std::lock_guard<std::mutex> lock(mutex_);
        for (auto& slot : slots_) if (slot.live) {
            slot.object.reset(); slot.type = std::type_index(typeid(void)); slot.type_name.clear();
            slot.references = 0; slot.live = false; ++slot.generation; if (slot.generation == 0) ++slot.generation;
            ++stats_.total_destroyed;
        }
        free_.clear(); // Vacated slots remain valid-but-unused; future creates append safely.
        stats_.live_objects = 0; stats_.slots = slots_.size();
    }

private:
    struct Slot {
        std::shared_ptr<void> object;
        std::type_index type{typeid(void)};
        std::string type_name;
        std::size_t references{};
        std::uint32_t generation{1};
        bool live{};
    };
    mutable std::mutex mutex_;
    std::vector<Slot> slots_;
    std::vector<std::uint32_t> free_;
    mutable Stats stats_{};
    void reject_locked() const noexcept { ++stats_.stale_handle_rejections; }
    Slot* find_locked(Handle h) noexcept {
        if (!h || h.index >= slots_.size()) return nullptr;
        Slot& slot = slots_[h.index]; return slot.live && slot.generation == h.generation ? &slot : nullptr;
    }
    const Slot* find_locked(Handle h) const noexcept {
        if (!h || h.index >= slots_.size()) return nullptr;
        const Slot& slot = slots_[h.index]; return slot.live && slot.generation == h.generation ? &slot : nullptr;
    }
};

} // namespace docmont::objects
