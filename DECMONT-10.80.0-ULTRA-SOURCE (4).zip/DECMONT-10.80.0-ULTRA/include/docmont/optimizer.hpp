#pragma once
#include "docmont/ir.hpp"
#include <cstddef>
namespace docmont {
struct OptimizationStats { std::size_t instructions_before{0}; std::size_t instructions_after{0}; std::size_t constants_folded{0};
 std::size_t algebraic_simplifications{0}; std::size_t constant_propagations{0};
 std::size_t unreachable_instructions_removed{0};
 std::size_t constant_branches_folded{0}; std::size_t jump_threads{0};
 std::size_t ssa_gvn_eliminations{0};
 std::size_t ssa_gvn_cross_block_eliminations{0};
 std::size_t ssa_memory_load_eliminations{0};
 std::size_t ssa_memory_load_cross_block_eliminations{0};
 std::size_t ssa_heap_stores_removed{0};
 std::size_t ssa_dead_stores_removed{0};
 std::size_t ssa_global_dce_instructions_removed{0}; };
OptimizationStats optimize_ir(ProgramIR& program);
}
