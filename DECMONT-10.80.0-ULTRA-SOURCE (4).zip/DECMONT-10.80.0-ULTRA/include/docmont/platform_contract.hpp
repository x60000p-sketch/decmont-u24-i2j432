#pragma once
#include <cstddef>
#include <cstdint>
#include <string>
#include <string_view>
#include <vector>

namespace docmont::platform {
// Stable architectural contracts. A selected backend is a request, not proof
// that a toolchain/device backend is installed or operational.
enum class ExecutionMode { Auto, VM, JIT, Native, WebAssembly };
enum class MemoryMode { Ownership, OwnershipWithGC, Manual, Hybrid };
enum class Target { PortableVM, WindowsX64, WindowsArm64, LinuxX64, LinuxArm64, MacOSX64, MacOSArm64, AndroidArm64, IOSArm64, WebWasm32, FreeBSDX64, RiscV64 };
enum class BackendStatus { Planned, HostImplemented, RequiresToolchain, RequiresVendorSDK };

struct RuntimeConfig {
    ExecutionMode execution{ExecutionMode::Auto};
    MemoryMode memory{MemoryMode::Hybrid};
    bool bounds_checks{true};
    bool deterministic{true};
    bool allow_unsafe{false};
    std::size_t heap_limit_bytes{256u * 1024u * 1024u};
};
struct Validation { bool ok{true}; std::string message{"ok"}; };
inline Validation validate(const RuntimeConfig& c) {
    if (c.heap_limit_bytes < 4096) return {false, "heap_limit_bytes must be at least 4096"};
    if (c.memory == MemoryMode::Manual && !c.allow_unsafe)
        return {false, "manual memory requires explicit allow_unsafe"};
    if (!c.bounds_checks && !c.allow_unsafe)
        return {false, "disabling bounds checks requires explicit allow_unsafe"};
    return {};
}
struct TargetDescriptor { Target target; std::string_view name; BackendStatus status; std::string_view note; };
inline constexpr TargetDescriptor targets[] = {
    {Target::PortableVM,"portable-vm",BackendStatus::HostImplemented,"DVM v1 is architecture-neutral; build the DOCMONT VM for each destination host"},
    {Target::WindowsX64,"windows-x86_64",BackendStatus::RequiresToolchain,"portable C11 subset; matching Windows C toolchain and runtime validation required"},
    {Target::WindowsArm64,"windows-aarch64",BackendStatus::RequiresToolchain,"requires an ARM64 Windows toolchain and runtime validation"},
    {Target::LinuxX64,"linux-x86_64",BackendStatus::HostImplemented,"host VM build and portable C11 source emission available; native feature parity is incomplete"},
    {Target::LinuxArm64,"linux-aarch64",BackendStatus::RequiresToolchain,"direct LLVM integer-MIR object emission is available through a Clang AArch64 target; linking and runtime validation require an AArch64 environment"},
    {Target::MacOSX64,"macos-x86_64",BackendStatus::RequiresToolchain,"requires Apple toolchain and target validation"},
    {Target::MacOSArm64,"macos-arm64",BackendStatus::RequiresToolchain,"requires Apple toolchain and target validation"},
    {Target::AndroidArm64,"android-arm64",BackendStatus::RequiresToolchain,"requires Android NDK, packaging and device validation"},
    {Target::IOSArm64,"ios-arm64",BackendStatus::RequiresVendorSDK,"requires Xcode, signing, platform integration and device validation"},
    {Target::WebWasm32,"web-wasm32",BackendStatus::RequiresToolchain,"direct LLVM integer-MIR wasm32 object emission is available through Clang; WASI integration, runtime and packaging are not implemented"},
    {Target::FreeBSDX64,"freebsd-x86_64",BackendStatus::Planned,"target runtime build and validation not yet implemented"},
    {Target::RiscV64,"riscv64",BackendStatus::RequiresToolchain,"direct LLVM integer-MIR object emission is available through Clang RISC-V; runtime and full-language backend integration are not implemented"}
};

inline constexpr std::string_view backend_status_name(BackendStatus status) noexcept {
    switch (status) {
        case BackendStatus::Planned: return "planned";
        case BackendStatus::HostImplemented: return "implemented";
        case BackendStatus::RequiresToolchain: return "requires-toolchain";
        case BackendStatus::RequiresVendorSDK: return "requires-vendor-sdk";
    }
    return "unknown";
}
inline constexpr std::string_view host_os_name() noexcept {
#if defined(_WIN32)
    return "windows";
#elif defined(__APPLE__)
    return "macos";
#elif defined(__FreeBSD__)
    return "freebsd";
#elif defined(__linux__)
    return "linux";
#else
    return "unknown";
#endif
}
inline constexpr std::string_view host_arch_name() noexcept {
#if defined(__x86_64__) || defined(_M_X64)
    return "x86_64";
#elif defined(__aarch64__) || defined(_M_ARM64)
    return "aarch64";
#elif defined(__riscv) && __riscv_xlen == 64
    return "riscv64";
#elif defined(__i386__) || defined(_M_IX86)
    return "x86";
#else
    return "unknown";
#endif
}
inline constexpr std::size_t target_count = sizeof(targets)/sizeof(targets[0]);
inline const TargetDescriptor* find_target(std::string_view name) noexcept {
    for (const auto& t : targets) if (t.name == name) return &t;
    return nullptr;
}
} // namespace docmont::platform

namespace docmont::decom::inplot {
enum class KernelDomain { RuntimeTask, SystemKernelBuildSpec };
enum class KernelPrivilege { UserSpace, Privileged };
struct SystemKernelSpec {
    std::string name;
    std::string architecture;
    std::string entry_symbol{"docmont_kernel_entry"};
    std::vector<std::string> required_subsystems;
    bool bootable_artifact_produced{false};
};
inline docmont::platform::Validation validate_system_spec(const SystemKernelSpec& s) {
    if (s.name.empty()) return {false,"system kernel name is empty"};
    if (s.architecture.empty()) return {false,"system kernel architecture is required"};
    if (s.entry_symbol.empty()) return {false,"system kernel entry symbol is required"};
    // This release defines a specification contract only; it does not claim
    // to produce a bootable privileged kernel image.
    if (s.bootable_artifact_produced) return {false,"4.7.0 does not produce bootable system-kernel artifacts"};
    return {};
}
} // namespace docmont::decom::inplot
