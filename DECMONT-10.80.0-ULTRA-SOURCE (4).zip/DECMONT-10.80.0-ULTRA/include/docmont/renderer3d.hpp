#pragma once

#include "docmont/graphics.hpp"
#include "docmont/rendering.hpp"
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace docmont::render3d {

struct RenderStats {
    std::size_t triangles_submitted{0};
    std::size_t triangles_rasterized{0};
    std::size_t fragments_passed{0};
    std::size_t fragments_depth_rejected{0};
};

// Deterministic CPU triangle rasterizer consuming the shared MeshData/Camera
// asset and camera contracts. Near-plane-crossing triangles are conservatively
// skipped; full homogeneous clipping is intentionally outside this increment.
class Renderer {
public:
    Renderer(int width, int height, Color clear = {0,0,0})
        : canvas_(width,height,clear), depth_(canvas_.pixels().size(),std::numeric_limits<float>::infinity()) {
        if (width<=0 || height<=0 || canvas_.pixels().empty())
            throw std::invalid_argument("renderer dimensions must be positive and within Canvas limits");
    }
    int width() const noexcept { return canvas_.width(); }
    int height() const noexcept { return canvas_.height(); }
    const Canvas& canvas() const noexcept { return canvas_; }
    const std::vector<float>& depth_buffer() const noexcept { return depth_; }
    const RenderStats& stats() const noexcept { return stats_; }
    void clear(Color color = {0,0,0}) {
        canvas_=Canvas(width(),height(),color);
        std::fill(depth_.begin(),depth_.end(),std::numeric_limits<float>::infinity());
        stats_={};
    }
    bool write_ppm(const std::string& path) const { return canvas_.write_ppm(path); }

    bool draw(const render::MeshData& mesh, const render::Camera& camera,
              Color tint = {255,255,255}, const math::Mat4& model = math::Mat4::identity()) {
        std::string error;
        if (!mesh.validate(&error)) return false;
        const auto view_projection=camera.projection_matrix()*camera.view_matrix()*model;
        for (std::size_t i=0;i<mesh.indices.size();i+=3) {
            ++stats_.triangles_submitted;
            const auto& va=mesh.vertices[mesh.indices[i]];
            const auto& vb=mesh.vertices[mesh.indices[i+1]];
            const auto& vc=mesh.vertices[mesh.indices[i+2]];
            const auto a=view_projection*math::Vec4{va.position.x,va.position.y,va.position.z,1};
            const auto b=view_projection*math::Vec4{vb.position.x,vb.position.y,vb.position.z,1};
            const auto c=view_projection*math::Vec4{vc.position.x,vc.position.y,vc.position.z,1};
            if (a.w<=1e-6f || b.w<=1e-6f || c.w<=1e-6f) continue;
            if (rasterize(a,b,c,tint)) ++stats_.triangles_rasterized;
        }
        return true;
    }
private:
    struct ScreenVertex { float x,y,z,inv_w; };
    ScreenVertex project(math::Vec4 p) const {
        const float inv=1.0f/p.w;
        const float nx=p.x*inv, ny=p.y*inv, nz=p.z*inv;
        return {(nx*0.5f+0.5f)*static_cast<float>(width()-1),
                (1.0f-(ny*0.5f+0.5f))*static_cast<float>(height()-1),
                nz*0.5f+0.5f,inv};
    }
    static float edge(const ScreenVertex& a,const ScreenVertex& b,float x,float y) noexcept {
        return (x-a.x)*(b.y-a.y)-(y-a.y)*(b.x-a.x);
    }
    bool rasterize(math::Vec4 ca,math::Vec4 cb,math::Vec4 cc,Color color) {
        ScreenVertex a=project(ca),b=project(cb),c=project(cc);
        float area=edge(a,b,c.x,c.y);
        if (std::abs(area)<1e-8f) return false;
        if (area<0) { std::swap(b,c); area=-area; }
        const float min_xf=std::max(0.0f,std::floor(std::min({a.x,b.x,c.x})));
        const float max_xf=std::min(static_cast<float>(width()-1),std::ceil(std::max({a.x,b.x,c.x})));
        const float min_yf=std::max(0.0f,std::floor(std::min({a.y,b.y,c.y})));
        const float max_yf=std::min(static_cast<float>(height()-1),std::ceil(std::max({a.y,b.y,c.y})));
        if (min_xf>max_xf || min_yf>max_yf) return false;
        const int min_x=static_cast<int>(min_xf),max_x=static_cast<int>(max_xf);
        const int min_y=static_cast<int>(min_yf),max_y=static_cast<int>(max_yf);
        bool covered=false;
        for (int y=min_y;y<=max_y;++y) for (int x=min_x;x<=max_x;++x) {
            const float px=static_cast<float>(x)+0.5f,py=static_cast<float>(y)+0.5f;
            const float wa=edge(b,c,px,py)/area,wb=edge(c,a,px,py)/area,wc=edge(a,b,px,py)/area;
            if (wa<0 || wb<0 || wc<0) continue;
            const float z=wa*a.z+wb*b.z+wc*c.z;
            if (z<0 || z>1) continue;
            const auto offset=static_cast<std::size_t>(y)*static_cast<std::size_t>(width())+static_cast<std::size_t>(x);
            if (z>=depth_[offset]) { ++stats_.fragments_depth_rejected; continue; }
            depth_[offset]=z;
            canvas_.pixel(x,y,color);
            ++stats_.fragments_passed;
            covered=true;
        }
        return covered;
    }
    Canvas canvas_;
    std::vector<float> depth_;
    RenderStats stats_{};
};

} // namespace docmont::render3d
