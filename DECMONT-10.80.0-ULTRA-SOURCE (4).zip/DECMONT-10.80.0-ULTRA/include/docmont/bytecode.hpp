#pragma once
#include "docmont/ir.hpp"
#include <cstdint>
#include <string>
#include <vector>
namespace docmont {
struct BytecodeResult { bool ok{false}; std::string message; std::vector<std::uint8_t> bytes; };
BytecodeResult encode_bytecode(const ProgramIR& ir);
BytecodeResult verify_bytecode(const std::vector<std::uint8_t>& bytes);
BytecodeResult decode_bytecode(const std::vector<std::uint8_t>& bytes, ProgramIR& out);
}
