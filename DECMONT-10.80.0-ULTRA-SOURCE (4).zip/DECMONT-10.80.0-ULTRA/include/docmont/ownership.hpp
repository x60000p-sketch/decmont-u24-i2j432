#pragma once
#include "docmont/compiler_core.hpp"
#include "docmont/ast.hpp"
#include <string>
#include <vector>

namespace docmont::ownership {

enum class OpKind { Declare, Read, Move, BorrowShared, BorrowMutable, EndBorrow, Assign, Drop, ReturnReference };
struct Operation {
    OpKind kind{OpKind::Read};
    std::string place;
    std::string loan;
    std::uint32_t source_region{};
    std::uint32_t target_region{};
    std::size_t line{};
};
struct BasicBlock {
    std::uint32_t id{};
    std::vector<Operation> operations;
    std::vector<std::uint32_t> successors;
};
struct Function {
    std::string name;
    std::uint32_t entry{};
    std::vector<BasicBlock> blocks;
};
struct Diagnostic {
    std::string code;
    std::string message;
    std::size_t line{};
};
struct AnalysisResult {
    bool ok{true};
    std::vector<Diagnostic> diagnostics;
    std::size_t dataflow_iterations{};
};

// Conservative forward dataflow checker for explicit MIR place/loan events.
// Unknown or path-dependent states are rejected rather than assumed safe.
AnalysisResult analyze(const Function& function);
AnalysisResult analyze(const core::MIRFunction& function);

// Source-level ownership validation for explicit move/&/&mut forms. The v1
// source checker supports straight-line function bodies and rejects ownership
// annotations under branching until full lexical CFG lowering is available.
std::vector<Diagnostic> validate_source(const Application& app);

} // namespace docmont::ownership
