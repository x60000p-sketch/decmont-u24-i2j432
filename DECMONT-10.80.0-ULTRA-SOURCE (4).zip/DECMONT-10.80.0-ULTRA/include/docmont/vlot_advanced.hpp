#pragma once
#include "docmont/vlot.hpp"
#include <array>
#include <cstdint>
#include <string>
#include <vector>

namespace docmont::vlot {

struct AssetRecord {
    std::string relative_path;
    std::uint64_t size{0};
    std::uint64_t hash{0};
};
struct AssetCatalog {
    std::vector<AssetRecord> entries;
    std::uint64_t total_bytes{0};
};
Result build_asset_catalog(const std::string& project_file, const ProjectConfig& project, AssetCatalog& out);

struct PackageReport {
    std::uint32_t version{1};
    std::uint32_t files{0};
    std::uint64_t payload_bytes{0};
};
Result build_package(const std::string& project_file, const std::string& output_file, PackageReport& report);
Result verify_package(const std::string& package_file, PackageReport& report);
Result load_scene(const std::string& scene_file, Scene& out);
Result compile_shader_file(const std::string& source_file, const std::string& material_file);
Result verify_material_file(const std::string& material_file);

struct ShaderProgram {
    std::string name;
    std::string model{"lambert"};
    std::array<float,3> base_color{1.0f,1.0f,1.0f};
    float roughness{0.5f};
    float metallic{0.0f};
    float emission{0.0f};
};
Result compile_shader(const std::string& source, ShaderProgram& out);
Color shade_fragment(const ShaderProgram& shader, Vec3 normal, Vec3 light_direction, float ambient = 0.12f);
void draw_shaded_triangle(SoftwareRenderer& renderer, Vertex a, Vertex b, Vertex c, const ShaderProgram& shader, Vec3 normal, Vec3 light_direction);
Result render_scene_2d(const Scene& scene, SoftwareRenderer& renderer);

struct Transform3 { Vec3 position{}; Vec3 scale{1,1,1}; };
struct WorldTransform { std::string id; Transform3 transform; };
Result resolve_world_transforms(const Scene& scene, std::vector<WorldTransform>& out);

struct RigidBody {
    std::string id;
    Vec3 position{};
    Vec3 velocity{};
    Vec3 half_extent{0.5f,0.5f,0.5f};
    float mass{1.0f};
    float restitution{0.0f};
    bool is_static{false};
};
struct PhysicsWorld {
    Vec3 gravity{0.0f,-9.81f,0.0f};
    std::vector<RigidBody> bodies;
};
Result validate_physics_world(const PhysicsWorld& world);
Result step_physics(PhysicsWorld& world, float delta_seconds, unsigned substeps = 1);

} // namespace docmont::vlot
