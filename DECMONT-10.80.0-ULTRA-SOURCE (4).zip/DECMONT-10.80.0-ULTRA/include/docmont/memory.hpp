#pragma once
#include <cstddef>
#include <cstdint>
#include <limits>
#include <new>
#include <stdexcept>
#include <vector>

namespace docmont::memory {
// Linear arena for frame-scoped/transient allocations. Individual deallocation
// is intentionally unsupported; reset() invalidates every outstanding pointer.
class LinearArena {
public:
    explicit LinearArena(std::size_t capacity) : storage_(capacity) {
        if (capacity == 0) throw std::invalid_argument("arena capacity must be non-zero");
    }
    LinearArena(const LinearArena&) = delete;
    LinearArena& operator=(const LinearArena&) = delete;
    LinearArena(LinearArena&&) noexcept = default;
    LinearArena& operator=(LinearArena&&) noexcept = default;

    void* allocate(std::size_t bytes, std::size_t alignment = alignof(std::max_align_t)) {
        if (bytes == 0) bytes = 1;
        if (alignment == 0 || (alignment & (alignment - 1)) != 0)
            throw std::invalid_argument("alignment must be a non-zero power of two");
        const auto base = reinterpret_cast<std::uintptr_t>(storage_.data());
        if (offset_ > storage_.size()) throw std::bad_alloc();
        const auto current = base + offset_;
        if (current > std::numeric_limits<std::uintptr_t>::max() - (alignment - 1)) throw std::bad_alloc();
        const auto aligned = (current + alignment - 1) & ~(static_cast<std::uintptr_t>(alignment) - 1);
        const auto padding = static_cast<std::size_t>(aligned - current);
        if (padding > storage_.size() - offset_ || bytes > storage_.size() - offset_ - padding) throw std::bad_alloc();
        offset_ += padding + bytes;
        ++allocation_count_;
        return reinterpret_cast<void*>(aligned);
    }
    template<class T, class... Args> T* make(Args&&... args) {
        return ::new (allocate(sizeof(T), alignof(T))) T(static_cast<Args&&>(args)...);
    }
    void reset() noexcept { offset_ = 0; allocation_count_ = 0; }
    std::size_t capacity() const noexcept { return storage_.size(); }
    std::size_t used() const noexcept { return offset_; }
    std::size_t allocation_count() const noexcept { return allocation_count_; }
private:
    std::vector<std::byte> storage_;
    std::size_t offset_{0};
    std::size_t allocation_count_{0};
};
} // namespace docmont::memory
