#pragma once
#include "docmont/compiler_core.hpp"
#include <filesystem>
#include <string>

namespace docmont::core {
struct DirectLLVMResult {
    bool ok{false};
    std::string message;
    std::string ir;
    std::string compiler_output;
};

// Directly lowers the verified integer MIR subset to LLVM IR. Unsupported
// source constructs are rejected rather than routed through the C backend.
DirectLLVMResult emit_direct_llvm_ir(const MIRModule& mir,
                                     const TypedHIRModule& hir,
                                     const TypeContext& types,
                                     const std::string& target_triple);
DirectLLVMResult compile_direct_llvm_object(const MIRModule& mir,
                                            const TypedHIRModule& hir,
                                            const TypeContext& types,
                                            const std::filesystem::path& output,
                                            const std::string& target_triple = "x86_64-unknown-linux-gnu",
                                            const std::string& clang_executable = "clang");
}
