#pragma once
#include "docmont/native_backend.hpp"
#include <filesystem>
#include <string>
namespace docmont {
struct NativeObjectResult { bool ok{false}; std::string message; std::string compiler_output; };
// Uses Clang's LLVM code-generation pipeline by compiling DOCMONT's emitted
// C11 translation unit to an x86-64 ELF relocatable object. This is not a
// direct DOCMONT-to-LLVM-IR lowering pass.
NativeObjectResult emit_llvm_ir(const ProgramIR& ir,
                                const std::filesystem::path& output,
                                const std::string& clang_executable = "clang",
                                const std::string& target = "x86_64-unknown-linux-gnu");
NativeObjectResult compile_native_object(const ProgramIR& ir,
                                         const std::filesystem::path& output,
                                         const std::string& clang_executable = "clang",
                                         const std::string& target = "x86_64-unknown-linux-gnu");
}
