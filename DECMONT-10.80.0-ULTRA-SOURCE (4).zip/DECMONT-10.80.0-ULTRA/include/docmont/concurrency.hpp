#pragma once
#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <functional>
#include <future>
#include <queue>
#include <exception>
#include <tuple>
#include <type_traits>
#include <mutex>
#include <optional>
#include <stdexcept>
#include <thread>
#include <type_traits>
#include <utility>
#include <memory>
#include <vector>

namespace docmont::concurrency {

class AtomicI64 {
public:
    explicit AtomicI64(std::int64_t initial=0) noexcept:value_(initial){}
    std::int64_t load(std::memory_order order=std::memory_order_seq_cst) const noexcept{return value_.load(order);}
    void store(std::int64_t value,std::memory_order order=std::memory_order_seq_cst) noexcept{value_.store(value,order);}
    std::int64_t fetch_add(std::int64_t value,std::memory_order order=std::memory_order_seq_cst) noexcept{return value_.fetch_add(value,order);}
private: std::atomic<std::int64_t> value_;
};

template<class T> class Mutex {
public:
    template<class F> auto with_lock(F&& fn) -> std::invoke_result_t<F,T&> {
        using Return=std::invoke_result_t<F,T&>;
        static_assert(!std::is_reference_v<Return>, "Mutex::with_lock cannot return a reference beyond the lock lifetime");
        std::lock_guard<std::mutex> guard(mutex_);
        if constexpr(std::is_void_v<Return>) std::invoke(std::forward<F>(fn),value_);
        else return std::invoke(std::forward<F>(fn),value_);
    }
private: std::mutex mutex_;T value_{};
};

template<class T> class Channel {
public:
    bool send(T value){std::lock_guard<std::mutex> lock(mutex_);if(closed_)return false;queue_.push_back(std::move(value));ready_.notify_one();return true;}
    std::optional<T> receive(){std::unique_lock<std::mutex> lock(mutex_);ready_.wait(lock,[&]{return closed_||!queue_.empty();});if(queue_.empty())return std::nullopt;T value=std::move(queue_.front());queue_.pop_front();return value;}
    void close(){std::lock_guard<std::mutex> lock(mutex_);closed_=true;ready_.notify_all();}
    bool is_closed()const{std::lock_guard<std::mutex> lock(mutex_);return closed_;}
private:mutable std::mutex mutex_;std::condition_variable ready_;std::deque<T> queue_;bool closed_{false};
};

// Fixed-size worker pool. Tasks submitted before shutdown are drained; new
// submissions after shutdown begins are rejected. Task exceptions travel via
// std::future. Worker threads hold shared state, so self-shutdown cannot leave
// a detached worker accessing a destroyed TaskScheduler object.
class TaskScheduler {
    struct SharedState {
        std::mutex mutex;
        std::condition_variable ready;
        std::queue<std::function<void()>> tasks;
        bool stopping{false};
    };
public:
    explicit TaskScheduler(std::size_t worker_count = std::thread::hardware_concurrency())
        : state_(std::make_shared<SharedState>()) {
        if (worker_count == 0) worker_count = 1;
        workers_.reserve(worker_count);
        try {
            for (std::size_t i = 0; i < worker_count; ++i) {
                auto shared = state_;
                workers_.emplace_back([shared] { worker_loop(std::move(shared)); });
            }
        } catch (...) {
            {
                std::lock_guard<std::mutex> lock(state_->mutex);
                state_->stopping = true;
            }
            state_->ready.notify_all();
            for (auto& worker : workers_) if (worker.joinable()) worker.join();
            throw;
        }
    }

    TaskScheduler(const TaskScheduler&) = delete;
    TaskScheduler& operator=(const TaskScheduler&) = delete;
    TaskScheduler(TaskScheduler&&) = delete;
    TaskScheduler& operator=(TaskScheduler&&) = delete;
    ~TaskScheduler() { shutdown(); }

    template<class F, class... Args>
    auto submit(F&& fn, Args&&... args)
        -> std::future<std::invoke_result_t<std::decay_t<F>, std::decay_t<Args>...>> {
        using Result = std::invoke_result_t<std::decay_t<F>, std::decay_t<Args>...>;
        auto task = std::make_shared<std::packaged_task<Result()>>(
            [callable = std::decay_t<F>(std::forward<F>(fn)),
             arguments = std::make_tuple(std::forward<Args>(args)...)]() mutable -> Result {
                return std::apply(std::move(callable), std::move(arguments));
            });
        auto future = task->get_future();
        const auto shared = state_;
        {
            std::lock_guard<std::mutex> lock(shared->mutex);
            if (shared->stopping) throw std::runtime_error("DOCMONT TaskScheduler is shutting down");
            shared->tasks.emplace([task] { (*task)(); });
        }
        shared->ready.notify_one();
        return future;
    }

    void shutdown() noexcept {
        const auto shared = state_;
        if (shared) {
            {
                std::lock_guard<std::mutex> lock(shared->mutex);
                shared->stopping = true;
            }
            shared->ready.notify_all();
        }
        for (auto& worker : workers_) {
            if (!worker.joinable()) continue;
            if (worker.get_id() == std::this_thread::get_id()) worker.detach();
            else { try { worker.join(); } catch (...) { } }
        }
    }

    std::size_t worker_count() const noexcept { return workers_.size(); }

private:
    static void worker_loop(std::shared_ptr<SharedState> shared) noexcept {
        for (;;) {
            std::function<void()> task;
            {
                std::unique_lock<std::mutex> lock(shared->mutex);
                shared->ready.wait(lock, [&] { return shared->stopping || !shared->tasks.empty(); });
                if (shared->stopping && shared->tasks.empty()) return;
                task = std::move(shared->tasks.front());
                shared->tasks.pop();
            }
            try { task(); } catch (...) { /* packaged_task transports task errors */ }
        }
    }

    std::shared_ptr<SharedState> state_;
    std::vector<std::thread> workers_;
};

class TaskGroup {
public:
    TaskGroup()=default;TaskGroup(const TaskGroup&)=delete;TaskGroup& operator=(const TaskGroup&)=delete;
    template<class F,class... Args> void spawn(F&& fn,Args&&... args){
        auto callable=std::decay_t<F>(std::forward<F>(fn));
        auto arguments=std::make_tuple(std::forward<Args>(args)...);
        threads_.emplace_back([this,callable=std::move(callable),arguments=std::move(arguments)]() mutable {
            try { std::apply(callable,std::move(arguments)); }
            catch (...) { std::lock_guard<std::mutex> guard(error_mutex_); if(!first_exception_)first_exception_=std::current_exception(); }
        });
    }
    void join(){
        for(auto& thread:threads_)if(thread.joinable())thread.join();
        threads_.clear();
        std::exception_ptr error;{std::lock_guard<std::mutex> guard(error_mutex_);error=std::exchange(first_exception_,{});}
        if(error)std::rethrow_exception(error);
    }
    std::size_t size()const noexcept{return threads_.size();}
    ~TaskGroup(){try{join();}catch(...){}}
private:std::vector<std::thread> threads_;std::mutex error_mutex_;std::exception_ptr first_exception_;
};

} // namespace docmont::concurrency
