#pragma once
#include <functional>
#include <stdexcept>
#include <optional>
#include <type_traits>
#include <utility>
#include <variant>

namespace docmont::error {
struct Unit {};
struct None {};

template<class T> class Option {
public:
    Option() : value_(None{}) {}
    static Option some(T value) { Option out; out.value_=std::move(value); return out; }
    static Option none() { return Option{}; }
    bool has_value() const noexcept { return std::holds_alternative<T>(value_); }
    explicit operator bool() const noexcept { return has_value(); }
    T& value() { if(!has_value())throw std::logic_error("Option::value on None");return std::get<T>(value_); }
    const T& value() const { if(!has_value())throw std::logic_error("Option::value on None");return std::get<T>(value_); }
    template<class F> auto map(F&& fn) const -> Option<std::decay_t<decltype(fn(std::declval<const T&>()))>> { using U=std::decay_t<decltype(fn(std::declval<const T&>()))>;return has_value()?Option<U>::some(fn(value())):Option<U>::none(); }
private:
    std::variant<None,T> value_;
};

template<class T,class E> class Result {
public:
    static Result ok(T value) { return Result(std::in_place_index<0>,std::move(value)); }
    static Result err(E error) { return Result(std::in_place_index<1>,std::move(error)); }
    bool is_ok() const noexcept { return value_.index()==0; }
    bool is_err() const noexcept { return !is_ok(); }
    explicit operator bool() const noexcept { return is_ok(); }
    T& value() { if(is_err())throw std::logic_error("Result::value on Err");return std::get<0>(value_); }
    const T& value() const { if(is_err())throw std::logic_error("Result::value on Err");return std::get<0>(value_); }
    E& error() { if(is_ok())throw std::logic_error("Result::error on Ok");return std::get<1>(value_); }
    const E& error() const { if(is_ok())throw std::logic_error("Result::error on Ok");return std::get<1>(value_); }
    template<class F> auto map(F&& fn) const -> Result<std::decay_t<decltype(fn(std::declval<const T&>()))>,E> { using U=std::decay_t<decltype(fn(std::declval<const T&>()))>;return is_ok()?Result<U,E>::ok(fn(value())):Result<U,E>::err(error()); }
private:
    template<class... Args> explicit Result(std::in_place_index_t<0> tag,Args&&... args):value_(tag,std::forward<Args>(args)...){ }
    template<class... Args> explicit Result(std::in_place_index_t<1> tag,Args&&... args):value_(tag,std::forward<Args>(args)...){ }
    std::variant<T,E> value_;
};

// Error propagation helper analogous to `?`: callers explicitly return the
// error value, preserving the original error type without exceptions.
template<class T,class E> struct Propagation {
    std::optional<T> value;
    std::optional<E> error;
    bool has_value() const noexcept { return value.has_value(); }
};
template<class T,class E> Propagation<T,E> propagate(const Result<T,E>& result) {
    if(result.is_ok())return {result.value(),std::nullopt};
    return {std::nullopt,result.error()};
}

} // namespace docmont::error
