#pragma once
#include "docmont/ast.hpp"
#include "docmont/diagnostic.hpp"
#include "docmont/token.hpp"
#include <vector>
namespace docmont {
struct ParseResult { Application app; std::vector<Diagnostic> diagnostics; };
class Parser {
public:
    explicit Parser(std::vector<Token> tokens);
    ParseResult parse();
private:
    std::vector<Token> tokens_; std::size_t pos_{0};
    const Token& current() const; Token advance(); bool accept(TokenKind kind);
    bool expect(TokenKind kind, const std::string& message, std::vector<Diagnostic>& d);
    void skip_newlines(); std::string scalar(std::vector<Diagnostic>& d);
    std::string parse_type_name(std::vector<Diagnostic>& d);
    EnumDecl parse_enum(std::vector<Diagnostic>& d);
    Statement parse_match(std::vector<Diagnostic>& d, const Token& start);
    std::shared_ptr<Expr> expression(std::vector<Diagnostic>& d);
    std::shared_ptr<Expr> logical_or(std::vector<Diagnostic>& d);
    std::shared_ptr<Expr> logical_and(std::vector<Diagnostic>& d);
    std::shared_ptr<Expr> unary(std::vector<Diagnostic>& d);
    std::shared_ptr<Expr> additive(std::vector<Diagnostic>& d);
    std::shared_ptr<Expr> comparison(std::vector<Diagnostic>& d);
    std::shared_ptr<Expr> multiplicative(std::vector<Diagnostic>& d);
    std::shared_ptr<Expr> primary(std::vector<Diagnostic>& d);
    void parse_property_or_block(Application& app, std::vector<Diagnostic>& d);
    FunctionDecl parse_function(std::vector<Diagnostic>& d);
    Statement parse_statement(std::vector<Diagnostic>& d);
    std::vector<Statement> parse_statement_block(std::vector<Diagnostic>& d);
    void parse_block(Application& app, const Token& start, std::vector<Diagnostic>& d);
};
}
