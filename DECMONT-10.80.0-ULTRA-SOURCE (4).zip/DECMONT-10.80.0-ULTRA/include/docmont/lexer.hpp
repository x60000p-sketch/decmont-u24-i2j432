#pragma once
#include "docmont/token.hpp"
#include "docmont/diagnostic.hpp"
#include <string>
#include <vector>
namespace docmont {
struct LexResult { std::vector<Token> tokens; std::vector<Diagnostic> diagnostics; };
class Lexer {
public:
    explicit Lexer(std::string source);
    LexResult scan();
private:
    std::string source_;
    std::size_t pos_{0};
    int line_{1}, column_{1};
    char peek() const;
    char advance();
    void skip_spaces();
};
}
