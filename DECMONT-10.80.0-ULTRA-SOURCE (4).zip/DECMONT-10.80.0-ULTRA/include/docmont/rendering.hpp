#pragma once

#include "docmont/math.hpp"
#include <cmath>
#include <cstdint>
#include <limits>
#include <optional>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <utility>
#include <vector>

namespace docmont::render {

struct Vertex {
    math::Vec3 position{};
    math::Vec3 normal{0.0f, 1.0f, 0.0f};
    math::Vec2 uv{};
};

struct Bounds3 {
    math::Vec3 minimum{};
    math::Vec3 maximum{};
};

struct MeshData {
    std::vector<Vertex> vertices;
    std::vector<std::uint32_t> indices;

    // Reject malformed triangle lists and non-finite vertex attributes before
    // data reaches a renderer or asset cache.
    bool validate(std::string* error = nullptr) const {
        auto fail = [&](const char* message) {
            if (error) *error = message;
            return false;
        };
        if (vertices.empty()) return fail("mesh has no vertices");
        if (indices.empty() || indices.size() % 3 != 0) return fail("mesh indices must contain complete triangles");
        for (const auto& v : vertices) {
            const float values[] = {v.position.x, v.position.y, v.position.z,
                                    v.normal.x, v.normal.y, v.normal.z, v.uv.x, v.uv.y};
            for (float value : values) if (!std::isfinite(value)) return fail("mesh contains a non-finite vertex attribute");
        }
        for (auto index : indices) if (index >= vertices.size()) return fail("mesh index is outside the vertex array");
        if (error) error->clear();
        return true;
    }

    Bounds3 bounds() const {
        if (vertices.empty()) throw std::logic_error("cannot compute bounds for an empty mesh");
        Bounds3 result{vertices.front().position, vertices.front().position};
        for (const auto& vertex : vertices) {
            const auto p = vertex.position;
            result.minimum = {std::min(result.minimum.x, p.x), std::min(result.minimum.y, p.y), std::min(result.minimum.z, p.z)};
            result.maximum = {std::max(result.maximum.x, p.x), std::max(result.maximum.y, p.y), std::max(result.maximum.z, p.z)};
        }
        return result;
    }
};

enum class ProjectionKind { Perspective, Orthographic };

struct Camera {
    math::Vec3 position{0.0f, 0.0f, 0.0f};
    math::Vec3 target{0.0f, 0.0f, -1.0f};
    math::Vec3 up{0.0f, 1.0f, 0.0f};
    ProjectionKind projection{ProjectionKind::Perspective};
    float vertical_fov_radians{1.04719755f};
    float aspect{16.0f / 9.0f};
    float near_plane{0.1f};
    float far_plane{1000.0f};
    float orthographic_height{10.0f};

    math::Mat4 view_matrix() const {
        const math::Vec3 forward = math::normalize(target - position);
        const math::Vec3 side = math::normalize(math::cross(forward, up));
        const math::Vec3 corrected_up = math::cross(side, forward);
        auto result = math::Mat4::identity();
        result.at(0,0)=side.x; result.at(0,1)=side.y; result.at(0,2)=side.z; result.at(0,3)=-math::dot(side, position);
        result.at(1,0)=corrected_up.x; result.at(1,1)=corrected_up.y; result.at(1,2)=corrected_up.z; result.at(1,3)=-math::dot(corrected_up, position);
        result.at(2,0)=-forward.x; result.at(2,1)=-forward.y; result.at(2,2)=-forward.z; result.at(2,3)=math::dot(forward, position);
        return result;
    }

    math::Mat4 projection_matrix() const {
        if (projection == ProjectionKind::Perspective)
            return math::perspective(vertical_fov_radians, aspect, near_plane, far_plane);
        if (!(aspect > 0.0f) || !(orthographic_height > 0.0f) || !(near_plane >= 0.0f) || !(far_plane > near_plane))
            throw std::invalid_argument("invalid orthographic camera parameters");
        const float half_h = orthographic_height * 0.5f;
        const float half_w = half_h * aspect;
        auto result = math::Mat4::identity();
        result.at(0,0)=1.0f/half_w;
        result.at(1,1)=1.0f/half_h;
        result.at(2,2)=-2.0f/(far_plane-near_plane);
        result.at(2,3)=-(far_plane+near_plane)/(far_plane-near_plane);
        return result;
    }
};

struct MeshHandle {
    std::uint32_t index{0};
    std::uint32_t generation{0};
    friend constexpr bool operator==(MeshHandle a, MeshHandle b) noexcept {
        return a.index == b.index && a.generation == b.generation;
    }
};

// CPU-side mesh asset catalog with stable names and generation-checked handles.
// It validates payloads but deliberately does not upload buffers to a GPU.
class MeshCatalog {
    struct Entry {
        std::uint32_t generation{1};
        bool alive{false};
        std::string name;
        MeshData mesh;
    };
public:
    MeshHandle insert(std::string name, MeshData mesh) {
        if (name.empty()) throw std::invalid_argument("mesh asset name must not be empty");
        if (names_.count(name)) throw std::invalid_argument("mesh asset name already exists");
        std::string error;
        if (!mesh.validate(&error)) throw std::invalid_argument("invalid mesh asset: " + error);
        std::uint32_t index;
        if (free_.empty()) {
            if (entries_.size() >= std::numeric_limits<std::uint32_t>::max()) throw std::length_error("mesh catalog capacity exhausted");
            index = static_cast<std::uint32_t>(entries_.size());
            entries_.push_back(Entry{});
        } else {
            index = free_.back();
            free_.pop_back();
        }
        auto& entry = entries_[index];
        entry.alive = true;
        entry.name = std::move(name);
        entry.mesh = std::move(mesh);
        names_.emplace(entry.name, index);
        return {index, entry.generation};
    }

    bool valid(MeshHandle handle) const noexcept {
        return handle.index < entries_.size() && entries_[handle.index].alive &&
               entries_[handle.index].generation == handle.generation;
    }
    const MeshData* get(MeshHandle handle) const noexcept {
        return valid(handle) ? &entries_[handle.index].mesh : nullptr;
    }
    std::optional<MeshHandle> find(const std::string& name) const noexcept {
        auto it = names_.find(name);
        if (it == names_.end()) return std::nullopt;
        const auto& entry = entries_[it->second];
        return MeshHandle{it->second, entry.generation};
    }
    bool erase(MeshHandle handle) {
        if (!valid(handle)) return false;
        auto& entry = entries_[handle.index];
        names_.erase(entry.name);
        entry.name.clear();
        entry.mesh = {};
        entry.alive = false;
        if (++entry.generation == 0) ++entry.generation;
        free_.push_back(handle.index);
        return true;
    }
    std::size_t size() const noexcept { return names_.size(); }
private:
    std::vector<Entry> entries_;
    std::vector<std::uint32_t> free_;
    std::unordered_map<std::string, std::uint32_t> names_;
};

} // namespace docmont::render
