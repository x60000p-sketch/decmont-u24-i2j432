#pragma once
#include <string>
#include <vector>

namespace docmont::assembly {
struct InlineAsmContract {
    std::string target{"x86_64-sysv"};
    std::string instruction_text;
    std::vector<std::string> inputs;
    std::vector<std::string> outputs;
    std::vector<std::string> clobbers;
    bool is_volatile{false};
};
struct ContractResult { bool ok{false}; std::vector<std::string> errors; };
ContractResult validate_inline_asm_contract(const InlineAsmContract& contract);
struct SimdIntrinsicContract { std::string target{"x86_64-sysv"}; std::string operation; std::string vector_type; std::string required_feature; };
ContractResult validate_simd_contract(const SimdIntrinsicContract& contract);
} // namespace docmont::assembly
