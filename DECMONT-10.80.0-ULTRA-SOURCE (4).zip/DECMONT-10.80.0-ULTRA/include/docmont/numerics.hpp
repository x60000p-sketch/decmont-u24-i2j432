#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <limits>
#include <numeric>
#include <stdexcept>
#include <string>
#include <vector>

namespace docmont::numerics {
using Vector = std::vector<double>;
using Matrix = std::vector<Vector>;

inline void require_finite(const Vector& v, const char* what) {
    for (double x : v) if (!std::isfinite(x)) throw std::domain_error(std::string(what) + " contains non-finite value");
}
inline double sum(const Vector& v) { require_finite(v,"vector"); return std::accumulate(v.begin(),v.end(),0.0); }
inline double mean(const Vector& v) { if(v.empty()) throw std::invalid_argument("mean of empty vector"); return sum(v)/static_cast<double>(v.size()); }
inline double variance(const Vector& v, bool sample=false) { if(v.size()<(sample?2u:1u)) throw std::invalid_argument("insufficient values for variance"); const double m=mean(v); double s=0; for(double x:v){const double d=x-m;s+=d*d;} return s/static_cast<double>(v.size()-(sample?1u:0u)); }
inline double standard_deviation(const Vector& v, bool sample=false) { return std::sqrt(variance(v,sample)); }
inline double median(Vector v) { if(v.empty()) throw std::invalid_argument("median of empty vector"); require_finite(v,"vector"); const auto n=v.size(), mid=n/2; std::nth_element(v.begin(),v.begin()+static_cast<std::ptrdiff_t>(mid),v.end()); const double hi=v[mid]; if(n%2) return hi; const auto lo=*std::max_element(v.begin(),v.begin()+static_cast<std::ptrdiff_t>(mid)); return (lo+hi)/2.0; }
inline double dot(const Vector& a,const Vector& b) { if(a.size()!=b.size()) throw std::invalid_argument("dot shape mismatch"); require_finite(a,"left vector"); require_finite(b,"right vector"); double s=0; for(std::size_t i=0;i<a.size();++i)s+=a[i]*b[i]; return s; }
inline double norm(const Vector& v) { return std::sqrt(dot(v,v)); }
inline Vector normalize(const Vector& v) { const double n=norm(v); if(n==0) throw std::domain_error("cannot normalize zero vector"); Vector o=v; for(double& x:o)x/=n; return o; }
inline Vector add(const Vector& a,const Vector& b) { if(a.size()!=b.size()) throw std::invalid_argument("vector shape mismatch"); Vector o(a.size()); for(std::size_t i=0;i<a.size();++i)o[i]=a[i]+b[i]; return o; }
inline Vector subtract(const Vector& a,const Vector& b) { if(a.size()!=b.size()) throw std::invalid_argument("vector shape mismatch"); Vector o(a.size()); for(std::size_t i=0;i<a.size();++i)o[i]=a[i]-b[i]; return o; }
inline Vector scale(const Vector& a,double k) { if(!std::isfinite(k)) throw std::domain_error("non-finite scale"); Vector o=a; for(double& x:o)x*=k; return o; }
inline Vector hadamard(const Vector& a,const Vector& b) { if(a.size()!=b.size()) throw std::invalid_argument("vector shape mismatch"); Vector o(a.size()); for(std::size_t i=0;i<a.size();++i)o[i]=a[i]*b[i]; return o; }
inline Vector linspace(double start,double stop,std::size_t count) { if(!std::isfinite(start)||!std::isfinite(stop)) throw std::domain_error("linspace endpoints must be finite"); if(count==0) return {}; if(count==1) return {start}; Vector o(count); for(std::size_t i=0;i<count;++i)o[i]=start+(stop-start)*static_cast<double>(i)/static_cast<double>(count-1); o.back()=stop; return o; }
inline Vector clamp(const Vector& v,double lo,double hi) { if(lo>hi) throw std::invalid_argument("clamp lower bound exceeds upper bound"); Vector o=v; for(double& x:o)x=std::clamp(x,lo,hi); return o; }
inline Vector moving_average(const Vector& v,std::size_t window) { if(window==0||window>v.size()) throw std::invalid_argument("invalid moving-average window"); Vector o; o.reserve(v.size()-window+1); double s=std::accumulate(v.begin(),v.begin()+static_cast<std::ptrdiff_t>(window),0.0); o.push_back(s/window); for(std::size_t i=window;i<v.size();++i){s+=v[i]-v[i-window];o.push_back(s/window);} return o; }
inline Vector convolve(const Vector& a,const Vector& b) { if(a.empty()||b.empty()) return {}; Vector o(a.size()+b.size()-1,0.0); for(std::size_t i=0;i<a.size();++i)for(std::size_t j=0;j<b.size();++j)o[i+j]+=a[i]*b[j]; return o; }
inline Matrix transpose(const Matrix& a) { if(a.empty()) return {}; const auto n=a.front().size(); for(const auto& r:a)if(r.size()!=n)throw std::invalid_argument("ragged matrix"); Matrix o(n,Vector(a.size())); for(std::size_t i=0;i<a.size();++i)for(std::size_t j=0;j<n;++j)o[j][i]=a[i][j]; return o; }
inline Matrix matmul(const Matrix& a,const Matrix& b) { if(a.empty()||b.empty()||a.front().size()!=b.size())throw std::invalid_argument("matrix shape mismatch"); const auto k=b.front().size(); for(const auto& r:a)if(r.size()!=b.size())throw std::invalid_argument("ragged left matrix"); for(const auto& r:b)if(r.size()!=k)throw std::invalid_argument("ragged right matrix"); Matrix o(a.size(),Vector(k)); for(std::size_t i=0;i<a.size();++i)for(std::size_t p=0;p<b.size();++p)for(std::size_t j=0;j<k;++j)o[i][j]+=a[i][p]*b[p][j]; return o; }
inline double determinant(Matrix a) { if(a.empty())throw std::invalid_argument("determinant of empty matrix"); const auto n=a.size(); for(const auto& r:a)if(r.size()!=n)throw std::invalid_argument("determinant requires square matrix"); double d=1; int sign=1; for(std::size_t c=0;c<n;++c){std::size_t pivot=c;for(std::size_t r=c+1;r<n;++r)if(std::abs(a[r][c])>std::abs(a[pivot][c]))pivot=r; if(std::abs(a[pivot][c])<1e-14)return 0; if(pivot!=c){std::swap(a[pivot],a[c]);sign=-sign;} const double p=a[c][c];d*=p;for(std::size_t r=c+1;r<n;++r){const double f=a[r][c]/p;for(std::size_t j=c+1;j<n;++j)a[r][j]-=f*a[c][j];}} return sign*d; }
inline Vector softmax(const Vector& v) { if(v.empty())return {}; require_finite(v,"softmax input"); const double m=*std::max_element(v.begin(),v.end()); Vector o(v.size()); double s=0;for(std::size_t i=0;i<v.size();++i){o[i]=std::exp(v[i]-m);s+=o[i];}for(double& x:o)x/=s;return o; }
inline Vector relu(const Vector& v) { Vector o=v;for(double& x:o)x=std::max(0.0,x);return o; }
inline Vector sigmoid(const Vector& v) { Vector o=v;for(double& x:o){if(x>=0){const double z=std::exp(-x);x=1/(1+z);}else{const double z=std::exp(x);x=z/(1+z);}}return o; }
inline Vector cumulative_sum(const Vector& v) { Vector o(v.size());std::partial_sum(v.begin(),v.end(),o.begin());return o; }
inline Vector differences(const Vector& v) { if(v.size()<2)return {};Vector o(v.size()-1);for(std::size_t i=1;i<v.size();++i)o[i-1]=v[i]-v[i-1];return o; }
inline Vector pairwise_min(const Vector& a,const Vector& b) { if(a.size()!=b.size())throw std::invalid_argument("vector shape mismatch");Vector o(a.size());for(std::size_t i=0;i<a.size();++i)o[i]=std::min(a[i],b[i]);return o; }
inline Vector pairwise_max(const Vector& a,const Vector& b) { if(a.size()!=b.size())throw std::invalid_argument("vector shape mismatch");Vector o(a.size());for(std::size_t i=0;i<a.size();++i)o[i]=std::max(a[i],b[i]);return o; }
} // namespace docmont::numerics
