#pragma once
#include <filesystem>
#include <string>
#include <vector>

namespace docmont::dpm {
struct Dependency { std::string name; std::string version; std::filesystem::path path; };
struct Manifest { std::string name; std::string version; std::string edition{"2026"}; std::vector<Dependency> dependencies; };
struct Diagnostic { std::string code; std::string message; std::size_t line{}; };
struct LoadResult { bool ok{false}; Manifest manifest; std::vector<Diagnostic> diagnostics; std::string source_fingerprint; };
struct ResolvedPackage { std::string name; std::string version; std::filesystem::path manifest_path; std::string source_fingerprint; };
struct ResolveResult { bool ok{false}; std::vector<ResolvedPackage> packages; std::vector<Diagnostic> diagnostics; };
LoadResult load_manifest(const std::filesystem::path& path);
ResolveResult resolve_local_dependencies(const std::filesystem::path& root_manifest);
std::string render_lockfile(const Manifest& manifest, const std::string& fingerprint);
bool write_lockfile(const std::filesystem::path& path, const Manifest& manifest,
                    const std::string& fingerprint, std::string& error);
std::string render_resolved_lockfile(const Manifest& root, const std::string& root_fingerprint, const std::vector<ResolvedPackage>& packages);
bool write_resolved_lockfile(const std::filesystem::path& path, const Manifest& root, const std::string& root_fingerprint, const std::vector<ResolvedPackage>& packages, std::string& error);
} // namespace docmont::dpm
