#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace docmont::gpu {
enum class Backend { Vulkan, Direct3D12, Metal, Cpu };
enum class Availability { Ready, LoaderOnly, UnsupportedPlatform, MissingRuntime, NoDevice, InitializationFailed };
struct BackendStatus {
    Backend backend{Backend::Cpu};
    Availability availability{Availability::MissingRuntime};
    bool runtime_present{false};
    bool device_available{false};
    bool queue_available{false};
    std::uint32_t api_version{};
    std::uint32_t device_count{};
    std::string detail;
};
struct GpuProbeReport { std::vector<BackendStatus> backends; };

// Performs a real Vulkan loader/instance/physical-device/logical-device probe.
// This is deliberately a probe and minimal queue initialization, not yet a
// complete renderer or compute command submission backend.
BackendStatus probe_vulkan();
BackendStatus probe_direct3d12();
BackendStatus probe_metal();
GpuProbeReport probe_all_backends();
std::string to_string(Backend backend);
std::string to_string(Availability availability);
} // namespace docmont::gpu
