# DOCMONT x86-64 System V Assembly Adapter (8.50.0)

The adapter validates a restricted, register-only assembly DSL and emits GNU assembler `.S` output. It is intended for leaf arithmetic functions and ABI experiments, not arbitrary inline assembly.

## Example

```text
DOCMONT_ASM 1
target x86_64-sysv
function add_i64(i64,i64) -> i64
    mov rax, rdi
    add rax, rsi
    ret
end
```

```sh
docmont asm-check math.dasm
docmont asm-emit-x86_64 math.dasm math.S
as --64 -o math.o math.S
```

## ABI contract

- Target: x86_64 System V ABI.
- Up to six integer parameters in `rdi`, `rsi`, `rdx`, `rcx`, `r8`, `r9`.
- Result: signed 64-bit value in `rax`.
- Only volatile registers are accepted: `rax`, `rcx`, `rdx`, `rsi`, `rdi`, `r8`, `r9`, `r10`, `r11`.
- Functions must terminate with `ret`.

## Accepted operations

`mov`, `add`, `sub`, two-register `imul`, `and`, `or`, `xor`, `neg`, `not`, `inc`, `dec`, `shl`, `shr`, `sar`, `ret`.

The validator rejects memory operands, arbitrary directives, macros, labels/branches, calls, syscalls, stack manipulation, callee-saved registers and unsupported instructions. Arithmetic immediates are constrained to legal signed 32-bit encodings; `mov` immediates must fit signed 64-bit; shift counts are 0..63.

The emitter currently does not target Windows x64, ARM64, RISC-V, WebAssembly, or other ABIs. It does not lower general DOCMONT expressions to assembly; the `.dasm` adapter is a separately validated low-level module format.
