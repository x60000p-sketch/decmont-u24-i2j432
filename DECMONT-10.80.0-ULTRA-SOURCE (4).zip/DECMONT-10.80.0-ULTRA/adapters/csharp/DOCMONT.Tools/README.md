Planned .NET desktop tools: project manager, editor, debugger and build orchestration.
