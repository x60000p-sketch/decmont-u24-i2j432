# DOCMONT Java/JNI Adapter (8.50.0)

This adapter generates a Java native-method wrapper plus the JNI C++ glue and a C ABI declaration header. It is an interoperability bridge, not a Java compiler or JVM implementation.

## Manifest

```text
DOCMONT_JAVA 1
package io.docmont.demo
class MathBridge
library docmont_native
function add_i64 symbol=docmont_add_i64 (i64,i64) -> i64
function greet symbol=docmont_greet (utf8) -> utf8
```

Each function line declares a Java method, a C ABI symbol, a list of parameter bridge types, and a return bridge type. Supported types are `i64`, `i32`, `f64`, `bool`, and `utf8`; `void` is accepted only as a return type. Method and native symbol names must be unique within the manifest.

## Generate

```sh
docmont java-bindings MathBridge.djava generated
```

Outputs:

- `MathBridge.java`: Java class with static native methods.
- `MathBridge_abi.h`: `extern "C"` native function declarations.
- `MathBridge_jni.cpp`: JNI entry points that forward to the C ABI symbols.

Implement the declared C ABI functions in a native library, compile the generated JNI glue against the JDK's `include/` and platform include directories, and load that library using the declared `System.loadLibrary` name.

## ABI and data rules

- Java `long`, `int`, `double`, and `boolean` map to `int64_t`, `int32_t`, `double`, and `bool`.
- Java `String` maps to a `const char*` native parameter/return.
- JNI conversion uses `GetStringUTFChars` and `NewStringUTF`, which use JNI modified UTF-8. The adapter does not normalize Unicode or provide ownership of returned C strings.
- Native string-return functions must return a non-null or null-terminated pointer whose storage remains valid until JNI copies it. Returning a pointer to a temporary local buffer is invalid.
- Native exceptions must not cross the C ABI boundary. Exception translation, arrays, objects, callbacks, overloaded methods, generics and async calls are not implemented.
- The generated JNI glue does not call DOCMONT source functions directly. A future native-export ABI/runtime bridge is needed to connect DOCMONT functions automatically.
