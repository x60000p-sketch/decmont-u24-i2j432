C ABI adapter boundary. Planned exports: source loading, diagnostics, IR inspection and runtime lifecycle. The public header currently exposes only a version placeholder.
