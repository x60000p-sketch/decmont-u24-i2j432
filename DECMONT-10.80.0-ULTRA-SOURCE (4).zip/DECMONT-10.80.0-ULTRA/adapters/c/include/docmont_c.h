#ifndef DOCMONT_C_H
#define DOCMONT_C_H
#ifdef __cplusplus
extern "C" {
#endif
typedef struct docmont_session docmont_session;
const char* docmont_version(void);
#ifdef __cplusplus
}
#endif
#endif
