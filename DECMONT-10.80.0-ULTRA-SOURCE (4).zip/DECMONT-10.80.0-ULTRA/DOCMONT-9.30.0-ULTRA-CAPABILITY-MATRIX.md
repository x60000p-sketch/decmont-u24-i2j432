# DOCMONT 9.30.0 ULTRA — Capability Matrix

Status values: IMPLEMENTED means code exists; TESTED means covered by automated tests on the stated host; PARTIAL means the scope is intentionally limited; NOT IMPLEMENTED means no production implementation is claimed.

| Area | 9.30.0 status | Verified scope / limitation |
|---|---|---|
| Lexer/parser, typed HIR/MIR, SSA | TESTED | Existing language/compiler subset; compatibility 3.4.0 |
| DVM runtime and bytecode | TESTED | DVM v1 |
| Ownership/borrow analysis | PARTIAL | Existing implemented analysis; not a complete Rust-equivalent borrow checker |
| Native compiler | PARTIAL | Direct MIR supported subset; Linux x86_64 executable and limited object generation |
| CMake SDK package | TESTED | Linux install and external CMake consumer |
| Project lifecycle / DPM | TESTED | Local project validation/build/package workflows |
| ECS, world, physics, navigation, AI | PARTIAL | Engine foundations, not a production AAA engine |
| Skeletal animation | PARTIAL | CPU skeleton sampling, pose blend and skinning |
| GLES offscreen renderer | TESTED | OpenGL ES 3.2 with Mesa llvmpipe in this environment; software rendering |
| GLES compute MatMul | TESTED | Existing 9.20 matrix multiplication and optional ReLU |
| GLES compute binary ops | TESTED | Add, Subtract, Multiply, Divide, Maximum, Minimum |
| GLES compute Softmax | TESTED | Stable row-wise Softmax, float32 |
| Detailed Render Graph | TESTED | Topological order, resource lifetimes, transient alias plan, RAW/WAR/WAW barriers |
| Vulkan renderer | NOT IMPLEMENTED | Existing Vulkan loader/device/queue probe only |
| D3D12 renderer | NOT IMPLEMENTED | Platform probe/adapter only; no complete rendering submission path |
| Metal renderer | NOT IMPLEMENTED | Platform probe/adapter only; no complete rendering submission path |
| ONNX CPU | PARTIAL | Bounded protobuf reader and documented operator subset |
| ONNX GPU provider | NOT IMPLEMENTED | GLES compute primitives are not integrated into general ONNX graph execution |
| TCP/UDP transport | PARTIAL | Framed TCP and sequenced UDP foundations; no production auth/TLS/NAT stack |
| Studio | PARTIAL | Local project/editor workflow; not a complete visual 3D editor |
| Windows/macOS/Android | PARTIAL | Presets/toolchains only; no native device verification in this release |
| PS5/Xbox | PARTIAL | Licensed vendor SDK adapter; no actual vendor SDK/devkit test in this environment |

## Host verification

Linux x86_64; GNU C/C++; Mesa OpenGL ES 3.2 `llvmpipe`. llvmpipe is software rasterization/compute and must not be reported as hardware acceleration.
