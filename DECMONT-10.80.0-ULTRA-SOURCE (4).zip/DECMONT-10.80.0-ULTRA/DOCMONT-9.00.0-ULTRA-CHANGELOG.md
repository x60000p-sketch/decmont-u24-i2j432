# Changelog — DOCMONT 9.00.0 ULTRA

- Added 14 ONNX CPU operators and packed integer attribute decoding; total supported list: 23.
- Added native executable/object builder wrapper with x86_64 link/run and cross-object mode.
- Added shader compiler wrapper for Vulkan GLSL, D3D12 HLSL and Apple Metal.
- Added Windows D3D12 device/direct command queue probe source.
- Added Apple Metal device/command queue probe source.
- Added PS5/Xbox vendor SDK CMake build adapter and manifest templates.
- Added Windows MSVC, macOS universal and Android arm64 CMake presets/toolchain wrappers.
- Added installable CMake package config and `DOCMONT::docmont_core` imported target.
- Updated compiler, Studio, CLI and project tool version contracts to 9.00.0.
- Preserved language compatibility 3.4.0 and DVM v1 bytecode.
