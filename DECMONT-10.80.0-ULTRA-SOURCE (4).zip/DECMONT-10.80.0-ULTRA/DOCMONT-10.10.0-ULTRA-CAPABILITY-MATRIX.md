# DECMONT 10.10.0 Capability Matrix

| Area | 10.10.0 status |
|---|---|
| Language compatibility | 3.4.0 preserved |
| DVM bytecode | v1 preserved |
| System Doctor | Human-readable and JSON diagnostics |
| Native compiler | Restricted MIR subset, not full-language parity |
| GLES | Existing host-dependent implementation; hardware acceleration reported separately |
| Vulkan | Loader/device probing; not a complete renderer |
| D3D12 / Metal | Platform-dependent adapters/stubs; target validation required |
| ONNX | Bounded CPU subset; general GPU provider not implemented |
| Game engine | Host-side foundations; production renderer/audio adapters incomplete |
| Other platforms | Require independent toolchain/device validation |

`doctor` is diagnostic only. A loader or target registry entry does not prove a usable device, queue, renderer or complete compiler backend.
