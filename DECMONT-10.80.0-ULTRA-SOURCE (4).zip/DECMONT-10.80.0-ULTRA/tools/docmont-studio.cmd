@echo off
set ROOT=%~dp0..\
if "%DOCMONT_EXECUTABLE%"=="" set DOCMONT_EXECUTABLE=%ROOT%build\docmont.exe
python "%ROOT%studio\server.py" --workspace "%CD%" --port 8787 --compiler "%DOCMONT_EXECUTABLE%"
