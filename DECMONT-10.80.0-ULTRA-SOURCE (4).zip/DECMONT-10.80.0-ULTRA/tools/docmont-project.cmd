@echo off
setlocal
set "SCRIPT=%~dp0docmont-project"
py -3 "%SCRIPT%" %*
exit /b %errorlevel%
