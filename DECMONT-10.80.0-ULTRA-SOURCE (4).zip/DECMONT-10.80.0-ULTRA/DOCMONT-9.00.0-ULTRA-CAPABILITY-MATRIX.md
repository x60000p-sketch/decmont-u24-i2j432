# DOCMONT 9.00.0 ULTRA — Capability Matrix

Status values: **Implemented & tested here**, **Platform-gated**, **Partial**, **Adapter/configuration only**, **Not implemented**.

| Area | Status | Exact verified scope |
|---|---|---|
| Core language / parser / SSA | Implemented & tested here | Retains 8.90 grammar/runtime contracts; language compatibility 3.4.0 |
| DVM | Implemented & tested here | DVM v1 compile, verify and execution; bytecode unchanged |
| Project lifecycle | Implemented & tested here | Scaffold, manifest validation, asset hashing, DVM build, verification, smoke run, deterministic ZIP |
| Studio | Implemented & tested here | Local workspace/editor/project check/build/package, existing Studio smoke suite |
| ONNX FLOAT loader | Implemented & tested here | Bounded protobuf parser, graph validation, max tensor element limits |
| ONNX CPU operators | Implemented & tested here | Add, Sub, Div, Mul, Pow, Max, Min, Gemm, Identity, MatMul, Relu, LeakyRelu, Elu, Softplus, HardSigmoid, Sigmoid, Softmax, Tanh, Flatten, Transpose, ReduceMean, Concat, Clip |
| ONNX full standard | Partial | FLOAT tensors only; no full operators/domains/control-flow/sparse/external-data/provider support |
| Native executable tool | Implemented & tested here | `docmont-native-build`; direct MIR integer subset linked and run on Linux x86_64; verified output process status 42 |
| Native cross objects | Implemented & tested here | Existing Clang MIR emitter creates x86_64, AArch64, wasm32, RISC-V objects; actual tested run only on x86_64 Linux |
| Native full game source | Partial | Direct MIR path does not compile all DOCMONT language, engine APIs or assets into a complete game |
| Shader compiler router | Implemented & tested here | Command selection, argument construction, dry-run and output validation tested with fixture compiler |
| Actual Vulkan shader compile | Adapter/configuration only | Requires local glslc or glslangValidator; neither was present for this release build |
| D3D12 shader compile | Adapter/configuration only | Requires DXC and Windows SDK |
| Metal shader compile | Adapter/configuration only | Requires Xcode `xcrun metal` on macOS |
| Vulkan device probe | Partial | Loader/instance/physical device/logical device/queue initialization when ICD/device exists; release host exposed no working ICD/device |
| Vulkan renderer/compute | Not implemented | No render pass/pipeline/resource/command submission implementation is claimed |
| D3D12 device probe | Platform-gated | Windows source creates a D3D12 device and direct queue; not compiled/tested on Linux |
| D3D12 renderer | Not implemented | No full render/compute pipeline claimed |
| Metal device probe | Platform-gated | Apple Objective-C++ source creates MTLDevice and command queue; not compiled/tested on Linux |
| Metal renderer | Not implemented | No full render/compute pipeline claimed |
| Windows x64 | Adapter/configuration only | Visual Studio 2022 preset; no Windows build host in this run |
| macOS Universal | Adapter/configuration only | Xcode arm64+x86_64 preset; no Apple host/SDK in this run |
| Android arm64-v8a | Adapter/configuration only | NDK toolchain wrapper and preset; no Android NDK in this run |
| Sony PlayStation SDK | Adapter/configuration only | Validates a private manifest and invokes the toolchain in an existing CMake project; tested using fixtures, not the user's actual SDK/devkit |
| Xbox GDK | Adapter/configuration only | Same vendor-supplied toolchain manifest flow; not tested against GDK |
| Console certification | Not implemented | Vendor packaging/signing/deployment/device checks remain external |
| CMake SDK package | Implemented & tested here | Installs `DOCMONT::docmont_core` imported target and version config |

## Test evidence

- Linux x86_64 Release build completed with GCC 14 / CMake 3.31.
- CTest: 76/76 passed.
- VS Code LSP: 8/8 passed independently.
- VS Code JavaScript checks: passed.
- ONNX generated protobuf fixtures cover extended operator computations and shape transformations.
- Native builder linked and ran x86_64 program; generated AArch64 object.
- Console build driver validated SDK manifest/license gate and dispatched configure/build using fake toolchain fixture only.
- Shader router validated backend flags and artifact checks with fake shader compiler fixture only.
- Installed CMake package and standalone runtime are smoke-tested on Linux.

## Required external validation

A real Sony SDK manifest and SDK toolchain must be present on the user's authorized machine to run `docmont-console-build`. This environment did not contain that proprietary SDK. Windows, macOS and Android require their official toolchains and CI/device validation. No backend should be marked Stable/Supported until those vendor builds and runtime tests pass.

## Additional release packaging evidence

- Installed `DOCMONT::docmont_core` CMake package consumed and linked from a separate C++ project.
- A project created with the installed `docmont-project` passed check/assets/build/package and DVM verification.
- The install archive contains compiler, static library, headers, CMake package exports, Studio assets, examples, shader sources and build tools.
