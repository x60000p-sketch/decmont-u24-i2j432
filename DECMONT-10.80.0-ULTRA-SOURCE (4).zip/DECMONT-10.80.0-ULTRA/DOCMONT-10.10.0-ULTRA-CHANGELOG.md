# DECMONT 10.10.0 Changelog

- Added `docmont doctor` human-readable system diagnostics.
- Added `docmont doctor --json` schema version 1 output.
- Reported host, DVM, Native compiler, GLES, GPU backend, game engine and ONNX capability boundaries.
- Preserved language compatibility 3.4.0 and DVM bytecode v1.
