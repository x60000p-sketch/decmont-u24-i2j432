#include "docmont/native_backend.hpp"
#include <iostream>
#include <string>

namespace {
int failures = 0;
void expect(bool condition, const char* name) {
    if (!condition) { std::cerr << "FAIL: " << name << '\n'; ++failures; }
}
}

int main() {
    using namespace docmont;
    auto emits = [](std::vector<Instruction> code) {
        ProgramIR ir; ir.name = "native_10_40"; ir.code = std::move(code);
        return emit_c_source(ir);
    };
    {
        const auto r = emits({{OpCode::PushInt,"",4,1},{OpCode::PushInt,"",4,1},
                              {OpCode::Equal,"",0,1},{OpCode::Print,"",0,1}});
        expect(r.ok && r.source.find("int eq=0") != std::string::npos,
               "integer equality lowers to native C");
    }
    {
        const auto r = emits({{OpCode::PushString,"decmont",0,1},{OpCode::PushString,"decmont",0,1},
                              {OpCode::NotEqual,"",0,1},{OpCode::Print,"",0,1}});
        expect(r.ok && r.source.find("strcmp(a.s,b.s)") != std::string::npos,
               "string inequality lowers with content comparison");
    }
    {
        const auto r = emits({{OpCode::PushInt,"",3,1},{OpCode::BoolNot,"",0,1},
                              {OpCode::Print,"",0,1}});
        expect(r.ok && r.source.find("stack[sp-1].i = (stack[sp-1].i==0)") != std::string::npos,
               "boolean not lowers in place");
    }
    {
        const auto r = emits({{OpCode::PushInt,"",2,1},{OpCode::PushInt,"",5,1},
                              {OpCode::LessEqual,"",0,1},{OpCode::Print,"",0,1}});
        expect(r.ok && r.source.find("v=(a.i<=b.i)") != std::string::npos,
               "ordered comparison lowers to native C");
    }
    {
        const auto r = emits({{OpCode::PushInt,"",1,1},{OpCode::PushInt,"",0,1},
                              {OpCode::LogicalOr,"",0,1},{OpCode::Print,"",0,1}});
        expect(r.ok && r.source.find("v=(a.i!=0 || b.i!=0)") != std::string::npos,
               "logical or lowers to normalized boolean");
    }
    {
        const auto r = emits({{OpCode::PushInt,"",1,1},{OpCode::BoolNot,"",0,1},
                              {OpCode::PushInt,"",2,1},{OpCode::Less,"",0,1},
                              {OpCode::Print,"",0,1}});
        expect(r.ok, "unary and binary stack effects verify together");
    }
    if (failures) return 1;
    std::cout << "DECMONT 10.40.0 native backend: 6 checks passed\n";
    return 0;
}
