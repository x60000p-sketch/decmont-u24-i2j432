#include "docmont/ssa.hpp"
#include <algorithm>
#include <cassert>
#include <iostream>
using namespace docmont;

static const SSAParameterEffect* effect_for(const SSAFunctionRegion& fn, std::size_t index) {
    auto it = std::find_if(fn.parameter_effects.begin(), fn.parameter_effects.end(),
        [&](const SSAParameterEffect& effect) { return effect.parameter_index == index; });
    return it == fn.parameter_effects.end() ? nullptr : &*it;
}

int main() {
    // mutate() performs an in-place array write through formal argument 0.
    // relay() forwards its own formal argument to mutate(); 7.70 must compose
    // the callee's parameter effect back to relay's caller-visible summary.
    ProgramIR program;
    program.code = {
        {OpCode::PushInt, {}, 0, 1}, // keeps the root-level verifier stack balanced
        {OpCode::Function, "mutate", 1, 1},
        {OpCode::PushInt, {}, 7, 1},
        {OpCode::ArrayPush, {}, 0, 1},
        {OpCode::Return, {}, 0, 1},
        {OpCode::PushInt, {}, 0, 1},
        {OpCode::Function, "relay", 1, 1},
        {OpCode::Call, "mutate", 1, 1},
        {OpCode::Return, {}, 0, 1}
    };
    const auto ssa = build_ssa(program);
    const auto checked = verify_ssa(ssa, program);
    if (!checked.ok) {
        for (const auto& error : checked.errors) std::cerr << error << '\n';
        return 2;
    }
    assert(ssa.functions.size() == 2);
    const auto mutate = std::find_if(ssa.functions.begin(), ssa.functions.end(),
        [](const SSAFunctionRegion& fn) { return fn.name == "mutate"; });
    const auto relay = std::find_if(ssa.functions.begin(), ssa.functions.end(),
        [](const SSAFunctionRegion& fn) { return fn.name == "relay"; });
    assert(mutate != ssa.functions.end() && relay != ssa.functions.end());
    const auto* mutate_effect = effect_for(*mutate, 0);
    const auto* relay_effect = effect_for(*relay, 0);
    assert(mutate_effect && mutate_effect->may_read_memory && mutate_effect->may_write_memory);
    assert(relay_effect && relay_effect->may_read_memory && relay_effect->may_write_memory);
    assert(!relay_effect->may_escape);
    assert(dump_ssa(ssa).find("parameter_effects=1") != std::string::npos);

    // A formal returned to the caller is summarized as escaping.
    ProgramIR identity;
    identity.code = {
        {OpCode::PushInt, {}, 0, 1},
        {OpCode::Function, "identity", 1, 1},
        {OpCode::Return, {}, 0, 1}
    };
    const auto identity_ssa = build_ssa(identity);
    const auto identity_check = verify_ssa(identity_ssa, identity);
    assert(identity_check.ok);
    const auto* identity_effect = effect_for(identity_ssa.functions.front(), 0);
    assert(identity_effect && identity_effect->may_escape);

    // An unresolved direct call must conservatively read, write and escape
    // every passed symbolic reference rather than attributing effects to a
    // single arbitrary operand.
    ProgramIR unknown_call;
    unknown_call.code = {
        {OpCode::PushInt, {}, 0, 1},
        {OpCode::Function, "unknown_forwarder", 1, 1},
        {OpCode::Call, "not_declared", 1, 1},
        {OpCode::Return, {}, 0, 1}
    };
    const auto unknown_ssa = build_ssa(unknown_call);
    assert(verify_ssa(unknown_ssa, unknown_call).ok);
    const auto* unknown_effect = effect_for(unknown_ssa.functions.front(), 0);
    assert(unknown_effect && unknown_effect->may_read_memory && unknown_effect->may_write_memory && unknown_effect->may_escape);

    // Invalid parameter indexes are rejected by the verifier.
    auto corrupted = ssa;
    corrupted.functions.front().parameter_effects.push_back({99, true, false, false});
    assert(!verify_ssa(corrupted, program).ok);
    std::cout << "DOCMONT 7.70.0 interprocedural parameter-effect tests passed\n";
}
