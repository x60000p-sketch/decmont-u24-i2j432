#include "docmont/bytecode.hpp"
#include "docmont/function_semantics.hpp"
#include "docmont/ir.hpp"
#include "docmont/lexer.hpp"
#include "docmont/parser.hpp"
#include "docmont/platform_contract.hpp"
#include "docmont/runtime.hpp"
#include "docmont/semantic.hpp"
#include <cassert>
#include <iostream>
#include <functional>
#include <sstream>

using namespace docmont;

static Application parse(const std::string& source) {
    Lexer lexer(source);
    auto lexed = lexer.scan();
    assert(lexed.diagnostics.empty());
    Parser parser(std::move(lexed.tokens));
    auto parsed = parser.parse();
    assert(parsed.diagnostics.empty());
    return parsed.app;
}

static std::string capture_execution(const std::function<int()>& run) {
    std::ostringstream captured;
    auto* old = std::cout.rdbuf(captured.rdbuf());
    const int status = run();
    std::cout.rdbuf(old);
    assert(status == 0);
    return captured.str();
}

static std::string run_capture(const Application& app) {
    return capture_execution([&] { return execute_application(app); });
}

int main() {
    const std::string source = R"(!docmont[3]
select architecture = portable
application = {
 name = "typed_portable_runtime"
 fn add(left: Int, right: Int): Int {
   return left + right
 }
 fn greet(name: String = "DOCMONT"): String {
   return "Hello " + name
 }
 fn positive(value: Int): Bool {
   return value > 0
 }
 fn offset(base: Int, value: Int = base + 3): Int {
   return value
 }
 let operation = add
 let greeting = greet
 let items = [4, 5]
 let pushed = push(items, operation(1, 2))
 let removed = pop(items)
 output = greet()
 output = greeting()
 output = pushed
 output = removed
 output = len(items)
 output = len("abc")
 output = len(object { key = 1 })
 output = offset(5)
 if (positive(operation(1, 2)) && true) {
   output = "boolean control flow"
 }
 complete
})";
    auto app = parse(source);
    assert(validate(app).empty());
    assert(validate_function_contracts(app).empty());
    const auto output = run_capture(app);
    assert(output == "Hello DOCMONT\nHello DOCMONT\n3\n3\n2\n3\n1\n8\nboolean control flow\n");

    // The architecture-neutral DVM path must preserve default arguments,
    // defaults that reference earlier parameters, string concatenation,
    // function references, and the len/push/pop built-ins.
    const auto ir = lower_to_ir(app);
    const auto encoded = encode_bytecode(ir);
    assert(encoded.ok);
    assert(verify_bytecode(encoded.bytes).ok);
    const auto vm_output = capture_execution([&] { return execute_bytecode(encoded.bytes); });
    assert(vm_output == output);

    const std::string bad_argument = R"(!docmont[3]
application = {
 name = "bad_argument"
 fn square(value: Int): Int { return value * value }
 let value = square("wrong")
 complete
})";
    auto bad = parse(bad_argument);
    const auto errors = validate_function_contracts(bad);
    assert(!errors.empty());
    bool found_argument_type = false;
    for (const auto& d : errors) if (d.message.find("expects Int, got String") != std::string::npos) found_argument_type = true;
    assert(found_argument_type);

    const std::string bad_return = R"(!docmont[3]
application = {
 name = "bad_return"
 fn wrong(): String { return 42 }
 complete
})";
    auto bad_result = parse(bad_return);
    const auto return_errors = validate_function_contracts(bad_result);
    assert(!return_errors.empty());

    const std::string no_return = R"(!docmont[3]
application = {
 name = "no_return"
 fn missing(): Int { let value = 1 }
 complete
})";
    auto missing_return = parse(no_return);
    const auto missing_errors = validate_function_contracts(missing_return);
    assert(!missing_errors.empty());

    const std::string short_circuit = R"(!docmont[3]
application = {
 name = "short_circuit_typecheck"
 if (false && missing_symbol) { output = 1 }
 if (true || missing_symbol) { output = 2 }
 complete
})";
    auto shorted = parse(short_circuit);
    assert(validate_function_contracts(shorted).empty());
    assert(platform::find_target("portable-vm") != nullptr);
    assert(platform::find_target("linux-aarch64") != nullptr);
    assert(platform::find_target("riscv64")->status == platform::BackendStatus::RequiresToolchain);
    assert(platform::host_arch_name() != "unknown");

    std::cout << "DOCMONT 8.40.0 language/type/portable-runtime tests passed\n";
}
