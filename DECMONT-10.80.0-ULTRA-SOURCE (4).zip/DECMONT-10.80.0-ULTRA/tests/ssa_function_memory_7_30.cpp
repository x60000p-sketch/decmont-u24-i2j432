#include "docmont/ssa.hpp"
#include "docmont/bytecode.hpp"
#include <algorithm>
#include <cassert>
#include <string>
#include <iostream>
using namespace docmont;

int main() {
    // The top-level jump skips the function table. Each function must still
    // receive its own CFG, stack SSA (including incoming argument values),
    // variable SSA and Memory SSA analysis.
    ProgramIR program;
    program.code = {
        {OpCode::PushInt, {}, 1, 1}, {OpCode::Print, {}, 0, 1},
        {OpCode::Jump, {}, 15, 1},
        {OpCode::Function, "pure", 0, 2},
        {OpCode::PushInt, {}, 42, 2}, {OpCode::Return, {}, 0, 2},
        {OpCode::Function, "mutate", 1, 3},
        {OpCode::Store, "items", 0, 3}, {OpCode::Load, "items", 0, 4},
        {OpCode::PushInt, {}, 7, 4}, {OpCode::ArrayPush, {}, 0, 4},
        {OpCode::Return, {}, 0, 4},
        {OpCode::Function, "wrapper", 0, 5},
        {OpCode::Call, "pure", 0, 5}, {OpCode::Return, {}, 0, 5},
        {OpCode::Function, "wrapper_mutate", 0, 6},
        {OpCode::PushInt, {}, 9, 6}, {OpCode::Call, "mutate", 1, 6},
        {OpCode::Return, {}, 0, 6},
        {OpCode::Function, "unresolved", 0, 7},
        {OpCode::Call, "not_registered", 0, 7}, {OpCode::Return, {}, 0, 7}
    };
    program.code[2].integer = static_cast<std::int64_t>(program.code.size());
    const auto ssa = build_ssa(program);
    assert(ssa.functions.size() == 5);
    { const auto checked=verify_ssa(ssa, program); if(!checked.ok){for(const auto& e:checked.errors)std::cerr<<e<<"\n";return 2;} }

    const auto find_fn = [&](const std::string& name) -> const SSAFunctionRegion& {
        const auto it = std::find_if(ssa.functions.begin(), ssa.functions.end(),
            [&](const SSAFunctionRegion& fn) { return fn.name == name; });
        assert(it != ssa.functions.end());
        return *it;
    };
    const auto& pure = find_fn("pure");
    const auto& mutate = find_fn("mutate");
    const auto& wrapper = find_fn("wrapper");
    const auto& wrapper_mutate = find_fn("wrapper_mutate");
    const auto& unresolved = find_fn("unresolved");
    assert(pure.analysis && pure.analysis->stack_ssa_valid);
    assert(mutate.analysis && mutate.analysis->stack_ssa_valid);
    assert(!pure.may_read_memory && !pure.may_write_memory && !pure.has_unknown_effects);
    assert(mutate.may_read_memory && mutate.may_write_memory && !mutate.has_unknown_effects);
    // Direct-call effect summaries propagate through the call graph.
    assert(!wrapper.may_read_memory && !wrapper.may_write_memory && !wrapper.has_unknown_effects);
    assert(wrapper_mutate.may_read_memory && wrapper_mutate.may_write_memory && !wrapper_mutate.has_unknown_effects);
    assert(unresolved.may_read_memory && unresolved.may_write_memory && unresolved.has_unknown_effects);
    assert(!mutate.analysis->memory_definitions.empty());
    assert(!mutate.analysis->memory_uses.empty());

    // A merge after memory-writing operations must receive a Memory Phi.
    ProgramIR diamond;
    diamond.code = {
        {OpCode::Load, "condition", 0, 1}, {OpCode::JumpIfZero, {}, 5, 1},
        {OpCode::NewObject, {}, 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Jump, {}, 7, 2}, {OpCode::NewObject, {}, 0, 3},
        {OpCode::Print, {}, 0, 3}, {OpCode::NewObject, {}, 0, 4},
        {OpCode::Print, {}, 0, 4}
    };
    const auto memory = build_ssa(diamond);
    assert(verify_ssa(memory, diamond).ok);
    assert(!memory.memory_phis.empty());
    const auto phi = std::find_if(memory.memory_phis.begin(), memory.memory_phis.end(),
        [](const SSAMemoryPhi& item) { return item.incoming.size() == 2; });
    assert(phi != memory.memory_phis.end());
    assert(encode_bytecode(diamond).ok);

    // Indirect calls are conservatively unknown and propagate through callers.
    ProgramIR indirect;
    indirect.code = {
        {OpCode::Jump, {}, 5, 1},
        {OpCode::Function, "dynamic", 0, 2},
        {OpCode::Load, "callable", 0, 2}, {OpCode::CallIndirect, {}, 0, 2},
        {OpCode::Return, {}, 0, 2}
    };
    // The jump target is one-past-end; the function still has a separate region.
    const auto indirect_ssa = build_ssa(indirect);
    assert(indirect_ssa.functions.size() == 1);
    assert(indirect_ssa.functions.front().has_unknown_effects);
    assert(verify_ssa(indirect_ssa, indirect).ok);

    const auto dump = dump_ssa(ssa);
    assert(dump.find("Functions analyzed: 5") != std::string::npos);
    assert(dump.find("memory_") != std::string::npos);
}
