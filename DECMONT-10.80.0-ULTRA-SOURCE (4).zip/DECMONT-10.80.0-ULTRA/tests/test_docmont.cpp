#include "docmont/lexer.hpp"
#include "docmont/parser.hpp"
#include "docmont/semantic.hpp"
#include "docmont/function_semantics.hpp"
#include "docmont/ir.hpp"
#include "docmont/runtime.hpp"
#include "docmont/bytecode.hpp"
#include "docmont/native_backend.hpp"
#include "docmont/graphics.hpp"
#include "docmont/math.hpp"
#include "docmont/engine.hpp"
#include "docmont/memory.hpp"
#include "docmont/heap.hpp"
#include "docmont/render_graph.hpp"
#include "docmont/renderer3d.hpp"
#include "docmont/rendering.hpp"
#include "docmont/vlot.hpp"
#include "docmont/vlot_advanced.hpp"
#include "docmont/decom.hpp"
#include "docmont/platform_contract.hpp"
#include "docmont/module_registry.hpp"
#include "docmont/tensor.hpp"
#include "docmont/numerics.hpp"
#include "docmont/module_system.hpp"
#include <fstream>
#include <iostream>
#include <limits>
#include <sstream>
#include <algorithm>
#include <cassert>
#include <string>
#include <vector>
#include <filesystem>

static docmont::Application parse_app(const std::string& source) {
    docmont::Lexer lexer(source);
    auto lexed = lexer.scan();
    assert(lexed.diagnostics.empty());
    docmont::Parser parser(lexed.tokens);
    auto parsed = parser.parse();
    assert(parsed.diagnostics.empty());
    return parsed.app;
}

int main() {
    const std::string valid = R"(!docmont[2]
select architecture = x86_64
application = {
 name = "TEST"
 memory = {
  allocation = automatic
  management = native
 }
 compute = {
  algorithm = selkon
  optimization = O3
 }
 output = "DOCMONT TEST"
 complete
})";

    auto app = parse_app(valid);
    assert(docmont::validate(app).empty());
    assert(app.name == "TEST");
    assert(app.outputs.size() == 1);
    auto ir = docmont::lower_to_ir(app);
    assert(ir.code.size() == 2);
    assert(ir.target == "x86_64");


    const std::string arithmetic = R"(!docmont[2]
select architecture = x86_64
application = {
 name = "ARITHMETIC"
 let result = (25 + 15) * 3
 output = result
 complete
})";
    auto arithmetic_app = parse_app(arithmetic);
    assert(docmont::validate(arithmetic_app).empty());
    auto arithmetic_ir = docmont::lower_to_ir(arithmetic_app);
    assert(arithmetic_ir.code.size() == 8);

    const std::string bad_types = R"(!docmont[2]
select architecture = x86_64
application = {
 name = "BAD_TYPES"
 let result = 5 + "hello"
 output = result
 complete
})";
    auto bad_type_app = parse_app(bad_types);
    const auto type_errors = docmont::validate(bad_type_app);
    assert(std::any_of(type_errors.begin(), type_errors.end(), [](const auto& d) {
        return d.message.find("requires integer operands") != std::string::npos;
    }));

    const std::string precedence = R"(!docmont[2]
select architecture = x86_64
application = {
 name = "PRECEDENCE"
 output = 2 + 3 * 4
 complete
})";
    auto precedence_app = parse_app(precedence);
    assert(docmont::validate(precedence_app).empty());
    auto precedence_ir = docmont::lower_to_ir(precedence_app);
    assert(precedence_ir.code[0].integer == 2);
    assert(precedence_ir.code[1].integer == 3);
    assert(precedence_ir.code[2].integer == 4);
    assert(precedence_ir.code[3].op == docmont::OpCode::Mul);
    assert(precedence_ir.code[4].op == docmont::OpCode::Add);


    std::ostringstream captured_out;
    auto* old_out = std::cout.rdbuf(captured_out.rdbuf());
    const int arithmetic_status = docmont::execute(arithmetic_ir);
    std::cout.rdbuf(old_out);
    assert(arithmetic_status == 0);
    assert(captured_out.str() == "120\n");

    const std::string divide_zero = R"(!docmont[2]
select architecture = x86_64
application = {
 name = "DIV_ZERO"
 output = 9 / (3 - 3)
 complete
})";
    auto divide_zero_app = parse_app(divide_zero);
    assert(docmont::validate(divide_zero_app).empty());
    auto divide_zero_ir = docmont::lower_to_ir(divide_zero_app);
    std::ostringstream captured_error;
    auto* old_error = std::cerr.rdbuf(captured_error.rdbuf());
    const int divide_zero_status = docmont::execute(divide_zero_ir);
    std::cerr.rdbuf(old_error);
    assert(divide_zero_status == 1);
    assert(captured_error.str().find("division by zero") != std::string::npos);

    // Portable overflow guard: this path is shared by GCC, Clang and MSVC.
    docmont::ProgramIR overflow_ir;
    overflow_ir.name = "OVERFLOW";
    overflow_ir.target = "x86_64";
    overflow_ir.code = {
        {docmont::OpCode::PushInt, {}, std::numeric_limits<std::int64_t>::max(), 7},
        {docmont::OpCode::PushInt, {}, 1, 7},
        {docmont::OpCode::Add, {}, 0, 7},
        {docmont::OpCode::Print, {}, 0, 7}
    };
    std::ostringstream overflow_error;
    old_error = std::cerr.rdbuf(overflow_error.rdbuf());
    const int overflow_status = docmont::execute(overflow_ir);
    std::cerr.rdbuf(old_error);
    assert(overflow_status == 1);
    assert(overflow_error.str().find("overflow") != std::string::npos);

    const std::string duplicate_variable = R"(!docmont[2]
select architecture = x86_64
application = {
 name = "DUPLICATE_VAR"
 let value = 1
 let value = 2
 complete
})";
    auto duplicate_variable_app = parse_app(duplicate_variable);
    const auto duplicate_variable_errors = docmont::validate(duplicate_variable_app);
    assert(std::any_of(duplicate_variable_errors.begin(), duplicate_variable_errors.end(), [](const auto& d) {
        return d.message.find("already declared") != std::string::npos;
    }));

    auto bad_arch = app;
    bad_arch.architecture = "mips64";
    assert(!docmont::validate(bad_arch).empty());

    auto incomplete = app;
    incomplete.complete = false;
    assert(!docmont::validate(incomplete).empty());

    auto bad_memory = app;
    for (auto& block : bad_memory.blocks) {
        if (block.name == "memory") {
            for (auto& property : block.properties) {
                if (property.key == "allocation") property.value = "invisible";
            }
        }
    }
    assert(!docmont::validate(bad_memory).empty());

    auto duplicate_property = app;
    for (auto& block : duplicate_property.blocks) {
        if (block.name == "memory") {
            block.properties.push_back({"allocation", "manual", 99});
        }
    }
    const auto duplicate_property_diagnostics = docmont::validate(duplicate_property);
    assert(std::any_of(duplicate_property_diagnostics.begin(), duplicate_property_diagnostics.end(),
        [](const auto& d) { return d.message.find("Duplicate property 'allocation'") != std::string::npos; }));

    auto duplicate_block = app;
    duplicate_block.blocks.push_back(duplicate_block.blocks.front());
    const auto duplicate_block_diagnostics = docmont::validate(duplicate_block);
    assert(std::any_of(duplicate_block_diagnostics.begin(), duplicate_block_diagnostics.end(),
        [](const auto& d) { return d.message.find("Duplicate block 'memory'") != std::string::npos; }));

    auto unknown_property = app;
    unknown_property.blocks.front().properties.push_back({"stealth_mode", "true", 100});
    const auto unknown_property_diagnostics = docmont::validate(unknown_property);
    assert(std::any_of(unknown_property_diagnostics.begin(), unknown_property_diagnostics.end(),
        [](const auto& d) { return d.message.find("Unknown property 'stealth_mode'") != std::string::npos; }));

    auto bad_bounds = app;
    for (auto& block : bad_bounds.blocks) {
        if (block.name == "memory") block.properties.push_back({"bounds", "maybe", 101});
    }
    const auto bad_bounds_diagnostics = docmont::validate(bad_bounds);
    assert(std::any_of(bad_bounds_diagnostics.begin(), bad_bounds_diagnostics.end(),
        [](const auto& d) { return d.message.find("memory.bounds must be enforced or unbounded") != std::string::npos; }));
    // DVM v1 container: deterministic encoding and structural/stack verification.
    auto encoded = docmont::encode_bytecode(arithmetic_ir);
    assert(encoded.ok);
    assert(encoded.bytes.size() > 20);
    auto verified = docmont::verify_bytecode(encoded.bytes);
    assert(verified.ok);
    assert(verified.message == "DVM bytecode verified");
    auto corrupted = encoded.bytes;
    corrupted[0] = 'X';
    auto rejected = docmont::verify_bytecode(corrupted);
    assert(!rejected.ok);
    assert(rejected.message.find("magic") != std::string::npos);

    // An opcode stream that consumes more values than it produces must be rejected.
    docmont::ProgramIR invalid_stack;
    invalid_stack.name = "INVALID_STACK";
    invalid_stack.target = "x86_64";
    invalid_stack.code = {{docmont::OpCode::Add, {}, 0, 1}};
    auto invalid_encoded = docmont::encode_bytecode(invalid_stack);
    assert(invalid_encoded.ok);
    auto invalid_verified = docmont::verify_bytecode(invalid_encoded.bytes);
    assert(!invalid_verified.ok);
    assert(invalid_verified.message.find("underflow") != std::string::npos);

    // DVM is now loadable and executable, not only structurally verifiable.
    docmont::ProgramIR decoded;
    auto decoded_result = docmont::decode_bytecode(encoded.bytes, decoded);
    assert(decoded_result.ok);
    assert(decoded.name == arithmetic_ir.name);
    assert(decoded.code.size() == arithmetic_ir.code.size());
    std::ostringstream vm_out;
    old_out = std::cout.rdbuf(vm_out.rdbuf());
    const int vm_status = docmont::execute_bytecode(encoded.bytes);
    std::cout.rdbuf(old_out);
    assert(vm_status == 0);
    assert(vm_out.str() == "120\n");

    // Native C source backend emits a compilable standalone translation unit.
    auto native = docmont::emit_c_source(arithmetic_ir);
    assert(native.ok);
    assert(native.source.find("int main(void)") != std::string::npos);
    assert(native.source.find("DOCMONT native runtime error") != std::string::npos);

    // Software 2D renderer primitives and PPM export.
    docmont::Canvas canvas(16, 16, {0,0,0});
    canvas.fill_rect(2, 2, 4, 4, {255,0,0});
    canvas.line(0, 0, 15, 15, {0,255,0});
    canvas.circle(8, 8, 3, {0,0,255});
    assert(canvas.width() == 16 && canvas.height() == 16);
    assert(canvas.pixels().size() == 256);
    assert(canvas.write_ppm("docmont_test_output.ppm"));


    // DOCMONT 3.2 structured control flow: if/else lowers to verified branches.
    const std::string branching = R"(!docmont[3]
select architecture = x86_64
application = {
 name = "BRANCHING"
 let score = 7
 if (score) {
  output = "accepted"
 } else {
  output = "rejected"
 }
 if (0) {
  output = "unreachable"
 }
 complete
})";
    auto branching_app = parse_app(branching);
    assert(docmont::validate(branching_app).empty());
    auto branching_ir = docmont::lower_to_ir(branching_app);
    assert(std::any_of(branching_ir.code.begin(), branching_ir.code.end(), [](const auto& i) { return i.op == docmont::OpCode::JumpIfZero; }));
    assert(std::any_of(branching_ir.code.begin(), branching_ir.code.end(), [](const auto& i) { return i.op == docmont::OpCode::Jump; }));
    std::ostringstream branch_out;
    old_out = std::cout.rdbuf(branch_out.rdbuf());
    const int branch_status = docmont::execute(branching_ir);
    std::cout.rdbuf(old_out);
    assert(branch_status == 0);
    assert(branch_out.str() == "accepted\n");

    auto branch_bytecode = docmont::encode_bytecode(branching_ir);
    assert(branch_bytecode.ok);
    assert(docmont::verify_bytecode(branch_bytecode.bytes).ok);
    std::ostringstream branch_vm_out;
    old_out = std::cout.rdbuf(branch_vm_out.rdbuf());
    const int branch_vm_status = docmont::execute_bytecode(branch_bytecode.bytes);
    std::cout.rdbuf(old_out);
    assert(branch_vm_status == 0);
    assert(branch_vm_out.str() == "accepted\n");

    docmont::ProgramIR bad_target;
    bad_target.name = "BAD_TARGET"; bad_target.target = "x86_64";
    bad_target.code = {{docmont::OpCode::Jump, {}, 99, 1}};
    auto bad_target_bytes = docmont::encode_bytecode(bad_target);
    assert(bad_target_bytes.ok);
    assert(!docmont::verify_bytecode(bad_target_bytes.bytes).ok);

    docmont::ProgramIR bad_merge;
    bad_merge.name = "BAD_MERGE"; bad_merge.target = "x86_64";
    bad_merge.code = {
        {docmont::OpCode::PushInt, {}, 1, 1},
        {docmont::OpCode::JumpIfZero, {}, 4, 1},
        {docmont::OpCode::PushInt, {}, 7, 2},
        {docmont::OpCode::Jump, {}, 4, 2}
    };
    auto bad_merge_bytes = docmont::encode_bytecode(bad_merge);
    assert(bad_merge_bytes.ok);
    assert(docmont::verify_bytecode(bad_merge_bytes.bytes).message.find("inconsistent stack depth") != std::string::npos);

    auto scoped_app = parse_app(R"(!docmont[3]
select architecture = x86_64
application = {
 name = "SCOPE"
 if (1) {
  let local_value = 3
 }
 output = local_value
 complete
})");
    const auto scope_errors = docmont::validate(scoped_app);
    assert(std::any_of(scope_errors.begin(), scope_errors.end(), [](const auto& d) { return d.message.find("Unknown variable 'local_value'") != std::string::npos; }));

    // VLOT hybrid platform layer: project loading, validation and truthful toolchain planning.
    {
        std::ofstream project_file("vlot_test.project");
        project_file << "VLOT 1\nname = \"VLOT_TEST\"\ntargets = pc, android, ps5\nrenderer = auto\nquality = high\nassets = assets\n";
    }
    docmont::vlot::ProjectConfig vproject;
    auto vload = docmont::vlot::load_project("vlot_test.project", vproject);
    assert(vload.ok && vproject.name == "VLOT_TEST" && vproject.targets.size() == 3);
    docmont::vlot::ToolchainAvailability no_sdks;
    auto vplan = docmont::vlot::create_build_plan(vproject, no_sdks);
    assert(vplan.targets.size() == 3);
    assert(vplan.targets[0].state == docmont::vlot::BuildState::Ready);
    assert(vplan.targets[1].state == docmont::vlot::BuildState::RequiresToolchain);
    assert(vplan.targets[2].state == docmont::vlot::BuildState::Blocked);
    assert(docmont::vlot::format_build_plan(vplan).find("authorized Sony developer access") != std::string::npos);

    docmont::vlot::ProjectConfig unsafe_project = vproject;
    unsafe_project.asset_root = "../outside";
    assert(!docmont::vlot::validate_project(unsafe_project).ok);
    docmont::vlot::Asset safe_asset{"hero", "assets/hero.mesh", "model"};
    assert(docmont::vlot::validate_asset(safe_asset).ok);
    safe_asset.relative_path = "../../secret";
    assert(!docmont::vlot::validate_asset(safe_asset).ok);

    docmont::vlot::Scene valid_scene;
    valid_scene.nodes.push_back({"root", "", {0,0,0}, {1,1,1}, {255,255,255}, 2, 2});
    valid_scene.nodes.push_back({"child", "root", {1,0,0}, {1,1,1}, {255,0,0}, 1, 1});
    assert(docmont::vlot::validate_scene(valid_scene).ok);
    valid_scene.nodes[0].parent = "child";
    assert(!docmont::vlot::validate_scene(valid_scene).ok);

    // VLOT software triangle renderer uses depth testing and emits a real image.
    docmont::vlot::SoftwareRenderer vrenderer(32, 32, {0,0,0});
    vrenderer.triangle({2,2,0.8f,{255,0,0}}, {29,2,0.8f,{255,0,0}}, {16,29,0.8f,{255,0,0}});
    vrenderer.triangle({5,5,0.2f,{0,255,0}}, {26,5,0.2f,{0,255,0}}, {16,25,0.2f,{0,255,0}});
    assert(vrenderer.write_ppm("vlot_test_render.ppm"));

    // VLOT advanced asset pipeline and deterministic, integrity-checked package.
    namespace fs = std::filesystem;
    fs::create_directories("vlot-advanced-test/assets/textures");
    { std::ofstream p("vlot-advanced-test/project.vlot"); p << "VLOT 1\nname = \"VLOT_ADVANCED_TEST\"\ntargets = pc\nrenderer = software\nquality = high\nassets = assets\n"; }
    { std::ofstream a("vlot-advanced-test/assets/textures/checker.bin", std::ios::binary); a << "VLOT-ASSET-PIPELINE"; }
    docmont::vlot::ProjectConfig advanced_project;
    assert(docmont::vlot::load_project("vlot-advanced-test/project.vlot", advanced_project).ok);
    docmont::vlot::AssetCatalog catalog;
    assert(docmont::vlot::build_asset_catalog("vlot-advanced-test/project.vlot", advanced_project, catalog).ok);
    assert(catalog.entries.size() == 1 && catalog.total_bytes == 19);
    docmont::vlot::PackageReport package_report;
    assert(docmont::vlot::build_package("vlot-advanced-test/project.vlot", "vlot-advanced-test/build.vpak", package_report).ok);
    assert(package_report.files == 2);
    docmont::vlot::PackageReport verified_report;
    assert(docmont::vlot::verify_package("vlot-advanced-test/build.vpak", verified_report).ok);
    assert(verified_report.files == 2 && verified_report.payload_bytes == package_report.payload_bytes);
    { std::ifstream in("vlot-advanced-test/build.vpak", std::ios::binary); std::vector<char> bytes((std::istreambuf_iterator<char>(in)), {}); assert(!bytes.empty()); bytes.back() ^= 0x01; std::ofstream out("vlot-advanced-test/tampered.vpak", std::ios::binary); out.write(bytes.data(), static_cast<std::streamsize>(bytes.size())); }
    assert(!docmont::vlot::verify_package("vlot-advanced-test/tampered.vpak", verified_report).ok);
    { std::ofstream bad("vlot-advanced-test/bad.vpak", std::ios::binary); bad << "NOPE"; }
    assert(!docmont::vlot::verify_package("vlot-advanced-test/bad.vpak", verified_report).ok);

    // VLOT shader DSL compiles to a bounded CPU material program and shades fragments.
    const std::string shader_source = "VSHADER 1\nname = TestSurface\nmodel = lambert\nbase_color = 0.8, 0.4, 0.2\nroughness = 0.35\nmetallic = 0.1\nemission = 0.0\n";
    docmont::vlot::ShaderProgram shader;
    assert(docmont::vlot::compile_shader(shader_source, shader).ok);
    const auto lit = docmont::vlot::shade_fragment(shader, {0,1,0}, {0,1,0});
    assert(lit.r > 0 && lit.g > 0 && lit.b > 0);
    assert(!docmont::vlot::compile_shader("VSHADER 1\nname = Bad\nroughness = 2\n", shader).ok);
    { std::ofstream src("vlot-advanced-test/test.vshader"); src << shader_source; }
    assert(docmont::vlot::compile_shader_file("vlot-advanced-test/test.vshader", "vlot-advanced-test/test.vsm").ok);
    assert(docmont::vlot::verify_material_file("vlot-advanced-test/test.vsm").ok);
    { std::ofstream src("vlot-advanced-test/bad.vscene"); src << "VSCENE 1\nnode a missing 0 0 0 1 1 1 1 1 255 0 0\n"; }
    docmont::vlot::Scene loaded_scene;
    assert(!docmont::vlot::load_scene("vlot-advanced-test/bad.vscene", loaded_scene).ok);
    docmont::vlot::SoftwareRenderer shaded_renderer(24,24,{0,0,0});
    docmont::vlot::draw_shaded_triangle(shaded_renderer,{1,1,0,{0,0,0}},{22,1,0,{0,0,0}},{12,22,0,{0,0,0}},shader,{0,1,0},{0,1,0});
    assert(shaded_renderer.write_ppm("vlot_shaded.ppm"));

    // Scene graph resolves parent transforms and renders a complete 2D scene.
    docmont::vlot::Scene hierarchy;
    hierarchy.nodes.push_back({"parent","",{10,12,0},{2,2,1},{255,255,255},4,4});
    hierarchy.nodes.push_back({"child","parent",{3,2,0},{0.5f,0.5f,1},{40,180,240},3,3});
    std::vector<docmont::vlot::WorldTransform> world;
    assert(docmont::vlot::resolve_world_transforms(hierarchy,world).ok);
    assert(world.size()==2 && std::abs(world[1].transform.position.x-16.0f)<0.001f);
    docmont::vlot::SoftwareRenderer scene_renderer(64,64,{0,0,0});
    assert(docmont::vlot::render_scene_2d(hierarchy,scene_renderer).ok);
    assert(scene_renderer.write_ppm("vlot_scene.ppm"));

    // DOCMONT 4.3 math foundation: vector algebra and row-major 3D transforms.
    using namespace docmont::math;
    const Vec3 axis_x{1,0,0}, axis_y{0,1,0};
    assert((cross(axis_x,axis_y).z==1.0f));
    assert(std::abs(length(Vec3{3,4,0})-5.0f)<0.0001f);
    const Mat4 model=Mat4::translation({10,20,30})*Mat4::scale({2,3,4});
    const Vec3 transformed=transform_point(model,{1,1,1});
    assert(std::abs(transformed.x-12)<0.0001f && std::abs(transformed.y-23)<0.0001f && std::abs(transformed.z-34)<0.0001f);
    const Mat4 projection=perspective(1.0f,16.0f/9.0f,0.1f,100.0f);
    assert(projection.at(0,0)>0 && projection.at(1,1)>0 && projection.at(3,2)==-1.0f);
    bool zero_normalize_rejected=false;
    try { (void)normalize(Vec3{0,0,0}); } catch(const std::domain_error&) { zero_normalize_rejected=true; }
    assert(zero_normalize_rejected);

    // DOCMONT 4.4 engine core: generation-safe ECS and transform hierarchy.
    struct Position { float x, y, z; };
    struct Velocity { float x, y, z; };
    docmont::engine::Registry registry;
    const auto actor = registry.create();
    registry.emplace<Position>(actor, Position{1,2,3});
    registry.emplace<Velocity>(actor, Velocity{0.5f,0,0});
    assert(registry.valid(actor) && registry.size()==1);
    assert((registry.view<Position,Velocity>().size()==1));
    assert(registry.get<Position>(actor)->x==1.0f);
    assert(registry.remove<Velocity>(actor));
    assert((registry.view<Position,Velocity>().empty()));
    assert(registry.destroy(actor) && !registry.valid(actor));
    const auto reused = registry.create();
    assert(reused.index==actor.index && reused.generation!=actor.generation);
    bool stale_component_rejected=false;
    try { registry.emplace<Position>(actor, Position{0,0,0}); } catch(const std::invalid_argument&) { stale_component_rejected=true; }
    assert(stale_component_rejected);

    docmont::engine::SceneGraph graph;
    const auto root=graph.create({{10,0,0},{2,2,2}});
    const auto child=graph.create({{1,0,0},{1,1,1}});
    const auto leaf=graph.create({{0,3,0},{1,1,1}});
    assert(graph.set_parent(child,root));
    assert(graph.set_parent(leaf,child));
    assert(!graph.set_parent(root,leaf)); // cycle rejected
    const auto leaf_world=graph.world_matrix(leaf);
    assert(leaf_world.has_value());
    const auto leaf_position=docmont::math::transform_point(*leaf_world,{0,0,0});
    assert(std::abs(leaf_position.x-12.0f)<0.0001f && std::abs(leaf_position.y-6.0f)<0.0001f);
    assert(!graph.world_matrix(9999).has_value());

    // DOCMONT 4.5 quaternion transforms, transient arena and render dependency graph.
    const float half_sqrt = std::sqrt(0.5f);
    const Quat quarter_turn{0,0,half_sqrt,half_sqrt};
    const Vec3 rotated = transform_point(Mat4::rotation(quarter_turn), {1,0,0});
    assert(std::abs(rotated.x)<0.0002f && std::abs(rotated.y-1.0f)<0.0002f);
    const Quat qnorm=normalize(Quat{0,0,2,2});
    assert(std::abs(dot(qnorm,qnorm)-1.0f)<0.0001f);

    docmont::memory::LinearArena arena(256);
    auto* arena_value=arena.make<std::uint64_t>(0xD0C0A55ULL);
    assert(reinterpret_cast<std::uintptr_t>(arena_value)%alignof(std::uint64_t)==0);
    assert(*arena_value==0xD0C0A55ULL && arena.allocation_count()==1 && arena.used()>=sizeof(std::uint64_t));
    arena.reset();
    assert(arena.used()==0 && arena.allocation_count()==0);
    bool arena_overflow=false;
    try { (void)arena.allocate(1024); } catch(const std::bad_alloc&) { arena_overflow=true; }
    assert(arena_overflow);

    // DOCMONT 4.25 budgeted heap: aligned allocation, accounting and safe rejection.
    docmont::memory::Heap heap(128);
    auto* heap_value = heap.make<std::uint64_t>(0x4250C0DEULL);
    assert(*heap_value == 0x4250C0DEULL);
    assert(reinterpret_cast<std::uintptr_t>(heap_value) % alignof(std::uint64_t) == 0);
    assert(heap.stats().live_bytes == sizeof(std::uint64_t));
    assert(heap.stats().live_blocks == 1 && heap.stats().total_allocations == 1);
    assert(heap.destroy(heap_value));
    assert(!heap.destroy(heap_value)); // stale/double free is rejected
    assert(heap.stats().live_bytes == 0 && heap.stats().total_deallocations == 1);
    void* heap_block = heap.allocate(96, 32);
    assert(reinterpret_cast<std::uintptr_t>(heap_block) % 32 == 0);
    bool heap_budget_rejected = false;
    try { (void)heap.allocate(40); } catch (const std::bad_alloc&) { heap_budget_rejected = true; }
    assert(heap_budget_rejected);
    assert(heap.deallocate(heap_block));
    assert(heap.stats().peak_bytes == 96 && heap.stats().live_blocks == 0);

    // DOCMONT 4.27: expanded heap diagnostics, tagged allocations and rollback.
    docmont::memory::Heap advanced_heap(512);
    assert(advanced_heap.budget_bytes() == 512);
    assert(advanced_heap.available_bytes() == 512 && advanced_heap.empty());
    auto* tagged = advanced_heap.make_tagged<std::string>("unit-test", "docmont");
    assert(*tagged == "docmont" && advanced_heap.owns(tagged));
    assert(advanced_heap.allocation_size(tagged).value() == sizeof(std::string));
    assert(advanced_heap.allocation_alignment(tagged).value() == alignof(std::string));
    assert(advanced_heap.allocation_tag(tagged).value() == "unit-test");
    assert(advanced_heap.allocation_count("unit-test") == 1);
    assert(advanced_heap.bytes_for_tag("unit-test") == sizeof(std::string));
    assert(advanced_heap.validate());
    const auto heap_checkpoint = advanced_heap.checkpoint();
    void* after_checkpoint = advanced_heap.allocate(48, 16, "temporary");
    assert(advanced_heap.owns(after_checkpoint));
    assert(advanced_heap.allocation_size(after_checkpoint).value() == 48);
    assert(advanced_heap.allocation_alignment(after_checkpoint).value() == 16);
    assert(advanced_heap.allocation_tag(after_checkpoint).value() == "temporary");
    assert(advanced_heap.allocation_count("temporary") == 1);
    assert(advanced_heap.bytes_for_tag("temporary") == 48);
    const auto leaks = advanced_heap.leak_report();
    assert(leaks.size() == 2 && leaks.front().tag == "unit-test");
    assert(advanced_heap.stats().live_blocks == 2);
    assert(advanced_heap.available_bytes() == 512 - sizeof(std::string) - 48);
    assert(!advanced_heap.set_budget(1));
    assert(advanced_heap.set_budget(1024));
    assert(advanced_heap.budget_bytes() == 1024);
    assert(advanced_heap.validate());
    assert(advanced_heap.rollback(heap_checkpoint) == 1);
    assert(!advanced_heap.owns(after_checkpoint));
    assert(advanced_heap.owns(tagged));
    assert(advanced_heap.clear_one("unit-test"));
    assert(advanced_heap.empty() && advanced_heap.validate());
    assert(advanced_heap.stats().total_allocations == 2);
    assert(advanced_heap.stats().total_deallocations == 2);
    advanced_heap.reset_peak();
    assert(advanced_heap.stats().peak_bytes == 0);
    assert(advanced_heap.try_allocate(2048) == nullptr);
    assert(advanced_heap.stats().failed_allocations >= 1);
    void* zero_sized = advanced_heap.allocate(0, alignof(std::max_align_t), "zero-normalized");
    assert(advanced_heap.allocation_size(zero_sized).value() == 1);
    assert(advanced_heap.deallocate(zero_sized));
    bool bad_alignment = false;
    try { (void)advanced_heap.allocate(8, 3); } catch (const std::invalid_argument&) { bad_alignment = true; }
    assert(bad_alignment);
    auto* counted = advanced_heap.make<int>(42);
    assert(*counted == 42 && advanced_heap.destroy(counted));
    assert(advanced_heap.validate());

    docmont::render::RenderGraph render_graph;
    const auto backbuffer=render_graph.resource("backbuffer", true);
    const auto depth=render_graph.resource("depth");
    const auto shadow=render_graph.resource("shadow-map");
    const auto shadow_pass=render_graph.pass({"shadow", {}, {shadow}, {}});
    const auto depth_pass=render_graph.pass({"depth-prepass", {}, {depth}, {}});
    const auto lighting_pass=render_graph.pass({"lighting", {shadow,depth}, {backbuffer}, {}});
    const auto schedule=render_graph.compile();
    assert(schedule.ok && schedule.order.size()==3);
    assert(schedule.order[0]==shadow_pass && schedule.order[1]==depth_pass && schedule.order[2]==lighting_pass);
    docmont::render::RenderGraph invalid_graph;
    const auto transient=invalid_graph.resource("transient");
    invalid_graph.pass({"read-too-early", {transient}, {}, {}});
    assert(!invalid_graph.compile().ok);
    // Read-before-overwrite hazard: the imported resource must remain readable
    // by the first pass before the later pass replaces it.
    docmont::render::RenderGraph hazard_graph;
    const auto imported=hazard_graph.resource("imported", true);
    hazard_graph.pass({"consume-import", {imported}, {}, {}});
    hazard_graph.pass({"replace-import", {}, {imported}, {}});
    const auto hazard_schedule=hazard_graph.compile();
    assert(hazard_schedule.ok && hazard_schedule.order.size()==2);
    assert(hazard_schedule.order[0]==0 && hazard_schedule.order[1]==1);

    // DOCMONT 4.6 mesh validation/catalog and camera matrices.
    docmont::render::MeshData triangle;
    triangle.vertices = {
        {{-1.0f, -1.0f, 0.0f}, {0.0f, 0.0f, 1.0f}, {0.0f, 0.0f}},
        {{ 1.0f, -1.0f, 0.0f}, {0.0f, 0.0f, 1.0f}, {1.0f, 0.0f}},
        {{ 0.0f,  1.0f, 0.0f}, {0.0f, 0.0f, 1.0f}, {0.5f, 1.0f}}
    };
    triangle.indices = {0, 1, 2};
    std::string mesh_error;
    assert(triangle.validate(&mesh_error) && mesh_error.empty());
    const auto triangle_bounds = triangle.bounds();
    assert(triangle_bounds.minimum.x == -1.0f && triangle_bounds.maximum.y == 1.0f);
    auto invalid_triangle = triangle;
    invalid_triangle.indices = {0, 1, 9};
    assert(!invalid_triangle.validate(&mesh_error));
    invalid_triangle = triangle;
    invalid_triangle.indices = {0, 1};
    assert(!invalid_triangle.validate(&mesh_error));

    docmont::render::MeshCatalog mesh_catalog;
    const auto triangle_handle = mesh_catalog.insert("triangle", triangle);
    assert(mesh_catalog.valid(triangle_handle) && mesh_catalog.size() == 1);
    assert(mesh_catalog.find("triangle").has_value());
    assert(mesh_catalog.get(triangle_handle)->indices.size() == 3);
    bool duplicate_mesh_rejected = false;
    try { (void)mesh_catalog.insert("triangle", triangle); } catch (const std::invalid_argument&) { duplicate_mesh_rejected = true; }
    assert(duplicate_mesh_rejected);
    assert(mesh_catalog.erase(triangle_handle) && !mesh_catalog.valid(triangle_handle));
    const auto replacement_mesh = mesh_catalog.insert("triangle-reloaded", triangle);
    assert(replacement_mesh.index == triangle_handle.index && replacement_mesh.generation != triangle_handle.generation);
    assert(mesh_catalog.get(triangle_handle) == nullptr);

    docmont::render::Camera camera;
    camera.position = {0.0f, 0.0f, 5.0f};
    camera.target = {0.0f, 0.0f, 0.0f};
    const auto camera_view = camera.view_matrix();
    const auto camera_origin = docmont::math::transform_point(camera_view, {0.0f, 0.0f, 0.0f});
    assert(std::abs(camera_origin.z + 5.0f) < 0.0001f);
    const auto camera_projection = camera.projection_matrix();
    assert(camera_projection.at(0,0) > 0.0f && camera_projection.at(3,2) == -1.0f);
    camera.projection = docmont::render::ProjectionKind::Orthographic;
    const auto ortho_projection = camera.projection_matrix();
    assert(std::abs(ortho_projection.at(0,0) - 0.1125f) < 0.0001f);
    camera.aspect = 0.0f;
    bool invalid_camera_rejected = false;
    try { (void)camera.projection_matrix(); } catch (const std::invalid_argument&) { invalid_camera_rejected = true; }
    assert(invalid_camera_rejected);

    // DOCMONT 4.6 CPU 3D renderer consumes shared MeshData and Camera APIs.
    camera.aspect=1.0f;
    docmont::render3d::Renderer renderer(96,96,{0,0,0});
    auto near_mesh=triangle;
    for (auto& vertex : near_mesh.vertices) vertex.position.z=1.0f;
    auto far_mesh=triangle;
    for (auto& vertex : far_mesh.vertices) vertex.position.z=-0.5f;
    assert(renderer.draw(near_mesh,camera,{255,0,0}));
    assert(renderer.draw(far_mesh,camera,{0,0,255}));
    const auto center=static_cast<std::size_t>(48)*96+48;
    assert(renderer.canvas().pixels()[center].r==255);
    assert(renderer.canvas().pixels()[center].b==0);
    assert(renderer.stats().triangles_submitted==2 && renderer.stats().triangles_rasterized==1);
    assert(renderer.stats().fragments_passed>0 && renderer.stats().fragments_depth_rejected>0);
    auto invalid_render_mesh=triangle;
    invalid_render_mesh.indices[2]=999;
    assert(!renderer.draw(invalid_render_mesh,camera));
    assert(renderer.write_ppm("docmont-3d-render.ppm"));

    // DOCMONT 4.8 tensor and numerical analytics contracts.
    {
        docmont::tensor::Tensor<double> t({2,3}, 0.0);
        t.at({1,2}) = 9.5;
        assert(t.rank()==2 && t.size()==6 && t.at({1,2})==9.5);
        auto reshaped=t.reshape({3,2});
        assert(reshaped.shape()[0]==3 && reshaped.at({2,1})==9.5);
        bool bounds=false; try { (void)t.at({2,0}); } catch(const std::out_of_range&) { bounds=true; }
        assert(bounds);
        const auto stats=docmont::tensor::describe(std::vector<double>{1,2,3,4});
        assert(std::abs(stats.mean-2.5)<1e-12 && std::abs(stats.variance-1.25)<1e-12);
        assert(stats.minimum==1.0 && stats.maximum==4.0);
    }

    // DOCMONT 4.7 DECOM standard libraries: numeric, kernel-plan, arrays,
    // matrices, signal, tensor, graph, serialization, compression and autodiff.
    {
        using namespace docmont::decom;
        const std::vector<double> nums{1.0,2.0,3.0,4.0};
        assert(selea::sum(nums)==10.0 && std::abs(selea::mean(nums)-2.5)<1e-12);
        assert(std::abs(stats::variance(nums)-1.25)<1e-12);
        auto ma=signal::moving_average(nums,2); assert(ma.size()==3 && ma[0]==1.5);
        auto m=matrix::identity(2); m.at(0,1)=2; auto mm=matrix::multiply(m,m);
        assert(mm.at(0,0)==1 && mm.at(0,1)==4);
        matrix::Matrix sys(2,2); sys.at(0,0)=2;sys.at(0,1)=1;sys.at(1,0)=1;sys.at(1,1)=3;
        auto sol=linalg::solve_gaussian(sys,{5,6}); assert(std::abs(sol[0]-1.8)<1e-12 && std::abs(sol[1]-1.4)<1e-12);
    }
    {
        using namespace docmont::decom;
        inplot::KernelConfig cfg; cfg.name="DOCMONT-USERSPACE"; cfg.workers=4;
        auto kernel=inplot::create(cfg); inplot::reserve(kernel,4096);
        assert(inplot::safe_mode(kernel.config) && kernel.reserved_bytes==4096);
        assert(abi::count()==31 && abi::find("decom.selea")!=nullptr);
        // DOCMONT hybrid runtime/memory contract and dual INPLOT domains.
        docmont::platform::RuntimeConfig runtime_cfg;
        assert(docmont::platform::validate(runtime_cfg).ok);
        runtime_cfg.memory = docmont::platform::MemoryMode::Manual;
        assert(!docmont::platform::validate(runtime_cfg).ok);
        runtime_cfg.allow_unsafe = true;
        assert(docmont::platform::validate(runtime_cfg).ok);
        runtime_cfg.bounds_checks = false;
        runtime_cfg.allow_unsafe = false;
        assert(!docmont::platform::validate(runtime_cfg).ok);
        assert(docmont::platform::find_target("linux-x86_64") != nullptr);
        assert(docmont::platform::target_count >= 8);
        docmont::decom::inplot::SystemKernelSpec system_spec;
        system_spec.name = "DOCMONT-OS-KERNEL";
        system_spec.architecture = "x86_64";
        assert(docmont::decom::inplot::validate_system_spec(system_spec).ok);
        docmont::modules::Registry registry;
        docmont::modules::Manifest core_module;
        core_module.name = "decom.selea";
        core_module.version = {1,0,0};
        core_module.exports.push_back({"mean", "fn(Array<f64>)->f64", true});
        assert(registry.add(core_module).ok);
        docmont::modules::Manifest consumer_module;
        consumer_module.name = "decom.analytics";
        consumer_module.exports.push_back({"analyze", "fn(Array<f64>)->Report", true});
        consumer_module.dependencies.push_back({"decom.selea",1});
        assert(registry.add(consumer_module).ok);
        assert(registry.validate_dependencies("decom.analytics").ok);
        assert(!registry.add(core_module).ok);
        docmont::modules::Manifest missing_module;
        missing_module.name = "decom.missing-test";
        missing_module.exports.push_back({"run", "fn()->void", true});
        missing_module.dependencies.push_back({"decom.absent",1});
        assert(registry.add(missing_module).ok);
        assert(!registry.validate_dependencies("decom.missing-test").ok);
        system_spec.bootable_artifact_produced = true;
        assert(!docmont::decom::inplot::validate_system_spec(system_spec).ok);
        std::vector<uint8_t> raw{7,7,7,2,2,9}; auto packed=compression::rle_encode(raw);
        assert(compression::rle_decode(packed)==raw);
        std::vector<uint8_t> stream; serialization::write_string(stream,"DOCMONT");
        size_t pos=0; assert(serialization::read_string(stream,pos)=="DOCMONT");
        autodiff::Dual x=autodiff::variable(3); auto y=x*x+autodiff::constant(2);
        assert(y.value==11 && y.derivative==6);
        graph::Graph g(3);g.add_edge(0,1);g.add_edge(1,2);assert(g.bfs(0).size()==3);
        tensor::Tensor t({2,2},3);assert(t.size()==4 && tensor::sum(t)==12);
        sparse::COO sp{2,2,{}};sp.add(0,0,2);sp.add(1,1,3);
        auto sv=sp.multiply(std::vector<double>{4,5});assert(sv[0]==8&&sv[1]==15);
        assert(numeric::is_prime(97)&&numeric::gcd(84,30)==6);
        auto opt=optimize::golden_section([](double z){return(z-2)*(z-2);},-5,5);
        assert(std::abs(opt.x-2)<1e-5);
        image::Image img(2,1,{10,20,30,255});image::invert(img);assert(img.at(0,0).r==245);
        assert(text::trim("  docmont  ")=="docmont");
    }

    // Fixed-substep AABB physics: gravity, static floor collision and validation.
    docmont::vlot::PhysicsWorld physics;
    physics.gravity={0,-9.81f,0};
    physics.bodies.push_back({"floor",{0,-1,0},{0,0,0},{5,0.5f,5},1,0,true});
    physics.bodies.push_back({"box",{0,2,0},{0,0,0},{0.5f,0.5f,0.5f},1,0,false});
    assert(docmont::vlot::validate_physics_world(physics).ok);
    for(int i=0;i<120;++i) assert(docmont::vlot::step_physics(physics,1.0f/60.0f,2).ok);
    assert(physics.bodies[1].position.y > -0.1f);
    assert(!docmont::vlot::step_physics(physics,1.0f,1).ok);


    // DOCMONT 4.11 parser-level module and import declarations.
    {
        const std::string source = "!docmont[3]\napplication = {\nmodule scientific.engine\nimport decom.math as math\nimport decom.matrix\ncomplete\n}\n";
        auto app = parse_app(source);
        assert(app.module_name == "scientific.engine");
        assert(app.imports.size() == 2);
        assert(app.imports[0].module == "decom.math" && app.imports[0].alias == "math");
        assert(app.imports[1].module == "decom.matrix" && app.imports[1].alias.empty());
    }

    // DOCMONT 4.9 module import resolver: dependency order, missing and cyclic imports.
    {
        namespace fs = std::filesystem;
        auto root = fs::temp_directory_path() / "docmont_490_module_test";
        fs::remove_all(root); fs::create_directories(root / "decom");
        { std::ofstream f(root / "app.docm"); f << "module app\nimport decom.math\n"; }
        { std::ofstream f(root / "decom" / "math.docm"); f << "module decom.math\n"; }
        docmont::modules::Resolver resolver(root);
        auto resolved = resolver.resolve(root / "app.docm");
        assert(resolved.ok() && resolved.order.size()==2);
        assert(resolved.imports.size()==1 && resolved.imports[0].name=="decom.math");
        { std::ofstream f(root / "app.docm"); f << "import decom.math as dm\n"; }
        auto aliased = resolver.resolve(root / "app.docm");
        assert(aliased.ok() && aliased.imports[0].alias=="dm");
        { std::ofstream f(root / "app.docm"); f << "import ../escape\n"; }
        auto invalid = resolver.resolve(root / "app.docm");
        assert(!invalid.ok());
        { std::ofstream f(root / "decom" / "math.docm"); f << "import app\n"; }
        auto cyclic = resolver.resolve(root / "app.docm");
        assert(!cyclic.ok());
        { std::ofstream f(root / "app.docm"); f << "import decom.missing\n"; }
        auto missing = resolver.resolve(root / "app.docm");
        assert(!missing.ok());
        fs::remove_all(root);
    }


    // DOCMONT 4.12: typed function declarations, return statements and array/call AST.
    {
        const std::string source = R"(!docmont[2]
application = {
 name = "FUNCTION_ARRAY_TEST"
 fn mean(values: Array) : Number {
   let count = 4
   return count
 }
 let data = [10, 20, 30, 40]
 let answer = mean(data)
 complete
})";
        auto parsed = parse_app(source);
        assert(parsed.functions.size() == 1);
        assert(parsed.functions[0].name == "mean");
        assert(parsed.functions[0].parameters.size() == 1);
        assert(parsed.functions[0].parameters[0].name == "values");
        assert(parsed.functions[0].parameters[0].type == "Array");
        assert(parsed.functions[0].return_type == "Number");
        assert(parsed.functions[0].body.size() == 2);
        assert(parsed.functions[0].body[1].kind == docmont::Statement::Kind::Return);
        assert(parsed.statements.size() == 2);
        assert(parsed.statements[0].expression->kind == docmont::ExprKind::ArrayLiteral);
        assert(parsed.statements[0].expression->elements.size() == 4);
        assert(parsed.statements[1].expression->kind == docmont::ExprKind::Call);
        assert(parsed.statements[1].expression->callee == "mean");
        assert(parsed.statements[1].expression->elements.size() == 1);
        auto contract = docmont::validate_function_contracts(parsed);
        assert(contract.empty());
        auto bad = parsed;
        bad.statements[1].expression->elements.clear();
        auto bad_contract = docmont::validate_function_contracts(bad);
        assert(!bad_contract.empty());
    }

    // DOCMONT 4.14 numerical runtime library: vectors, statistics, matrices and activations.
    {
        using namespace docmont::numerics;
        const Vector v{1.0, 2.0, 3.0, 4.0};
        assert(mean(v) == 2.5);
        assert(std::abs(variance(v) - 1.25) < 1e-12);
        assert(median(Vector{9, 1, 5, 3}) == 4.0);
        assert(dot(Vector{1,2,3}, Vector{4,5,6}) == 32.0);
        assert(std::abs(norm(Vector{3,4}) - 5.0) < 1e-12);
        assert(normalize(Vector{0,5})[1] == 1.0);
        assert((add(Vector{1,2},Vector{3,4}) == Vector{4,6}));
        assert((linspace(0,1,3) == Vector{0,0.5,1}));
        assert((moving_average(Vector{1,2,3,4},2) == Vector{1.5,2.5,3.5}));
        assert((convolve(Vector{1,2},Vector{1,1}) == Vector{1,3,2}));
        const Matrix product=matmul(Matrix{{1,2},{3,4}},Matrix{{5,6},{7,8}});
        assert(product[0][0]==19 && product[1][1]==50);
        assert(determinant(Matrix{{1,2},{3,4}})==-2.0);
        const auto probabilities=softmax(Vector{0,0});
        assert(std::abs(probabilities[0]-0.5)<1e-12);
        assert((relu(Vector{-1,0,2}) == Vector{0,0,2}));
        assert((differences(Vector{2,5,9}) == Vector{3,4}));
        bool rejected=false; try { (void)dot(Vector{1},Vector{1,2}); } catch(const std::invalid_argument&) { rejected=true; }
        assert(rejected);
    }

}
