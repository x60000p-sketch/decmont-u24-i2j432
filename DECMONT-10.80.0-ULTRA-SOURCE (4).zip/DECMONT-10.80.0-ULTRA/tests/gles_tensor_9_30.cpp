#include "docmont/gles_runtime.hpp"
#include <cassert>
#include <cmath>
#include <iostream>

int main() {
    const auto info = docmont::gpu::probe_gles();
    if (!info.available || !info.compute_supported) {
        std::cout << "GLES compute unavailable; tensor kernels skipped: " << info.detail << '\n';
        return 0;
    }
    using namespace docmont::gpu;
    auto add = compute_binary({1,2,3,4}, {5,6,7,8}, TensorBinaryOp::Add);
    if (!add.ok) { std::cerr << add.error << '\n'; return 1; }
    assert((add.values == std::vector<float>{6,8,10,12}));
    auto mul = compute_binary({1,-2,3,-4}, {2,3,-2,-1}, TensorBinaryOp::Multiply);
    if (!mul.ok) { std::cerr << mul.error << '\n'; return 2; }
    assert((mul.values == std::vector<float>{2,-6,-6,4}));
    auto div = compute_binary({2,6,8,10}, {2,3,4,5}, TensorBinaryOp::Divide);
    if (!div.ok) { std::cerr << div.error << '\n'; return 3; }
    assert((div.values == std::vector<float>{1,2,2,2}));
    auto softmax = compute_softmax({1,2,3, 1000,1001,1002}, 2, 3);
    if (!softmax.ok) { std::cerr << softmax.error << '\n'; return 4; }
    assert(softmax.values.size()==6);
    for (int row=0; row<2; ++row) {
        float sum=0; for(int col=0;col<3;++col) { auto v=softmax.values[row*3+col]; assert(std::isfinite(v)&&v>0); sum+=v; }
        assert(std::abs(sum-1.0f)<1e-4f);
    }
    assert(!compute_binary({1,2},{1},TensorBinaryOp::Add).ok);
    assert(!compute_softmax({1,2},0,2).ok);
    std::cout << "DOCMONT 9.30 GLES tensor kernels passed; renderer=" << info.renderer
              << "; hardware=" << (info.hardware_accelerated?"yes":"no") << '\n';
}
