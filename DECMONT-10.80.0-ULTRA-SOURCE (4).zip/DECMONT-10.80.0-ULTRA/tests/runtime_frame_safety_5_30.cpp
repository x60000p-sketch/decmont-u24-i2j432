#include "docmont/runtime.hpp"
#include <cassert>
using namespace docmont;
int main() {
    // A well-formed function consumes its own argument and returns exactly one value.
    ProgramIR good; good.name = "frame-good";
    good.code = {
        {OpCode::PushInt, {}, 41, 1},
        {OpCode::Call, "identity", 1, 1},
        {OpCode::Print, {}, 0, 1},
        {OpCode::Jump, {}, 8, 1},
        {OpCode::Function, "identity", 1, 2},
        {OpCode::Store, "value", 0, 2},
        {OpCode::Load, "value", 0, 3},
        {OpCode::Return, {}, 0, 3}
    };
    assert(execute(good) == 0);

    // Extra values left in a callee frame are rejected instead of silently discarded.
    ProgramIR extra; extra.name = "frame-extra";
    extra.code = {
        {OpCode::Call, "bad", 0, 1},
        {OpCode::Print, {}, 0, 1},
        {OpCode::Jump, {}, 8, 1},
        {OpCode::Function, "bad", 0, 2},
        {OpCode::PushInt, {}, 1, 3},
        {OpCode::PushInt, {}, 2, 3},
        {OpCode::Return, {}, 0, 3}
    };
    assert(execute(extra) != 0);

    // A malformed nested call cannot use values below the current frame's base.
    ProgramIR crossing; crossing.name = "frame-crossing";
    crossing.code = {
        {OpCode::PushInt, {}, 77, 1},
        {OpCode::PushInt, {}, 1, 1},
        {OpCode::Call, "outer", 1, 1},
        {OpCode::Print, {}, 0, 1},
        {OpCode::Jump, {}, 10, 1},
        {OpCode::Function, "outer", 1, 2},
        {OpCode::Store, "arg", 0, 2},
        {OpCode::Call, "zero", 1, 3},
        {OpCode::Return, {}, 0, 3},
        {OpCode::Function, "zero", 0, 4},
        {OpCode::PushInt, {}, 0, 4},
        {OpCode::Return, {}, 0, 4}
    };
    assert(execute(crossing) != 0);
}
