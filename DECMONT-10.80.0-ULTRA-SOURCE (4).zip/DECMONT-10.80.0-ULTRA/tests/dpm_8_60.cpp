#include "docmont/package_manager.hpp"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
int main(){
    const auto root=std::filesystem::temp_directory_path()/"docmont-dpm-8-60-test";std::filesystem::remove_all(root);std::filesystem::create_directories(root);
    const auto manifest=root/"docmont.dpm";
    {std::ofstream out(manifest);out<<"[package]\nname = \"demo_app\"\nversion = \"1.2.3\"\nedition = \"2026\"\n\n[dependencies]\nmath_core = \"2.0.1\"\ntext_util = \"0.4.2\"\n";}
    auto loaded=docmont::dpm::load_manifest(manifest);assert(loaded.ok&&loaded.manifest.dependencies.size()==2);
    auto lock1=docmont::dpm::render_lockfile(loaded.manifest,loaded.source_fingerprint);auto lock2=docmont::dpm::render_lockfile(loaded.manifest,loaded.source_fingerprint);assert(lock1==lock2);
    std::string error;const auto lock_path=root/"docmont.lock";assert(docmont::dpm::write_lockfile(lock_path,loaded.manifest,loaded.source_fingerprint,error));
    std::ifstream in(lock_path);std::string actual((std::istreambuf_iterator<char>(in)),{});assert(actual==lock1&&actual.find("math_core")!=std::string::npos);
    {std::ofstream out(manifest);out<<"[package]\nname = \"bad name\"\nversion = \"1.2\"\nedition = \"2026\"\n";}
    auto invalid=docmont::dpm::load_manifest(manifest);assert(!invalid.ok&&!invalid.diagnostics.empty());
    std::filesystem::remove_all(root);std::cout<<"DOCMONT 8.60.0 DPM tests passed\n";
}
