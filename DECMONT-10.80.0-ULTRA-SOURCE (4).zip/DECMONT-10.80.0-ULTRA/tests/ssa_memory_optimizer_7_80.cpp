#include "docmont/optimizer.hpp"
#include "docmont/ssa.hpp"
#include "docmont/bytecode.hpp"
#include "docmont/runtime.hpp"
#include <algorithm>
#include <cassert>
#include <iostream>
#include <sstream>
using namespace docmont;

static std::size_t count_op(const ProgramIR& ir, OpCode op) {
    return static_cast<std::size_t>(std::count_if(ir.code.begin(), ir.code.end(),
        [&](const Instruction& instruction) { return instruction.op == op; }));
}

static std::string run_vm(const ProgramIR& ir) {
    const auto encoded = encode_bytecode(ir);
    assert(encoded.ok);
    std::ostringstream output;
    auto* previous = std::cout.rdbuf(output.rdbuf());
    const auto status = execute_bytecode(encoded.bytes);
    std::cout.rdbuf(previous);
    assert(status == 0);
    return output.str();
}

static ProgramIR object_read_program(bool same_object_write, bool same_field_write) {
    ProgramIR ir; ir.name = "memory-read-cse"; ir.target = "x86_64";
    ir.code = {
        {OpCode::NewObject, {}, 0, 1},
        {OpCode::PushInt, {}, 7, 1}, {OpCode::ObjectSet, "x", 0, 1},
        {OpCode::Store, "a", 0, 1}, {OpCode::NewObject, {}, 0, 1},
        {OpCode::Store, "b", 0, 1},
        {OpCode::Load, same_object_write ? "a" : "b", 0, 3},
        {OpCode::PushInt, {}, 9, 3},
        {OpCode::ObjectSet, same_field_write ? "x" : "y", 0, 3}
    };
    ir.code.insert(ir.code.begin() + 7, {{OpCode::Load, "a", 0, 2}, {OpCode::ObjectGet, "x", 0, 2}, {OpCode::Print, {}, 0, 2}});
    ir.code.insert(ir.code.end(), {{OpCode::Load, "a", 0, 4}, {OpCode::ObjectGet, "x", 0, 4}, {OpCode::Print, {}, 0, 4}});
    return ir;
}

int main() {
    // Variable SSA carries a known allocation through Store -> Load.
    ProgramIR repeated;
    repeated.code = {
        {OpCode::NewObject, {}, 0, 1},
        {OpCode::PushInt, {}, 5, 1}, {OpCode::ObjectSet, "value", 0, 1},
        {OpCode::Store, "item", 0, 1},
        {OpCode::Load, "item", 0, 2}, {OpCode::ObjectGet, "value", 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Load, "item", 0, 3}, {OpCode::ObjectGet, "value", 0, 3}, {OpCode::Print, {}, 0, 3}
    };
    const auto before = build_ssa(repeated);
    assert(verify_ssa(before, repeated).ok);
    const auto load_use = std::find_if(before.value_uses.begin(), before.value_uses.end(),
        [](const SSAValueUse& use) { return use.instruction == 5 && use.operand_index == 0; });
    assert(load_use != before.value_uses.end());
    const auto base_points = std::find_if(before.points_to_sets.begin(), before.points_to_sets.end(),
        [&](const SSAPointsToSet& points) { return points.value == load_use->value; });
    assert(base_points != before.points_to_sets.end());
    assert(!base_points->unknown && base_points->allocation_sites == std::vector<std::size_t>{0});
    const auto expected_output = run_vm(repeated);
    const auto stats = optimize_ir(repeated);
    assert(stats.ssa_memory_load_eliminations == 1);
    assert(run_vm(repeated) == expected_output);
    assert(count_op(repeated, OpCode::ObjectGet) == 1);
    assert(encode_bytecode(repeated).ok);

    // ObjectHas reads are forwarded too, but a write to that exact field kills the fact.
    ProgramIR object_has;
    object_has.code = {
        {OpCode::NewObject, {}, 0, 1}, {OpCode::PushInt, {}, 3, 1},
        {OpCode::ObjectSet, "present", 0, 1}, {OpCode::Store, "record", 0, 1},
        {OpCode::Load, "record", 0, 2}, {OpCode::ObjectHas, "present", 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Load, "record", 0, 3}, {OpCode::ObjectHas, "present", 0, 3}, {OpCode::Print, {}, 0, 3}
    };
    const auto has_output = run_vm(object_has);
    assert(optimize_ir(object_has).ssa_memory_load_eliminations == 1);
    assert(count_op(object_has, OpCode::ObjectHas) == 1);
    assert(run_vm(object_has) == has_output);

    // Writes to a distinct allocation do not invalidate the cached field.
    auto disjoint = object_read_program(false, true);
    const auto disjoint_stats = optimize_ir(disjoint);
    assert(disjoint_stats.ssa_memory_load_eliminations == 1);
    assert(count_op(disjoint, OpCode::ObjectGet) == 1);

    // Same object + same field is a real invalidation.
    auto same_field = object_read_program(true, true);
    const auto same_field_stats = optimize_ir(same_field);
    assert(same_field_stats.ssa_memory_load_eliminations == 0);
    assert(count_op(same_field, OpCode::ObjectGet) == 2);

    // A different field on the same object is independent for named properties.
    auto other_field = object_read_program(true, false);
    const auto other_field_stats = optimize_ir(other_field);
    assert(other_field_stats.ssa_memory_load_eliminations == 1);

    // Unknown-base writes flush all memory facts.
    ProgramIR unknown_write;
    unknown_write.code = {
        {OpCode::NewObject, {}, 0, 1}, {OpCode::Store, "item", 0, 1},
        {OpCode::Load, "item", 0, 2}, {OpCode::ObjectGet, "x", 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Load, "external", 0, 3}, {OpCode::PushInt, {}, 11, 3}, {OpCode::ObjectSet, "x", 0, 3},
        {OpCode::Load, "item", 0, 4}, {OpCode::ObjectGet, "x", 0, 4}, {OpCode::Print, {}, 0, 4}
    };
    assert(optimize_ir(unknown_write).ssa_memory_load_eliminations == 0);

    // ArrayLength is preserved across a write to a disjoint array.
    ProgramIR arrays;
    arrays.code = {
        {OpCode::PushInt, {}, 1, 1}, {OpCode::MakeArray, {}, 1, 1}, {OpCode::Store, "a", 0, 1},
        {OpCode::PushInt, {}, 2, 1}, {OpCode::MakeArray, {}, 1, 1}, {OpCode::Store, "b", 0, 1},
        {OpCode::Load, "a", 0, 2}, {OpCode::ArrayLength, {}, 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Load, "b", 0, 3}, {OpCode::PushInt, {}, 8, 3}, {OpCode::PushInt, {}, 0, 3},
        {OpCode::ArraySet, {}, 0, 3},
        {OpCode::Load, "a", 0, 4}, {OpCode::ArrayLength, {}, 0, 4}, {OpCode::Print, {}, 0, 4}
    };
    const auto array_stats = optimize_ir(arrays);
    assert(array_stats.ssa_memory_load_eliminations == 1);
    assert(count_op(arrays, OpCode::ArrayLength) == 1);
    assert(encode_bytecode(arrays).ok);

    // Constant-index ArrayGet reads are forwarded across unrelated pure code.
    ProgramIR array_get;
    array_get.code = {
        {OpCode::PushInt, {}, 13, 1}, {OpCode::MakeArray, {}, 1, 1}, {OpCode::Store, "items", 0, 1},
        {OpCode::Load, "items", 0, 2}, {OpCode::PushInt, {}, 0, 2}, {OpCode::ArrayGet, {}, 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Load, "items", 0, 3}, {OpCode::PushInt, {}, 0, 3}, {OpCode::ArrayGet, {}, 0, 3}, {OpCode::Print, {}, 0, 3}
    };
    const auto array_get_output = run_vm(array_get);
    const auto array_get_stats = optimize_ir(array_get);
    assert(array_get_stats.ssa_memory_load_eliminations == 1);
    assert(count_op(array_get, OpCode::ArrayGet) == 1);
    assert(run_vm(array_get) == array_get_output);

    // A write to the same array invalidates both element and length observations.
    ProgramIR array_mutation;
    array_mutation.code = {
        {OpCode::PushInt, {}, 13, 1}, {OpCode::MakeArray, {}, 1, 1}, {OpCode::Store, "items", 0, 1},
        {OpCode::Load, "items", 0, 2}, {OpCode::PushInt, {}, 0, 2}, {OpCode::ArrayGet, {}, 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Load, "items", 0, 3}, {OpCode::PushInt, {}, 0, 3}, {OpCode::PushInt, {}, 21, 3}, {OpCode::ArraySet, {}, 0, 3},
        {OpCode::Load, "items", 0, 4}, {OpCode::PushInt, {}, 0, 4}, {OpCode::ArrayGet, {}, 0, 4}, {OpCode::Print, {}, 0, 4}
    };
    const auto mutation_output = run_vm(array_mutation);
    assert(optimize_ir(array_mutation).ssa_memory_load_eliminations == 0);
    assert(count_op(array_mutation, OpCode::ArrayGet) == 2);
    assert(run_vm(array_mutation) == mutation_output);

    ProgramIR array_push;
    array_push.code = {
        {OpCode::PushInt, {}, 1, 1}, {OpCode::MakeArray, {}, 1, 1}, {OpCode::Store, "items", 0, 1},
        {OpCode::Load, "items", 0, 2}, {OpCode::ArrayLength, {}, 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Load, "items", 0, 3}, {OpCode::PushInt, {}, 2, 3}, {OpCode::ArrayPush, {}, 0, 3}, {OpCode::Print, {}, 0, 3},
        {OpCode::Load, "items", 0, 4}, {OpCode::ArrayLength, {}, 0, 4}, {OpCode::Print, {}, 0, 4}
    };
    assert(optimize_ir(array_push).ssa_memory_load_eliminations == 0);
    assert(count_op(array_push, OpCode::ArrayLength) == 2);

    // A callee's parameter write effect invalidates the caller's same object.
    ProgramIR called;
    called.code = {
        {OpCode::NewObject, {}, 0, 1}, {OpCode::Store, "item", 0, 1},
        {OpCode::Load, "item", 0, 2}, {OpCode::ObjectGet, "x", 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Load, "item", 0, 3}, {OpCode::Call, "mutate", 1, 3}, {OpCode::Store, "ignored", 0, 3},
        {OpCode::Load, "item", 0, 4}, {OpCode::ObjectGet, "x", 0, 4}, {OpCode::Print, {}, 0, 4},
        {OpCode::PushInt, {}, 0, 5}, // root CFG placeholder for function argument stack
        {OpCode::Function, "mutate", 1, 6},
        {OpCode::PushInt, {}, 99, 6}, {OpCode::ObjectSet, "x", 0, 6},
        {OpCode::Return, {}, 0, 6}
    };
    const auto call_stats = optimize_ir(called);
    assert(call_stats.ssa_memory_load_eliminations == 0);
    assert(count_op(called, OpCode::ObjectGet) == 2);
    assert(encode_bytecode(called).ok);

    std::cout << "DOCMONT 7.80.0 alias-aware memory read optimization tests passed\n";
}
