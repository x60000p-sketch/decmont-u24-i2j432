#include "docmont/direct_llvm_backend.hpp"
#include "docmont/lexer.hpp"
#include "docmont/parser.hpp"
#include "docmont/semantic.hpp"
#include "docmont/function_semantics.hpp"
#include "docmont/source_frontend.hpp"
#include <cassert>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sys/wait.h>

int main() {
    using namespace docmont;
    const std::string source=R"(!docmont[3]
application = {
 name = "direct_mir_native"
 fn main(): Int {
   let a = 20
   let b = 22
   let c = a + b
   return c
 }
 complete
})";
    Lexer lexer(source); auto lexed=lexer.scan(); assert(lexed.diagnostics.empty());
    Parser parser(std::move(lexed.tokens)); auto parsed=parser.parse(); assert(parsed.diagnostics.empty());
    assert(validate(parsed.app).empty()); assert(validate_function_contracts(parsed.app).empty());
    auto lowered=frontend::lower_to_hir_mir(parsed.app); assert(lowered.diagnostics.empty());
    auto direct=core::emit_direct_llvm_ir(lowered.mir,lowered.hir,lowered.types,"x86_64-unknown-linux-gnu");
    assert(direct.ok); assert(direct.ir.find("target triple = \"x86_64-unknown-linux-gnu\"")!=std::string::npos);
    assert(direct.ir.find("add i64")!=std::string::npos);
    const auto root=std::filesystem::temp_directory_path()/"docmont-native-mir-8-70";
    std::filesystem::remove_all(root); std::filesystem::create_directories(root);
    const auto x86=root/"main-x86.o";
    auto x86_result=core::compile_direct_llvm_object(lowered.mir,lowered.hir,lowered.types,x86,"x86_64-unknown-linux-gnu");
    assert(x86_result.ok&&std::filesystem::file_size(x86)>0);
    const auto executable=root/"native-main";
    const std::string link="clang "+x86.string()+" -o "+executable.string(); assert(std::system(link.c_str())==0);
    const int status=std::system(executable.c_str()); assert(status!=-1&&WIFEXITED(status)&&WEXITSTATUS(status)==42);
    const auto arm=root/"main-arm64.o";
    auto arm_result=core::compile_direct_llvm_object(lowered.mir,lowered.hir,lowered.types,arm,"aarch64-unknown-linux-gnu");
    assert(arm_result.ok&&std::filesystem::file_size(arm)>0);
    const auto wasm=root/"main-wasm.o";
    auto wasm_result=core::compile_direct_llvm_object(lowered.mir,lowered.hir,lowered.types,wasm,"wasm32-unknown-unknown");
    assert(wasm_result.ok&&std::filesystem::file_size(wasm)>0);
    const auto riscv=root/"main-riscv.o";
    auto riscv_result=core::compile_direct_llvm_object(lowered.mir,lowered.hir,lowered.types,riscv,"riscv64-unknown-elf");
    assert(riscv_result.ok&&std::filesystem::file_size(riscv)>0);
    const std::string unsupported=R"(!docmont[3] application = { name = "unsupported" fn main() { output = "not-native-integer" } complete })";
    Lexer bad_lexer(unsupported);auto bad_tokens=bad_lexer.scan();Parser bad_parser(std::move(bad_tokens.tokens));auto bad_app=bad_parser.parse();assert(bad_app.diagnostics.empty());
    auto bad_lowered=frontend::lower_to_hir_mir(bad_app.app);assert(bad_lowered.diagnostics.empty());
    auto rejected=core::emit_direct_llvm_ir(bad_lowered.mir,bad_lowered.hir,bad_lowered.types,"x86_64-unknown-linux-gnu");
    assert(!rejected.ok);
    std::filesystem::remove_all(root);
    std::cout<<"DOCMONT 8.70.0 direct MIR-to-LLVM tests passed (x86-64 run, AArch64/WASM/RISC-V object generation)\n";
}
