#include "docmont/ssa.hpp"
#include <algorithm>
#include <cassert>
#include <iostream>
using namespace docmont;

static const SSAPointsToSet& points_for(const SSAProgram& ssa, std::size_t value) {
    const auto it = std::find_if(ssa.points_to_sets.begin(), ssa.points_to_sets.end(),
        [&](const SSAPointsToSet& p) { return p.value == value; });
    assert(it != ssa.points_to_sets.end());
    return *it;
}

int main() {
    // A statically named object field carries the assigned allocation site's
    // provenance through ObjectSet -> ObjectGet.
    ProgramIR object;
    object.code = {
        {OpCode::NewObject, {}, 0, 1},          // site 0: owner
        {OpCode::Dup, {}, 0, 1},
        {OpCode::NewObject, {}, 0, 1},          // site 2: child
        {OpCode::ObjectSet, "child", 0, 1},
        {OpCode::ObjectGet, "child", 0, 1},
        {OpCode::Return, {}, 0, 1}
    };
    const auto ssa = build_ssa(object);
    const auto checked = verify_ssa(ssa, object);
    if (!checked.ok) {
        for (const auto& error : checked.errors) std::cerr << error << '\n';
        return 2;
    }
    assert(ssa.field_points_to.size() == 1);
    assert(ssa.field_points_to[0].allocation_site == 0);
    assert(ssa.field_points_to[0].field == "child");
    assert(ssa.field_points_to[0].allocation_sites == std::vector<std::size_t>{2});
    const auto get = std::find_if(ssa.value_definitions.begin(), ssa.value_definitions.end(),
        [](const SSAValueDefinition& d) { return d.op == OpCode::ObjectGet; });
    assert(get != ssa.value_definitions.end());
    assert(points_for(ssa, get->id).allocation_sites == std::vector<std::size_t>{2});
    assert(!points_for(ssa, get->id).unknown);
    assert(dump_ssa(ssa).find("Field-sensitive points-to: 1 field slots") != std::string::npos);

    // A function returning its first argument exports a symbolic parameter
    // summary; a direct call substitutes the caller's concrete points-to set.
    ProgramIR calls;
    calls.code = {
        {OpCode::NewObject, {}, 0, 1},
        {OpCode::Call, "identity", 1, 1},
        {OpCode::Return, {}, 0, 1},
        {OpCode::Function, "identity", 1, 1},
        {OpCode::Return, {}, 0, 1}
    };
    const auto call_ssa = build_ssa(calls);
    const auto call_checked = verify_ssa(call_ssa, calls);
    if (!call_checked.ok) {
        for (const auto& error : call_checked.errors) std::cerr << error << '\n';
        return 3;
    }
    assert(call_ssa.functions.size() == 1);
    const auto& identity = call_ssa.functions.front();
    assert(identity.return_parameter_indices == std::vector<std::size_t>{0});
    assert(!identity.return_unknown);
    const auto call = std::find_if(call_ssa.value_definitions.begin(), call_ssa.value_definitions.end(),
        [](const SSAValueDefinition& d) { return d.op == OpCode::Call; });
    assert(call != call_ssa.value_definitions.end());
    const auto& returned = points_for(call_ssa, call->id);
    assert(returned.allocation_sites == std::vector<std::size_t>{0});
    assert(!returned.unknown);

    // A factory returning a locally allocated object exports a stable source
    // allocation-site identity into the direct caller's points-to set.
    ProgramIR factory;
    factory.code = {
        {OpCode::Call, "make_item", 0, 1},
        {OpCode::Return, {}, 0, 1},
        {OpCode::Function, "make_item", 0, 1},
        {OpCode::NewObject, {}, 0, 1},
        {OpCode::Return, {}, 0, 1}
    };
    const auto factory_ssa = build_ssa(factory);
    const auto factory_checked = verify_ssa(factory_ssa, factory);
    if (!factory_checked.ok) {
        for (const auto& error : factory_checked.errors) std::cerr << error << '\n';
        return 4;
    }
    assert(factory_ssa.functions.size() == 1);
    assert(factory_ssa.functions.front().return_allocation_sites == std::vector<std::size_t>{3});
    const auto factory_call = std::find_if(factory_ssa.value_definitions.begin(), factory_ssa.value_definitions.end(),
        [](const SSAValueDefinition& d) { return d.op == OpCode::Call; });
    assert(factory_call != factory_ssa.value_definitions.end());
    assert(points_for(factory_ssa, factory_call->id).allocation_sites == std::vector<std::size_t>{3});
    assert(!points_for(factory_ssa, factory_call->id).unknown);

    auto corrupted = ssa;
    corrupted.field_points_to.front().allocation_site = 999999;
    assert(!verify_ssa(corrupted, object).ok);
    std::cout << "DOCMONT 7.60.0 field-sensitive and interprocedural points-to tests passed\n";
}
