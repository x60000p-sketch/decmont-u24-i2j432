#include "docmont/ssa.hpp"
#include <algorithm>
#include <cassert>
#include <iostream>
#include <memory>
using namespace docmont;

int main() {
    ProgramIR p;
    p.code = {
        {OpCode::Jump, {}, 11, 1},
        {OpCode::Function, "heap_touch", 0, 2},
        {OpCode::NewObject, {}, 0, 2},
        {OpCode::Load, "items", 0, 2},
        {OpCode::ArrayGet, {}, 0, 2},
        {OpCode::ObjectHas, "name", 0, 2},
        {OpCode::Return, {}, 0, 2},
        {OpCode::Function, "cell_touch", 0, 3},
        {OpCode::LoadCell, "captured", 0, 3},
        {OpCode::Return, {}, 0, 3},
        {OpCode::Function, "caller", 0, 4},
        {OpCode::Call, "heap_touch", 0, 4},
        {OpCode::Call, "cell_touch", 0, 4},
        {OpCode::Return, {}, 0, 4},
        {OpCode::Function, "dynamic", 0, 5},
        {OpCode::Load, "fn", 0, 5},
        {OpCode::CallIndirect, {}, 0, 5},
        {OpCode::Return, {}, 0, 5}
    };
    p.code[0].integer = static_cast<std::int64_t>(p.code.size());
    const auto ssa = build_ssa(p);
    const auto verified = verify_ssa(ssa, p);
    if (!verified.ok) { for (const auto& e : verified.errors) std::cerr << e << '\n'; return 2; }

    const auto find_fn = [&](const char* name) -> const SSAFunctionRegion& {
        const auto it = std::find_if(ssa.functions.begin(), ssa.functions.end(),
            [&](const SSAFunctionRegion& fn) { return fn.name == name; });
        assert(it != ssa.functions.end()); return *it;
    };
    const auto& heap = find_fn("heap_touch");
    const auto& cell = find_fn("cell_touch");
    const auto& caller = find_fn("caller");
    const auto& dynamic = find_fn("dynamic");
    assert((heap.alias_read_mask & 0x1) != 0);
    assert((heap.alias_write_mask & 0x1) != 0);
    assert((heap.alias_read_mask & 0x2) == 0);
    assert((cell.alias_read_mask & 0x2) != 0);
    assert((cell.alias_read_mask & 0x1) == 0);
    assert((caller.alias_read_mask & 0x3) == 0x3);
    assert((caller.alias_write_mask & 0x1) != 0);
    assert(dynamic.alias_read_mask == 0x7 && dynamic.alias_write_mask == 0x7);
    assert(dynamic.may_read_memory && dynamic.may_write_memory && dynamic.has_unknown_effects);
    assert(alias_regions_may_alias(SSAAliasRegion::HeapAggregate, SSAAliasRegion::HeapAggregate));
    assert(!alias_regions_may_alias(SSAAliasRegion::HeapAggregate, SSAAliasRegion::ClosureCell));
    assert(alias_regions_may_alias(SSAAliasRegion::Unknown, SSAAliasRegion::ClosureCell));

    bool saw_heap=false, saw_cell=false, saw_unknown=false;
    for (const auto& a : heap.analysis->alias_accesses) saw_heap |= a.region==SSAAliasRegion::HeapAggregate;
    for (const auto& a : cell.analysis->alias_accesses) saw_cell |= a.region==SSAAliasRegion::ClosureCell;
    for (const auto& a : dynamic.analysis->alias_accesses) saw_unknown |= a.region==SSAAliasRegion::Unknown && a.may_alias_mask==0x7;
    assert(saw_heap && saw_cell && saw_unknown);
    const auto dump = dump_ssa(ssa);
    assert(dump.find("Alias accesses:") != std::string::npos);
    assert(dump.find("alias_read_mask=0x") != std::string::npos);
    auto corrupted = ssa;
    assert(corrupted.functions.front().analysis);
    corrupted.functions.front().analysis = std::make_shared<SSAProgram>(*corrupted.functions.front().analysis);
    assert(!corrupted.functions.front().analysis->alias_accesses.empty());
    corrupted.functions.front().analysis->alias_accesses.front().may_alias_mask = 0x7;
    assert(!verify_ssa(corrupted, p).ok);
    std::cout << "DOCMONT 7.40.0 alias analysis tests passed\n";
}
