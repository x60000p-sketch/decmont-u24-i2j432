set(src [=[
!docmont[3]
application = {
 name = default_parameter_test
 fn greet(name: String = "world", punctuation: String = "!") : String {
   return name + punctuation
 }
 fn add(base: Int, amount: Int = 5) : Int {
   return base + amount
 }
 fn scaled(base: Int, factor: Int = base * 2) : Int {
   return base * factor
 }
 output = greet()
 output = greet("Ada")
 output = greet("DOCMONT", " 4.50")
 output = add(10)
 output = add(10, 7)
 output = scaled(6)
 complete
}
]=])
file(WRITE "${CMAKE_CURRENT_BINARY_DIR}/language_4_50.docm" "${src}")
execute_process(COMMAND "${DOCMONT}" run "${CMAKE_CURRENT_BINARY_DIR}/language_4_50.docm" RESULT_VARIABLE rc OUTPUT_VARIABLE out ERROR_VARIABLE err)
if(NOT rc EQUAL 0)
 message(FATAL_ERROR "default-parameter program failed: ${err}")
endif()
set(expected "world!\nAda!\nDOCMONT 4.50\n15\n17\n72\n")
if(NOT out STREQUAL expected)
 message(FATAL_ERROR "unexpected output. Expected=[${expected}] Actual=[${out}]")
endif()
