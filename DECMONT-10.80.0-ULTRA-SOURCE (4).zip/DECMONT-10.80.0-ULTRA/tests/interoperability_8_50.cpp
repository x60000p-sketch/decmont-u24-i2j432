#include "docmont/interoperability.hpp"

#include <cassert>
#include <iostream>
#include <string>

int main() {
    using namespace docmont::interop;
    const std::string manifest = R"(DOCMONT_JAVA 1
package io.docmont.demo
class MathBridge
library docmont_native
function add_i64 symbol=docmont_add_i64 (i64,i64) -> i64
function is_even symbol=docmont_is_even (i64) -> bool
function greet symbol=docmont_greet (utf8) -> utf8
function scale symbol=docmont_scale (f64,f64) -> f64
function reset symbol=docmont_reset () -> void
)";
    JavaArtifacts java;
    auto java_result = generate_java_artifacts(manifest, java);
    assert(java_result.ok);
    assert(java.java_source.find("public static native long add_i64(long p0, long p1)") != std::string::npos);
    assert(java.java_source.find("System.loadLibrary(\"docmont_native\")") != std::string::npos);
    assert(java.abi_header.find("docmont_add_i64(int64_t a0, int64_t a1)") != std::string::npos);
    assert(java.jni_source.find("Java_io_docmont_demo_MathBridge_add_1i64") != std::string::npos);
    assert(java.jni_source.find("GetStringUTFChars") != std::string::npos);
    assert(java.jni_source.find("JNI_TRUE") != std::string::npos);

    JavaArtifacts invalid_java;
    auto bad_manifest = generate_java_artifacts("DOCMONT_JAVA 1\npackage java.bad\nclass Bad\nlibrary x\nfunction call symbol=bad (void) -> i64\n", invalid_java);
    assert(!bad_manifest.ok);

    const std::string assembly = R"(DOCMONT_ASM 1
target x86_64-sysv
function add_i64(i64,i64) -> i64
    mov rax, rdi
    add rax, rsi
    ret
end
function multiply_i64(i64,i64) -> i64
    mov rax, rdi
    imul rax, rsi
    ret
end
)";
    AssemblyModule module;
    auto asm_result = parse_assembly(assembly, module);
    assert(asm_result.ok);
    assert(module.functions.size() == 2);
    std::string gas;
    auto emit = emit_gas_x86_64(module, gas);
    assert(emit.ok);
    assert(gas.find(".intel_syntax noprefix") != std::string::npos);
    assert(gas.find("add rax, rsi") != std::string::npos);
    assert(gas.find("imul rax, rsi") != std::string::npos);

    AssemblyModule rejected;
    auto memory_access = parse_assembly("DOCMONT_ASM 1\ntarget x86_64-sysv\nfunction unsafe(i64) -> i64\nmov rax, [rdi]\nret\nend\n", rejected);
    assert(!memory_access.ok);
    auto directive = parse_assembly("DOCMONT_ASM 1\ntarget x86_64-sysv\n.section .text\n", rejected);
    assert(!directive.ok);
    auto missing_ret = parse_assembly("DOCMONT_ASM 1\ntarget x86_64-sysv\nfunction broken(i64) -> i64\nmov rax, rdi\nend\n", rejected);
    assert(!missing_ret.ok);
    auto oversized_immediate = parse_assembly("DOCMONT_ASM 1\ntarget x86_64-sysv\nfunction too_big(i64) -> i64\nadd rax, 2147483648\nret\nend\n", rejected);
    assert(!oversized_immediate.ok);

    std::cout << "DOCMONT 8.50.0 Java/JNI and x86_64 assembly adapter tests passed\n";
}
