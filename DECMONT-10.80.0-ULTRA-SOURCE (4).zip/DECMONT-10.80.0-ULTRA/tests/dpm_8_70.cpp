#include "docmont/package_manager.hpp"
#include <cassert>
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <iterator>
static void write(const std::filesystem::path& path,const std::string& text){std::filesystem::create_directories(path.parent_path());std::ofstream out(path);out<<text;}
int main(){
 using namespace docmont::dpm; const auto root=std::filesystem::temp_directory_path()/"docmont-dpm-8-70-test";std::filesystem::remove_all(root);
 write(root/"docmont.dpm","[package]\nname = \"application\"\nversion = \"1.0.0\"\nedition = \"2026\"\n[dependencies]\ncore = { path = \"vendor/core\" }\n");
 write(root/"vendor/core/docmont.dpm","[package]\nname = \"core\"\nversion = \"2.1.0\"\nedition = \"2026\"\n[dependencies]\nformatter = { path = \"../formatter\" }\n");
 write(root/"vendor/formatter/docmont.dpm","[package]\nname = \"formatter\"\nversion = \"0.3.0\"\nedition = \"2026\"\n");
 auto loaded=load_manifest(root/"docmont.dpm");assert(loaded.ok&&loaded.manifest.dependencies.size()==1&&loaded.manifest.dependencies[0].path=="vendor/core");
 auto resolved=resolve_local_dependencies(root/"docmont.dpm");assert(resolved.ok&&resolved.packages.size()==2);assert(resolved.packages[0].name=="core");assert(resolved.packages[1].name=="formatter");
 const auto lock=render_resolved_lockfile(loaded.manifest,loaded.source_fingerprint,resolved.packages);assert(lock.find("lock-version = 2")!=std::string::npos);assert(lock.find("formatter")!=std::string::npos);
 write(root/"vendor/formatter/docmont.dpm","[package]\nname = \"formatter\"\nversion = \"0.3.0\"\nedition = \"2026\"\n[dependencies]\ncore = { path = \"../core\" }\n");
 auto cyclic=resolve_local_dependencies(root/"docmont.dpm");assert(!cyclic.ok);assert(std::any_of(cyclic.diagnostics.begin(),cyclic.diagnostics.end(),[](const auto& d){return d.code=="DPM025";}));
 std::filesystem::remove_all(root);std::cout<<"DOCMONT 8.70.0 transitive local DPM tests passed\n";
}
