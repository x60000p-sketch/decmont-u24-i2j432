#include "docmont/console_sdk.hpp"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
#if !defined(_WIN32)
#include <sys/stat.h>
#endif
int main(){namespace fs=std::filesystem;auto root=fs::temp_directory_path()/"docmont-console-sdk-test";fs::remove_all(root);fs::create_directories(root/"include");fs::create_directories(root/"bin");std::ofstream(root/"toolchain.cmake")<<"# test toolchain\n";std::ofstream(root/"bin/compiler")<<"#!/bin/sh\nexit 0\n";
#if !defined(_WIN32)
chmod((root/"bin/compiler").c_str(),0755);
#endif
std::ofstream m(root/"sdk.dcsdk");m<<"platform=playstation5\nsdk_root="<<root.string()<<"\nsdk_version=mock-test\ncompiler=bin/compiler\ncmake_toolchain=toolchain.cmake\ninclude_dir=include\nlicense_acknowledged=true\n";m.close();auto ok=docmont::platform::probe_console_sdk(docmont::platform::ConsolePlatform::PlayStation5,(root/"sdk.dcsdk").string());assert(ok.adapter_configured&&!ok.hardware_validated);auto bad=docmont::platform::probe_console_sdk(docmont::platform::ConsolePlatform::XboxSeries,(root/"sdk.dcsdk").string());assert(!bad.adapter_configured);fs::remove_all(root);std::cout<<"DOCMONT official console SDK manifest validation passed (no console certification claimed)\n";}
