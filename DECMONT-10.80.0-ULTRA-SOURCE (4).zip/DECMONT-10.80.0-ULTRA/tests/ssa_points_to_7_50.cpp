#include "docmont/ssa.hpp"
#include <algorithm>
#include <cassert>
#include <iostream>
using namespace docmont;

int main() {
    ProgramIR p;
    p.code = {
        {OpCode::PushInt, {}, 10, 1},
        {OpCode::MakeArray, {}, 1, 1},       // allocation site 1
        {OpCode::Dup, {}, 0, 1},
        {OpCode::PushInt, {}, 20, 1},
        {OpCode::ArrayPush, {}, 0, 1},       // base is the duplicated array
        {OpCode::PushInt, {}, 30, 1},
        {OpCode::NewObject, {}, 0, 1},       // allocation site 6
        {OpCode::Return, {}, 0, 1}
    };
    const auto ssa = build_ssa(p);
    const auto checked = verify_ssa(ssa, p);
    if (!checked.ok) {
        for (const auto& error : checked.errors) std::cerr << error << '\n';
        return 2;
    }
    assert(ssa.allocation_sites.size() == 2);
    assert(ssa.points_to_sets.size() == ssa.value_definitions.size());
    const auto array_value = std::find_if(ssa.value_definitions.begin(), ssa.value_definitions.end(),
        [](const SSAValueDefinition& d) { return d.instruction == 1; });
    const auto object_value = std::find_if(ssa.value_definitions.begin(), ssa.value_definitions.end(),
        [](const SSAValueDefinition& d) { return d.instruction == 6; });
    assert(array_value != ssa.value_definitions.end() && object_value != ssa.value_definitions.end());
    const auto points_for = [&](std::size_t value) -> const SSAPointsToSet& {
        const auto it = std::find_if(ssa.points_to_sets.begin(), ssa.points_to_sets.end(),
            [&](const SSAPointsToSet& x) { return x.value == value; });
        assert(it != ssa.points_to_sets.end()); return *it;
    };
    const auto& array_points = points_for(array_value->id);
    const auto& object_points = points_for(object_value->id);
    assert(array_points.allocation_sites == std::vector<std::size_t>{1});
    assert(!array_points.unknown);
    assert(object_points.allocation_sites == std::vector<std::size_t>{6});
    assert(!points_to_sets_may_alias(array_points, object_points));

    const auto access = std::find_if(ssa.alias_accesses.begin(), ssa.alias_accesses.end(),
        [](const SSAAliasAccess& a) { return a.instruction == 4; });
    assert(access != ssa.alias_accesses.end());
    assert(access->points_to_sites == std::vector<std::size_t>{1});
    assert(!access->points_to_unknown && access->must_alias_singleton);

    SSAPointsToSet unknown; unknown.unknown = true;
    assert(points_to_sets_may_alias(array_points, unknown));
    SSAPointsToSet symbolic_parameter; symbolic_parameter.parameter_indices = {0};
    assert(points_to_sets_may_alias(symbolic_parameter, array_points));

    auto corrupted = ssa;
    assert(!corrupted.alias_accesses.empty());
    corrupted.alias_accesses.front().points_to_sites.push_back(999999);
    assert(!verify_ssa(corrupted, p).ok);

    // A control-flow join must union allocation-site provenance through a stack Phi.
    ProgramIR branch;
    branch.code = {
        {OpCode::PushInt, {}, 1, 1},
        {OpCode::JumpIfZero, {}, 4, 1},
        {OpCode::NewObject, {}, 0, 1},       // site 2
        {OpCode::Jump, {}, 5, 1},
        {OpCode::MakeArray, {}, 0, 1},       // site 4
        {OpCode::Return, {}, 0, 1}
    };
    const auto branch_ssa = build_ssa(branch);
    const auto branch_check = verify_ssa(branch_ssa, branch);
    if (!branch_check.ok) {
        for (const auto& error : branch_check.errors) std::cerr << error << '\n';
        return 3;
    }
    assert(!branch_ssa.stack_phis.empty());
    const auto& merge_phi = branch_ssa.stack_phis.front();
    const auto& merged_points = [&]() -> const SSAPointsToSet& {
        const auto it = std::find_if(branch_ssa.points_to_sets.begin(), branch_ssa.points_to_sets.end(),
            [&](const SSAPointsToSet& x) { return x.value == merge_phi.result; });
        assert(it != branch_ssa.points_to_sets.end()); return *it;
    }();
    assert((merged_points.allocation_sites == std::vector<std::size_t>{2, 4}));
    assert(!merged_points.unknown);
    SSAPointsToSet one_branch_allocation; one_branch_allocation.allocation_sites = {2};
    assert(points_to_sets_may_alias(merged_points, one_branch_allocation));

    const auto dump = dump_ssa(ssa);
    assert(dump.find("Points-to: allocation_sites=2") != std::string::npos);
    assert(dump.find("must_alias_singleton=yes") != std::string::npos);
    std::cout << "DOCMONT 7.50.0 points-to tests passed\n";
}
