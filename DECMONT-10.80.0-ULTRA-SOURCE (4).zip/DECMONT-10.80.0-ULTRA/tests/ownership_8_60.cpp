#include "docmont/ownership.hpp"
#include <cassert>
#include <iostream>
using namespace docmont::ownership;
static bool has(const AnalysisResult& r,const std::string& code){for(const auto& d:r.diagnostics)if(d.code==code)return true;return false;}
int main(){
    Function safe{"safe",0,{{0,{{OpKind::Declare,"text"},{OpKind::BorrowShared,"text","a"},{OpKind::BorrowShared,"text","b"},{OpKind::Read,"text"},{OpKind::EndBorrow,{},"a"},{OpKind::EndBorrow,{},"b"},{OpKind::Move,"text"}}, {}}}};
    auto a=analyze(safe);assert(a.ok);
    Function use_after_move{"move",0,{{0,{{OpKind::Declare,"value"},{OpKind::Move,"value"},{OpKind::Read,"value"}}, {}}}};
    auto b=analyze(use_after_move);assert(!b.ok&&has(b,"OWN011"));
    Function mutable_conflict{"borrow",0,{{0,{{OpKind::Declare,"value"},{OpKind::BorrowShared,"value","shared"},{OpKind::BorrowMutable,"value","mutable"}}, {}}}};
    auto c=analyze(mutable_conflict);assert(!c.ok&&has(c,"OWN017"));
    Function move_borrowed{"move",0,{{0,{{OpKind::Declare,"value"},{OpKind::BorrowShared,"value","loan"},{OpKind::Move,"value"}}, {}}}};
    auto d=analyze(move_borrowed);assert(!d.ok&&has(d,"OWN013"));
    Function dangling{"return",0,{{0,{{OpKind::Declare,"local"},{OpKind::ReturnReference,"local",{},3,0}}, {}}}};
    auto e=analyze(dangling);assert(!e.ok&&has(e,"OWN022"));
    Function cfg{"cfg",0,{{0,{{OpKind::Declare,"x"}}, {1,2}},{1,{{OpKind::Move,"x"}}, {3}},{2,{{OpKind::Read,"x"}}, {3}},{3,{{OpKind::Read,"x"}}, {}}}};
    auto f=analyze(cfg);assert(!f.ok&&has(f,"OWN011"));
    docmont::core::MIRFunction mir{"mir_move",0,{{0,{{docmont::core::MIROpKind::Declare,"v",{},1},{docmont::core::MIROpKind::Move,"v",{},1},{docmont::core::MIROpKind::Read,"v",{},1}}, {}}}};
    auto g=analyze(mir);assert(!g.ok&&has(g,"OWN011"));
    std::cout<<"DOCMONT 8.60.0 ownership tests passed\n";
}
