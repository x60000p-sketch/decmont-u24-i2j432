#include "docmont/game_engine.hpp"
#include "docmont/platform_contract.hpp"
#include "docmont/rendering_advanced.hpp"
#include <array>
#include <cassert>
#include <cmath>
#include <cstdint>
#include <iostream>
#include <limits>
#include <vector>

using namespace docmont;
using namespace docmont::game;

int main() {
    // Asset catalog: deterministic IDs, references and dependency-cycle checks.
    AssetCatalog assets;
    const auto mesh = assets.register_asset("world/mesh", AssetKind::Mesh, "Assets/world.mesh", "sha256:mesh");
    const auto mat = assets.register_asset("world/material", AssetKind::Material, "Assets/world.mat", "sha256:mat");
    const auto tex = assets.register_asset("world/albedo", AssetKind::Texture, "Assets/albedo.ktx", "sha256:tex");
    assert(assets.add_dependency(mat, tex));
    assert(assets.add_dependency(mesh, mat));
    assert(assets.set_state(mesh, AssetState::Ready));
    assert(assets.validate().empty());
    assert(!assets.add_dependency(tex, tex));

    AssetCatalog cyclic;
    auto a = cyclic.register_asset("a", AssetKind::Other, "a");
    auto b = cyclic.register_asset("b", AssetKind::Other, "b");
    assert(cyclic.add_dependency(a, b));
    assert(cyclic.add_dependency(b, a));
    assert(!cyclic.validate().empty());

    // World partition: deterministic active/simulation/dormant transitions and budget.
    WorldPartition partition(100.0f);
    assert(partition.define_cell({0,0,0}, 5));
    assert(partition.define_cell({1,0,0}, 3));
    assert(partition.define_cell({3,0,0}, 1));
    auto transitions = partition.update_focus({1,0,1}, 0, 2, 8, 10);
    assert(transitions.size() == 3);
    assert(partition.find({0,0,0})->state == CellState::Active);
    assert(partition.find({1,0,0})->state == CellState::SimulationOnly);
    assert(partition.find({3,0,0})->state == CellState::Dormant);
    auto budgeted = partition.update_focus({300,0,1}, 0, 0, 1, 11);
    assert(budgeted.size() == 1);

    // Physics: fixed-step AABB collision with a static floor.
    PhysicsWorld physics;
    RigidBodyDesc floor; floor.position={0,-1,0}; floor.half_extents={10,1,10}; floor.mass=0;
    const auto floor_id=physics.add_body(floor);
    RigidBodyDesc box; box.position={0,0.25f,0}; box.half_extents={0.5f,0.5f,0.5f}; box.mass=1;
    const auto box_id=physics.add_body(box);
    auto step=physics.step(1.0f/60.0f);
    assert(step.bodies_integrated==1 && step.broadphase_pairs==1 && step.contacts==1);
    assert(physics.body(box_id)->position.y >= -0.001f);
    assert(physics.remove_body(floor_id));
    bool invalid_dt=false; try { (void)physics.step(1.0f); } catch(const std::invalid_argument&) { invalid_dt=true; }
    assert(invalid_dt);

    // Grid navigation: A* routes around a blocked column.
    NavigationGrid nav(8, 6);
    for(int y=0;y<5;++y) assert(nav.set_blocked({3,y}, true));
    auto path=nav.find_path({0,0},{7,0});
    assert(path && (path->front()==GridPoint{0,0}) && (path->back()==GridPoint{7,0}));
    assert(path->size()>8);
    assert(!nav.find_path({0,0},{3,0}));
    NavigationGrid weighted(5,3);
    assert(weighted.set_cost({1,1},20.0f));
    auto weighted_path=weighted.find_path({0,1},{4,1});
    assert(weighted_path && weighted_path->size()>5);

    // Utility AI: finite scores only, stable first-wins tie behavior.
    const std::array<UtilityOption,4> goals{{{"patrol",0.3f},{"heal",0.9f},{"invalid",std::numeric_limits<float>::quiet_NaN()},{"retreat",0.9f}}};
    auto choice=choose_utility(goals);
    assert(choice && choice->name=="heal" && choice->index==1);
    assert(!choose_utility(std::span<const UtilityOption>{}));

    // Behavior trees: selector fallback and sequence short-circuit semantics.
    BehaviorTree behavior;
    bool action_ran=false;
    const auto has_target=behavior.condition("has-target", [] { return BehaviorStatus::Failure; });
    const auto attack=behavior.action("attack", [&] { action_ran=true; return BehaviorStatus::Success; });
    const auto engage=behavior.sequence({has_target,attack});
    const auto patrol=behavior.action("patrol", [] { return BehaviorStatus::Running; });
    const auto root=behavior.selector({engage,patrol});
    assert(!behavior.validate(root));
    assert(behavior.tick(root)==BehaviorStatus::Running && !action_ran);
    bool invalid_behavior=false; try { (void)behavior.tick(999); } catch(const std::invalid_argument&) { invalid_behavior=true; }
    assert(invalid_behavior);

    // Animation blend weights are normalized and reject duplicate/invalid clips.
    const std::array<AnimationWeight,3> blend{{{"idle",0.25f},{"walk",0.75f},{"disabled",0.0f}}};
    auto normalized=normalize_animation_weights(blend);
    assert(normalized && normalized->size()==2);
    assert(std::abs((*normalized)[0].weight+(*normalized)[1].weight-1.0f)<1e-6f);
    const std::array<AnimationWeight,2> bad_blend{{{"walk",0.5f},{"walk",0.5f}}};
    assert(!normalize_animation_weights(bad_blend));

    // Deterministic in-game clock and bounded weather parameters.
    WorldClock clock(100.0);
    assert(std::abs(clock.sunlight()-0.0f)<1e-5f);
    clock.advance(25.0);
    assert(std::abs(clock.day_fraction()-0.5)<1e-9);
    assert(clock.sunlight()>0.99f);
    assert(clock.set_weather(18.0f,4.0f,0.35f,0.2f));
    assert(!clock.set_weather(18.0f,-1.0f,0.35f,0.2f));

    // Audio voice budgeting: deterministic priority then attenuation ordering.
    AudioScene audio;
    assert(audio.upsert({1,{1,0,0},1,1,20,1,true}));
    assert(audio.upsert({2,{5,0,0},1,1,20,5,false}));
    assert(audio.upsert({3,{100,0,0},1,1,20,99,false}));
    auto voices=audio.mix({{0,0,0}},1);
    assert(voices.size()==1 && voices.front().id==2);
    assert(!audio.upsert({4,{0,0,0},-1,1,2,0,false}));

    // Network snapshot codec: deterministic ordering, checksum and corruption rejection.
    const std::array<ReplicatedTransform,2> transforms{{{20,{2,3,4}},{10,{1,2,3}}}};
    std::string codec_error;
    auto packet=SnapshotCodec::encode(77,transforms,&codec_error);
    assert(packet && codec_error.empty());
    auto decoded=SnapshotCodec::decode(*packet);
    assert(decoded.ok && decoded.snapshot.sequence==77 && decoded.snapshot.entities.size()==2);
    assert(decoded.snapshot.entities[0].entity==10 && decoded.snapshot.entities[1].entity==20);
    auto corrupt=*packet; corrupt[10]^=0x80;
    assert(!SnapshotCodec::decode(corrupt).ok);
    const std::array<ReplicatedTransform,2> duplicates{{{1,{0,0,0}},{1,{1,1,1}}}};
    assert(!SnapshotCodec::encode(1,duplicates));

    // GPU selection is capability-profile based; it doesn't pretend to submit API work.
    DeviceCapabilities caps; caps.device_name="test-gpu"; caps.vulkan=true; caps.compute=true; caps.ray_tracing=false;
    const std::array<GraphicsAPI,3> preference{{GraphicsAPI::Vulkan,GraphicsAPI::Metal,GraphicsAPI::Software}};
    auto selected=select_graphics_api(caps,preference,false);
    assert(selected && selected->api==GraphicsAPI::Vulkan && selected->hardware_accelerated);
    DeviceCapabilities cpu;
    auto fallback=select_graphics_api(cpu,preference,true);
    assert(fallback && fallback->api==GraphicsAPI::Software && !fallback->hardware_accelerated);
    assert(!select_graphics_api(cpu,preference,false));

    // Forward and deferred render-graph plans compile into deterministic pass order.
    auto forward=build_render_pipeline(RenderPath::Forward);
    auto deferred=build_render_pipeline(RenderPath::Deferred);
    assert(forward.ok && forward.ordered_passes.size()==4 && forward.ordered_passes.front()=="depth-prepass");
    assert(deferred.ok && deferred.ordered_passes.size()==4 && deferred.ordered_passes.front()=="gbuffer");

    // CPU reference PBR BRDF and HDR tone-mapping foundations.
    const auto pbr=render::evaluate_pbr_ggx({0.8f,0.6f,0.4f,1.0f},0.1f,0.5f,{0,0,1},{0,0,1},{0,0,1});
    assert(std::isfinite(pbr.r) && std::isfinite(pbr.g) && std::isfinite(pbr.b));
    assert(pbr.r>0 && pbr.g>0 && pbr.b>0);
    const auto mapped=render::tonemap_aces({4.0f,2.0f,1.0f,1.0f});
    assert(mapped.r<=1.0f && mapped.r>mapped.g && mapped.g>mapped.b);
    bool invalid_pbr=false; try { (void)render::evaluate_pbr_ggx({1,1,1,1},2.0f,0.5f,{0,0,1},{0,0,1},{0,0,1}); } catch(const std::invalid_argument&) { invalid_pbr=true; }
    assert(invalid_pbr);

    // Profiler rejects invalid measurements and maintains bounded rolling history.
    FrameProfiler profiler(2);
    assert(!profiler.latest());
    profiler.record({1.0,2.0,0.2,0.1,0.05,100,200,300,4096,2048});
    profiler.record({3.0,4.0,0.4,0.2,0.1,110,210,310,8192,4096});
    profiler.record({5.0,6.0,0.5,0.3,0.1,120,220,320,8192,4096});
    assert(profiler.samples()==2 && std::abs(*profiler.average_cpu_ms()-4.0)<1e-9);
    bool invalid_metric=false; try { profiler.record({-1.0}); } catch(const std::invalid_argument&) { invalid_metric=true; }
    assert(invalid_metric);

    GameProjectConfig project{"UltraDemo","linux-x86_64",1,true,false};
    assert(validate_project(project,assets).ok);
    project.target="unknown-platform";
    assert(!validate_project(project,assets).ok);

    std::cout << "DOCMONT ULTRA game engine foundation tests passed\n";
    return 0;
}
