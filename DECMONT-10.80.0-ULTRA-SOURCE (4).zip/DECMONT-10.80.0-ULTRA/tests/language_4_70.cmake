execute_process(
  COMMAND "${DOCMONT}" run "${SOURCE_DIR}/examples/language_4_70.docm"
  RESULT_VARIABLE rc OUTPUT_VARIABLE out ERROR_VARIABLE err)
if(NOT rc EQUAL 0)
  message(FATAL_ERROR "DOCMONT mutable closure example failed (${rc}): ${err}")
endif()
string(REPLACE "\r\n" "\n" out "${out}")
set(expected "1\n2\n3\n3\n")
if(NOT out STREQUAL expected)
  message(FATAL_ERROR "Unexpected mutable closure output. Expected [${expected}], got [${out}]")
endif()
