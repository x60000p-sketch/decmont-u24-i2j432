execute_process(COMMAND "${DOCMONT}" run "${SOURCE_DIR}/examples/arrays_loops_4_16.docm"
  RESULT_VARIABLE rc OUTPUT_VARIABLE out ERROR_VARIABLE err)
if(NOT rc EQUAL 0)
  message(FATAL_ERROR "DOCMONT 4.16 runtime failed: ${err}")
endif()
if(NOT out MATCHES "60" OR NOT out MATCHES "99" OR NOT out MATCHES "\\[10, 99, 30\\]")
  message(FATAL_ERROR "Unexpected DOCMONT 4.16 output: ${out}")
endif()
