#include "docmont/native_backend.hpp"
#include <iostream>
#include <string>
int main() {
 using namespace docmont; ProgramIR ir; ir.name="native_heap_10_70";
 ir.code={{OpCode::PushInt,"",5,1},{OpCode::MakeArray,"",1,1},{OpCode::PushInt,"",7,1},{OpCode::ArrayPush,"",0,1},{OpCode::Print,"",0,1}};
 const auto r=emit_c_source(ir); int failures=0;
 auto expect=[&](bool ok,const char* label){if(!ok){std::cerr<<"FAIL: "<<label<<'\n';++failures;}};
 expect(r.ok,"native array program emits");
 expect(r.source.find("MAX_ARRAY_BYTES=64u*1024u*1024u")!=std::string::npos,"64 MiB payload budget emitted");
 expect(r.source.find("g_array_bytes")!=std::string::npos,"allocated bytes accounted");
 expect(r.source.find("(MAX_ARRAY_BYTES-g_array_bytes)/sizeof(Value)")!=std::string::npos,"remaining byte budget checked");
 expect(r.source.find("nc>SIZE_MAX/sizeof(Value)")!=std::string::npos,"capacity multiplication overflow guarded");
 expect(r.source.find("g_array_bytes+=added*sizeof(Value)")!=std::string::npos,"growth accounting committed");
 expect(r.source.find("g_array_bytes=0")!=std::string::npos,"cleanup resets accounting");
 if(failures)return 1; std::cout<<"DECMONT 10.70.0 native heap: 7 checks passed\n"; return 0;
}
