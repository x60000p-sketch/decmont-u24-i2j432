#include "docmont/ssa.hpp"
#include "docmont/optimizer.hpp"
#include "docmont/bytecode.hpp"
#include "docmont/runtime.hpp"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <sstream>
using namespace docmont;


static std::string run_vm(const ProgramIR& ir) {
    auto encoded = encode_bytecode(ir); assert(encoded.ok);
    std::ostringstream output; auto* old = std::cout.rdbuf(output.rdbuf());
    const auto status = execute_bytecode(encoded.bytes); std::cout.rdbuf(old);
    assert(status == 0); return output.str();
}

static const SSAIntegerRange* range_for(const SSAProgram& ssa, std::size_t value) {
    auto it = std::find_if(ssa.integer_ranges.begin(), ssa.integer_ranges.end(),
        [&](const SSAIntegerRange& range) { return range.value == value; });
    return it == ssa.integer_ranges.end() ? nullptr : &*it;
}

int main() {
    // A constant stored into a local and then loaded as an array selector is
    // propagated through variable SSA and used to name the exact memory slot.
    ProgramIR stored_constant;
    stored_constant.code = {
        {OpCode::PushInt, {}, 10, 1}, {OpCode::PushInt, {}, 20, 1},
        {OpCode::PushInt, {}, 30, 1}, {OpCode::MakeArray, {}, 3, 1},
        {OpCode::Store, "items", 0, 1},
        {OpCode::PushInt, {}, 0, 2}, {OpCode::PushInt, {}, 1, 2},
        {OpCode::Add, {}, 0, 2}, {OpCode::Store, "index", 0, 2},
        {OpCode::Load, "items", 0, 3}, {OpCode::Load, "index", 0, 3},
        {OpCode::ArrayGet, {}, 0, 3}, {OpCode::Print, {}, 0, 3}
    };
    auto stored_ssa = build_ssa(stored_constant);
    assert(verify_ssa(stored_ssa, stored_constant).ok);
    auto index_load = std::find_if(stored_ssa.value_definitions.begin(), stored_ssa.value_definitions.end(),
        [](const SSAValueDefinition& d) { return d.op == OpCode::Load && d.text == "index"; });
    assert(index_load != stored_ssa.value_definitions.end());
    auto index_range = range_for(stored_ssa, index_load->id);
    assert(index_range && index_range->minimum == 1 && index_range->maximum == 1);
    auto slot_read = std::find_if(stored_ssa.memory_uses.begin(), stored_ssa.memory_uses.end(),
        [](const SSAMemoryUse& use) { return use.instruction == 11 && use.partition_key == "array:3:1"; });
    assert(slot_read != stored_ssa.memory_uses.end());

    // A control-flow Phi that merges 1 and 2 yields [1,2], not a fabricated
    // singleton. It must therefore retain the coarse heap dependency.
    ProgramIR joined_range;
    joined_range.code = {
        {OpCode::PushInt, {}, 10, 1}, {OpCode::PushInt, {}, 20, 1},
        {OpCode::PushInt, {}, 30, 1}, {OpCode::MakeArray, {}, 3, 1},
        {OpCode::Store, "items", 0, 1},
        {OpCode::PushInt, {}, 0, 2}, {OpCode::JumpIfZero, {}, 10, 2},
        {OpCode::PushInt, {}, 1, 3}, {OpCode::Store, "index", 0, 3},
        {OpCode::Jump, {}, 12, 3},
        {OpCode::PushInt, {}, 2, 4}, {OpCode::Store, "index", 0, 4},
        {OpCode::Load, "items", 0, 5}, {OpCode::Load, "index", 0, 5},
        {OpCode::ArrayGet, {}, 0, 5}, {OpCode::Print, {}, 0, 5}
    };
    auto joined_ssa = build_ssa(joined_range);
    assert(verify_ssa(joined_ssa, joined_range).ok);
    auto joined_load = std::find_if(joined_ssa.value_definitions.begin(), joined_ssa.value_definitions.end(),
        [](const SSAValueDefinition& d) { return d.op == OpCode::Load && d.text == "index"; });
    assert(joined_load != joined_ssa.value_definitions.end());
    auto joined = range_for(joined_ssa, joined_load->id);
    assert(joined && joined->minimum == 1 && joined->maximum == 2);
    assert(std::none_of(joined_ssa.memory_uses.begin(), joined_ssa.memory_uses.end(),
        [](const SSAMemoryUse& use) { return use.instruction == 14 && use.partition_key.rfind("array:", 0) == 0; }));

    // A singleton selector recovered through a local variable is also
    // eligible for memory-read CSE; the rewrite must preserve VM output.
    ProgramIR cse_case;
    cse_case.code = {
        {OpCode::PushInt, {}, 10, 1}, {OpCode::PushInt, {}, 20, 1},
        {OpCode::MakeArray, {}, 2, 1}, {OpCode::Store, "items", 0, 1},
        {OpCode::PushInt, {}, 1, 2}, {OpCode::Store, "index", 0, 2},
        {OpCode::Load, "items", 0, 3}, {OpCode::Load, "index", 0, 3},
        {OpCode::ArrayGet, {}, 0, 3}, {OpCode::Print, {}, 0, 3},
        {OpCode::Load, "items", 0, 4}, {OpCode::Load, "index", 0, 4},
        {OpCode::ArrayGet, {}, 0, 4}, {OpCode::Print, {}, 0, 4}
    };
    const auto cse_before = run_vm(cse_case);
    const auto cse_stats = optimize_ir(cse_case);
    assert(cse_stats.ssa_memory_load_eliminations == 1);
    assert(run_vm(cse_case) == cse_before);

    // Checked arithmetic does not publish a range when the result may overflow.
    ProgramIR overflow;
    overflow.code = {
        {OpCode::PushInt, {}, INT64_MAX, 1}, {OpCode::PushInt, {}, 1, 1},
        {OpCode::Add, {}, 0, 1}, {OpCode::Store, "index", 0, 1},
        {OpCode::Load, "index", 0, 2}, {OpCode::Print, {}, 0, 2}
    };
    auto overflow_ssa = build_ssa(overflow);
    assert(verify_ssa(overflow_ssa, overflow).ok);
    auto overflow_load = std::find_if(overflow_ssa.value_definitions.begin(), overflow_ssa.value_definitions.end(),
        [](const SSAValueDefinition& d) { return d.op == OpCode::Load && d.text == "index"; });
    assert(overflow_load != overflow_ssa.value_definitions.end());
    assert(range_for(overflow_ssa, overflow_load->id) == nullptr);

    std::cout << "DOCMONT 8.3.0.0 integer-range SSA tests passed\n";
}
