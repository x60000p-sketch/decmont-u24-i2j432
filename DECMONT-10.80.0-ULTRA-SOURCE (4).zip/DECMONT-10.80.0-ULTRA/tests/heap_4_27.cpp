#include "docmont/heap.hpp"
#include <cassert>
#include <cstdint>
#include <new>
#include <string>

int main() {
    using docmont::memory::Heap;
    Heap heap(256);
    assert(heap.budget_bytes() == 256);                                      // 1
    assert(heap.empty());                                                    // 2
    assert(heap.available_bytes() == 256);                                   // 3
    void* zero = heap.allocate(0, alignof(std::max_align_t), "zero");       // 4
    assert(heap.allocation_size(zero).value() == 1);                         // 5
    assert(heap.owns(zero));                                                 // 6
    assert(heap.allocation_tag(zero).value() == "zero");                    // 7
    assert(heap.allocation_alignment(zero).value() == alignof(std::max_align_t)); // 8
    assert(heap.deallocate(zero));                                           // 9
    assert(!heap.deallocate(zero));                                          // 10

    auto* text = heap.make_tagged<std::string>("strings", "DOCMONT");      // 11
    assert(*text == "DOCMONT");
    assert(heap.allocation_count("strings") == 1);                         // 12
    assert(heap.bytes_for_tag("strings") == sizeof(std::string));          // 13
    assert(heap.validate());                                                 // 14
    auto cp = heap.checkpoint();                                             // 15
    void* later = heap.allocate(32, 16, "scratch");                         // 16
    assert(heap.leak_report().size() == 2);                                  // 17
    assert(heap.rollback(cp) == 1);                                          // 18
    assert(!heap.owns(later));                                               // 19
    assert(heap.owns(text));                                                 // 20
    assert(heap.set_budget(512));                                            // 21
    assert(heap.budget_bytes() == 512);                                      // 22
    assert(heap.stats().live_blocks == 1);                                   // 23
    assert(heap.stats().total_allocations == 3);                             // 24
    assert(heap.stats().total_deallocations == 2);                           // 25
    heap.reset_peak();
    assert(heap.stats().peak_bytes == 0);
    assert(heap.clear_one("strings"));                                      // 26
    assert(heap.empty());
    assert(heap.validate());
    assert(heap.try_allocate(1024) == nullptr);                              // 27
    assert(heap.stats().failed_allocations > 0);                             // 28
    bool invalid_alignment = false;
    try { (void)heap.allocate(4, 3); } catch (const std::invalid_argument&) { invalid_alignment = true; }
    assert(invalid_alignment);                                               // 29
    auto* value = heap.make<int>(27);                                        // 30
    assert(*value == 27 && heap.destroy(value));
    heap.clear();
    assert(heap.empty() && heap.validate());
}
