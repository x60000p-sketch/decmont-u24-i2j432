import importlib.util, json, shutil, subprocess, tempfile, threading, urllib.request, urllib.error
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('docmont_studio_server',ROOT/'studio'/'server.py')
mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)

def request(url, method='GET', body=None):
    data=None if body is None else json.dumps(body).encode()
    req=urllib.request.Request(url,data=data,headers={'Content-Type':'application/json'} if data is not None else {},method=method)
    try:
        with urllib.request.urlopen(req,timeout=10) as r:return r.status,json.loads(r.read().decode())
    except urllib.error.HTTPError as e:return e.code,json.loads(e.read().decode())

def main():
    with tempfile.TemporaryDirectory() as td:
        ws=Path(td)
        compiler=sys.argv[1] if len(sys.argv)>1 else ''
        # Studio opens a generated, manifest-backed DOCMONT workspace.
        created=subprocess.run([str(ROOT/'tools'/'docmont-project'),'new','StudioGame',str(ws)],capture_output=True,text=True)
        assert created.returncode==0, created.stderr
        shutil.copy2(ROOT/'examples'/'hello.docm',ws/'hello.docm')
        (ws/'assets'/'models'/'sample.glb').write_bytes(b'glTF\x02\x00\x00\x00')
        subprocess.run([str(ROOT/'tools'/'docmont-project'),'assets',str(ws)],check=True,capture_output=True,text=True)
        server=mod.StudioServer(('127.0.0.1',0),mod.Handler,ws,compiler)
        th=threading.Thread(target=server.serve_forever,daemon=True);th.start();base=f'http://127.0.0.1:{server.server_port}'
        try:
            st,h=request(base+'/api/health');assert st==200 and h['version']=='9.00.0'
            st,project=request(base+'/api/project');assert st==200 and project['configured'] and project['name']=='StudioGame' and project['entry_exists']
            st,files=request(base+'/api/files');assert st==200 and any(x['path']=='hello.docm' for x in files['files'])
            st,assets=request(base+'/api/assets');assert st==200 and any(x['path']=='assets/models/sample.glb' and x['kind']=='model' for x in assets['assets'])
            st,read=request(base+'/api/read?path=hello.docm');assert st==200 and 'DOCMONT_HELLO' in read['content']
            st,saved=request(base+'/api/save','POST',{'path':'hello.docm','content':read['content']+'\n'});assert st==200 and saved['backup_created']
            st,bad=request(base+'/api/read?path=..%2Foutside.docm');assert st==400
            st,bad=request(base+'/api/save','POST',{'path':'../../outside.docm','content':'bad'});assert st==400
            st,js=request(base+'/api/validate','POST',{'path':'hello.docm'});assert st==200 and js['ok'],js
            st,asset_refresh=request(base+'/api/project/assets','POST',{});assert st==200 and asset_refresh['ok'],asset_refresh
            st,check=request(base+'/api/project/check','POST',{});assert st==200 and check['ok'],check
            st,build=request(base+'/api/project/build','POST',{});assert st==200 and build['ok'] and 'Build succeeded' in build['stdout'],build
            st,package=request(base+'/api/project/package','POST',{});assert st==200 and package['ok'] and (ws/'dist'/'studio-project.zip').is_file(),package
            print('DOCMONT Studio project dashboard, source/asset browser, safe edits/backups, compiler validation, project check/build/package and path traversal rejection passed')
        finally:server.shutdown();server.server_close();th.join(timeout=2)
if __name__=='__main__':main()
