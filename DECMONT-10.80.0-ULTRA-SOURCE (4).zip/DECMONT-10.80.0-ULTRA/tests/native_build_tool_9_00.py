#!/usr/bin/env python3
import os, subprocess, sys, tempfile
from pathlib import Path
script=Path(sys.argv[1]).resolve(); compiler=Path(sys.argv[2]).resolve(); clang=Path(sys.argv[3]).resolve(); source=Path(sys.argv[4]).resolve()
with tempfile.TemporaryDirectory(prefix="docmont-native-build-test-") as td:
    exe=Path(td)/"native-main"
    proc=subprocess.run([str(script),str(source),"-o",str(exe),"--docmont",str(compiler),"--clang",str(clang)],text=True,capture_output=True)
    assert proc.returncode==0,(proc.stdout,proc.stderr)
    assert exe.is_file() and exe.stat().st_size>0
    ran=subprocess.run([str(exe)],check=False)
    assert ran.returncode==42,ran.returncode
    obj=Path(td)/"arm64.o"
    cross=subprocess.run([str(script),str(source),"-o",str(obj),"--target","aarch64-unknown-linux-gnu","--object-only","--docmont",str(compiler),"--clang",str(clang)],text=True,capture_output=True)
    assert cross.returncode==0,(cross.stdout,cross.stderr)
    assert obj.is_file() and obj.stat().st_size>0
print("DOCMONT native build tool tests passed: x86_64 link/run and AArch64 object generation")
