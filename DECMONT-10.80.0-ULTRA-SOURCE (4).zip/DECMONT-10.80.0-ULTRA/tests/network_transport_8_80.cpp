#include "docmont/network_transport.hpp"
#include <array>
#include <cassert>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <thread>
using namespace docmont::network;using namespace std::chrono_literals;
int main(){
    std::string error;auto listener=TcpListener::bind_any(0,&error);assert(listener&&listener->local_port()!=0);
    std::thread server([&]{auto c=listener->accept(2s,&error);assert(c);auto r=c->receive_frame(2s);assert(r.ok&&r.payload.size()==3&&r.payload[0]=='h');const std::array<std::uint8_t,2> ack{'o','k'};assert(c->send_frame(ack,&error));});
    auto client=TcpConnection::connect({"127.0.0.1",listener->local_port()},2s,&error);assert(client);const std::array<std::uint8_t,3> payload{'h','i','!'};assert(client->send_frame(payload,&error));auto reply=client->receive_frame(2s);assert(reply.ok&&reply.payload.size()==2&&reply.payload[1]=='k');server.join();
    auto receiver=UdpSocket::bind_any(0,&error);auto sender=UdpSocket::bind_any(0,&error);assert(receiver&&sender);const std::array<std::uint8_t,4> datagram{'p','i','n','g'};assert(sender->send_to({"127.0.0.1",receiver->local_port()},77,datagram,&error));auto got=receiver->receive(2s);assert(got.ok&&got.sequence==77&&got.payload.size()==4&&got.from.port==sender->local_port());
    assert(crc32(datagram)!=0);assert(!sender->send_to({"example.com",7},1,datagram,&error));
    std::cout<<"DOCMONT TCP framed transport and UDP datagram transport passed\n";
}
