#include "docmont/native_backend.hpp"
#include <iostream>
#include <string>
#include <utility>
#include <vector>
namespace {
int failures=0;
void expect(bool ok,const char* label){if(!ok){std::cerr<<"FAIL: "<<label<<'\n';++failures;}}
docmont::NativeSourceResult emit(std::vector<docmont::Instruction> code){docmont::ProgramIR ir;ir.name="native_object_10_80";ir.code=std::move(code);return docmont::emit_c_source(ir);}
}
int main(){using namespace docmont;
 {auto r=emit({{OpCode::NewObject,"",0,1},{OpCode::PushInt,"",42,1},{OpCode::ObjectSet,"answer",0,1},{OpCode::ObjectGet,"answer",0,1},{OpCode::Print,"",0,1}});expect(r.ok,"object create/set/get emits");expect(r.source.find("object_set((Object*)base->a,\"answer\",val)")!=std::string::npos,"property set lowers with checked receiver");expect(r.source.find("object_get((Object*)base->a,\"answer\",&value)")!=std::string::npos,"property get lowers with missing-key check");expect(r.source.find("atexit(object_cleanup)")!=std::string::npos,"objects register deterministic cleanup");}
 {auto r=emit({{OpCode::NewObject,"",0,1},{OpCode::ObjectHas,"ready",0,1},{OpCode::Print,"",0,1}});expect(r.ok&&r.source.find("object_has((Object*)base->a,\"ready\")")!=std::string::npos,"property has lowers");}
 {auto r=emit({{OpCode::NewObject,"",0,1},{OpCode::ArrayLength,"",0,1},{OpCode::Print,"",0,1}});expect(r.ok&&r.source.find("((Object*)v->a)->len")!=std::string::npos,"object length lowers");}
 {auto r=emit({{OpCode::NewObject,"",0,1},{OpCode::PushInt,"",1,1},{OpCode::ObjectSet,"x",0,1}});expect(r.ok&&r.source.find("MAX_OBJECT_BYTES=64u*1024u*1024u")!=std::string::npos,"object field heap budget is emitted");expect(r.source.find("MAX_OBJECT_FIELDS=1000000")!=std::string::npos,"object field count is bounded");expect(r.source.find("bycap+o->cap")!=std::string::npos,"object growth budget includes already-accounted capacity");}
 {auto r=emit({{OpCode::ObjectGet,"x",0,1}});expect(!r.ok&&r.message.find("operand stack underflow")!=std::string::npos,"object receiver underflow rejected");}
 {auto r=emit({{OpCode::NewObject,"",0,1},{OpCode::ObjectSet,"",0,1}});expect(!r.ok&&r.message.find("operand stack underflow")!=std::string::npos,"object set underflow rejected");}
 if(failures)return 1;std::cout<<"DECMONT 10.80.0 native objects: 12 checks passed\n";return 0;}
