#!/usr/bin/env python3
"""Generate a tiny ONNX protobuf model and verify DOCMONT CLI inspection/inference."""
import pathlib
import struct
import subprocess
import sys
import tempfile


def varint(value: int) -> bytes:
    out = bytearray()
    while value >= 0x80:
        out.append((value & 0x7F) | 0x80)
        value >>= 7
    out.append(value)
    return bytes(out)


def tag(field: int, wire: int) -> bytes:
    return varint((field << 3) | wire)


def blob(field: int, value: bytes) -> bytes:
    return tag(field, 2) + varint(len(value)) + value


def string(field: int, value: str) -> bytes:
    return blob(field, value.encode())


def packed_ints(values) -> bytes:
    return b''.join(varint(v) for v in values)


def tensor(name, shape, values):
    raw = b''.join(struct.pack('<f', v) for v in values)
    return blob(1, packed_ints(shape)) + tag(2, 0) + varint(1) + blob(9, raw) + string(8, name)


def node(op, inputs, output):
    return b''.join(string(1, i) for i in inputs) + string(2, output) + string(4, op)


def value_info(name):
    return string(1, name)


def model_bytes():
    graph = string(2, 'docmont-tiny-mlp')
    graph += blob(1, node('MatMul', ['X', 'W'], 'M'))
    graph += blob(1, node('Add', ['M', 'B'], 'A'))
    graph += blob(1, node('Relu', ['A'], 'Y'))
    graph += blob(5, tensor('W', [2, 2], [1.0, 0.0, 0.0, 2.0]))
    graph += blob(5, tensor('B', [2], [-1.0, 1.0]))
    graph += blob(11, value_info('X'))
    graph += blob(12, value_info('Y'))
    return tag(1, 0) + varint(8) + blob(7, graph)


def main():
    compiler = pathlib.Path(sys.argv[1]).resolve()
    with tempfile.TemporaryDirectory(prefix='docmont-onnx-cli-') as td:
        model_path = pathlib.Path(td) / 'tiny.onnx'
        model_path.write_bytes(model_bytes())
        info = subprocess.run([str(compiler), 'onnx-info', str(model_path)], text=True, capture_output=True, check=False)
        if info.returncode != 0 or 'Graph: docmont-tiny-mlp' not in info.stdout or 'MatMul' not in info.stdout:
            raise SystemExit(f'onnx-info failed: {info.stdout}\n{info.stderr}')
        run = subprocess.run([str(compiler), 'onnx-run', str(model_path), '--shape', '1,2', '--values', '3,-2'], text=True, capture_output=True, check=False)
        if run.returncode != 0 or 'values=2,0' not in run.stdout:
            raise SystemExit(f'onnx-run failed: {run.stdout}\n{run.stderr}')
    print('DOCMONT ONNX CLI model inspection and CPU inference passed: output [2, 0]')


if __name__ == '__main__':
    main()
