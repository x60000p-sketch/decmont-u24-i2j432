#include "docmont/bytecode.hpp"
#include "docmont/function_semantics.hpp"
#include "docmont/ir.hpp"
#include "docmont/lexer.hpp"
#include "docmont/ownership.hpp"
#include "docmont/parser.hpp"
#include "docmont/runtime.hpp"
#include "docmont/semantic.hpp"
#include "docmont/source_frontend.hpp"
#include <cassert>
#include <algorithm>
#include <functional>
#include <iostream>
#include <sstream>

using namespace docmont;
static Application parse(const std::string& source) {
    Lexer lexer(source); auto lexed=lexer.scan(); assert(lexed.diagnostics.empty());
    Parser parser(std::move(lexed.tokens)); auto parsed=parser.parse();
    if(!parsed.diagnostics.empty()) { for(const auto& d:parsed.diagnostics) std::cerr<<d.message<<"\n"; }
    assert(parsed.diagnostics.empty()); return parsed.app;
}
static std::string capture(const std::function<int()>& fn) {
    std::ostringstream out; auto* old=std::cout.rdbuf(out.rdbuf()); const int rc=fn(); std::cout.rdbuf(old); assert(rc==0); return out.str();
}
int main() {
  const std::string source=R"(!docmont[3]
select architecture = portable
application = {
 name = "enum_generic_result"
 enum Status { Ready, Failed(String) }
 enum Packet { Data(Int, String) }
 fn identity<T>(value: T): T { return value }
 fn fail(): Result<Int, String> { return Result::Err("broken") }
 fn propagate(): Result<Int, String> {
   let value = fail()?
   return Result::Ok(value)
 }
 fn option_none(): Option<Int> { return Option::None() }
 fn option_propagate(): Option<Int> {
   let value = option_none()?
   return Option::Some(value)
 }
 fn main() {
   let packet = Packet::Data(7, "item")
   match packet { Packet::Data(payload) => { output = payload } }
   let status = Status::Failed("enum payload")
   match status {
     Status::Ready => { output = "ready" }
     Status::Failed(message) => { output = message }
   }
   output = identity(42)
   let result = propagate()
   match result {
     Result::Ok(value) => { output = value }
     Result::Err(message) => { output = message }
   }
   let option = option_propagate()
   match option {
     Option::Some(value) => { output = value }
     Option::None => { output = "none" }
   }
 }
 complete
})";
  auto app=parse(source);
  assert(validate(app).empty());
  assert(validate_function_contracts(app).empty());
  assert(ownership::validate_source(app).empty());
  const auto expected="[7, item]\nenum payload\n42\nbroken\nnone\n";
  const auto interpreted=capture([&]{return execute_application(app);});
  assert(interpreted==expected);
  const auto ir=lower_to_ir(app); const auto encoded=encode_bytecode(ir);
  assert(encoded.ok); assert(verify_bytecode(encoded.bytes).ok);
  const auto vm=capture([&]{return execute_bytecode(encoded.bytes);});
  assert(vm==expected);

  const std::string bad_match=R"(!docmont[3]
application = { name = "bad_match" enum State { Ready, Failed } fn main() { let state = State::Ready match state { State::Ready => { output = 1 } } } complete
})";
  auto bad=parse(bad_match); auto bad_types=validate_function_contracts(bad);
  assert(std::any_of(bad_types.begin(),bad_types.end(),[](const auto& d){return d.message.find("Non-exhaustive match")!=std::string::npos;}));

  const std::string bad_generic=R"(!docmont[3]
application = {
 name = "bad_generic"
 fn accept<T: Numeric>(value: T): T { return value }
 fn main() { let value = accept("not numeric") }
 complete
})";
  auto generic_bad=parse(bad_generic); auto generic_errors=validate_function_contracts(generic_bad);
  assert(std::any_of(generic_errors.begin(),generic_errors.end(),[](const auto& d){return d.message.find("does not satisfy trait bound 'Numeric'")!=std::string::npos;}));

  const std::string bad_try=R"(!docmont[3]
application = { name = "bad_try" fn main() { let value = 12? } complete }
})";
  auto try_bad=parse(bad_try); auto try_errors=validate_function_contracts(try_bad);
  assert(std::any_of(try_errors.begin(),try_errors.end(),[](const auto& d){return d.message.find("postfix '?' requires Option")!=std::string::npos;}));

  const std::string bad_ownership=R"(!docmont[3]
application = {
 name = "bad_ownership"
 fn invalid(): Int {
   let value = 7
   let reference = &mut value
   let moved = move value
   output = value
   return 0
 }
 complete
})";
  auto owned_bad=parse(bad_ownership); auto ownership_errors=ownership::validate_source(owned_bad);
  assert(std::any_of(ownership_errors.begin(),ownership_errors.end(),[](const auto& d){return d.code=="OWN013";}));

  const std::string branch_move=R"(!docmont[3]
application = {
 name = "branch_move"
 fn invalid(): Int {
   let value = 7
   if (true) { let moved = move value }
   output = value
   return 0
 }
 complete
})";
  auto branch_bad=parse(branch_move);auto branch_errors=ownership::validate_source(branch_bad);
  assert(std::any_of(branch_errors.begin(),branch_errors.end(),[](const auto& d){return d.code=="OWN011";}));

  const std::string scoped_borrow=R"(!docmont[3]
application = {
 name = "scoped_borrow"
 fn valid(): Int {
   let value = 7
   if (true) { let borrowed = &value output = borrowed }
   let moved = move value
   return 0
 }
 complete
})";
  auto scoped_ok=parse(scoped_borrow);assert(ownership::validate_source(scoped_ok).empty());

  const std::string mutable_read=R"(!docmont[3]
application = {
 name = "mutable_read"
 fn invalid(): Int {
   let value = 7
   let borrowed = &mut value
   output = value
   return 0
 }
 complete
})";
  auto mutable_bad=parse(mutable_read);auto mutable_errors=ownership::validate_source(mutable_bad);
  assert(std::any_of(mutable_errors.begin(),mutable_errors.end(),[](const auto& d){return d.code=="OWN023";}));

  const std::string returned_borrow=R"(!docmont[3]
application = {
 name = "returned_borrow"
 fn invalid(): &Int {
   let value = 7
   let borrowed = &value
   return borrowed
 }
 complete
})";
  auto returned_bad=parse(returned_borrow);auto returned_errors=ownership::validate_source(returned_bad);
  assert(std::any_of(returned_errors.begin(),returned_errors.end(),[](const auto& d){return d.code=="OWN022";}));

  const auto frontend=frontend::lower_to_hir_mir(app);
  assert(frontend.diagnostics.empty()); assert(frontend.hir.functions.size()==7); assert(frontend.mir.functions.size()==7);
  assert(std::any_of(frontend.hir.functions.begin(),frontend.hir.functions.end(),[](const auto& f){return f.name=="identity"&&!f.generic_parameters.empty();}));
  assert(std::any_of(frontend.hir.functions.begin(),frontend.hir.functions.end(),[](const auto& f){return f.name.find("identity__i64") == 0 && f.generic_parameters.empty();}));
  assert(std::any_of(frontend.mir.functions.begin(),frontend.mir.functions.end(),[](const auto& f){return f.name.find("identity__i64") == 0;}));
  std::cout<<"DOCMONT 8.70.0 source enums/generics/Result/Option/ownership/HIR-MIR tests passed\n";
}
