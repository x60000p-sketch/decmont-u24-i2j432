if(NOT DEFINED DOCMONT)
  message(FATAL_ERROR "DOCMONT executable path is required")
endif()
if(NOT DEFINED SOURCE_DIR)
  message(FATAL_ERROR "SOURCE_DIR is required")
endif()
execute_process(
  COMMAND "${DOCMONT}" run "${SOURCE_DIR}/examples/language_4_60.docm"
  RESULT_VARIABLE rc OUTPUT_VARIABLE out ERROR_VARIABLE err
)
if(NOT rc EQUAL 0)
  message(FATAL_ERROR "DOCMONT lambda example failed (${rc}): ${err}")
endif()
string(REPLACE "\r\n" "\n" out "${out}")
set(expected "21\n15\n12\nfunction\n")
if(NOT out STREQUAL expected)
  message(FATAL_ERROR "Unexpected lambda output. Expected [${expected}], got [${out}]")
endif()
