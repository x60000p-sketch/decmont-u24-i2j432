#include "docmont/skeletal_animation.hpp"
#include <cassert>
#include <cmath>
#include <iostream>
using namespace docmont;using namespace docmont::animation;
int main(){
    Skeleton s;assert(s.add_bone({"root",-1,{},math::Mat4::identity()}));Transform child;child.translation={0,1,0};assert(s.add_bone({"hand",0,child,math::Mat4::identity()}));assert(s.validate());assert(s.find_bone("hand")==1);
    AnimationClip clip;clip.name="reach";clip.duration=1;clip.looping=false;BoneTrack track;track.bone=1;track.translations={{{0},{0,1,0}},{{1},{2,1,0}}};track.rotations={{{0},{0,0,0,1}},{{1},{0,0,0,1}}};clip.tracks.push_back(track);std::string error;assert(Animator::validate_clip(s,clip,&error));
    auto pose=Animator::sample(s,clip,0.5f);assert(std::abs(pose.local[1].translation.x-1.0f)<1e-5f);
    auto matrices=Animator::build_matrices(s,pose,&error);assert(matrices&&matrices->skin.size()==2);
    std::vector<SkinnedVertex> vertices{{{1,0,0},{0,1,0}}};BoneInfluence influence;influence.indices[0]=1;influence.weights[0]=1;auto skinned=Animator::skin(*matrices,vertices,{influence},&error);assert(skinned&&std::abs(skinned->front().position.x-2.0f)<1e-5f);
    auto base=Animator::bind_pose(s);auto blended=Animator::blend(base,pose,0.5f,&error);assert(blended&&std::abs(blended->local[1].translation.x-0.5f)<1e-5f);
    clip.tracks[0].translations[1].time=2;assert(!Animator::validate_clip(s,clip,&error));
    BoneInfluence bad;bad.indices[0]=9;bad.weights[0]=1;assert(!Animator::skin(*matrices,vertices,{bad},&error));
    Skeleton cycle;assert(cycle.add_bone({"a",-1,{},math::Mat4::identity()}));assert(!cycle.add_bone({"b",1,{},{}}));
    std::cout<<"DOCMONT skeletal animation sampling, hierarchy, blending and CPU skinning passed\n";
}
