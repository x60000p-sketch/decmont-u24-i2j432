#include "docmont/ir.hpp"
#include "docmont/runtime.hpp"
#include <cassert>
#include <cstdint>

int main() {
    docmont::ProgramIR ir;
    ir.name = "stack_limit_regression";
    ir.target = "x86_64";
    ir.code.reserve(65538);
    for (int i = 0; i < 65537; ++i)
        ir.code.push_back({docmont::OpCode::PushInt, {}, 0, 1});
    ir.code.push_back({docmont::OpCode::MakeArray, {}, 65537, 1});
    // execute() must stop before allocating the oversized array.
    assert(docmont::execute(ir) == 1);
    return 0;
}
