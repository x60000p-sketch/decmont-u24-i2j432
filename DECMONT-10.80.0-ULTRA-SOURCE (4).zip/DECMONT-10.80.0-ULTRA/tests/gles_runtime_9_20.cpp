#include "docmont/gles_runtime.hpp"
#include <cassert>
#include <cmath>
#include <iostream>
int main(){
    auto info=docmont::gpu::probe_gles();
    if(!info.available){
        std::cout<<"DOCMONT GLES backend unavailable on this host ("<<info.detail<<"); platform skip\n";
        return 0;
    }
    assert(!info.renderer.empty()&&!info.version.empty());
    auto frame=docmont::gpu::render_triangle_offscreen(64,64);
    if(!frame.ok){std::cerr<<frame.error<<'\n';return 1;}
    assert(frame.rgba.size()==64u*64u*4u);
    const auto px=(32u*64u+32u)*4u;
    assert(frame.rgba[px]>150&&frame.rgba[px+1]<100&&frame.rgba[px+3]>200);
    if(info.compute_supported){
        const std::vector<float> a={1,2,3,4,5,6};
        const std::vector<float> b={1,2,3,4,5,6};
        auto product=docmont::gpu::compute_matmul(a,2,3,b,2,false);
        if(!product.ok){std::cerr<<product.error<<'\n';return 2;}
        assert(product.values.size()==4);
        assert(std::abs(product.values[0]-22.0f)<1e-4f);
        assert(std::abs(product.values[1]-28.0f)<1e-4f);
        assert(std::abs(product.values[2]-49.0f)<1e-4f);
        assert(std::abs(product.values[3]-64.0f)<1e-4f);
        auto relu=docmont::gpu::compute_matmul({-1,0,0,1},2,2,{1,0,0,1},2,true);
        assert(relu.ok&&relu.values==std::vector<float>({0,0,0,1}));
    }
    std::cout<<"DOCMONT 9.20 EGL/GLES offscreen renderer passed; renderer="<<info.renderer
             <<"; compute="<<(info.compute_supported?"yes":"no")
             <<"; hardware="<<(info.hardware_accelerated?"yes":"no")<<'\n';
}
