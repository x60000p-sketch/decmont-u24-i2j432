#!/usr/bin/env python3
import os, subprocess, sys, tempfile
from pathlib import Path
script=Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory(prefix="docmont-shader-test-") as td:
    root=Path(td);src=root/"sample.vert";src.write_text("#version 450\nvoid main(){gl_Position=vec4(0.0);}\n")
    fake=root/"glslc";log=root/"args.txt";fake.write_text("#!/usr/bin/env python3\nimport pathlib,sys\na=sys.argv[1:]\npathlib.Path("+repr(str(log))+ ").write_text('\\n'.join(a))\nout=pathlib.Path(a[a.index('-o')+1]);out.write_bytes(b'SPIRV')\n") ;fake.chmod(0o755)
    out=root/"sample.spv"
    dry=subprocess.run([str(script),"vulkan",str(src),"-o",str(out),"--compiler",str(fake),"--dry-run"],text=True,capture_output=True)
    assert dry.returncode==0,(dry.stdout,dry.stderr)
    assert not out.exists()
    run=subprocess.run([str(script),"vulkan",str(src),"-o",str(out),"--compiler",str(fake)],text=True,capture_output=True)
    assert run.returncode==0,(run.stdout,run.stderr)
    args=log.read_text().splitlines()
    assert "--target-env=vulkan1.2" in args and out.is_file() and out.read_bytes()==b"SPIRV"
print("DOCMONT shader pipeline tests passed: compiler selection, target flags, dry-run and artifact validation")
