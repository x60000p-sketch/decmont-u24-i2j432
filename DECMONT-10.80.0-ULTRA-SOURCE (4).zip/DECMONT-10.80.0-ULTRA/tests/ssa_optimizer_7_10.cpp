#include "docmont/optimizer.hpp"
#include "docmont/bytecode.hpp"
#include "docmont/ssa.hpp"
#include <cassert>
#include <string>
using namespace docmont;

static std::size_t count_temp_loads(const ProgramIR& p) {
    std::size_t count = 0;
    for (const auto& ins : p.code)
        if (ins.op == OpCode::Load && ins.operand.rfind("__docmont_ssa_gvn_", 0) == 0) ++count;
    return count;
}

int main() {
    // A dominating expression is reused in a later basic block reached by an
    // unconditional edge. The optimizer must carry the identical SSA value
    // representative across the edge and preserve valid branch offsets.
    ProgramIR sequential;
    sequential.code = {
        {OpCode::Load, "x", 0, 1}, {OpCode::Load, "y", 0, 1}, {OpCode::Add, {}, 0, 1}, {OpCode::Print, {}, 0, 1},
        {OpCode::Load, "condition", 0, 2}, {OpCode::JumpIfZero, {}, 10, 2},
        {OpCode::Load, "x", 0, 3}, {OpCode::Load, "y", 0, 3}, {OpCode::Add, {}, 0, 3}, {OpCode::Print, {}, 0, 3},
        {OpCode::PushInt, {}, 0, 4}, {OpCode::Return, {}, 0, 4}
    };
    const auto seq_stats = optimize_ir(sequential);
    assert(seq_stats.ssa_gvn_eliminations == 1);
    assert(seq_stats.ssa_gvn_cross_block_eliminations == 1);
    assert(count_temp_loads(sequential) >= 2); // representative reload + eliminated reload
    assert(encode_bytecode(sequential).ok);
    assert(verify_ssa(build_ssa(sequential), sequential).ok);

    // A common expression remains available at a diamond join only if every
    // predecessor carries the same representative.
    ProgramIR diamond;
    diamond.code = {
        {OpCode::Load, "x", 0, 1}, {OpCode::Load, "y", 0, 1}, {OpCode::Add, {}, 0, 1}, {OpCode::Print, {}, 0, 1},
        {OpCode::Load, "condition", 0, 2}, {OpCode::JumpIfZero, {}, 8, 2},
        {OpCode::Jump, {}, 10, 3}, {OpCode::Return, {}, 0, 3},
        {OpCode::Jump, {}, 10, 4}, {OpCode::Return, {}, 0, 4},
        {OpCode::Load, "z", 0, 5}, {OpCode::Print, {}, 0, 5},
        {OpCode::Load, "x", 0, 6}, {OpCode::Load, "y", 0, 6}, {OpCode::Add, {}, 0, 6}, {OpCode::Print, {}, 0, 6}
    };
    const auto diamond_stats = optimize_ir(diamond);
    assert(diamond_stats.ssa_gvn_eliminations == 1);
    assert(diamond_stats.ssa_gvn_cross_block_eliminations == 1);
    assert(encode_bytecode(diamond).ok);
    assert(verify_ssa(build_ssa(diamond), diamond).ok);

    // If one path crosses a call (an effect barrier), the value is not
    // available at the join and must be recomputed there.
    ProgramIR barrier;
    barrier.code = {
        {OpCode::Load, "x", 0, 1}, {OpCode::Load, "y", 0, 1}, {OpCode::Add, {}, 0, 1}, {OpCode::Print, {}, 0, 1},
        {OpCode::Load, "condition", 0, 2}, {OpCode::JumpIfZero, {}, 10, 2},
        {OpCode::Call, "mutate", 0, 3}, {OpCode::Print, {}, 0, 3}, {OpCode::Jump, {}, 12, 3}, {OpCode::Return, {}, 0, 3},
        {OpCode::Jump, {}, 12, 4}, {OpCode::Return, {}, 0, 4},
        {OpCode::Load, "z", 0, 5}, {OpCode::Print, {}, 0, 5},
        {OpCode::Load, "x", 0, 6}, {OpCode::Load, "y", 0, 6}, {OpCode::Add, {}, 0, 6}, {OpCode::Print, {}, 0, 6}
    };
    const auto barrier_stats = optimize_ir(barrier);
    assert(barrier_stats.ssa_gvn_cross_block_eliminations == 0);
    assert(barrier_stats.ssa_gvn_eliminations == 0);
    assert(encode_bytecode(barrier).ok);
    assert(verify_ssa(build_ssa(barrier), barrier).ok);

    // Expressions are not materialized into compiler temporaries unless a
    // later common-subexpression use actually reuses them.
    ProgramIR unique_only;
    unique_only.code = {
        {OpCode::Load, "a", 0, 1}, {OpCode::Load, "b", 0, 1}, {OpCode::Add, {}, 0, 1}, {OpCode::Print, {}, 0, 1}
    };
    const auto unique_stats = optimize_ir(unique_only);
    assert(unique_stats.ssa_gvn_eliminations == 0);
    assert(count_temp_loads(unique_only) == 0);
    assert(encode_bytecode(unique_only).ok);
}
