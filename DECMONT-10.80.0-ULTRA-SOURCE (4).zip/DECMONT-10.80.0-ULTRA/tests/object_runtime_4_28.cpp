#include "docmont/object_runtime.hpp"
#include <cassert>
#include <string>
#include <thread>
#include <vector>

struct Widget { explicit Widget(int n, std::string s = "x") : value(n), name(std::move(s)) {} int value; std::string name; };
struct Other { int n{7}; };

int main() {
    using docmont::objects::ObjectRuntime;
    ObjectRuntime runtime;
    auto h = runtime.create<Widget>(42, "runtime");
    assert(h && runtime.alive(h));
    assert(runtime.get<Widget>(h)->value == 42);
    assert(runtime.get<Widget>(h)->name == "runtime");
    assert(runtime.reference_count(h) == 1);
    assert(!runtime.get<Other>(h));
    assert(runtime.retain(h) && runtime.reference_count(h) == 2);
    {
        auto root = runtime.root(h);
        assert(root && runtime.reference_count(h) == 3);
        auto copy = root;
        assert(runtime.reference_count(h) == 4);
        auto moved = std::move(copy);
        assert(!copy && moved);
    }
    assert(runtime.reference_count(h) == 2);
    assert(runtime.release(h) && runtime.alive(h));
    assert(runtime.release(h) && !runtime.alive(h));
    assert(runtime.get<Widget>(h) == nullptr);
    auto replacement = runtime.create<Other>();
    assert(replacement.index == h.index && replacement.generation != h.generation);
    assert(!runtime.retain(h));
    assert(runtime.type_name(replacement).find("Other") != std::string::npos || !runtime.type_name(replacement).empty());
    auto records = runtime.snapshot();
    assert(records.size() == 1 && records[0].handle == replacement);
    assert(runtime.validate());

    // Concurrent handle retain/release operations are serialized by the runtime.
    std::vector<std::thread> workers;
    for (int i = 0; i < 4; ++i) workers.emplace_back([&] {
        for (int n = 0; n < 1000; ++n) { assert(runtime.retain(replacement)); assert(runtime.release(replacement)); }
    });
    for (auto& worker : workers) worker.join();
    assert(runtime.reference_count(replacement) == 1);
    auto stats = runtime.stats();
    assert(stats.live_objects == 1 && stats.total_created == 2 && stats.total_destroyed == 1);
    assert(stats.retain_operations >= 4002 && stats.release_operations >= 4002);
    assert(stats.stale_handle_rejections >= 2);
    runtime.clear();
    assert(!runtime.alive(replacement) && runtime.stats().live_objects == 0);
    assert(runtime.validate());
}
