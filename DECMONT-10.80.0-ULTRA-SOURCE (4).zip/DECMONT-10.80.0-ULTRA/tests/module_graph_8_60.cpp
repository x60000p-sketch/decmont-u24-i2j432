#include "docmont/module_system.hpp"
#include <cassert>
#include <filesystem>
#include <fstream>
#include <iostream>
static void write(const std::filesystem::path& p,const char* s){std::ofstream out(p);out<<s;}
int main(){
    auto root=std::filesystem::temp_directory_path()/"docmont-module-graph-8-60";std::filesystem::remove_all(root);std::filesystem::create_directories(root);
    auto entry=root/"main.docm";write(entry,"import alpha\n");write(root/"alpha.docm","import beta\n");write(root/"beta.docm","!docmont[2]\n");
    docmont::modules::Resolver resolver(root);auto ok=resolver.resolve(entry);assert(ok.ok()&&ok.order.size()==3);
    write(root/"beta.docm","import alpha\n");auto cycle=resolver.resolve(entry);assert(!cycle.ok());bool saw_cycle=false;for(const auto& d:cycle.diagnostics)if(d.code=="MOD004")saw_cycle=true;assert(saw_cycle);
    std::filesystem::remove_all(root);std::cout<<"DOCMONT 8.60.0 module graph tests passed\n";
}
