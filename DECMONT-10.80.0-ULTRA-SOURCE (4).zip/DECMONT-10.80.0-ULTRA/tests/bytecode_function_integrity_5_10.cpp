#include "docmont/bytecode.hpp"
#include <cassert>
#include <string>
using namespace docmont;

static bool verifies(ProgramIR ir, const std::string& expected = {}) {
    auto encoded = encode_bytecode(ir);
    assert(encoded.ok);
    auto result = verify_bytecode(encoded.bytes);
    if (expected.empty()) return result.ok;
    return !result.ok && result.message.find(expected) != std::string::npos;
}

int main() {
    ProgramIR valid;
    valid.name = "integrity";
    valid.code = {
        {OpCode::PushInt, {}, 7, 1},
        {OpCode::Call, "identity", 1, 1},
        {OpCode::Print, {}, 0, 1},
        {OpCode::Jump, {}, 8, 1},
        {OpCode::Function, "identity", 1, 2},
        {OpCode::Store, "value", 0, 2},
        {OpCode::Load, "value", 0, 3},
        {OpCode::Return, {}, 0, 3}
    };
    assert(verifies(valid));

    auto missing = valid;
    missing.code[1].operand = "missing";
    assert(verifies(missing, "call to undefined function"));

    auto mismatch = valid;
    mismatch.code[1].integer = 0;
    assert(verifies(mismatch, "function call arity mismatch"));

    auto duplicate = valid;
    duplicate.code.insert(duplicate.code.end(), {
        {OpCode::Function, "identity", 1, 9},
        {OpCode::PushInt, {}, 0, 9},
        {OpCode::Return, {}, 0, 9}
    });
    assert(verifies(duplicate, "duplicate function declaration"));

    auto dangling_ref = valid;
    dangling_ref.code.insert(dangling_ref.code.begin(), {OpCode::LoadFunction, "ghost", 0, 1});
    // The existing jump still targets the old end; function reference validation
    // happens before control-flow verification and must reject this image.
    assert(verifies(dangling_ref, "unresolved function reference"));
    return 0;
}
