#include "docmont/bytecode.hpp"
#include "docmont/optimizer.hpp"
#include "docmont/runtime.hpp"
#include "docmont/ssa.hpp"
#include <algorithm>
#include <cassert>
#include <iostream>
#include <sstream>
using namespace docmont;
static std::string run_vm(const ProgramIR& ir) {
    auto encoded = encode_bytecode(ir); assert(encoded.ok);
    std::ostringstream output; auto* old = std::cout.rdbuf(output.rdbuf());
    const auto status = execute_bytecode(encoded.bytes); std::cout.rdbuf(old);
    assert(status == 0); return output.str();
}
static std::size_t count_op(const ProgramIR& ir, OpCode op) {
    return static_cast<std::size_t>(std::count_if(ir.code.begin(), ir.code.end(),
        [&](const Instruction& x) { return x.op == op; }));
}
int main() {
    ProgramIR ir;
    ir.code = {
        {OpCode::PushInt, {}, 10, 1}, {OpCode::PushInt, {}, 20, 1},
        {OpCode::MakeArray, {}, 2, 1}, {OpCode::Store, "items", 0, 1},
        {OpCode::Load, "items", 0, 2}, {OpCode::PushInt, {}, 0, 2},
        {OpCode::ArrayGet, {}, 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Load, "items", 0, 3}, {OpCode::PushInt, {}, 1, 3},
        {OpCode::PushInt, {}, 99, 3}, {OpCode::ArraySet, {}, 0, 3},
        {OpCode::Load, "items", 0, 4}, {OpCode::PushInt, {}, 0, 4},
        {OpCode::ArrayGet, {}, 0, 4}, {OpCode::Print, {}, 0, 4}
    };
    const auto ssa = build_ssa(ir);
    assert(verify_ssa(ssa, ir).ok);
    const auto read0 = std::find_if(ssa.memory_uses.begin(), ssa.memory_uses.end(),
        [](const SSAMemoryUse& u) { return u.instruction == 6 && u.partition_key == "array:2:0"; });
    const auto write1 = std::find_if(ssa.memory_definitions.begin(), ssa.memory_definitions.end(),
        [](const SSAMemoryDefinition& d) { return d.instruction == 11 && d.partition_key == "array:2:1"; });
    assert(read0 != ssa.memory_uses.end());
    assert(write1 != ssa.memory_definitions.end());
    const auto read0_again = std::find_if(ssa.memory_uses.begin(), ssa.memory_uses.end(),
        [](const SSAMemoryUse& u) { return u.instruction == 14 && u.partition_key == "array:2:0"; });
    assert(read0_again != ssa.memory_uses.end() && read0_again->version == read0->version);
    const auto before = run_vm(ir);
    const auto stats = optimize_ir(ir);
    assert(stats.ssa_memory_load_eliminations == 1);
    assert(count_op(ir, OpCode::ArrayGet) == 1);
    assert(run_vm(ir) == before);

    // A dynamic index write must conservatively invalidate all known slots.
    ProgramIR dynamic;
    dynamic.code = {
        {OpCode::PushInt, {}, 10, 1}, {OpCode::PushInt, {}, 20, 1},
        {OpCode::MakeArray, {}, 2, 1}, {OpCode::Store, "items", 0, 1},
        {OpCode::Load, "items", 0, 2}, {OpCode::PushInt, {}, 0, 2},
        {OpCode::ArrayGet, {}, 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Load, "items", 0, 3}, {OpCode::Load, "idx", 0, 3},
        {OpCode::PushInt, {}, 77, 3}, {OpCode::ArraySet, {}, 0, 3},
        {OpCode::Load, "items", 0, 4}, {OpCode::PushInt, {}, 0, 4},
        {OpCode::ArrayGet, {}, 0, 4}, {OpCode::Print, {}, 0, 4}
    };
    const auto dynamic_ssa = build_ssa(dynamic);
    assert(verify_ssa(dynamic_ssa, dynamic).ok);
    const auto dynamic_before = std::find_if(dynamic_ssa.memory_uses.begin(), dynamic_ssa.memory_uses.end(),
        [](const SSAMemoryUse& u) { return u.instruction == 6 && u.partition_key == "array:2:0"; });
    const auto dynamic_after = std::find_if(dynamic_ssa.memory_uses.begin(), dynamic_ssa.memory_uses.end(),
        [](const SSAMemoryUse& u) { return u.instruction == 14 && u.partition_key == "array:2:0"; });
    assert(dynamic_before != dynamic_ssa.memory_uses.end() && dynamic_after != dynamic_ssa.memory_uses.end());
    assert(dynamic_before->version != dynamic_after->version);
    assert(optimize_ir(dynamic).ssa_memory_load_eliminations == 0);
    assert(count_op(dynamic, OpCode::ArrayGet) == 2);
    std::cout << "DOCMONT 8.10.0 compatibility regression tests passed\n";
}
