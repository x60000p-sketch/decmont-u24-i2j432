#include "docmont/ssa.hpp"
#include "docmont/optimizer.hpp"
#include "docmont/bytecode.hpp"
#include "docmont/runtime.hpp"
#include <algorithm>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <sstream>
using namespace docmont;

static std::string run_vm(const ProgramIR& ir) {
    auto encoded = encode_bytecode(ir); assert(encoded.ok);
    std::ostringstream output; auto* old = std::cout.rdbuf(output.rdbuf());
    const auto status = execute_bytecode(encoded.bytes); std::cout.rdbuf(old);
    assert(status == 0); return output.str();
}

static const SSAPointsToSet* points(const SSAProgram& ssa, std::size_t value) {
    auto it = std::find_if(ssa.points_to_sets.begin(), ssa.points_to_sets.end(),
        [&](const SSAPointsToSet& item) { return item.value == value; });
    return it == ssa.points_to_sets.end() ? nullptr : &*it;
}

int main() {
    // Outer[0] contains an inner allocation. Resolving the outer constant-index
    // load must recover the inner allocation site and its independent slot SSA.
    ProgramIR nested;
    nested.code = {
        {OpCode::PushInt, {}, 11, 1}, {OpCode::PushInt, {}, 22, 1},
        {OpCode::MakeArray, {}, 2, 1}, {OpCode::Store, "inner", 0, 1},
        {OpCode::Load, "inner", 0, 2}, {OpCode::PushInt, {}, 7, 2},
        {OpCode::MakeArray, {}, 2, 2}, {OpCode::Store, "outer", 0, 2},
        {OpCode::Load, "outer", 0, 3}, {OpCode::PushInt, {}, 0, 3},
        {OpCode::ArrayGet, {}, 0, 3}, {OpCode::Store, "selected", 0, 3},
        {OpCode::Load, "selected", 0, 4}, {OpCode::PushInt, {}, 0, 4},
        {OpCode::ArrayGet, {}, 0, 4}, {OpCode::Print, {}, 0, 4}
    };
    const auto nested_ssa = build_ssa(nested);
    assert(verify_ssa(nested_ssa, nested).ok);
    auto nested_load = std::find_if(nested_ssa.value_definitions.begin(), nested_ssa.value_definitions.end(),
        [](const SSAValueDefinition& d) { return d.instruction == 10 && d.op == OpCode::ArrayGet; });
    assert(nested_load != nested_ssa.value_definitions.end());
    const auto* nested_points = points(nested_ssa, nested_load->id);
    assert(nested_points && !nested_points->unknown);
    assert(std::find(nested_points->allocation_sites.begin(), nested_points->allocation_sites.end(), 2) != nested_points->allocation_sites.end());
    auto inner_read = std::find_if(nested_ssa.memory_uses.begin(), nested_ssa.memory_uses.end(),
        [](const SSAMemoryUse& u) { return u.instruction == 14 && u.partition_key == "array:2:0"; });
    assert(inner_read != nested_ssa.memory_uses.end());

    // Constant arithmetic is resolved for the array selector (0 + 1).
    ProgramIR computed;
    computed.code = {
        {OpCode::PushInt, {}, 10, 1}, {OpCode::PushInt, {}, 20, 1},
        {OpCode::MakeArray, {}, 2, 1}, {OpCode::Store, "items", 0, 1},
        {OpCode::Load, "items", 0, 2}, {OpCode::PushInt, {}, 0, 2},
        {OpCode::PushInt, {}, 1, 2}, {OpCode::Add, {}, 0, 2},
        {OpCode::ArrayGet, {}, 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Load, "items", 0, 3}, {OpCode::PushInt, {}, 0, 3},
        {OpCode::PushInt, {}, 1, 3}, {OpCode::Add, {}, 0, 3},
        {OpCode::PushInt, {}, 99, 3}, {OpCode::ArraySet, {}, 0, 3}
    };
    const auto computed_ssa = build_ssa(computed);
    assert(verify_ssa(computed_ssa, computed).ok);
    auto computed_read = std::find_if(computed_ssa.memory_uses.begin(), computed_ssa.memory_uses.end(),
        [](const SSAMemoryUse& u) { return u.instruction == 8 && u.partition_key == "array:2:1"; });
    auto computed_write = std::find_if(computed_ssa.memory_definitions.begin(), computed_ssa.memory_definitions.end(),
        [](const SSAMemoryDefinition& d) { return d.instruction == 15 && d.partition_key == "array:2:1"; });
    assert(computed_read != computed_ssa.memory_uses.end());
    assert(computed_write != computed_ssa.memory_definitions.end());

    // A computed constant write to slot 1 must preserve a cached read of slot 0.
    ProgramIR optimizer_case;
    optimizer_case.code = {
        {OpCode::PushInt, {}, 10, 1}, {OpCode::PushInt, {}, 20, 1},
        {OpCode::MakeArray, {}, 2, 1}, {OpCode::Store, "items", 0, 1},
        {OpCode::Load, "items", 0, 2}, {OpCode::PushInt, {}, 0, 2},
        {OpCode::ArrayGet, {}, 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::Load, "items", 0, 3}, {OpCode::PushInt, {}, 0, 3},
        {OpCode::PushInt, {}, 1, 3}, {OpCode::Add, {}, 0, 3},
        {OpCode::PushInt, {}, 99, 3}, {OpCode::ArraySet, {}, 0, 3},
        {OpCode::Load, "items", 0, 4}, {OpCode::PushInt, {}, 0, 4},
        {OpCode::ArrayGet, {}, 0, 4}, {OpCode::Print, {}, 0, 4}
    };
    const auto optimizer_before = run_vm(optimizer_case);
    const auto optimizer_stats = optimize_ir(optimizer_case);
    assert(optimizer_stats.ssa_memory_load_eliminations == 1);
    assert(run_vm(optimizer_case) == optimizer_before);

    // Overflowing compile-time selectors must remain unknown and never be
    // folded into an arbitrary array partition.
    ProgramIR overflow;
    overflow.code = {
        {OpCode::PushInt, {}, 1, 1}, {OpCode::PushInt, {}, 2, 1},
        {OpCode::MakeArray, {}, 2, 1}, {OpCode::Store, "a", 0, 1},
        {OpCode::Load, "a", 0, 2},
        {OpCode::PushInt, {}, INT64_MAX, 2}, {OpCode::PushInt, {}, 1, 2},
        {OpCode::Add, {}, 0, 2}, {OpCode::ArrayGet, {}, 0, 2}, {OpCode::Print, {}, 0, 2}
    };
    const auto overflow_ssa = build_ssa(overflow);
    assert(verify_ssa(overflow_ssa, overflow).ok);
    assert(std::none_of(overflow_ssa.memory_uses.begin(), overflow_ssa.memory_uses.end(),
        [](const SSAMemoryUse& u) { return u.instruction == 8 && u.partition_key.rfind("array:", 0) == 0; }));

    std::cout << "DOCMONT 8.20.0 nested-array and selector-analysis tests passed\n";
}
