#include "docmont/render_graph.hpp"
#include <cassert>
#include <iostream>

int main() {
    using namespace docmont::render;
    RenderGraph graph;
    auto imported = graph.resource("swapchain", true);
    auto a = graph.resource(ResourceDesc{"gbuffer", 4096, 256, false, true});
    auto b = graph.resource(ResourceDesc{"lighting", 2048, 256, false, true});
    auto c = graph.resource(ResourceDesc{"postfx", 1024, 256, false, true});
    auto p0 = graph.pass(PassDesc{"geometry", {}, {a}, {}});
    auto p1 = graph.pass(PassDesc{"lighting", {a}, {b}, {}});
    auto p2 = graph.pass(PassDesc{"post", {b}, {c}, {}});
    auto p3 = graph.pass(PassDesc{"present", {c}, {imported}, {}});
    (void)p0; (void)p1; (void)p2; (void)p3;
    auto plan = graph.compile_detailed();
    assert(plan.ok && plan.order.size()==4);
    assert(plan.lifetimes.size()==4);
    assert(plan.barriers.size()>=3);
    // gbuffer, lighting and postfx have disjoint lifetimes and can reuse one allocation.
    std::size_t slot_a=static_cast<std::size_t>(-1),slot_b=slot_a,slot_c=slot_a;
    for(const auto& l:plan.lifetimes){if(l.resource==a)slot_a=l.alias_slot;if(l.resource==b)slot_b=l.alias_slot;if(l.resource==c)slot_c=l.alias_slot;}
    assert(slot_a!=static_cast<std::size_t>(-1));
    // Adjacent pass lifetimes overlap when a pass reads one resource and writes another.
    assert(slot_a!=slot_b && slot_b!=slot_c);
    RenderGraph alias_graph;
    auto x=alias_graph.resource(ResourceDesc{"scratch-x",1024,256,false,true});
    auto y=alias_graph.resource(ResourceDesc{"scratch-y",512,256,false,true});
    alias_graph.pass(PassDesc{"write-x",{}, {x}, {}});
    alias_graph.pass(PassDesc{"consume-x",{x},{}, {}});
    alias_graph.pass(PassDesc{"write-y",{}, {y}, {}});
    auto alias_plan=alias_graph.compile_detailed();
    assert(alias_plan.ok && alias_plan.transient_allocations.size()==1);
    assert(alias_plan.lifetimes[0].alias_slot==alias_plan.lifetimes[1].alias_slot);
    bool rejected=false;
    try { graph.resource(ResourceDesc{"bad-align",128,3,false,true}); }
    catch(const std::invalid_argument&) { rejected=true; }
    assert(rejected);
    RenderGraph invalid;
    auto transient=invalid.resource("transient",false);
    invalid.pass(PassDesc{"read-before-write",{transient},{},{}});
    assert(!invalid.compile_detailed().ok);
    RenderGraph hazards;
    auto history=hazards.resource("history",true);
    auto hread=hazards.pass(PassDesc{"history-read",{history},{},{}});
    auto hwrite=hazards.pass(PassDesc{"history-write",{},{history},{}});
    auto hazard_plan=hazards.compile_detailed();
    assert(hazard_plan.ok);
    bool war=false;for(const auto& barrier:hazard_plan.barriers)if(barrier.resource==history&&barrier.source==hread&&barrier.destination==hwrite)war=true;
    assert(war); // write-after-read barrier must preserve the preceding reader.
    std::cout << "DOCMONT 9.30 detailed render graph passed; alias slots=" << plan.transient_allocations.size()
              << "; barriers=" << plan.barriers.size() << '\n';
}
