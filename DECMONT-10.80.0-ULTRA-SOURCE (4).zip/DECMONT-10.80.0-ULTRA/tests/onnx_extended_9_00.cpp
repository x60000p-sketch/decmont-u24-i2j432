#include "docmont/onnx_runtime.hpp"
#include <cassert>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <map>
#include <iostream>
#include <string>
#include <vector>
using namespace docmont::neural;
namespace {
void varint(std::vector<std::uint8_t>& o,std::uint64_t v){while(v>=128){o.push_back(static_cast<std::uint8_t>(v)|0x80);v>>=7;}o.push_back(static_cast<std::uint8_t>(v));}
void tag(std::vector<std::uint8_t>& o,unsigned f,unsigned w){varint(o,(f<<3)|w);}
void bytes(std::vector<std::uint8_t>& o,unsigned f,const std::vector<std::uint8_t>& b){tag(o,f,2);varint(o,b.size());o.insert(o.end(),b.begin(),b.end());}
void text(std::vector<std::uint8_t>& o,unsigned f,const std::string& s){bytes(o,f,{s.begin(),s.end()});}
std::vector<std::uint8_t> packed(std::initializer_list<std::int64_t> xs){std::vector<std::uint8_t> b;for(auto x:xs)varint(b,static_cast<std::uint64_t>(x));return b;}
std::vector<std::uint8_t> value_info(const std::string& n){std::vector<std::uint8_t>b;text(b,1,n);return b;}
std::vector<std::uint8_t> integer_attr(const std::string& name,std::int64_t value){std::vector<std::uint8_t>a;text(a,1,name);tag(a,3,0);varint(a,static_cast<std::uint64_t>(value));return a;}
std::vector<std::uint8_t> integers_attr(const std::string& name,std::initializer_list<std::int64_t> values){std::vector<std::uint8_t>a;text(a,1,name);bytes(a,8,packed(values));return a;}
std::vector<std::uint8_t> float_attr(const std::string& name,float value){std::vector<std::uint8_t>a;text(a,1,name);tag(a,2,5);std::uint32_t u;std::memcpy(&u,&value,4);for(int i=0;i<4;++i)a.push_back(static_cast<std::uint8_t>(u>>(8*i)));return a;}
std::vector<std::uint8_t> node(const std::string& op,const std::vector<std::string>& inputs,const std::string& output,const std::vector<std::vector<std::uint8_t>>& attrs={}){std::vector<std::uint8_t>n;for(const auto& x:inputs)text(n,1,x);text(n,2,output);text(n,4,op);for(const auto&a:attrs)bytes(n,5,a);return n;}
std::vector<std::uint8_t> model(const std::vector<std::vector<std::uint8_t>>& nodes,const std::vector<std::string>& inputs,const std::vector<std::string>& outputs){std::vector<std::uint8_t>g;for(const auto&n:nodes)bytes(g,1,n);text(g,2,"extended-9.00");for(const auto&i:inputs)bytes(g,11,value_info(i));for(const auto&o:outputs)bytes(g,12,value_info(o));std::vector<std::uint8_t>m;tag(m,1,0);varint(m,8);bytes(m,7,g);return m;}
Tensor run_one(const std::vector<std::uint8_t>& model_bytes,const std::map<std::string,Tensor>& inputs){OnnxModel m;std::string e;assert(m.load_bytes(model_bytes,&e)&&e.empty());auto r=m.run(inputs);assert(r.ok&&r.outputs.size()==1);return r.outputs.begin()->second;}
bool near(float a,float b){return std::abs(a-b)<1e-5f;}
}
int main(){
    auto flat=run_one(model({node("Flatten",{"X"},"Y",{integer_attr("axis",1)})},{"X"},{"Y"}),{{"X",Tensor{{2,2,2},{0,1,2,3,4,5,6,7}}}});
    assert(flat.shape==std::vector<std::int64_t>({2,4})&&flat.values.size()==8);
    auto trans=run_one(model({node("Transpose",{"X"},"Y",{integers_attr("perm",{1,0})})},{"X"},{"Y"}),{{"X",Tensor{{2,3},{1,2,3,4,5,6}}}});
    assert(trans.shape==std::vector<std::int64_t>({3,2})&&trans.values==std::vector<float>({1,4,2,5,3,6}));
    auto mean=run_one(model({node("ReduceMean",{"X"},"Y",{integers_attr("axes",{1}),integer_attr("keepdims",0)})},{"X"},{"Y"}),{{"X",Tensor{{2,2},{1,2,3,4}}}});
    assert(mean.shape==std::vector<std::int64_t>({2})&&near(mean.values[0],1.5f)&&near(mean.values[1],3.5f));
    auto concat=run_one(model({node("Concat",{"A","B"},"Y",{integer_attr("axis",1)})},{"A","B"},{"Y"}),{{"A",Tensor{{1,2},{1,2}}},{"B",Tensor{{1,2},{3,4}}}});
    assert(concat.shape==std::vector<std::int64_t>({1,4})&&concat.values==std::vector<float>({1,2,3,4}));
    auto sub=run_one(model({node("Sub",{"A","B"},"Y")},{"A","B"},{"Y"}),{{"A",Tensor{{2},{5,9}}},{"B",Tensor{{1},{2}}}});
    assert(sub.values==std::vector<float>({3,7}));
    auto div=run_one(model({node("Div",{"A","B"},"Y")},{"A","B"},{"Y"}),{{"A",Tensor{{2},{6,8}}},{"B",Tensor{{1},{2}}}});
    assert(div.values==std::vector<float>({3,4}));
    auto clip=run_one(model({node("Clip",{"X"},"Y",{float_attr("min",-1.0f),float_attr("max",1.0f)})},{"X"},{"Y"}),{{"X",Tensor{{3},{-3,0.5f,4}}}});
    assert(clip.values==std::vector<float>({-1,0.5f,1}));
    auto leak=run_one(model({node("LeakyRelu",{"X"},"Y",{float_attr("alpha",0.1f)})},{"X"},{"Y"}),{{"X",Tensor{{2},{-2,3}}}});
    assert(near(leak.values[0],-0.2f)&&near(leak.values[1],3));
    OnnxModel unsupported;std::string e;assert(unsupported.load_bytes(model({node("Conv",{"X"},"Y")},{"X"},{"Y"}),&e));assert(unsupported.info().unsupported_operators.size()==1&&unsupported.info().unsupported_operators[0]=="Conv");assert(!unsupported.run({{"X",Tensor{{1},{1}}}}).ok);
    const auto ops=supported_operators();assert(ops.size()>=23);
    std::cout<<"DOCMONT 9.00 ONNX CPU extensions passed: broadcast arithmetic, Flatten, Transpose, ReduceMean, Concat, Clip, LeakyRelu\n";
}
