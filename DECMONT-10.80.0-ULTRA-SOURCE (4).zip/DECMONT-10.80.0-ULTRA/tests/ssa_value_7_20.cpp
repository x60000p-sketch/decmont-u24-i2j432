#include "docmont/ssa.hpp"
#include "docmont/optimizer.hpp"
#include "docmont/bytecode.hpp"
#include <cassert>
#include <algorithm>
using namespace docmont;

int main() {
    // Operand-stack expressions are represented as SSA values with explicit
    // data dependencies, not merely inferred from variable Load/Store pairs.
    ProgramIR arithmetic;
    arithmetic.code = {
        {OpCode::PushInt, {}, 2, 1}, {OpCode::PushInt, {}, 3, 1},
        {OpCode::Add, {}, 0, 1}, {OpCode::PushInt, {}, 4, 1},
        {OpCode::Mul, {}, 0, 1}, {OpCode::Print, {}, 0, 1}
    };
    auto values = build_ssa(arithmetic);
    assert(values.stack_ssa_valid);
    assert(verify_ssa(values, arithmetic).ok);
    auto add = std::find_if(values.value_definitions.begin(), values.value_definitions.end(),
        [](const SSAValueDefinition& d) { return d.instruction == 2 && d.op == OpCode::Add; });
    auto mul = std::find_if(values.value_definitions.begin(), values.value_definitions.end(),
        [](const SSAValueDefinition& d) { return d.instruction == 4 && d.op == OpCode::Mul; });
    assert(add != values.value_definitions.end() && add->operands.size() == 2);
    assert(mul != values.value_definitions.end() && mul->operands.size() == 2);
    assert(mul->operands[0] == add->id);

    // A value left on the operand stack across both branch arms gets a stack
    // Phi at the join, with one edge-specific input from each predecessor.
    ProgramIR diamond;
    diamond.code = {
        {OpCode::Load, "condition", 0, 1}, {OpCode::JumpIfZero, {}, 4, 1},
        {OpCode::PushInt, {}, 10, 2}, {OpCode::Jump, {}, 5, 2},
        {OpCode::PushInt, {}, 20, 3}, {OpCode::Print, {}, 0, 4}
    };
    auto merged = build_ssa(diamond);
    assert(merged.stack_ssa_valid);
    assert(verify_ssa(merged, diamond).ok);
    assert(merged.stack_phis.size() == 1);
    assert(merged.stack_phis[0].stack_slot == 0);
    assert(merged.stack_phis[0].incoming.size() == 2);
    assert(merged.stack_phis[0].incoming[0].second != merged.stack_phis[0].incoming[1].second);

    // Invalid stack states are not silently accepted by the SSA verifier.
    ProgramIR underflow;
    underflow.code = {{OpCode::Print, {}, 0, 1}};
    auto invalid = build_ssa(underflow);
    assert(!invalid.stack_ssa_valid);
    assert(!verify_ssa(invalid, underflow).ok);

    // Phi-aware global DCE removes assignments whose merge result is never
    // read, including the incoming literal stores on both branch edges.
    ProgramIR dead_phi;
    dead_phi.code = {
        {OpCode::Load, "condition", 0, 1}, {OpCode::JumpIfZero, {}, 5, 1},
        {OpCode::PushInt, {}, 10, 2}, {OpCode::Store, "unused", 0, 2},
        {OpCode::Jump, {}, 7, 2}, {OpCode::PushInt, {}, 20, 3},
        {OpCode::Store, "unused", 0, 3}, {OpCode::PushInt, {}, 1, 4},
        {OpCode::Print, {}, 0, 4}
    };
    const auto stats = optimize_ir(dead_phi);
    assert(stats.ssa_dead_stores_removed == 2);
    assert(stats.ssa_global_dce_instructions_removed >= 4);
    assert(encode_bytecode(dead_phi).ok);
    assert(verify_ssa(build_ssa(dead_phi), dead_phi).ok);
}
