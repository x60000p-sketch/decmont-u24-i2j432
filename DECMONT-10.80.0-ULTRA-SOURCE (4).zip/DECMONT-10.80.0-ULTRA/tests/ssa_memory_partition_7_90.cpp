#include "docmont/ssa.hpp"
#include "docmont/ir.hpp"
#include <algorithm>
#include <cassert>
#include <iostream>
using namespace docmont;

static std::size_t count_region_uses(const SSAProgram& ssa, std::size_t instruction, SSAAliasRegion region) {
    return static_cast<std::size_t>(std::count_if(ssa.memory_uses.begin(), ssa.memory_uses.end(),
        [&](const SSAMemoryUse& use) { return use.instruction == instruction && use.region == region; }));
}
static std::size_t count_region_defs(const SSAProgram& ssa, std::size_t instruction, SSAAliasRegion region) {
    return static_cast<std::size_t>(std::count_if(ssa.memory_definitions.begin(), ssa.memory_definitions.end(),
        [&](const SSAMemoryDefinition& def) { return !def.phi && def.instruction == instruction && def.region == region; }));
}

int main() {
    // Heap allocation writes must not advance the closure-cell memory token.
    ProgramIR isolated;
    isolated.code = {
        {OpCode::NewObject, {}, 0, 1}, {OpCode::Store, "obj", 0, 1},
        {OpCode::LoadCell, "captured", 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::NewObject, {}, 0, 3}, {OpCode::Print, {}, 0, 3}
    };
    const auto isolated_ssa = build_ssa(isolated);
    const auto isolated_check = verify_ssa(isolated_ssa, isolated);
    assert(isolated_check.ok);
    assert(count_region_defs(isolated_ssa, 0, SSAAliasRegion::HeapAggregate) == 1);
    assert(count_region_defs(isolated_ssa, 0, SSAAliasRegion::ClosureCell) == 0);
    assert(count_region_uses(isolated_ssa, 2, SSAAliasRegion::ClosureCell) == 1);
    assert(count_region_uses(isolated_ssa, 2, SSAAliasRegion::HeapAggregate) == 0);
    const auto cell_read = std::find_if(isolated_ssa.memory_uses.begin(), isolated_ssa.memory_uses.end(),
        [](const SSAMemoryUse& use) { return use.instruction == 2 && use.region == SSAAliasRegion::ClosureCell; });
    assert(cell_read != isolated_ssa.memory_uses.end() && cell_read->version == 0);

    // An unknown indirect call has read/write effects in both concrete partitions.
    ProgramIR unknown_call;
    unknown_call.code = {
        {OpCode::Load, "callable", 0, 1}, {OpCode::CallIndirect, {}, 0, 1}, {OpCode::Print, {}, 0, 1}
    };
    const auto call_ssa = build_ssa(unknown_call);
    assert(verify_ssa(call_ssa, unknown_call).ok);
    assert(count_region_uses(call_ssa, 1, SSAAliasRegion::HeapAggregate) == 1);
    assert(count_region_uses(call_ssa, 1, SSAAliasRegion::ClosureCell) == 1);
    assert(count_region_defs(call_ssa, 1, SSAAliasRegion::HeapAggregate) == 1);
    assert(count_region_defs(call_ssa, 1, SSAAliasRegion::ClosureCell) == 1);

    // Each region gets an independently typed Memory Phi at a control-flow join.
    ProgramIR diamond;
    diamond.code = {
        {OpCode::Load, "condition", 0, 1}, {OpCode::JumpIfZero, {}, 5, 1},
        {OpCode::NewObject, {}, 0, 2}, {OpCode::Print, {}, 0, 2}, {OpCode::Jump, {}, 7, 2},
        {OpCode::LoadCell, "captured", 0, 3}, {OpCode::Print, {}, 0, 3},
        {OpCode::Load, "callable", 0, 4}, {OpCode::CallIndirect, {}, 0, 4}, {OpCode::Print, {}, 0, 4}
    };
    const auto diamond_ssa = build_ssa(diamond);
    assert(verify_ssa(diamond_ssa, diamond).ok);
    const bool heap_phi = std::any_of(diamond_ssa.memory_phis.begin(), diamond_ssa.memory_phis.end(),
        [](const SSAMemoryPhi& phi) { return phi.region == SSAAliasRegion::HeapAggregate && phi.incoming.size() == 2; });
    const bool cell_phi = std::any_of(diamond_ssa.memory_phis.begin(), diamond_ssa.memory_phis.end(),
        [](const SSAMemoryPhi& phi) { return phi.region == SSAAliasRegion::ClosureCell && phi.incoming.size() == 2; });
    assert(heap_phi && cell_phi);

    const auto dump = dump_ssa(isolated_ssa);
    assert(dump.find("Memory SSA partitions: heap_aggregate + closure_cell") != std::string::npos);
    assert(dump.find("[closure_cell]") != std::string::npos);
    std::cout << "DOCMONT 7.90.0 partitioned Memory SSA tests passed\n";
}
