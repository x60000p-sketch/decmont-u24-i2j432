#include "docmont/gpu_runtime.hpp"
#include <cassert>
#include <iostream>
using namespace docmont::gpu;
int main(){auto report=probe_all_backends();assert(report.backends.size()==4);bool vulkan=false,d3d=false,metal=false,cpu=false;for(const auto& b:report.backends){if(b.backend==Backend::Vulkan){vulkan=true;if(b.runtime_present)assert(b.availability!=Availability::MissingRuntime);}if(b.backend==Backend::Direct3D12){d3d=true;
#if !defined(_WIN32)
assert(b.availability==Availability::UnsupportedPlatform);
#endif
}if(b.backend==Backend::Metal){metal=true;
#if !defined(__APPLE__)
assert(b.availability==Availability::UnsupportedPlatform);
#endif
}if(b.backend==Backend::Cpu){cpu=true;assert(b.availability==Availability::Ready);}}
assert(vulkan&&d3d&&metal&&cpu);std::cout<<"DOCMONT GPU runtime loader/backend capability probe passed\n";}
