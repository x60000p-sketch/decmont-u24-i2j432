#include "docmont/ssa.hpp"
#include <cassert>
#include <algorithm>
using namespace docmont;
int main(){
 ProgramIR diamond; diamond.code={
  {OpCode::PushInt,{},1,1},{OpCode::Store,"x",0,1},
  {OpCode::PushInt,{},1,2},{OpCode::JumpIfZero,{},7,2},
  {OpCode::PushInt,{},10,3},{OpCode::Store,"x",0,3},{OpCode::Jump,{},9,3},
  {OpCode::PushInt,{},20,4},{OpCode::Store,"x",0,4},
  {OpCode::Load,"x",0,5},{OpCode::Print,{},0,5}
 };
 auto ssa=build_ssa(diamond);
 auto valid=verify_ssa(ssa,diamond); assert(valid.ok&&valid.errors.empty());
 // Corrupt a Phi edge: verifier must reject incomplete predecessor coverage.
 auto broken=ssa; bool changed=false;
 for(auto& block:broken.blocks) if(!block.phis.empty()&&!block.phis[0].incoming.empty()){
  block.phis[0].incoming.pop_back(); changed=true; break;
 }
 assert(changed); auto invalid=verify_ssa(broken,diamond); assert(!invalid.ok&&!invalid.errors.empty());
 // Corrupt a Load's version so it refers to a definition that does not exist.
 auto bad_use=ssa; assert(!bad_use.uses.empty()); bad_use.uses[0].version=9999;
 auto invalid_use=verify_ssa(bad_use,diamond); assert(!invalid_use.ok);
 // Straight-line program and loop-carried Phi are also accepted.
 ProgramIR straight;straight.code={{OpCode::PushInt,{},7,1},{OpCode::Store,"v",0,1},{OpCode::Load,"v",0,2},{OpCode::Print,{},0,2}};
 auto straight_ssa=build_ssa(straight);assert(verify_ssa(straight_ssa,straight).ok);
 ProgramIR loop;loop.code={{OpCode::PushInt,{},0,1},{OpCode::Store,"i",0,1},{OpCode::Load,"i",0,2},{OpCode::PushInt,{},1,2},{OpCode::Add,{},0,2},{OpCode::Store,"i",0,2},{OpCode::Load,"i",0,3},{OpCode::JumpIfZero,{},10,3},{OpCode::Jump,{},2,3},{OpCode::Return,{},0,4}};
 auto loop_ssa=build_ssa(loop);assert(loop_ssa.phi_count>=1);assert(verify_ssa(loop_ssa,loop).ok);
}
