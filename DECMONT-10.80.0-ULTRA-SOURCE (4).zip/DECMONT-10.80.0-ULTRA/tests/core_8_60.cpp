#include "docmont/compiler_core.hpp"
#include "docmont/error_system.hpp"
#include "docmont/asm_contract.hpp"
#include "docmont/concurrency.hpp"
#include "docmont/ffi_contract.hpp"
#include <cassert>
#include <iostream>
#include <string>
#include <vector>

int main(){
    using namespace docmont::core;
    TypeContext types;
    const auto i32=types.primitive(TypeKind::I32), i64=types.primitive(TypeKind::I64);
    assert(i32&&i64&&i32!=i64);
    const auto t=types.generic_parameter("T");
    const auto option_t=types.option(t);
    assert(types.display(option_t)=="Option<T>");
    TraitSolver traits;
    assert(traits.define_trait({"Numeric",{{"add","(Self,Self)->Self"}}}).ok);
    assert(traits.add_implementation({"Numeric",i32,{{"add","(Self,Self)->Self"}}}).ok);
    assert(traits.satisfies(i32,"Numeric").ok);
    assert(!traits.satisfies(i64,"Numeric").ok);
    GenericFunction identity{"identity",{{"T",{"Numeric"}}},{t},t};
    GenericSolver generics(types,traits);
    auto good=generics.instantiate(identity,{{"T",i32}});
    assert(good.ok&&good.concrete_parameters.size()==1);
    assert(good.concrete_parameters[0]==i32&&good.concrete_return==i32);
    assert(!generics.instantiate(identity,{{"T",i64}}).ok);
    assert(generics.specialization_count()==1);

    EnumDefinition state{"State",{"Ready","Running","Stopped"}};
    auto exhaustive=check_enum_patterns(state,{{Pattern::Kind::Variant,"Ready"},{Pattern::Kind::Variant,"Running"},{Pattern::Kind::Variant,"Stopped"}});
    assert(exhaustive.exhaustive&&exhaustive.missing_variants.empty());
    auto partial=check_enum_patterns(state,{{Pattern::Kind::Variant,"Ready"}});
    assert(!partial.exhaustive&&partial.missing_variants.size()==2);
    auto wildcard=check_enum_patterns(state,{{Pattern::Kind::Variant,"Ready"},{Pattern::Kind::Wildcard,{}}});
    assert(wildcard.exhaustive);
    auto duplicate=check_enum_patterns(state,{{Pattern::Kind::Variant,"Ready"},{Pattern::Kind::Variant,"Ready"}});
    assert(!duplicate.exhaustive&&duplicate.duplicate_variants.size()==1);

    TypedHIRModule hir{"test",{{"main",{},{{"value",i32,false}},i32,true}}};
    assert(verify_typed_hir(hir,types).empty());
    hir.functions[0].locals.push_back({"value",i32,false});
    assert(!verify_typed_hir(hir,types).empty());
    MIRModule mir{"test",{{"main",0,{{0,{{MIROpKind::Declare,"x",{},i32},{MIROpKind::Read,"x",{},i32},{MIROpKind::Return,"x",{},i32}}, {}}}}}};
    assert(verify_mir(mir,types).empty());
    mir.functions[0].blocks[0].successors.push_back(99);
    assert(!verify_mir(mir,types).empty());

    using docmont::error::Option;using docmont::error::Result;
    auto maybe=Option<int>::some(21).map([](int x){return x*2;});
    assert(maybe.has_value()&&maybe.value()==42);
    assert(!Option<int>::none().has_value());
    auto ok=Result<int,std::string>::ok(42);assert(ok.is_ok()&&ok.value()==42);
    auto bad=Result<int,std::string>::err("failure");auto propagated=docmont::error::propagate(bad);
    assert(!propagated.has_value()&&propagated.error.value()=="failure");

    docmont::ffi::FunctionABI ffi_ok{"docmont_sum", "C", {docmont::ffi::CType::I64,docmont::ffi::CType::I64}, docmont::ffi::CType::I64};
    assert(docmont::ffi::validate_c_abi(ffi_ok).ok);
    ffi_ok.result=docmont::ffi::CType::Utf8Pointer;
    assert(!docmont::ffi::validate_c_abi(ffi_ok).ok);
    ffi_ok.owned_string_result=true;
    assert(docmont::ffi::validate_c_abi(ffi_ok).ok);

    docmont::assembly::InlineAsmContract asm_ok;asm_ok.instruction_text="add %rsi, %rax";asm_ok.inputs={"rsi"};asm_ok.outputs={"rax"};asm_ok.clobbers={"cc"};assert(docmont::assembly::validate_inline_asm_contract(asm_ok).ok);
    asm_ok.target="arm64";assert(!docmont::assembly::validate_inline_asm_contract(asm_ok).ok);
    assert(docmont::assembly::validate_simd_contract({"x86_64-sysv","add","i32x4","sse2"}).ok);
    assert(!docmont::assembly::validate_simd_contract({"x86_64-sysv","add","i32x8","sse2"}).ok);

    docmont::concurrency::AtomicI64 counter;docmont::concurrency::TaskGroup tasks;
    for(int i=0;i<4;++i)tasks.spawn([&counter]{for(int j=0;j<1000;++j)counter.fetch_add(1,std::memory_order_relaxed);});
    tasks.join();assert(counter.load()==4000);
    docmont::concurrency::TaskGroup throwing;throwing.spawn([]{throw std::runtime_error("task failure");});bool surfaced=false;try{throwing.join();}catch(const std::runtime_error&){surfaced=true;}assert(surfaced);
    docmont::concurrency::Channel<int> channel;assert(channel.send(7));auto item=channel.receive();assert(item&&*item==7);channel.close();assert(!channel.receive());
    docmont::concurrency::Mutex<int> locked;locked.with_lock([](int& value){value=9;});assert(locked.with_lock([](int& value){return value;})==9);
    std::cout<<"DOCMONT 8.60.0 compiler-core tests passed\n";
}
