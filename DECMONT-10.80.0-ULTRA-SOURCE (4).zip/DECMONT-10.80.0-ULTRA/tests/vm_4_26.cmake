set(src "${CMAKE_CURRENT_LIST_DIR}/../examples/heap_runtime_4_26.docm")
set(bc "${CMAKE_CURRENT_BINARY_DIR}/heap_runtime_4_26.dvm")
execute_process(COMMAND "${DOCMONT_EXECUTABLE}" bytecode "${src}" "${bc}" RESULT_VARIABLE c OUTPUT_VARIABLE co ERROR_VARIABLE ce)
if(NOT c EQUAL 0)
  message(FATAL_ERROR "bytecode compilation failed: ${co}${ce}")
endif()
execute_process(COMMAND "${DOCMONT_EXECUTABLE}" verify "${bc}" RESULT_VARIABLE v OUTPUT_VARIABLE vo ERROR_VARIABLE ve)
if(NOT v EQUAL 0)
  message(FATAL_ERROR "bytecode verification failed: ${vo}${ve}")
endif()
execute_process(COMMAND "${DOCMONT_EXECUTABLE}" vm-run "${bc}" RESULT_VARIABLE r OUTPUT_VARIABLE out ERROR_VARIABLE err)
if(NOT r EQUAL 0)
  message(FATAL_ERROR "VM execution failed: ${out}${err}")
endif()
set(expected "[10, 20, 30]
4
[10, 20, 30, 40]
40
[10, 20, 30]
[[1, 2], [77, 4]]
2
")
if(NOT out STREQUAL expected)
  message(FATAL_ERROR "unexpected output. Expected=[${expected}] Actual=[${out}]")
endif()
