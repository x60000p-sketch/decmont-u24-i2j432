if(NOT DEFINED DOCMONT OR NOT DEFINED SOURCE_DIR OR NOT DEFINED WORK_DIR OR
   NOT DEFINED DOCMONT_JAVAC OR NOT DEFINED DOCMONT_JAVA OR
   NOT DEFINED DOCMONT_AS OR NOT DEFINED DOCMONT_CXX)
  message(FATAL_ERROR "interop integration test is missing required tool paths")
endif()

file(REMOVE_RECURSE "${WORK_DIR}")
file(MAKE_DIRECTORY "${WORK_DIR}/generated" "${WORK_DIR}/native" "${WORK_DIR}/classes")

execute_process(
  COMMAND "${DOCMONT}" java-bindings "${SOURCE_DIR}/examples/interop/MathBridge.djava" "${WORK_DIR}/generated"
  RESULT_VARIABLE gen_result OUTPUT_VARIABLE gen_out ERROR_VARIABLE gen_err)
if(NOT gen_result EQUAL 0)
  message(FATAL_ERROR "Java binding generation failed: ${gen_out}${gen_err}")
endif()

file(WRITE "${WORK_DIR}/native/native_impl.cpp" [=[
#include "MathBridge_abi.h"
#include <string>
extern "C" {
std::int64_t docmont_add_i64(std::int64_t a, std::int64_t b) { return a + b; }
bool docmont_is_even(std::int64_t x) { return (x % 2) == 0; }
const char* docmont_greet(const char* name) { static std::string value; value = std::string("Hello ") + (name ? name : ""); return value.c_str(); }
double docmont_scale(double x, double y) { return x * y; }
void docmont_reset(void) {}
}
]=])
file(WRITE "${WORK_DIR}/native/BridgeSmoke.java" [=[
import io.docmont.demo.MathBridge;
public final class BridgeSmoke {
  public static void main(String[] args) {
    if (MathBridge.add_i64(20, 22) != 42) throw new AssertionError("i64 JNI bridge");
    if (!MathBridge.is_even(42) || MathBridge.is_even(41)) throw new AssertionError("bool JNI bridge");
    if (!"Hello DOCMONT".equals(MathBridge.greet("DOCMONT"))) throw new AssertionError("utf8 JNI bridge");
    if (Math.abs(MathBridge.scale(1.5, 2.0) - 3.0) > 1e-9) throw new AssertionError("f64 JNI bridge");
    MathBridge.reset();
    System.out.println("Java/JNI DOCMONT bridge OK");
  }
}
]=])

get_filename_component(JAVAC_REAL "${DOCMONT_JAVAC}" REALPATH)
get_filename_component(JAVA_BIN_DIR "${JAVAC_REAL}" DIRECTORY)
get_filename_component(JAVA_HOME_DIR "${JAVA_BIN_DIR}" DIRECTORY)
if(NOT EXISTS "${JAVA_HOME_DIR}/include/jni.h")
  message(FATAL_ERROR "cannot locate JNI headers below JAVA_HOME=${JAVA_HOME_DIR}")
endif()

execute_process(
  COMMAND "${DOCMONT_CXX}" -std=c++20 -shared -fPIC
          "-I${JAVA_HOME_DIR}/include" "-I${JAVA_HOME_DIR}/include/linux"
          "-I${WORK_DIR}/generated"
          -o "${WORK_DIR}/native/libdocmont_native.so"
          "${WORK_DIR}/generated/MathBridge_jni.cpp" "${WORK_DIR}/native/native_impl.cpp"
  RESULT_VARIABLE jni_build_result OUTPUT_VARIABLE jni_build_out ERROR_VARIABLE jni_build_err)
if(NOT jni_build_result EQUAL 0)
  message(FATAL_ERROR "JNI native library build failed: ${jni_build_out}${jni_build_err}")
endif()

execute_process(
  COMMAND "${DOCMONT_JAVAC}" -d "${WORK_DIR}/classes"
          "${WORK_DIR}/generated/MathBridge.java" "${WORK_DIR}/native/BridgeSmoke.java"
  RESULT_VARIABLE javac_result OUTPUT_VARIABLE javac_out ERROR_VARIABLE javac_err)
if(NOT javac_result EQUAL 0)
  message(FATAL_ERROR "javac failed: ${javac_out}${javac_err}")
endif()
execute_process(
  COMMAND "${DOCMONT_JAVA}" "-Djava.library.path=${WORK_DIR}/native" -cp "${WORK_DIR}/classes" BridgeSmoke
  RESULT_VARIABLE java_result OUTPUT_VARIABLE java_out ERROR_VARIABLE java_err)
if(NOT java_result EQUAL 0 OR NOT java_out MATCHES "Java/JNI DOCMONT bridge OK")
  message(FATAL_ERROR "Java/JNI execution failed: ${java_out}${java_err}")
endif()

execute_process(
  COMMAND "${DOCMONT}" asm-emit-x86_64 "${SOURCE_DIR}/examples/interop/math.dasm" "${WORK_DIR}/math.S"
  RESULT_VARIABLE asm_emit_result OUTPUT_VARIABLE asm_emit_out ERROR_VARIABLE asm_emit_err)
if(NOT asm_emit_result EQUAL 0)
  message(FATAL_ERROR "assembly emission failed: ${asm_emit_out}${asm_emit_err}")
endif()
execute_process(
  COMMAND "${DOCMONT_AS}" --64 -o "${WORK_DIR}/math.o" "${WORK_DIR}/math.S"
  RESULT_VARIABLE as_result OUTPUT_VARIABLE as_out ERROR_VARIABLE as_err)
if(NOT as_result EQUAL 0)
  message(FATAL_ERROR "GNU as failed: ${as_out}${as_err}")
endif()
file(WRITE "${WORK_DIR}/asm_harness.cpp" [=[
#include <cstdint>
extern "C" std::int64_t add_i64(std::int64_t, std::int64_t);
extern "C" std::int64_t multiply_i64(std::int64_t, std::int64_t);
int main() { return add_i64(20, 22) == 42 && multiply_i64(6, 7) == 42 ? 0 : 1; }
]=])
execute_process(
  COMMAND "${DOCMONT_CXX}" "${WORK_DIR}/asm_harness.cpp" "${WORK_DIR}/math.o" -o "${WORK_DIR}/asm_harness"
  RESULT_VARIABLE link_result OUTPUT_VARIABLE link_out ERROR_VARIABLE link_err)
if(NOT link_result EQUAL 0)
  message(FATAL_ERROR "assembly harness link failed: ${link_out}${link_err}")
endif()
execute_process(
  COMMAND "${WORK_DIR}/asm_harness"
  RESULT_VARIABLE asm_run_result OUTPUT_VARIABLE asm_run_out ERROR_VARIABLE asm_run_err)
if(NOT asm_run_result EQUAL 0)
  message(FATAL_ERROR "native assembly execution failed: ${asm_run_out}${asm_run_err}")
endif()

message(STATUS "Java/JNI bridge and x86_64 GNU Assembly integration passed")
