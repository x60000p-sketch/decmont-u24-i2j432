#!/usr/bin/env python3
import json, os, subprocess, sys, tempfile
from pathlib import Path
script=Path(sys.argv[1]).resolve()
with tempfile.TemporaryDirectory(prefix="docmont-console-build-test-") as td:
    root=Path(td); sdk=root/"sdk"; project=root/"project"; sdk.mkdir(); project.mkdir()
    (sdk/"include").mkdir(); (sdk/"bin").mkdir()
    (sdk/"toolchain.cmake").write_text("# test-only toolchain manifest target\n")
    compiler=sdk/"bin"/"fake-compiler"; compiler.write_text("#!/bin/sh\nexit 0\n"); compiler.chmod(0o755)
    fakecmake=root/"fake-cmake"; log=root/"calls.jsonl"
    fakecmake.write_text("#!/usr/bin/env python3\nimport json,sys\nwith open("+repr(str(log))+",'a') as f:f.write(json.dumps(sys.argv[1:])+'\\n')\nsys.exit(0)\n")
    fakecmake.chmod(0o755)
    (project/"CMakeLists.txt").write_text("cmake_minimum_required(VERSION 3.20)\nproject(sdk_adapter_test C)\n")
    manifest=root/"ps5.dcsdk"
    manifest.write_text("\n".join([
        "platform=playstation5", f"sdk_root={sdk}", "sdk_version=fixture-1.0",
        "compiler=bin/fake-compiler", "cmake_toolchain=toolchain.cmake", "include_dir=include", "license_acknowledged=true", ""
    ]))
    build=root/"build"
    common=[str(script),"ps5",str(project),"--manifest",str(manifest),"--build-dir",str(build),"--cmake",str(fakecmake)]
    dry=subprocess.run(common+["--dry-run"],text=True,capture_output=True)
    assert dry.returncode==0,(dry.stdout,dry.stderr)
    assert "CMAKE_TOOLCHAIN_FILE=" in dry.stdout and "SDK paths validated" in dry.stdout
    actual=subprocess.run(common,text=True,capture_output=True)
    assert actual.returncode==0,(actual.stdout,actual.stderr)
    calls=[json.loads(x) for x in log.read_text().splitlines()]
    assert len(calls)==2 and calls[0][0]=="-S" and calls[1][0]=="--build"
    bad=manifest.read_text().replace("license_acknowledged=true","license_acknowledged=false")
    manifest.write_text(bad)
    denied=subprocess.run(common+["--dry-run"],text=True,capture_output=True)
    assert denied.returncode==2 and "license_acknowledged=true" in denied.stderr
print("DOCMONT console SDK build driver tests passed: manifest validation, dry-run, configure/build dispatch, license gate")
