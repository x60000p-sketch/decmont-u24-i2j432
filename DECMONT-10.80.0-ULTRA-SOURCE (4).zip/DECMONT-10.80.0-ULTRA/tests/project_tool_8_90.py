#!/usr/bin/env python3
"""End-to-end verification of DOCMONT 8.90 project lifecycle tooling."""
from __future__ import annotations
import hashlib, json, os, pathlib, subprocess, sys, tempfile, zipfile

TOOL = pathlib.Path(sys.argv[1]).resolve()
COMPILER = pathlib.Path(sys.argv[2]).resolve()

def call(*args: str, ok: bool = True):
    env = os.environ.copy(); env["DOCMONT_EXECUTABLE"] = str(COMPILER)
    p = subprocess.run([str(TOOL), *map(str, args)], text=True, capture_output=True, env=env, timeout=90)
    if ok and p.returncode != 0:
        raise AssertionError(f"command failed: {args}\nstdout={p.stdout}\nstderr={p.stderr}")
    if not ok and p.returncode == 0:
        raise AssertionError(f"command unexpectedly passed: {args}\n{p.stdout}")
    return p

def main():
    with tempfile.TemporaryDirectory(prefix="docmont-890-project-") as td:
        base = pathlib.Path(td); project = base / "ArenaGame"
        p = call("new", "ArenaGame", str(project))
        assert "Created DOCMONT project" in p.stdout
        assert (project / "docmont.toml").is_file()
        assert (project / "src/main.docm").is_file()
        assert (project / "assets/scenes/main.dscene").is_file()

        check = json.loads(call("check", str(project)).stdout)
        assert check["ok"] and check["compiler_checked"] and check["asset_count"] == 1

        # Add a binary asset and ensure the integrity manifest detects changes.
        model = project / "assets/models/ship.glb"; model.write_bytes(b"glTF\x02\x00\x00\x00")
        call("assets", str(project))
        check2 = json.loads(call("check", str(project)).stdout)
        assert check2["asset_count"] == 2
        model.write_bytes(b"changed asset bytes")
        call("check", str(project), ok=False)
        call("assets", str(project))

        build = call("build", str(project))
        assert "Build succeeded" in build.stdout and "DOCMONT project ready" in build.stdout
        manifest = json.loads((project / "build/build-manifest.json").read_text())
        artifact = project / manifest["artifact"]
        assert artifact.is_file() and hashlib.sha256(artifact.read_bytes()).hexdigest() == manifest["artifact_sha256"]

        package1 = base / "one.zip"; package2 = base / "two.zip"
        call("package", str(project), "--output", str(package1), "--no-compiler")
        call("package", str(project), "--output", str(package2), "--no-compiler")
        h1 = hashlib.sha256(package1.read_bytes()).hexdigest()
        h2 = hashlib.sha256(package2.read_bytes()).hexdigest()
        assert h1 == h2, "source package must be reproducible"
        with zipfile.ZipFile(package1) as z:
            names = z.namelist()
            assert any(n.endswith("/src/main.docm") for n in names)
            assert any(n.endswith("/assets/models/ship.glb") for n in names)
            assert not any("/build/" in n or "/dist/" in n for n in names)

        # Malformed scene and unsafe manifest path are rejected before build.
        scene = project / "assets/scenes/main.dscene"
        good_scene = scene.read_text()
        scene.write_text("{not-json", encoding="utf-8")
        call("check", str(project), ok=False)
        scene.write_text(good_scene, encoding="utf-8")
        manifest_path = project / "docmont.toml"
        good_manifest = manifest_path.read_text()
        manifest_path.write_text(good_manifest.replace('src/main.docm', '../outside.docm'), encoding="utf-8")
        call("check", str(project), ok=False)

    print("DOCMONT 8.90 project scaffold, manifest/scene validation, asset hashing, compiler check, DVM build/verify/run, reproducible packaging and path-safety tests passed")

if __name__ == "__main__": main()
