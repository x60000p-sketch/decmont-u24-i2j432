#include "docmont/bytecode.hpp"
#include <cassert>
#include <string>
using namespace docmont;
static bool valid(ProgramIR ir, const std::string& expected = {}) {
    auto encoded = encode_bytecode(ir); assert(encoded.ok);
    auto result = verify_bytecode(encoded.bytes);
    if (expected.empty()) return result.ok;
    return !result.ok && result.message.find(expected) != std::string::npos;
}
int main() {
    ProgramIR good; good.name = "flow";
    good.code = {
        {OpCode::PushInt, {}, 9, 1}, {OpCode::Call, "identity", 1, 1},
        {OpCode::Print, {}, 0, 1}, {OpCode::Jump, {}, 8, 1},
        {OpCode::Function, "identity", 1, 2}, {OpCode::Store, "x", 0, 2},
        {OpCode::Load, "x", 0, 3}, {OpCode::Return, {}, 0, 3}
    };
    assert(valid(good));
    auto underflow = good; underflow.code[6] = {OpCode::Store, "x", 0, 3};
    assert(valid(underflow, "invalid function control flow"));
    auto bad_jump = good; bad_jump.code[6] = {OpCode::Jump, {}, 8, 3};
    assert(valid(bad_jump, "invalid function control flow"));
    auto no_return = good; no_return.code[7] = {OpCode::PushInt, {}, 1, 3};
    assert(valid(no_return, "invalid function control flow"));
    auto extra = good; extra.code[6] = {OpCode::PushInt, {}, 4, 3};
    extra.code[7] = {OpCode::PushInt, {}, 5, 3};
    extra.code.push_back({OpCode::Return, {}, 0, 3});
    extra.code[3].integer = 9;
    assert(valid(extra, "invalid function control flow"));
    return 0;
}
