set(src [=[!docmont[3]
application = {
 name = language_4_40
 let person = object { name = "Ada", age = 37 }
 person.age = 38
 output = person.name
 output = person.age
 output = len(person)
 output = type(person)
 output = has(person, "name")
 output = keys(person)
 complete
}
]=])
file(WRITE "${CMAKE_CURRENT_BINARY_DIR}/language_4_40.docm" "${src}")
execute_process(COMMAND "${DOCMONT}" run "${CMAKE_CURRENT_BINARY_DIR}/language_4_40.docm" RESULT_VARIABLE rc OUTPUT_VARIABLE out ERROR_VARIABLE err)
if(NOT rc EQUAL 0 OR NOT out MATCHES "Ada" OR NOT out MATCHES "38" OR NOT out MATCHES "2" OR NOT out MATCHES "object" OR NOT out MATCHES "true" OR NOT out MATCHES "age")
 message(FATAL_ERROR "DOCMONT 4.40 language feature test failed: rc=${rc}; out=${out}; err=${err}")
endif()
