execute_process(COMMAND "${DOCMONT}" run "${SOURCE_DIR}/examples/while_control_4_17.docm"
  RESULT_VARIABLE rc OUTPUT_VARIABLE out ERROR_VARIABLE err)
if(NOT rc EQUAL 0)
  message(FATAL_ERROR "DOCMONT 4.17 while runtime failed: ${err}")
endif()
if(NOT out STREQUAL "3\n3\n")
  message(FATAL_ERROR "Unexpected DOCMONT 4.17 output: ${out}")
endif()
