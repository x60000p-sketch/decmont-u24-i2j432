#include "docmont/native_backend.hpp"
#include <iostream>
#include <string>

namespace {
int failures = 0;
void expect(bool condition, const char* name) {
    if (!condition) { std::cerr << "FAIL: " << name << '\n'; ++failures; }
}
}

int main() {
    using namespace docmont;
    {
        ProgramIR ir; ir.name = "valid";
        ir.code = {{OpCode::PushInt, "", 20, 1}, {OpCode::PushInt, "", 22, 1},
                   {OpCode::Add, "", 0, 1}, {OpCode::Print, "", 0, 1}};
        const auto result = emit_c_source(ir);
        expect(result.ok, "valid arithmetic program emits C");
        expect(result.source.find("Value stack[2]") != std::string::npos,
               "stack allocation uses verified maximum depth");
    }
    {
        ProgramIR ir; ir.code = {{OpCode::Print, "", 0, 7}};
        const auto result = emit_c_source(ir);
        expect(!result.ok && result.message.find("underflow") != std::string::npos,
               "stack underflow rejected before emission");
    }
    {
        ProgramIR ir; ir.code = {{OpCode::Jump, "", 9, 12}};
        const auto result = emit_c_source(ir);
        expect(!result.ok && result.message.find("outside") != std::string::npos,
               "out-of-range jump rejected");
    }
    {
        ProgramIR ir;
        ir.code = {{OpCode::PushInt, "", 1, 1}, {OpCode::JumpIfZero, "", 4, 1},
                   {OpCode::PushInt, "", 2, 2}, {OpCode::Jump, "", 4, 2}};
        const auto result = emit_c_source(ir);
        expect(!result.ok && result.message.find("inconsistent stack depth") != std::string::npos,
               "control-flow merge requires equal stack depth");
    }
    {
        ProgramIR ir; ir.code = {{OpCode::PushInt, "", 1, 1}, {OpCode::Jump, "", 0, 1}};
        const auto result = emit_c_source(ir);
        expect(!result.ok && result.message.find("inconsistent stack depth") != std::string::npos,
               "positive-growth loop rejected");
    }
    {
        ProgramIR ir; ir.code = {{OpCode::Jump, "", 99, 1}, {OpCode::PushInt, "", 1, 2}};
        const auto result = emit_c_source(ir);
        expect(!result.ok && result.message.find("outside") != std::string::npos,
               "unreachable invalid branch is rejected too");
    }
    {
        ProgramIR ir;
        ir.code = {{OpCode::PushInt, "", 0, 1}, {OpCode::JumpIfZero, "", 4, 1},
                   {OpCode::PushInt, "", 1, 2}, {OpCode::Print, "", 0, 2}};
        const auto result = emit_c_source(ir);
        expect(result.ok, "conditional branch consumes its condition and verifies");
    }
    {
        ProgramIR ir; ir.code = {{OpCode::MakeArray, "", 0, 3}};
        const auto result = emit_c_source(ir);
        expect(!result.ok && result.message.find("does not yet support opcode") != std::string::npos,
               "unsupported opcode rejected with explicit diagnostic");
    }
    {
        ProgramIR ir; ir.code.reserve(4097);
        for (int i = 0; i < 4097; ++i) ir.code.push_back({OpCode::PushInt, "", i, 1});
        const auto result = emit_c_source(ir);
        expect(!result.ok && result.message.find("safety limit") != std::string::npos,
               "excessive native operand stack rejected before C emission");
    }
    {
        ProgramIR ir; ir.code = {{OpCode::PushInt, "", 7, 1}, {OpCode::Print, "", 0, 1}};
        const auto result = emit_c_source(ir);
        expect(result.ok && result.source.find("Value stack[1]") != std::string::npos,
               "minimum valid stack allocation remains one slot");
    }
    if (failures) return 1;
    std::cout << "DECMONT 10.30.0 native backend verifier: 10 checks passed\n";
    return 0;
}
