#include "docmont/ssa.hpp"
#include <cassert>
#include <algorithm>
using namespace docmont;
int main(){
 // Diamond: two stores reach a join, requiring a phi for x.
 ProgramIR p; p.code={
  {OpCode::PushInt,{},1,1},{OpCode::Store,"x",0,1},
  {OpCode::PushInt,{},1,2},{OpCode::JumpIfZero,{},7,2},
  {OpCode::PushInt,{},10,3},{OpCode::Store,"x",0,3},{OpCode::Jump,{},9,3},
  {OpCode::PushInt,{},20,4},{OpCode::Store,"x",0,4},
  {OpCode::Load,"x",0,5},{OpCode::Print,{},0,5}
 };
 auto s=build_ssa(p); assert(s.blocks.size()==4); assert(s.variable_count==1); assert(s.phi_count==1);
 const SSAPhi* phi=nullptr; for(const auto& b:s.blocks)for(const auto& x:b.phis)if(x.variable=="x")phi=&x;
 assert(phi&&phi->incoming.size()==2); assert(phi->incoming[0].second!=phi->incoming[1].second);
 assert(!s.uses.empty()); auto use=std::find_if(s.uses.begin(),s.uses.end(),[](const SSAUse& u){return u.variable=="x";}); assert(use!=s.uses.end()&&use->version==phi->result_version);
 auto text=dump_ssa(s);assert(text.find("phi(")!=std::string::npos);assert(text.find("DF=")!=std::string::npos);
 // Straight-line program has no phi and a load sees the preceding definition.
 ProgramIR straight;straight.code={{OpCode::PushInt,{},7,1},{OpCode::Store,"v",0,1},{OpCode::Load,"v",0,2},{OpCode::Print,{},0,2}};
 auto t=build_ssa(straight);assert(t.phi_count==0&&t.definitions.size()==1&&t.uses.size()==1);assert(t.uses[0].version==t.definitions[0].version);
 // A loop-carried definition creates a phi at the loop header.
 ProgramIR loop;loop.code={{OpCode::PushInt,{},0,1},{OpCode::Store,"i",0,1},{OpCode::Load,"i",0,2},{OpCode::PushInt,{},1,2},{OpCode::Add,{},0,2},{OpCode::Store,"i",0,2},{OpCode::Load,"i",0,3},{OpCode::JumpIfZero,{},10,3},{OpCode::Jump,{},2,3},{OpCode::Return,{},0,4}};
 auto l=build_ssa(loop);assert(l.phi_count>=1);
}
