#include "docmont/bytecode.hpp"
#include "docmont/runtime.hpp"
#include <cassert>
#include <cstdint>
#include <iostream>

int main() {
    using namespace docmont;
    ProgramIR program;
    program.name = "object-vm-contract";
    program.code = {
        {OpCode::NewObject, {}, 0, 1},
        {OpCode::PushInt, {}, 42, 2},
        {OpCode::ObjectSet, "health", 0, 3},
        {OpCode::ObjectHas, "health", 0, 4},
        {OpCode::Print, {}, 0, 5}
    };
    auto encoded = encode_bytecode(program);
    assert(encoded.ok);
    auto verified = verify_bytecode(encoded.bytes);
    assert(verified.ok);
    ProgramIR decoded;
    auto decoded_result = decode_bytecode(encoded.bytes, decoded);
    assert(decoded_result.ok);
    assert(decoded.code.size() == program.code.size());
    assert(decoded.code[2].op == OpCode::ObjectSet);
    assert(decoded.code[2].operand == "health");
    assert(execute(decoded) == 0);

    ProgramIR read;
    read.name = "object-read-contract";
    read.code = {
        {OpCode::NewObject, {}, 0, 1},
        {OpCode::PushInt, {}, 99, 2},
        {OpCode::ObjectSet, "score", 0, 3},
        {OpCode::ObjectGet, "score", 0, 4},
        {OpCode::Print, {}, 0, 5}
    };
    assert(execute(read) == 0);

    ProgramIR missing;
    missing.code = {
        {OpCode::NewObject, {}, 0, 1},
        {OpCode::ObjectGet, "missing", 0, 2},
        {OpCode::Print, {}, 0, 3}
    };
    assert(execute(missing) != 0);

    ProgramIR invalid;
    invalid.code = {{OpCode::ObjectSet, "x", 0, 1}};
    auto bad = encode_bytecode(invalid);
    assert(bad.ok);
    assert(!verify_bytecode(bad.bytes).ok);
    std::cout << "DOCMONT 4.29 object VM tests passed\n";
}
