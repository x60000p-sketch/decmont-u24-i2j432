#include "docmont/concurrency.hpp"
#include <cassert>
#include <atomic>
#include <chrono>
#include <iostream>
#include <stdexcept>
#include <vector>

int main() {
    using namespace docmont::concurrency;
    TaskScheduler scheduler(3);
    assert(scheduler.worker_count() == 3);
    AtomicI64 total{0};
    std::vector<std::future<void>> jobs;
    for (int i = 0; i < 120; ++i) {
        jobs.push_back(scheduler.submit([&total] { total.fetch_add(1); }));
    }
    auto answer = scheduler.submit([](int a, int b) { return a + b; }, 20, 22);
    auto exception = scheduler.submit([]() -> int { throw std::runtime_error("expected"); });
    for (auto& job : jobs) job.get();
    assert(answer.get() == 42);
    bool propagated = false;
    try { (void)exception.get(); } catch (const std::runtime_error& e) { propagated = std::string(e.what()) == "expected"; }
    assert(propagated);
    assert(total.load() == 120);
    scheduler.shutdown();
    bool rejected = false;
    try { (void)scheduler.submit([] { return 1; }); } catch (const std::runtime_error&) { rejected = true; }
    assert(rejected);
    std::cout << "DOCMONT 8.70.0 TaskScheduler tests passed\n";
}
