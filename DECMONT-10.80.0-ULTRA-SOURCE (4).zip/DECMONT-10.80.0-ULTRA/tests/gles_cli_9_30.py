import pathlib, subprocess, sys, tempfile
exe=pathlib.Path(sys.argv[1])
info=subprocess.run([str(exe), 'gles-info'],text=True,capture_output=True)
if info.returncode:
    print('GLES probe unavailable on this host:',info.stderr or info.stdout)
    raise SystemExit(0)
assert 'Available: yes' in info.stdout
with tempfile.TemporaryDirectory() as d:
    image=pathlib.Path(d)/'frame.ppm'
    rendered=subprocess.run([str(exe),'gles-render-demo',str(image)],text=True,capture_output=True)
    if rendered.returncode:
        print(rendered.stderr);raise SystemExit(rendered.returncode)
    data=image.read_bytes()
    assert data.startswith(b'P6\n256 256\n255\n')
compute=subprocess.run([str(exe),'gles-compute-demo'],text=True,capture_output=True)
if compute.returncode:
    print('GLES compute unavailable:',compute.stderr or compute.stdout)
    raise SystemExit(0)
assert 'GLES tensor Add: 6 8 10 12' in compute.stdout
print('DOCMONT 9.30 GLES CLI smoke passed')
