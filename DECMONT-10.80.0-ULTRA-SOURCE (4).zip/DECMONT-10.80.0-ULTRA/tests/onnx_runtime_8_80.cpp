#include "docmont/onnx_runtime.hpp"
#include <cassert>
#include <cmath>
#include <cstring>
#include <cstdint>
#include <iostream>
#include <vector>
using namespace docmont::neural;
namespace {
void varint(std::vector<std::uint8_t>& o,std::uint64_t v){while(v>=128){o.push_back(static_cast<std::uint8_t>(v)|0x80);v>>=7;}o.push_back(static_cast<std::uint8_t>(v));}
void tag(std::vector<std::uint8_t>& o,unsigned f,unsigned w){varint(o,(f<<3)|w);}
void bytes(std::vector<std::uint8_t>& o,unsigned f,const std::vector<std::uint8_t>& b){tag(o,f,2);varint(o,b.size());o.insert(o.end(),b.begin(),b.end());}
void text(std::vector<std::uint8_t>& o,unsigned f,const std::string& s){bytes(o,f,{s.begin(),s.end()});}
std::vector<std::uint8_t> packed_ints(std::initializer_list<std::int64_t> a){std::vector<std::uint8_t> r;for(auto x:a)varint(r,static_cast<std::uint64_t>(x));return r;}
std::vector<std::uint8_t> tensor(const std::string& name,std::initializer_list<std::int64_t> shape,std::initializer_list<float> values){std::vector<std::uint8_t> t;auto d=packed_ints(shape);bytes(t,1,d);tag(t,2,0);varint(t,1);std::vector<std::uint8_t> raw;for(float x:values){std::uint32_t b;std::memcpy(&b,&x,4);for(int i=0;i<4;++i)raw.push_back(static_cast<std::uint8_t>(b>>(i*8)));}bytes(t,4,raw);text(t,8,name);return t;}
std::vector<std::uint8_t> value_info(const std::string& name){std::vector<std::uint8_t> x;text(x,1,name);return x;}
std::vector<std::uint8_t> node(const std::string& op,std::initializer_list<std::string> inputs,const std::string& output){std::vector<std::uint8_t> n;for(const auto& i:inputs)text(n,1,i);text(n,2,output);text(n,4,op);return n;}
std::vector<std::uint8_t> tensor_raw(const std::string& name,std::initializer_list<std::int64_t> shape,std::initializer_list<float> values){std::vector<std::uint8_t> t;auto d=packed_ints(shape);bytes(t,1,d);tag(t,2,0);varint(t,1);std::vector<std::uint8_t> raw;for(float x:values){std::uint32_t b;std::memcpy(&b,&x,4);for(int i=0;i<4;++i)raw.push_back(static_cast<std::uint8_t>(b>>(i*8)));}bytes(t,9,raw);text(t,8,name);return t;}
std::vector<std::uint8_t> model(){std::vector<std::uint8_t> g;text(g,2,"tiny-mlp");bytes(g,1,node("MatMul",{"X","W"},"M"));bytes(g,1,node("Add",{"M","B"},"A"));bytes(g,1,node("Relu",{"A"},"Y"));bytes(g,5,tensor_raw("W",{2,2},{1,0,0,2}));bytes(g,5,tensor("B",{2},{-1,1}));bytes(g,11,value_info("X"));bytes(g,12,value_info("Y"));std::vector<std::uint8_t> m;tag(m,1,0);varint(m,8);bytes(m,7,g);return m;}
}
int main(){OnnxModel model;std::string error;assert(model.load_bytes(::model(),&error));assert(model.loaded());assert(model.info().graph_name=="tiny-mlp"&&model.info().nodes.size()==3&&model.info().inputs.size()==1&&model.info().outputs[0]=="Y");Tensor input{{1,2},{3,-2}};auto result=model.run({{"X",input}});assert(result.ok&&result.outputs.count("Y"));const auto& y=result.outputs.at("Y");assert(y.shape==std::vector<std::int64_t>({1,2}));assert(std::abs(y.values[0]-2.0f)<1e-6f&&std::abs(y.values[1])<1e-6f);assert(!model.run({}).ok);Tensor bad{{1,2},{1}};assert(!model.run({{"X",bad}}).ok);
    auto corrupt=::model();corrupt.pop_back();OnnxModel invalid;assert(!invalid.load_bytes(corrupt,&error));assert(supported_operators().size()>=23);std::cout<<"DOCMONT ONNX protobuf loading and CPU inference (MatMul/Add/Relu) passed\n";}
