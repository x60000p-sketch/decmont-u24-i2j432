#include "docmont/bytecode.hpp"
#include "docmont/optimizer.hpp"
#include "docmont/runtime.hpp"
#include "docmont/ssa.hpp"
#include <algorithm>
#include <cassert>
#include <iostream>
#include <sstream>
using namespace docmont;

static std::string run_vm(const ProgramIR& ir) {
    const auto encoded = encode_bytecode(ir);
    assert(encoded.ok);
    std::ostringstream output;
    auto* previous = std::cout.rdbuf(output.rdbuf());
    const auto status = execute_bytecode(encoded.bytes);
    std::cout.rdbuf(previous);
    assert(status == 0);
    return output.str();
}
static std::size_t count_op(const ProgramIR& ir, OpCode op) {
    return static_cast<std::size_t>(std::count_if(ir.code.begin(), ir.code.end(),
        [&](const Instruction& instruction) { return instruction.op == op; }));
}
static const SSAMemoryUse* field_use(const SSAProgram& ssa, std::size_t instruction,
                                     const std::string& key) {
    auto found = std::find_if(ssa.memory_uses.begin(), ssa.memory_uses.end(),
        [&](const SSAMemoryUse& use) {
            return use.instruction == instruction && use.partition_key == key;
        });
    return found == ssa.memory_uses.end() ? nullptr : &*found;
}

static ProgramIR diamond_read(bool mutate_one_arm, int condition) {
    ProgramIR ir;
    ir.code = {
        {OpCode::NewObject, {}, 0, 1}, {OpCode::Store, "obj", 0, 1},
        {OpCode::Load, "obj", 0, 1}, {OpCode::PushInt, {}, 42, 1},
        {OpCode::ObjectSet, "x", 0, 1}, {OpCode::Store, "sink_init", 0, 1},
        {OpCode::Load, "obj", 0, 2}, {OpCode::ObjectGet, "x", 0, 2}, {OpCode::Print, {}, 0, 2},
        {OpCode::PushInt, {}, condition, 3}, {OpCode::Store, "condition", 0, 3},
        {OpCode::Load, "condition", 0, 3}, {OpCode::JumpIfZero, {}, mutate_one_arm ? 18 : 16, 3}
    };
    if (mutate_one_arm) {
        ir.code.insert(ir.code.end(), {
            {OpCode::Load, "obj", 0, 4}, {OpCode::PushInt, {}, 88, 4},
            {OpCode::ObjectSet, "x", 0, 4}, {OpCode::Store, "sink_branch", 0, 4},
            {OpCode::Jump, {}, 20, 4},
            {OpCode::PushInt, {}, 200, 5}, {OpCode::Print, {}, 0, 5},
            {OpCode::Load, "obj", 0, 6}, {OpCode::ObjectGet, "x", 0, 6}, {OpCode::Print, {}, 0, 6}
        });
    } else {
        ir.code.insert(ir.code.end(), {
            {OpCode::PushInt, {}, 100, 4}, {OpCode::Print, {}, 0, 4},
            {OpCode::Jump, {}, 18, 4},
            {OpCode::PushInt, {}, 200, 5}, {OpCode::Print, {}, 0, 5},
            {OpCode::Load, "obj", 0, 6}, {OpCode::ObjectGet, "x", 0, 6}, {OpCode::Print, {}, 0, 6}
        });
    }
    return ir;
}

int main() {
    // Field-sensitive Memory SSA creates independent tokens for x and y.
    ProgramIR fields;
    fields.code = {
        {OpCode::NewObject, {}, 0, 1}, {OpCode::Store, "obj", 0, 1},
        {OpCode::Load, "obj", 0, 2}, {OpCode::PushInt, {}, 1, 2},
        {OpCode::ObjectSet, "x", 0, 2}, {OpCode::Store, "sink_x", 0, 2},
        {OpCode::Load, "obj", 0, 3}, {OpCode::ObjectGet, "x", 0, 3}, {OpCode::Print, {}, 0, 3},
        {OpCode::Load, "obj", 0, 4}, {OpCode::PushInt, {}, 2, 4},
        {OpCode::ObjectSet, "y", 0, 4}, {OpCode::Store, "sink_y", 0, 4},
        {OpCode::Load, "obj", 0, 5}, {OpCode::ObjectGet, "x", 0, 5}, {OpCode::Print, {}, 0, 5}
    };
    const auto field_ssa = build_ssa(fields);
    assert(verify_ssa(field_ssa, fields).ok);
    const auto* first_x = field_use(field_ssa, 7, "object:0:x");
    const auto* second_x = field_use(field_ssa, 14, "object:0:x");
    assert(first_x && second_x && first_x->version == second_x->version);
    assert(field_use(field_ssa, 14, "object:0:y") == nullptr);
    const auto dump = dump_ssa(field_ssa);
    assert(dump.find("object:0:x") != std::string::npos);
    assert(dump.find("object:0:y") != std::string::npos);

    // Unknown calls write every discovered object-field partition.
    ProgramIR unknown_call;
    unknown_call.code = {
        {OpCode::NewObject, {}, 0, 1}, {OpCode::Store, "obj", 0, 1},
        {OpCode::Load, "obj", 0, 2}, {OpCode::PushInt, {}, 1, 2},
        {OpCode::ObjectSet, "x", 0, 2}, {OpCode::Store, "sink", 0, 2},
        {OpCode::Load, "obj", 0, 3}, {OpCode::ObjectGet, "x", 0, 3}, {OpCode::Print, {}, 0, 3},
        {OpCode::Load, "callable", 0, 4}, {OpCode::CallIndirect, {}, 0, 4},
        {OpCode::Store, "call_result", 0, 4},
        {OpCode::Load, "obj", 0, 5}, {OpCode::ObjectGet, "x", 0, 5}, {OpCode::Print, {}, 0, 5}
    };
    const auto call_ssa = build_ssa(unknown_call);
    assert(verify_ssa(call_ssa, unknown_call).ok);
    const auto* before_call = field_use(call_ssa, 7, "object:0:x");
    const auto* after_call = field_use(call_ssa, 13, "object:0:x");
    assert(before_call && after_call && before_call->version != after_call->version);

    // Every branch produces a Memory Phi for the concrete object field.
    ProgramIR diamond_field;
    diamond_field.code = {
        {OpCode::NewObject, {}, 0, 1}, {OpCode::Store, "obj", 0, 1},
        {OpCode::Load, "obj", 0, 1}, {OpCode::PushInt, {}, 0, 1},
        {OpCode::ObjectSet, "x", 0, 1}, {OpCode::Store, "sink0", 0, 1},
        {OpCode::Load, "condition", 0, 2}, {OpCode::JumpIfZero, {}, 13, 2},
        {OpCode::Load, "obj", 0, 3}, {OpCode::PushInt, {}, 1, 3},
        {OpCode::ObjectSet, "x", 0, 3}, {OpCode::Store, "sink1", 0, 3},
        {OpCode::Jump, {}, 17, 3},
        {OpCode::Load, "obj", 0, 4}, {OpCode::PushInt, {}, 2, 4},
        {OpCode::ObjectSet, "x", 0, 4}, {OpCode::Store, "sink2", 0, 4},
        {OpCode::Load, "obj", 0, 5}, {OpCode::ObjectGet, "x", 0, 5}, {OpCode::Print, {}, 0, 5}
    };
    const auto diamond_ssa = build_ssa(diamond_field);
    assert(verify_ssa(diamond_ssa, diamond_field).ok);
    assert(std::any_of(diamond_ssa.memory_phis.begin(), diamond_ssa.memory_phis.end(),
        [](const SSAMemoryPhi& phi) { return phi.partition_key == "object:0:x" && phi.incoming.size() == 2; }));

    // CFG-wide Memory GVN reuses a dominating read at a diamond join.
    auto cross_block = diamond_read(false, 0);
    const auto cross_output = run_vm(cross_block);
    const auto cross_stats = optimize_ir(cross_block);
    assert(cross_stats.ssa_memory_load_eliminations == 1);
    assert(cross_stats.ssa_memory_load_cross_block_eliminations == 1);
    assert(count_op(cross_block, OpCode::ObjectGet) == 1);
    assert(run_vm(cross_block) == cross_output);
    auto cross_output_true = diamond_read(false, 1);
    const auto expected_true = run_vm(cross_output_true);
    optimize_ir(cross_output_true);
    assert(run_vm(cross_output_true) == expected_true);

    // A write on only one incoming path kills the fact at the join.
    auto one_arm_write = diamond_read(true, 0);
    const auto one_arm_output = run_vm(one_arm_write);
    const auto one_arm_stats = optimize_ir(one_arm_write);
    assert(one_arm_stats.ssa_memory_load_eliminations == 0);
    assert(count_op(one_arm_write, OpCode::ObjectGet) == 2);
    assert(run_vm(one_arm_write) == one_arm_output);

    // Heap DSE removes an earlier same-field literal write with a dead result store.
    ProgramIR object_dse;
    object_dse.code = {
        {OpCode::NewObject, {}, 0, 1}, {OpCode::Store, "obj", 0, 1},
        {OpCode::Load, "obj", 0, 2}, {OpCode::PushInt, {}, 1, 2},
        {OpCode::ObjectSet, "x", 0, 2}, {OpCode::Store, "sink1", 0, 2},
        {OpCode::Load, "obj", 0, 3}, {OpCode::PushInt, {}, 2, 3},
        {OpCode::ObjectSet, "x", 0, 3}, {OpCode::Store, "sink2", 0, 3},
        {OpCode::Load, "obj", 0, 4}, {OpCode::ObjectGet, "x", 0, 4}, {OpCode::Print, {}, 0, 4}
    };
    const auto object_output = run_vm(object_dse);
    const auto object_stats = optimize_ir(object_dse);
    assert(object_stats.ssa_heap_stores_removed == 1);
    assert(count_op(object_dse, OpCode::ObjectSet) == 1);
    assert(run_vm(object_dse) == object_output);

    // Heap DSE also handles constant in-range array slots.
    ProgramIR array_dse;
    array_dse.code = {
        {OpCode::PushInt, {}, 10, 1}, {OpCode::MakeArray, {}, 1, 1}, {OpCode::Store, "items", 0, 1},
        {OpCode::Load, "items", 0, 2}, {OpCode::PushInt, {}, 0, 2},
        {OpCode::PushInt, {}, 11, 2}, {OpCode::ArraySet, {}, 0, 2},
        {OpCode::Load, "items", 0, 3}, {OpCode::PushInt, {}, 0, 3},
        {OpCode::PushInt, {}, 22, 3}, {OpCode::ArraySet, {}, 0, 3},
        {OpCode::Load, "items", 0, 4}, {OpCode::PushInt, {}, 0, 4},
        {OpCode::ArrayGet, {}, 0, 4}, {OpCode::Print, {}, 0, 4}
    };
    const auto array_output = run_vm(array_dse);
    const auto array_stats = optimize_ir(array_dse);
    assert(array_stats.ssa_heap_stores_removed == 1);
    assert(count_op(array_dse, OpCode::ArraySet) == 1);
    assert(run_vm(array_dse) == array_output);

    // A read between two stores observes the first write and blocks DSE.
    ProgramIR observed_write;
    observed_write.code = {
        {OpCode::NewObject, {}, 0, 1}, {OpCode::Store, "obj", 0, 1},
        {OpCode::Load, "obj", 0, 2}, {OpCode::PushInt, {}, 1, 2},
        {OpCode::ObjectSet, "x", 0, 2}, {OpCode::Store, "sink1", 0, 2},
        {OpCode::Load, "obj", 0, 3}, {OpCode::ObjectGet, "x", 0, 3}, {OpCode::Print, {}, 0, 3},
        {OpCode::Load, "obj", 0, 4}, {OpCode::PushInt, {}, 2, 4},
        {OpCode::ObjectSet, "x", 0, 4}, {OpCode::Store, "sink2", 0, 4}
    };
    assert(optimize_ir(observed_write).ssa_heap_stores_removed == 0);
    assert(count_op(observed_write, OpCode::ObjectSet) == 2);

    // An out-of-range array slot is never considered removable: the original
    // store may trap before a later write could execute.
    ProgramIR bounds_sensitive;
    bounds_sensitive.code = {
        {OpCode::PushInt, {}, 10, 1}, {OpCode::MakeArray, {}, 1, 1}, {OpCode::Store, "items", 0, 1},
        {OpCode::Load, "items", 0, 2}, {OpCode::PushInt, {}, 1, 2},
        {OpCode::PushInt, {}, 11, 2}, {OpCode::ArraySet, {}, 0, 2},
        {OpCode::Load, "items", 0, 3}, {OpCode::PushInt, {}, 1, 3},
        {OpCode::PushInt, {}, 22, 3}, {OpCode::ArraySet, {}, 0, 3}
    };
    assert(optimize_ir(bounds_sensitive).ssa_heap_stores_removed == 0);
    assert(count_op(bounds_sensitive, OpCode::ArraySet) == 2);

    std::cout << "DOCMONT 8.00.0 field-sensitive Memory SSA + CFG Memory GVN + heap DSE tests passed\n";
}
