#include "docmont/native_backend.hpp"
#include <iostream>
#include <string>
#include <vector>

int main() {
    using namespace docmont;
    ProgramIR ir; ir.name = "native_heap_10_60";
    ir.code = {{OpCode::PushInt,"",5,1}, {OpCode::MakeArray,"",1,1},
               {OpCode::ArrayLength,"",0,1}, {OpCode::Print,"",0,1}};
    const auto r = emit_c_source(ir);
    int failures = 0;
    auto expect = [&](bool ok, const char* label) {
        if (!ok) { std::cerr << "FAIL: " << label << '\n'; ++failures; }
    };
    expect(r.ok, "native array program emits");
    expect(r.source.find("array_register(Array *a)") != std::string::npos, "heap registry is emitted");
    expect(r.source.find("MAX_ARRAY_OBJECTS=65536") != std::string::npos, "array object count is bounded");
    expect(r.source.find("static void array_cleanup(void)") != std::string::npos, "deterministic heap cleanup is emitted");
    expect(r.source.find("free(g_arrays[i]->items)") != std::string::npos, "array payloads are released");
    expect(r.source.find("free(g_arrays[i])") != std::string::npos, "array headers are released");
    expect(r.source.find("atexit(array_cleanup)") != std::string::npos, "cleanup runs on normal and error exits");
    if (failures) return 1;
    std::cout << "DECMONT 10.60.0 native heap: 7 checks passed\n";
    return 0;
}
