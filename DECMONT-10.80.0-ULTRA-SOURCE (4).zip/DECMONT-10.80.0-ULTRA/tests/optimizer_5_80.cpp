#include "docmont/optimizer.hpp"
#include "docmont/bytecode.hpp"
#include <cassert>
#include <algorithm>
#include <limits>
using namespace docmont;
int main(){
 ProgramIR ir;ir.name="optimizer-test";ir.target="x86_64";ir.code={{OpCode::PushInt,{},20,1},{OpCode::PushInt,{},22,1},{OpCode::Add,{},0,1},{OpCode::PushInt,{},6,2},{OpCode::PushInt,{},7,2},{OpCode::Mul,{},0,2},{OpCode::Print,{},0,3}};
 auto s=optimize_ir(ir);assert(s.instructions_before==7&&s.instructions_after==3&&s.constants_folded==2);assert(ir.code[0].integer==42&&ir.code[1].integer==42);assert(encode_bytecode(ir).ok);
 ProgramIR unary; unary.code={{OpCode::PushInt,{},0,4},{OpCode::BoolNot,{},0,4},{OpCode::Print,{},0,4}};
 auto unary_stats=optimize_ir(unary); assert(unary_stats.constants_folded==1); assert(unary.code.size()==2); assert(unary.code[0].op==OpCode::PushInt&&unary.code[0].integer==1); assert(encode_bytecode(unary).ok);
 ProgramIR unary_truthy; unary_truthy.code={{OpCode::PushInt,{},-9,5},{OpCode::BoolNot,{},0,5}};
 assert(optimize_ir(unary_truthy).constants_folded==1); assert(unary_truthy.code[0].integer==0);
 ProgramIR overflow;overflow.code={{OpCode::PushInt,{},std::numeric_limits<std::int64_t>::max(),1},{OpCode::PushInt,{},1,1},{OpCode::Add,{},0,1}};assert(optimize_ir(overflow).constants_folded==0&&overflow.code.size()==3);
 ProgramIR div0;div0.code={{OpCode::PushInt,{},9,1},{OpCode::PushInt,{},0,1},{OpCode::Div,{},0,1}};assert(optimize_ir(div0).constants_folded==0);

 ProgramIR identities; identities.code={{OpCode::Load,"x",0,6},{OpCode::PushInt,{},0,6},{OpCode::Add,{},0,6},{OpCode::PushInt,{},1,6},{OpCode::Mul,{},0,6},{OpCode::Print,{},0,6}};
 auto identity_stats=optimize_ir(identities); assert(identity_stats.algebraic_simplifications==2); assert(identities.code.size()==2); assert(identities.code[0].op==OpCode::Load&&identities.code[1].op==OpCode::Print); assert(encode_bytecode(identities).ok);
 ProgramIR identity_branch; identity_branch.code={{OpCode::Jump,{},1,7},{OpCode::PushInt,{},0,7},{OpCode::Add,{},0,7}}; auto branch_stats=optimize_ir(identity_branch); assert(branch_stats.algebraic_simplifications==0); assert(identity_branch.code.size()==3);
 ProgramIR left_identities; left_identities.code={{OpCode::PushInt,{},0,8},{OpCode::Load,"x",0,8},{OpCode::Add,{},0,8},{OpCode::PushInt,{},1,8},{OpCode::Load,"y",0,8},{OpCode::Mul,{},0,8},{OpCode::Print,{},0,8}};
 auto left_stats=optimize_ir(left_identities); assert(left_stats.algebraic_simplifications==2); assert(left_identities.code.size()==3); assert(left_identities.code[0].op==OpCode::Load&&left_identities.code[0].operand=="x"); assert(left_identities.code[1].op==OpCode::Load&&left_identities.code[1].operand=="y"); assert(encode_bytecode(left_identities).ok);
 ProgramIR left_identity_branch; left_identity_branch.code={{OpCode::Jump,{},1,9},{OpCode::PushInt,{},0,9},{OpCode::Load,"x",0,9},{OpCode::Add,{},0,9}}; auto left_branch_stats=optimize_ir(left_identity_branch); assert(left_branch_stats.algebraic_simplifications==0); assert(left_identity_branch.code.size()==4);
 ProgramIR propagated; propagated.code={{OpCode::PushInt,{},41,10},{OpCode::Store,"answer",0,10},{OpCode::Load,"answer",0,11},{OpCode::Print,{},0,11}};
 auto propagation_stats=optimize_ir(propagated); assert(propagation_stats.constant_propagations==1); assert(propagation_stats.ssa_dead_stores_removed==1); assert(propagated.code.size()==2); assert(propagated.code[0].op==OpCode::PushInt&&propagated.code[0].integer==41); assert(propagated.code[1].op==OpCode::Print); assert(encode_bytecode(propagated).ok);
 ProgramIR overwritten; overwritten.code={{OpCode::PushInt,{},41,12},{OpCode::Store,"answer",0,12},{OpCode::PushInt,{},9,13},{OpCode::Store,"answer",0,13},{OpCode::Load,"answer",0,14}};
 auto overwritten_stats=optimize_ir(overwritten); assert(overwritten_stats.constant_propagations==1); assert(overwritten.code.back().op==OpCode::PushInt&&overwritten.code.back().integer==9);
 ProgramIR branch_kill; branch_kill.code={{OpCode::PushInt,{},41,15},{OpCode::Store,"answer",0,15},{OpCode::Jump,{},4,16},{OpCode::Load,"answer",0,17},{OpCode::Print,{},0,17}};
 auto branch_kill_stats=optimize_ir(branch_kill); assert(branch_kill_stats.constant_propagations==0);
 ProgramIR cfg_same; cfg_same.code={{OpCode::PushInt,{},1,20},{OpCode::Store,"x",0,20},{OpCode::JumpIfZero,{},5,21},{OpCode::PushInt,{},1,22},{OpCode::Store,"x",0,22},{OpCode::Load,"x",0,23},{OpCode::Print,{},0,23}};
 auto cfg_same_stats=optimize_ir(cfg_same); assert(cfg_same_stats.constant_propagations==1); assert(cfg_same.code[5].op==OpCode::PushInt&&cfg_same.code[5].integer==1); assert(encode_bytecode(cfg_same).ok);
 ProgramIR cfg_different; cfg_different.code={{OpCode::PushInt,{},1,24},{OpCode::Store,"x",0,24},{OpCode::JumpIfZero,{},5,25},{OpCode::PushInt,{},2,26},{OpCode::Store,"x",0,26},{OpCode::Load,"x",0,27},{OpCode::Print,{},0,27}};
 auto cfg_diff_stats=optimize_ir(cfg_different); assert(cfg_diff_stats.constant_propagations==0); assert(cfg_different.code[5].op==OpCode::Load);
 ProgramIR cfg_loop; cfg_loop.code={{OpCode::PushInt,{},1,28},{OpCode::Store,"x",0,28},{OpCode::Jump,{},2,29},{OpCode::Load,"x",0,30}};
 assert(optimize_ir(cfg_loop).constant_propagations==0);

 ProgramIR loop_invariant; loop_invariant.code={{OpCode::PushInt,{},1,31},{OpCode::Store,"x",0,31},{OpCode::PushInt,{},1,32},{OpCode::JumpIfZero,{},7,32},{OpCode::PushInt,{},1,33},{OpCode::Store,"x",0,33},{OpCode::Jump,{},2,34},{OpCode::Load,"x",0,35},{OpCode::Print,{},0,35}};
 auto loop_invariant_stats=optimize_ir(loop_invariant); assert(loop_invariant_stats.constant_propagations==1); assert(std::any_of(loop_invariant.code.begin(),loop_invariant.code.end(),[](const Instruction& x){return x.op==OpCode::PushInt&&x.integer==1;})); assert(encode_bytecode(loop_invariant).ok);
 ProgramIR loop_variant; loop_variant.code={{OpCode::PushInt,{},1,36},{OpCode::Store,"x",0,36},{OpCode::PushInt,{},1,37},{OpCode::JumpIfZero,{},7,37},{OpCode::PushInt,{},2,38},{OpCode::Store,"x",0,38},{OpCode::Jump,{},2,39},{OpCode::Load,"x",0,40},{OpCode::Print,{},0,40}};
 auto loop_variant_stats=optimize_ir(loop_variant); assert(loop_variant_stats.constant_propagations==0); assert(loop_variant.code[7].op==OpCode::Load); assert(encode_bytecode(loop_variant).ok);
 ProgramIR branch;branch.code={{OpCode::Jump,{},2,1},{OpCode::PushInt,{},1,1},{OpCode::PushInt,{},2,1},{OpCode::Add,{},0,1},{OpCode::Print,{},1,1}};assert(optimize_ir(branch).constants_folded==0);assert(branch.code[0].integer==1);
 // O2 CFG cleanup removes unreachable blocks and remaps surviving branches.
 ProgramIR dead_blocks; dead_blocks.code={{OpCode::Jump,{},3,50},{OpCode::PushInt,{},99,51},{OpCode::Print,{},0,51},{OpCode::PushInt,{},7,52},{OpCode::Print,{},0,52}};
 auto dead_stats=optimize_ir(dead_blocks);
 assert(dead_stats.unreachable_instructions_removed==2);
 assert(dead_blocks.code.size()==3);
 assert(dead_blocks.code[0].op==OpCode::Jump&&dead_blocks.code[0].integer==1);
 assert(dead_blocks.code[1].op==OpCode::PushInt&&dead_blocks.code[1].integer==7);
 assert(encode_bytecode(dead_blocks).ok);
 ProgramIR after_return; after_return.code={{OpCode::PushInt,{},1,53},{OpCode::Return,{},0,53},{OpCode::PushInt,{},2,54},{OpCode::Print,{},0,54}};
 auto return_stats=optimize_ir(after_return);
 assert(return_stats.unreachable_instructions_removed==2);
 assert(after_return.code.size()==2&&after_return.code[1].op==OpCode::Return);
 assert(encode_bytecode(after_return).ok);

 // O3 resolves literal JumpIfZero conditions and then removes newly dead CFG blocks.
 ProgramIR always_true; always_true.code={{OpCode::PushInt,{},1,60},{OpCode::JumpIfZero,{},6,60},{OpCode::PushInt,{},7,61},{OpCode::Print,{},0,61},{OpCode::Jump,{},7,61},{OpCode::PushInt,{},8,61},{OpCode::Print,{},0,61},{OpCode::Return,{},0,62}};
 auto true_stats=optimize_ir(always_true);
 assert(true_stats.constant_branches_folded==1);
 assert(true_stats.unreachable_instructions_removed>=1);
 assert(always_true.code.size()==4);
 assert(always_true.code[0].op==OpCode::PushInt&&always_true.code[0].integer==7);
 assert(encode_bytecode(always_true).ok);
 ProgramIR always_false; always_false.code={{OpCode::PushInt,{},0,63},{OpCode::JumpIfZero,{},4,63},{OpCode::PushInt,{},8,64},{OpCode::Print,{},0,64},{OpCode::Return,{},0,65}};
 auto false_stats=optimize_ir(always_false);
 assert(false_stats.constant_branches_folded==1);
 assert(always_false.code.size()==2);
 assert(always_false.code[0].op==OpCode::Jump&&always_false.code[0].integer==1);
 assert(always_false.code[1].op==OpCode::Return);
 assert(encode_bytecode(always_false).ok);
 // A branch target into the condition pair must prevent folding.
 ProgramIR targeted_condition; targeted_condition.code={{OpCode::Jump,{},1,66},{OpCode::PushInt,{},1,67},{OpCode::JumpIfZero,{},4,67},{OpCode::Return,{},0,68},{OpCode::Return,{},0,69}};
 auto targeted_stats=optimize_ir(targeted_condition);
 assert(targeted_stats.constant_branches_folded==0);
 assert(encode_bytecode(targeted_condition).ok);

 // O3 jump threading bypasses chains of unconditional jumps and preserves semantics.
 ProgramIR threaded; threaded.code={{OpCode::Jump,{},2,70},{OpCode::PushInt,{},99,70},{OpCode::Jump,{},4,71},{OpCode::PushInt,{},88,71},{OpCode::PushInt,{},7,72},{OpCode::Print,{},0,72}};
 auto threaded_stats=optimize_ir(threaded);
 assert(threaded_stats.jump_threads>=1);
 assert(encode_bytecode(threaded).ok);
 ProgramIR conditional_thread; conditional_thread.code={{OpCode::PushInt,{},0,73},{OpCode::JumpIfZero,{},3,73},{OpCode::Return,{},0,74},{OpCode::Jump,{},5,75},{OpCode::PushInt,{},1,76},{OpCode::Return,{},76,76}};
 auto conditional_thread_stats=optimize_ir(conditional_thread);
 assert(conditional_thread_stats.jump_threads>=1);
 assert(encode_bytecode(conditional_thread).ok);
 // A cyclic jump chain must not be threaded into a different target.
 ProgramIR jump_cycle; jump_cycle.code={{OpCode::Jump,{},1,77},{OpCode::Jump,{},0,78},{OpCode::Return,{},0,79}};
 auto cycle_stats=optimize_ir(jump_cycle);
 assert(cycle_stats.jump_threads==0);
 assert(encode_bytecode(jump_cycle).ok);

}
