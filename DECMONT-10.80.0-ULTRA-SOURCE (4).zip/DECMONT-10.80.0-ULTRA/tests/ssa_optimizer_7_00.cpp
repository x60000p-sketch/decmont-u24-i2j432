#include "docmont/optimizer.hpp"
#include "docmont/bytecode.hpp"
#include "docmont/ssa.hpp"
#include <cassert>
using namespace docmont;

int main() {
    // Identical pure expression in one basic block: the second calculation is
    // replaced by a Load from the first expression's compiler-generated slot.
    ProgramIR repeated;
    repeated.code = {
        {OpCode::Load, "x", 0, 1}, {OpCode::Load, "y", 0, 1}, {OpCode::Add, {}, 0, 1}, {OpCode::Print, {}, 0, 1},
        {OpCode::Load, "x", 0, 2}, {OpCode::Load, "y", 0, 2}, {OpCode::Add, {}, 0, 2}, {OpCode::Print, {}, 0, 2}
    };
    const auto gvn = optimize_ir(repeated);
    assert(gvn.ssa_gvn_eliminations == 1);
    assert(encode_bytecode(repeated).ok);
    assert(verify_ssa(build_ssa(repeated), repeated).ok);
    bool has_temp_store = false, has_temp_reload = false;
    for (const auto& ins : repeated.code) {
        if (ins.op == OpCode::Store && ins.operand.rfind("__docmont_ssa_gvn_", 0) == 0) has_temp_store = true;
        if (ins.op == OpCode::Load && ins.operand.rfind("__docmont_ssa_gvn_", 0) == 0) has_temp_reload = true;
    }
    assert(has_temp_store && has_temp_reload);

    // A new SSA version prevents reuse after the source variable is changed.
    ProgramIR redefined;
    redefined.code = {
        {OpCode::Load, "x", 0, 1}, {OpCode::Load, "y", 0, 1}, {OpCode::Add, {}, 0, 1}, {OpCode::Print, {}, 0, 1},
        {OpCode::PushInt, {}, 9, 2}, {OpCode::Store, "x", 0, 2},
        {OpCode::Load, "x", 0, 3}, {OpCode::Load, "y", 0, 3}, {OpCode::Add, {}, 0, 3}, {OpCode::Print, {}, 0, 3}
    };
    const auto changed = optimize_ir(redefined);
    assert(changed.ssa_gvn_eliminations == 0);
    assert(encode_bytecode(redefined).ok);

    // Branch targets inside a candidate expression prohibit rewriting it.
    ProgramIR targeted;
    targeted.code = {
        {OpCode::Jump, {}, 1, 1},
        {OpCode::Load, "x", 0, 2}, {OpCode::Load, "y", 0, 2}, {OpCode::Add, {}, 0, 2}, {OpCode::Print, {}, 0, 2}
    };
    const auto branch_stats = optimize_ir(targeted);
    assert(branch_stats.ssa_gvn_eliminations == 0);
    assert(encode_bytecode(targeted).ok);

    // Unused literal-only stores can be removed together with their producer.
    ProgramIR dead_store;
    dead_store.code = {
        {OpCode::PushInt, {}, 42, 1}, {OpCode::Store, "unused", 0, 1},
        {OpCode::PushInt, {}, 7, 2}, {OpCode::Print, {}, 2, 2}
    };
    const auto dse = optimize_ir(dead_store);
    assert(dse.ssa_dead_stores_removed == 1);
    assert(dead_store.code.size() == 2);
    assert(dead_store.code[0].op == OpCode::PushInt && dead_store.code[0].integer == 7);
    assert(encode_bytecode(dead_store).ok);

    // A value feeding a Phi is live on the incoming edge and must be retained.
    ProgramIR phi_live;
    phi_live.code = {
        {OpCode::PushInt, {}, 99, 1}, {OpCode::Store, "dead", 0, 1},
        {OpCode::Load, "condition", 0, 2}, {OpCode::JumpIfZero, {}, 8, 2},
        {OpCode::PushInt, {}, 10, 3}, {OpCode::Store, "x", 0, 3}, {OpCode::Jump, {}, 10, 3},
        {OpCode::Return, {}, 0, 3},
        {OpCode::PushInt, {}, 20, 4}, {OpCode::Store, "x", 0, 4},
        {OpCode::Load, "x", 0, 5}, {OpCode::Print, {}, 0, 5}
    };
    const auto phi_stats = optimize_ir(phi_live);
    assert(phi_stats.ssa_dead_stores_removed == 1);
    assert(encode_bytecode(phi_live).ok);
}
