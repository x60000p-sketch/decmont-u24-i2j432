#include "docmont/native_backend.hpp"
#include <iostream>
#include <string>
#include <utility>
#include <vector>

namespace {
int failures = 0;
void expect(bool ok, const char* name) {
    if (!ok) { std::cerr << "FAIL: " << name << '\n'; ++failures; }
}
docmont::NativeSourceResult emit(std::vector<docmont::Instruction> code) {
    docmont::ProgramIR ir; ir.name = "native_10_50"; ir.code = std::move(code);
    return docmont::emit_c_source(ir);
}
}
int main() {
    using namespace docmont;
    {
        auto r = emit({{OpCode::PushInt,"",11,1},{OpCode::PushInt,"",22,1},
                       {OpCode::MakeArray,"",2,1},{OpCode::ArrayLength,"",0,1},{OpCode::Print,"",0,1}});
        expect(r.ok && r.source.find("array_new(2,stack,&sp)") != std::string::npos,
               "array creation and length lower to C11");
    }
    {
        auto r = emit({{OpCode::PushInt,"",7,1},{OpCode::PushInt,"",9,1},
                       {OpCode::MakeArray,"",2,1},{OpCode::PushInt,"",1,1},
                       {OpCode::ArrayGet,"",0,1},{OpCode::Print,"",0,1}});
        expect(r.ok && r.source.find("base.a->items[(size_t)ix.i]") != std::string::npos,
               "array get lowers with bounds validation");
    }
    {
        auto r = emit({{OpCode::PushInt,"",7,1},{OpCode::PushInt,"",9,1},
                       {OpCode::MakeArray,"",2,1},{OpCode::PushInt,"",0,1},
                       {OpCode::PushInt,"",42,1},{OpCode::ArraySet,"",0,1}});
        expect(r.ok && r.source.find("base.a->items[(size_t)ix.i]=val") != std::string::npos,
               "array set lowers to checked mutation");
    }
    {
        auto r = emit({{OpCode::PushInt,"",1,1},{OpCode::MakeArray,"",1,1},
                       {OpCode::PushInt,"",2,1},{OpCode::ArrayPush,"",0,1},{OpCode::Print,"",0,1}});
        expect(r.ok && r.source.find("array_push(base->a,val)") != std::string::npos,
               "array push lowers with bounded growth");
    }
    {
        auto r = emit({{OpCode::PushInt,"",1,1},{OpCode::MakeArray,"",1,1},
                       {OpCode::ArrayPop,"",0,1},{OpCode::Print,"",0,1}});
        expect(r.ok && r.source.find("a->items[--a->len]") != std::string::npos,
               "array pop lowers to last-element extraction");
    }
    {
        auto r = emit({{OpCode::MakeArray,"",-1,1}});
        expect(!r.ok && r.message.find("invalid array element count") != std::string::npos,
               "negative array element count is rejected");
    }
    {
        auto r = emit({{OpCode::PushInt,"",0,1},{OpCode::ArrayGet,"",0,1}});
        expect(!r.ok && r.message.find("operand stack underflow") != std::string::npos,
               "array operand underflow is rejected");
    }
    if (failures) return 1;
    std::cout << "DECMONT 10.50.0 native backend: 7 checks passed\n";
    return 0;
}
