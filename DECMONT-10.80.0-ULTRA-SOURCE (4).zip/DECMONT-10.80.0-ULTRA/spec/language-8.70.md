# DOCMONT 8.70.0 Language Surface

This document describes the source forms exercised by the 8.70.0 language regression suite. It is not a claim that every generalization of these constructs is complete.

## Enums and matching

```docmont
!docmont[3]
application = {
  name = "enum-sample"
  enum State { Ready, Failed(String) }
  fn main() {
    let state = State::Failed("problem")
    match state {
      State::Ready => { output = "ready" }
      State::Failed(message) => { output = message }
    }
  }
  complete
}
```

Enum cases can be matched in the interpreter and DVM. For a case with multiple payload fields, the currently supported binding captures the packed payload array; individual field destructuring and nested patterns are not implemented.

## Generic functions

```docmont
fn identity<T>(value: T): T {
  return value
}
```

Generic parameters, inference for supported direct calls, and built-in trait bounds are checked. HIR/MIR specialization records are produced for resolved direct calls. Runtime bodies are still generic-erased; fully specialized native body codegen is deferred.

## Option / Result and propagation

```docmont
fn fail(): Result<Int, String> {
  return Result::Err("failed")
}

fn propagate(): Result<Int, String> {
  let value = fail()?
  return Result::Ok(value)
}
```

`Option<T>`, `Result<T,E>`, their `Some`/`None` and `Ok`/`Err` constructors, matching, and postfix `?` are supported by the current interpreter and DVM path for the tested forms. Error propagation is not yet generalized into a fully typed exception/unwinding runtime.

## Ownership markers

The source checker recognizes:

```docmont
let moved = move value
let shared = &value
let exclusive = &mut value
```

It diagnoses supported move/borrow conflicts and branch-join cases. Loop-carried borrow analysis is not enabled in the source checker and reports `OWN093`.
