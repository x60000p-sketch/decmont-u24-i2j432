# DOCMONT Portable Bytecode and Target Matrix — 8.40.0

## DVM v1

DVM v1 is a virtual instruction format, not a native CPU instruction set. It uses:

- magic `DVMB`;
- format version `1`;
- explicit little-endian 32-bit and 64-bit fields;
- length-prefixed UTF-8/text operands;
- a verifier that checks record bounds, opcode range, jump targets, function references, call arity, and per-region stack consistency.

A DVM file is therefore not tied to one host's instruction encoding. The destination still needs a DOCMONT VM binary built for that destination OS and CPU. Portability of the file format is distinct from availability of every platform build.

## Target registry

The runtime registry uses these values:

| Identifier | Status | Requirement |
|---|---|---|
| `portable-vm` | implemented | DVM v1 portable bytecode; build VM for each destination host |
| `linux-x86_64` | implemented | Built and tested in this release |
| `windows-x86_64` | requires-toolchain | Windows toolchain and runtime validation; C11 subset only |
| `windows-aarch64` | requires-toolchain | ARM64 Windows toolchain and runtime validation |
| `linux-aarch64` | requires-toolchain | AArch64 toolchain and runtime validation |
| `macos-x86_64` | requires-toolchain | Apple toolchain and runtime validation |
| `macos-arm64` | requires-toolchain | Apple toolchain and runtime validation |
| `android-arm64` | requires-toolchain | Android NDK, packaging and device validation |
| `ios-arm64` | requires-vendor-sdk | Xcode, signing and device validation |
| `web-wasm32` | planned | WebAssembly/WASI backend not implemented |
| `freebsd-x86_64` | planned | Runtime port not implemented/validated |
| `riscv64` | planned | RISC-V backend not implemented/validated |

Inspect the build at runtime:

```sh
docmont targets
docmont target-info portable-vm
docmont host-info
```

A target selector records intent and does not install a toolchain or create a missing backend. Native C emission currently covers only a subset of language/runtime operations and is not a full portable backend.
