# DPM v1 Manifest Subset

DOCMONT Package Manager (DPM) in 8.60.0 accepts the following subset:

```toml
[package]
name = "demo_app"
version = "1.0.0"
edition = "2026"

[dependencies]
math_core = "1.2.0"
```

Rules:
- `name` is an identifier-like package name.
- `version` and dependency versions must be exactly three numeric components.
- `edition` must be `2026`.
- Only `[package]` and `[dependencies]` sections are accepted.
- Dependency declarations are exact version strings and are sorted by name in lockfiles.
- The lock file records root identity, manifest fingerprint, and direct dependency declarations.
- `fnv1a64` is a deterministic drift fingerprint, not a cryptographic signature or package authenticity mechanism.
- Remote fetch, semantic version ranges, transitive graph solving, cache management, artifact checksums, and signature verification are deferred.
