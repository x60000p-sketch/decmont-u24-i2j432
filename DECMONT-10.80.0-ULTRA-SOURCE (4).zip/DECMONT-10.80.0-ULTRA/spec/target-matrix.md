# DOCMONT target matrix

Planning baseline only; none of these targets is claimed as implemented by the current 2.3.0 compiler.

| Target | Native | VM | Required toolchain | Status |
|---|---|---|---|---|
| x86-64 Linux | Planned first | Planned | GCC/Clang, ELF, linker | Not implemented |
| x86-64 Windows | Planned | Planned | MSVC/LLVM, COFF, Windows SDK | Not implemented |
| AArch64 Linux | Planned | Planned | AArch64 toolchain, ELF | Not implemented |
| AArch64 Android | Planned later | Planned | Android NDK, ARM64 ABI | Not implemented |
| x86-64 macOS | Later | Planned | Apple SDK, Mach-O | Not implemented |
| AArch64 macOS | Later | Planned | Apple SDK, Mach-O | Not implemented |
| iOS | Constrained research | Platform-dependent | Apple SDK, signing, sandbox | Not implemented |
| Consoles | Vendor SDK only | Vendor SDK only | Platform-holder authorization | Not a general target |

A target is supported only with a documented target triple/ABI, compatible backend/runtime, CI evidence, target smoke test (or explicitly labeled emulator test), and packaging/signing documentation. Cross-compilation alone does not prove runtime compatibility.
