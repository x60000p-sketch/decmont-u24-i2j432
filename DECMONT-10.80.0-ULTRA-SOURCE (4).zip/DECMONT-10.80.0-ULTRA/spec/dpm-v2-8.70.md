# DOCMONT Package Manager — DPM v2 (8.70.0)

## Manifest example

```toml
[package]
name = "demo-app"
version = "1.0.0"
edition = "2026"

[dependencies]
corelib = { path = "vendor/core", version = "1.2.0" }
```

A dependency path points to a directory containing `docmont.dpm`. DPM validates the loaded package name and declared version, traverses local path dependencies transitively, blocks path traversal outside the permitted project/workspace root, detects dependency cycles, and writes a deterministic v2 lockfile with manifest fingerprints.

## Commands

```sh
docmont dpm-check examples/dpm_8_70/docmont.dpm
docmont dpm-resolve examples/dpm_8_70/docmont.dpm
docmont dpm-lock examples/dpm_8_70/docmont.dpm build/docmont.lock
```

## Scope

Implemented: local path graph, transitive resolution, name/version validation, cycle detection, path-root checks, deterministic lockfile and fingerprints.

Not implemented: remote registry download, authentication, package signatures, cryptographic archive verification, a full semantic-version constraint solver, source cache, and reproducible remote artifact acquisition. Registry declarations remain reported as unfetched; they are not presented as resolved packages.
