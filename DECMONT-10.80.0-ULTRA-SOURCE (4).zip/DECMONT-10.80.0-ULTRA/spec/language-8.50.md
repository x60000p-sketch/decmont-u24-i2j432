# DOCMONT 8.50.0 Language and Interoperability Contract

This release preserves the DOCMONT 3.4.0 source grammar and DVM v1 bytecode encoding. The primary additions are external Java/JNI and x86-64 System V assembly adapter tools.

## Java bridge manifest

A `DOCMONT_JAVA 1` manifest defines a Java package, wrapper class, library name and one or more external C ABI symbols. Supported bridge types are `i64`, `i32`, `f64`, `bool`, `utf8`, and return-only `void`. The generator emits `.java`, `_abi.h`, and `_jni.cpp` files. The generated native symbols must be implemented and linked by the library author; source-level DOCMONT functions are not automatically exported by this bridge yet.

## Assembly module

A `DOCMONT_ASM 1` module targets `x86_64-sysv` and defines integer leaf functions using a restricted register-only instruction set. Arguments use the System V integer argument registers and returns use `rax`. The validator rejects arbitrary assembler text, memory addressing, control-flow labels, calls, stack operations and non-volatile registers. The backend emits GNU `.S` text, which must be assembled and linked by the host toolchain.

## Existing language and runtime behavior

DOCMONT retains the 8.40.0 typed-function checks, DVM v1 runtime, array/object semantics, SSA and memory optimizer. No bytecode format change is introduced. The Java/Assembly adapters are external integration tools; they do not change the core grammar or VM instruction set.

## Not implemented in 8.50.0

This release does not claim C++ feature parity. It does not include a Java compiler, JVM bytecode backend, automatic DOCMONT function export into JNI, unrestricted inline assembly, ARM64 assembly generation, generics, traits, user-defined enums, ownership/borrow checking, exception handling, async/await, or production-quality native backends for all targets.
