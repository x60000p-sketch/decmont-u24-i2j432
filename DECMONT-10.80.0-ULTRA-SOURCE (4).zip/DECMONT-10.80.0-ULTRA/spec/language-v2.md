# DOCMONT Language v2 — implemented subset

## Program structure
```ebnf
program       = header, newline, architecture?, application ;
header        = "!docmont", "[", integer, "]" ;
architecture  = "select", "architecture", "=", identifier ;
application   = "application", "=", "{", member*, "}" ;
member        = "complete" | property | block ;
block         = identifier, "=", "{", property*, "}" ;
property      = identifier, "=", scalar ;
scalar        = identifier | integer | string ;
```

## Current syntax
- Header: `!docmont[2]`
- Architecture: `select architecture = x86_64` or `arm64`
- Application: `application = { ... }`
- Name: `name = "APP_NAME"`
- Blocks: `memory = { ... }`, `compute = { ... }`
- Output: `output = "text"`
- Required terminator: `complete`

## Operator design (reserved, not yet executable)
`= + - / | ° ™ × *` are reserved for a later typed-expression grammar.
Their meanings must be defined per operand type. For example, `+` may mean numeric addition for integers and concatenation for strings, but it must not silently mean both without type rules. `™` is metadata decoration, not a CPU instruction.

## Semantic validation
- name is mandatory.
- architecture must be a supported target.
- memory block must define allocation and management.
- optional memory.bounds accepts `enforced` or `unbounded`.
- duplicate blocks and duplicate properties are errors within the application/block scope.
- unknown properties in the implemented `memory` and `compute` blocks are errors.
- compute.algorithm is recommended.
- complete is mandatory by grammar and validation.

## Planned advanced language features
1. DLEX morphology: decomposition of identifiers and compound terms.
2. DGRAM: grammar with operator precedence and nested expressions.
3. DSEM: typed semantic graph, symbol resolution and ambiguity reporting.
4. DCONTEXT: lexical scopes, modules, imports and context-sensitive names.
5. DLOGIC: contracts, invariants, constraints and compile-time proofs.
6. DOCMONT IR: typed, target-neutral SSA-like representation.
7. Backends: LLVM-based x86-64 and AArch64 code generation.
8. Domain DSLs: graphics, physics, circuit simulation and network protocols.


## DOCMONT 2.2 expression subset

Application statements may declare immutable single-assignment variables with
`let identifier = expression` and emit values with `output = expression`. The
expression grammar is: `expression := additive`; `additive := multiplicative
((+ | -) multiplicative)*`; `multiplicative := primary ((* | /) primary)*`;
`primary := integer | string | identifier | ( expression )`. Operators are left
associative; `*` and `/` have higher precedence than `+` and `-`. The initial
static types are integer and string. Arithmetic requires integer operands.
Variables are visible only after declaration and cannot be redeclared in the
same application scope. Integer arithmetic uses signed 64-bit values with
runtime overflow and division-by-zero diagnostics.
