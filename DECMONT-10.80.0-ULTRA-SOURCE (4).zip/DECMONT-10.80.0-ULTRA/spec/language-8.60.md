# DOCMONT 8.60.0 Language Feature Matrix

The source grammar remains DOCMONT 3.4.0. The following table separates source-language availability from compiler-core APIs.

| Capability | 8.60.0 status | Where available | Limitation |
|---|---|---|---|
| Typed HIR | Foundation implemented | `compiler_core.hpp` | Not yet lowered from the source AST |
| MIR CFG + verifier | Foundation implemented | `compiler_core.hpp` | Structural checks only; no full source MIR lowering |
| Generics | Constraint API implemented | `GenericSolver` | No generic syntax or body monomorphization |
| Traits | Constraint API implemented | `TraitSolver` | Signature matching only; no source `impl` syntax/overlap rules |
| Ownership / Move | Explicit MIR analysis | `ownership.hpp` | Not enabled on all source functions; limited place model |
| Borrow / Lifetime | Conservative CFG analysis | `ownership.hpp` | No full field/reborrow/async lifetime model |
| Enum exhaustiveness | Checker API implemented | `check_enum_patterns` | No source `enum` / `match` grammar or payload patterns |
| Option / Result | C++ runtime API | `error_system.hpp` | No DOCMONT VM tags or `?` operator |
| Module imports | CLI-integrated resolver | `modules-check` | Resolves files; no whole-program symbol/type linking |
| DPM manifest + lock | CLI-integrated subset | `dpm-check`, `dpm-lock` | No package downloads/registry/transitive solver |
| LLVM IR output | Implemented via Clang C lowering | `llvm-ir` | Limited source opcode support; not direct HIR lowering |
| Native x86-64 object | Implemented via Clang/LLVM | `native-object` | Linux x86_64 only; narrow IR subset |
| Inline ASM contract | Validation API | `asm_contract.hpp` | Not DOCMONT source syntax or instruction emitter |
| SIMD contracts | Shape/feature validator | `validate_simd_contract` | No intrinsic library/code generation |
| C ABI validation | Implemented API | `ffi_contract.hpp` | Not full automatic FFI binding from source |
| Java/JNI | Existing generator retained | `java-bindings` | Requires JDK/JNI toolchain; manual native symbol implementation |
| Threads / Atomics / Channels | C++ runtime foundation | `concurrency.hpp` | No VM scheduler or source-level concurrency syntax |

## Newly added CLI commands

```sh
docmont core-info
docmont modules-check <entry.docm> <module-root>
docmont dpm-check <project.dpm>
docmont dpm-lock <project.dpm> <project.lock>
docmont llvm-ir <source.docm> <output.ll> [clang]
docmont native-object <source.docm> <output.o> [clang]
```

## DPM manifest subset

```toml
[package]
name = "demo_app"
version = "1.0.0"
edition = "2026"

[dependencies]
math_core = "1.2.0"
text_util = "0.4.1"
```

Only quoted values, the `package` and `dependencies` sections, and exact numeric `major.minor.patch` versions are accepted. The emitted lock fingerprint uses stable FNV-1a 64-bit and must not be treated as a cryptographic authenticity check.
