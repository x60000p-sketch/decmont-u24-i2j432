# DOCMONT 8.70.0 Direct MIR-to-LLVM Backend

## Goal

Provide a real direct path from verified MIR to LLVM IR for a deliberately restricted, auditable source subset. Unsupported operations are rejected; they are not silently dropped or routed through C.

## Currently supported native MIR operations

- 64-bit integer constants
- Local integer values already lowered into MIR definitions
- Unary integer negation in the source-lowering subset
- `+`, `-`, `*`
- Integer return from `main`

Eligible source functions are straight-line and return an integer. The regression example `examples/native_mir_8_70.docm` calculates `20 + 22`; on x86_64 Linux the object is linked and executed, returning process exit code 42.

## CLI

```sh
docmont llvm-mir examples/native_mir_8_70.docm build/main.ll
docmont native-mir-object examples/native_mir_8_70.docm build/main.o x86_64-unknown-linux-gnu
```

## Object targets tested

- `x86_64-unknown-linux-gnu` — object emitted, linked, and executed
- `aarch64-unknown-linux-gnu` — object emission tested only
- `wasm32-unknown-unknown` — object emission tested only
- `riscv64-unknown-elf` — object emission tested only

All cross-target requests require a Clang build with the corresponding target support. Runtime libraries, ABI glue, linkers, sysroots, deployment, and execution are separate requirements and are not provided by object emission alone.

## Not implemented

- General MIR support for branches, loops, PHI nodes, memory, strings, closures, exceptions, generics, and aggregates
- Full direct Typed-HIR-to-LLVM lowering for all DOCMONT features
- Native linker/packager and target runtime for AArch64, WASM, or RISC-V
- Windows, Apple, Android, or console targets
