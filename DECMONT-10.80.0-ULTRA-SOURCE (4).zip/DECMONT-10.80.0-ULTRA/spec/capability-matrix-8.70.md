# DOCMONT 8.70.0 Capability Matrix

Legend: **Integrated** = source or CLI behavior exercised by tests; **Partial** = a real restricted implementation; **API only** = native API exists but is not a language construct; **Deferred** = not implemented.

| Area | Status | Exact scope |
|---|---|---|
| AST -> Typed HIR -> MIR | Partial / integrated v1 | Source front-end runs and verifiers pass; not every control-flow and runtime semantic is lowered faithfully |
| Generic syntax and inference | Partial | Generic functions, supported direct-call inference, built-in bounds |
| Generic monomorphization | Partial | Stable specialized HIR/MIR records; runtime remains erased; no per-instantiation native machine-code bodies |
| User Traits / impl | Deferred | Built-in trait constraints only; no general user-authored trait/impl system |
| Ownership / Move / Borrow | Partial | Explicit markers, simple source dataflow, `if`/`match` branch joins, local escape checks; loops rejected with `OWN093` |
| Full lifetime system / NLL | Deferred | No complete lifetime parameter inference, reborrowing, or all alias/loop cases |
| Enum / Match | Integrated subset | Source parser, interpreter, DVM, type/exhaustiveness checks; multi-field payload binds as packed array |
| Option / Result / `?` | Integrated subset | Constructors, matching, and tested propagation work in interpreter and DVM |
| Direct MIR -> LLVM IR | Partial | Integer-only straight-line MIR subset, direct emission, unsupported forms rejected |
| Native x86_64 | Verified | Object linked and executed on Linux x86_64; smoke program exit code 42 |
| AArch64 / WASM / RISC-V | Partial | Target object generation tested; no target linking, runtime, packaging, or execution validation |
| DPM v2 | Partial / integrated | Local transitive path dependencies, cycle/version/name validation, deterministic lockfile |
| Remote package registry | Deferred | No download, signature checks, or full semantic-version resolver |
| Assembly DSL | Partial / existing | External x86-64 DSL and assembler emission remain; no inline assembly in general DOCMONT source |
| ABI / C / Java | Partial / existing | C ABI contracts and Java/JNI generation retained; not a Java compiler or JVM |
| SIMD | Partial / contract only | Capability/shape validation; no general SIMD lowering or code generation |
| Threads / Atomics / Channels | API available | Native runtime primitives retained |
| TaskScheduler | API only / tested | Fixed worker pool, futures, exception propagation, shutdown; not wired to DOCMONT `async`/`await` or VM |
| Async / Await | Deferred | No source syntax or VM scheduler integration |
| Cross-platform release binaries | Deferred | Only Linux x86_64 compiler binary built and verified |

## Verification summary

- CTest: 60/60 passed
- VS Code LSP integration: 8/8 tests passed (also included in CTest)
- VS Code `npm run check`: passed
- Interpreter and DVM output equality: passed for `examples/language_8_70.docm`
- Direct LLVM object: x86_64 linked and executed; returned 42
- Cross-target object output: AArch64 Linux, wasm32, RISC-V ELF generation tests passed
- DPM: two transitive local packages resolved; lockfile generation tested
- Concurrency: 120 submitted tasks, result future, exception propagation, and post-shutdown rejection tested

## Compatibility

- Compiler: 8.70.0
- Language compatibility: 3.4.0
- DVM: v1; encoding unchanged
- Verified host: Linux x86_64
