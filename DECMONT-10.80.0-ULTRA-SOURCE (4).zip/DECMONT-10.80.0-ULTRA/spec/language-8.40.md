# DOCMONT 8.40.0 Language Contract

This document describes the semantic/runtime contract strengthened by compiler release 8.40.0. It does not replace the DOCMONT 3.4.0 grammar specification.

## Function declarations and types

```docmont
fn add(left: Int, right: Int): Int {
    return left + right
}

fn label(name: String = "DOCMONT"): String {
    return "Hello " + name
}

fn offset(base: Int, value: Int = base + 3): Int {
    return value
}
```

Supported annotation names currently map to these runtime categories:

| Names | DOCMONT type | Runtime representation |
|---|---|---|
| `Int`, `Integer`, `i32`, `i64`, `Number` | Integer | signed 64-bit integer |
| `Bool`, `Boolean` | Boolean | integer-compatible truth value |
| `String` | String | byte string |
| `Array` | Array | bounded VM array |
| `Object` | Object | dynamic property map |
| `Function` | Function | function/closure reference |
| `Void`, `Unit` | Void | no explicit result |

The checker validates declared parameter types, provided argument types, return statements, and default values. Required parameters cannot follow parameters with defaults. Non-void typed functions need a return on the simple paths the current flow analysis can prove.

A function alias can retain its statically known signature:

```docmont
let combine = add
output = combine(20, 22)
```

## Default argument evaluation

DVM lowering stores each explicitly provided argument once. It then evaluates omitted defaults from left to right. Earlier parameter names in a default expression refer to the already materialized argument values:

```docmont
fn offset(base: Int, value: Int = base + 3): Int {
    return value
}
output = offset(5)
```

Statically known named function aliases use the same lowering. Unresolved/dynamic function values still rely on runtime arity rules and should be called with the full declared parameter list in this release.

## Expressions and built-ins

- Integer arithmetic is signed 64-bit with checked overflow in the VM.
- `+` supports integer addition and string concatenation. VM concatenation has a 16 MiB limit.
- `&&` and `||` are short-circuiting.
- Conditions accept `Bool` or `Int` values.
- `push(array, value)` appends and returns the resulting length.
- `pop(array)` removes and returns the last item; an empty array is a runtime error.
- `len(value)` and `length(value)` accept arrays, objects, and strings. String length is the number of UTF-8 bytes, not Unicode grapheme clusters.

## Portable DVM execution

The compiler can emit DVM version 1 bytecode:

```sh
docmont bytecode source.docm app.dvm
docmont verify app.dvm
docmont vm-run app.dvm
```

DVM fields use fixed-width encodings and explicit little-endian serialization. The bytecode instruction stream does not contain x86/AArch64 machine instructions, so it can be transported between hosts. Execution still requires a DOCMONT VM compiled for the destination host.

## Type system and language features not yet present

This release does not implement generic type parameters, interfaces/traits, user-defined enums, pattern matching, exception handling, async/await, concurrency primitives, package/module import resolution, macro expansion, full FFI, or full native-backend parity. The grammar compatibility version remains 3.4.0.
