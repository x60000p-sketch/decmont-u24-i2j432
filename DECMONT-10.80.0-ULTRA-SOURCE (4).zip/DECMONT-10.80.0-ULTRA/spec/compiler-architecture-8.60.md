# DOCMONT 8.60.0 — Compiler Architecture Specification

## 1. Design goals

8.60.0 establishes a set of explicit compiler contracts that can mature into a unified systems-language pipeline without breaking the existing 3.4.0 grammar or DVM v1 artifacts. The architecture is intentionally layered:

1. **Frontend:** current lexer, parser, AST, semantic validation, and function-contract validation.
2. **Typed HIR:** interned type identities, generic parameter references, typed locals/parameters, and function signatures.
3. **MIR:** explicit places, operations, basic blocks, CFG successors, and verifier diagnostics.
4. **Ownership analysis:** forward dataflow over MIR move/borrow events; unknown path states are conservatively rejected.
5. **Existing optimization IR:** the current instruction IR, SSA, integer range analysis, and partitioned Memory SSA remain the production path for existing source programs.
6. **Backends:** DVM v1; existing restricted C11 emitter; a Clang adapter that turns the supported C11 subset into LLVM IR or x86-64 ELF relocatable objects; existing Java/JNI and x86-64 assembly adapters.

**Important separation:** Typed HIR/MIR is now represented and verified as a public compiler-core API, but source AST-to-HIR-to-MIR lowering is not yet implemented. The architecture document defines that future connection; the implementation report distinguishes it from current executable paths.

## 2. Type identity and type interning

`TypeContext` assigns stable-in-context 32-bit `TypeId` values to interned types. The supported model kinds are:

- Unit, Bool, I32, I64, U32, U64, F32, F64, String
- Named and GenericParameter
- Tuple, Reference, MutableReference, Array
- Option, Result, Function, Enum

Composite type keys include the kind, nominal/generic name, array length, and child TypeIds. The context owns all type records and exposes recursive display and generic substitution. TypeIds are process/context-local; they are not stable serialized identifiers and must not be written into bytecode or lockfiles.

## 3. Trait solving and generic specialization

A `TraitDefinition` contains required method names and canonical signature strings. A `TraitImplementation` is accepted only when:

- the trait exists;
- the target TypeId is valid;
- there is no prior implementation for the same `(trait, type)` pair;
- every required method exists with an exact signature;
- no undeclared method is provided.

A `GenericFunction` lists named generic parameters and required trait constraints. Instantiation requires exactly one valid TypeId for each parameter, validates every trait bound, recursively substitutes generic parameters through composite parameter/return types, and caches a specialization identity derived from the function name and concrete TypeIds.

This is constraint solving and specialization identity generation. It does not yet clone function bodies, perform recursive monomorphization, resolve overlapping blanket impls, or emit per-specialization machine code.

## 4. Typed HIR and MIR verification

Typed HIR records functions, parameters, locals, mutability metadata, and return TypeIds. The verifier detects duplicate function/local names, invalid TypeIds, and value returns from unit functions.

MIR represents a function as numbered basic blocks. Each operation names an explicit place and optional loan identity; blocks provide successor IDs. The MIR verifier checks unique block IDs, a valid entry block, valid successor edges, valid type references for typed writes, non-empty place names, and loan IDs for borrow operations.

The verifiers are structural foundations. They do not yet prove all expression typing, definite assignment, dominance, or full SSA equivalence for source-language functions.

## 5. Ownership and borrow dataflow

The ownership engine models each place as one of `Uninitialized`, `Live`, `Moved`, or `MaybeMoved`. At control-flow joins, differing incoming states become `MaybeMoved`. Active loans are conservatively unioned across incoming paths.

Operations include:

- Declare / Assign
- Read / Move / Drop
- BorrowShared / BorrowMutable / EndBorrow
- ReturnReference with source and destination region depths

Safety rules reject reads of moved, uninitialized, or maybe-moved places; moves/drops/assignments while borrowed; mutable/shared conflicts; duplicate/inactive loan IDs; and returning references from a deeper (shorter-lived) region into a shallower (longer-lived) region.

The engine is deliberately conservative. It does not yet model Copy types, field projections, reborrowing, two-phase borrows, destructors, closure capture, async suspension, or complete source lexical lifetimes.

## 6. Enums and pattern checking

Enum definitions are described as a named list of variants. Patterns currently include explicit variant and wildcard forms. The checker reports missing variants, duplicates, and unknown variants and computes exhaustiveness. Payload patterns, guards, nested destructuring, and parser/runtime lowering are deferred.

## 7. Option and Result semantics

`Option<T>` represents absence/presence. `Result<T,E>` carries either a value or a typed error. Both support `map`. An explicit propagation carrier allows a caller to distinguish success from the error to return without exceptions.

The C++ API does not yet imply source-language syntax, VM tagged-value support, bytecode tags, error stack traces, or an unwind ABI. The `?` token/operator is not implemented.

## 8. Modules and package management

The current `modules::Resolver` scans imports, resolves dotted module names beneath a configured root, detects cycles, prevents path escapes, and returns dependency order. The new CLI exposes it as `modules-check`.

The DPM v1 manifest subset supports `[package]` with quoted `name`, `version`, `edition`, and `[dependencies]` exact version declarations. Dependencies are sorted before lockfile output. The manifest fingerprint is FNV-1a 64-bit and is for deterministic change detection only. Remote fetching, registry authentication, transitive solving, checksums of downloaded artifacts, source mirroring, and cache eviction are deferred.

## 9. LLVM and native object adapter

The native adapter uses the existing DOCMONT instruction IR and `emit_c_source`. Clang is invoked with an explicit `x86_64-unknown-linux-gnu` target:

- `-S -emit-llvm` creates textual LLVM IR;
- `-c` creates an ELF64 relocatable object.

Clang lowers the generated C through its LLVM pipeline. There is no direct DOCMONT HIR/MIR-to-LLVM IR translator in 8.60.0, and the environment does not include the LLVM C++ development SDK. The tested object is compiled, linked, and executed on Linux x86_64.

The C emitter supports a deliberately small instruction set: integer/string constants, local load/store, print, simple jumps, and checked integer add/subtract/multiply/divide. It rejects array operations and now rejects every unimplemented opcode. This restriction avoids generating apparently successful but semantically incomplete object files.

## 10. FFI, assembly, SIMD, and concurrency

- C ABI contract: scalar and pointer-compatible types, C calling convention, no variadics, and explicit lifetime contract for returned UTF-8 pointers.
- Java/JNI: 8.50.0 binding generator retained and re-verified with the installed JDK.
- Assembly: existing restricted x86-64 System V source adapter retained; new operand/clobber contract checker is not parser-integrated.
- SIMD: contract metadata recognizes selected SSE2/AVX2 vector shapes and operations; it does not emit instructions.
- Concurrency: C++ wrappers use standard threads, atomics, mutexes, condition variables, and queues. There is no DOCMONT async executor, scheduler, VM-level channel, or language syntax.

## 11. Compatibility and target boundaries

Language compatibility remains 3.4.0 and DVM bytecode encoding remains v1 unchanged. Native object and LLVM IR generation in this release is tested only for Linux x86_64. Clang being LLVM-based does not itself provide tested Windows, macOS, ARM64, RISC-V, WebAssembly, Android, or iOS support.
