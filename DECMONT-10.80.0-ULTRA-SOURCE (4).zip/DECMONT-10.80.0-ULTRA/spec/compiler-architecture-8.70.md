# DOCMONT 8.70.0 Compiler Architecture

## Pipeline

```text
DOCMONT source
  -> Lexer / Parser / AST
  -> semantic + function-contract checks
  -> Typed HIR lowering and verification
  -> MIR lowering and verification
       |-> interpreter / DVM lowering (existing execution path)
       `-> restricted native integer MIR lowering
              -> LLVM IR text
              -> Clang target code generation
              -> native relocatable object
```

The direct native path consumes verified MIR and does not pass through generated C. The legacy `native-object` / `llvm-ir` route remains a separate C11-to-Clang adapter for its historical supported subset.

## Typed HIR

The source front-end interns source and composite types, records function parameters and result types, carries generic parameter declarations and trait constraints, and verifies basic type references and function structure. `core-check <file.docm>` runs this lowering and the HIR/MIR verifiers.

## Generic specialization

Generic function declarations are represented in HIR. For resolved direct calls, the front-end creates specialization records with stable names (for example `identity__i64`) and substituted parameter/result types in HIR and MIR. Runtime execution continues through generic-erased interpreter/DVM function bodies; complete monomorphized native function-body code generation is not yet implemented.

Built-in constraints currently recognized by source checking include `Numeric`, `Display`, `Equatable`, and `Clone`. This does not yet provide user-authored `trait`/`impl` declarations or a complete coherence/orphan-rule implementation.

## MIR

MIR includes verified basic-block structure and operations for the currently lowered constructs. The direct native integer subset adds `ConstantI64`, `AddI64`, `SubI64`, `MulI64`, and `ReturnI64`, with def-use and ordering checks. The source frontend emits native integer operations only for eligible straight-line functions.

HIR/MIR lowering is version 1. It does not yet preserve all source control-flow, exception, closure, or memory semantics in a fully faithful general-purpose MIR.

## Ownership

The source checker handles explicit `move`, shared borrow `&`, mutable borrow `&mut`, branch joins for supported `if`/`match`, use-after-move, conflicting loans, and local-reference escape checks. The lower-level ownership CFG API supports explicit place/loan events and dataflow.

Loop-carried source loans are explicitly rejected (diagnostic `OWN093`) rather than guessed. This is not a complete Rust-style non-lexical lifetime system, and reborrowing, lifetime parameters, and all alias cases remain unfinished.

## Execution and compatibility

- Language compatibility: 3.4.0
- DVM bytecode: v1; encoding unchanged
- Existing interpreter and DVM remain supported
- Native direct backend: restricted integer MIR subset
