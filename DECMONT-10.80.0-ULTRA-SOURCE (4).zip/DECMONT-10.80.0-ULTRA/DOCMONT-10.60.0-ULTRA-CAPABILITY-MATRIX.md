# DECMONT 10.60.0 capability matrix

| Area | Status | Verified scope |
|---|---|---|
| Language compatibility | Available | 3.4.0 retained |
| DVM | Available | Bytecode v1 retained |
| Native C11 lowering | Expanded subset | Arithmetic, branches, comparisons, logic, strings and core arrays |
| Native arrays | Available in lowered subset | Create/get/set/length/push/pop with type and bounds checks |
| Native heap registry | Available | Tracks up to 65,536 array objects per process |
| Native heap cleanup | Available | `atexit` cleanup frees each registered array payload and header once |
| Native array capacity | Bounded | 1,000,000 aggregate reserved `Value` slots per process |
| Ownership semantics | Limited | Process-lifetime arena/registry; no tracing GC, refcounting, deterministic lexical drop or cycle collection |
| Native verifier | Available | Jump bounds, reachable stack dataflow, merge-depth consistency, underflow, 4096-slot stack cap and 1,000,000-instruction cap |
| Native compiler parity | Not complete | Objects, functions, closures, cells and other unsupported opcodes still use DVM |
| GPU backends | Partial | Existing probes/adapters; not full production Vulkan/D3D12/Metal renderers |
| ONNX GPU | Not implemented | Bounded CPU operator subset only |
| Platforms | Not fully validated | Linux x86_64 build; other platforms need dedicated CI/toolchains |
| Consoles | Not validated | Vendor SDK and authorized devkits required |

The registry is a process-lifetime ownership mechanism, not a garbage collector. It prevents native arrays from remaining allocated after process termination and handles all generated-program exit paths, but it does not reclaim arrays while a program is still running.
