# DECMONT 10.30.0 ULTRA — Release Notes

## Native backend resource hardening
- Adds a verifier limit of 4,096 operand-stack slots before C11 source emission.
- Rejects instruction streams larger than 1,000,000 instructions before control-flow analysis.
- Keeps stack-depth/control-flow merge validation from 10.20.0.
- Adds regression tests for stack-limit rejection and minimum valid stack allocation.

## Compatibility
- Language compatibility: 3.4.0.
- DVM bytecode format remains v1.
- Native C emission remains a restricted opcode subset; this release does not claim full-language native compilation.

## Validation scope
Build and tests are reported only for the host platform actually used to produce this package. Other operating systems, GPU APIs, and console SDK targets require their own toolchains and hardware validation.
