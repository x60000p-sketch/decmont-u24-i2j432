# DECMONT 10.70.0 ULTRA — Changelog

- Added aggregate 64 MiB Native C11 array-payload budget.
- Added byte accounting for array creation and successful capacity growth.
- Added capacity multiplication overflow guard.
- Preserved transactional `realloc` behavior: accounting changes only after successful allocation.
- Added 10.70.0 native heap source-generation regression tests.
- Updated CLI, CMake, and VS Code extension release identifiers.
