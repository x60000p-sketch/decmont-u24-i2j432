# Changelog — DOCMONT 10.00.0 ULTRA

## Added
- Consolidated `doctor` diagnostics for host architecture, pointer width, logical CPU thread count, GLES compute/hardware acceleration and GPU backend runtime/device/queue status.
- Explicit scope reporting for native compiler, game engine and AI execution.
- CLI contract test for doctor output.

## Changed
- CMake project, CLI version strings, language metadata, VS Code extension metadata and integration expectations advanced to 10.00.0.
- Language compatibility remains 3.4.0; DVM bytecode remains v1.

## Not claimed
- Full native compiler for every language feature or architecture.
- Complete Vulkan, Direct3D 12 or Metal renderer.
- General ONNX GPU provider.
- Production-ready game engine on every platform.
