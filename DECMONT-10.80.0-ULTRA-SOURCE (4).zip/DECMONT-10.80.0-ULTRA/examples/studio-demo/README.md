# DOCMONT Studio Demo Project

Open this directory as the Studio workspace. The `arena.dscene` document is a simple JSON scene inspected by the canvas preview. `surface.dmat` is a material metadata example. These files are demonstration data; this release does not yet import/render their assets through a GPU backend.

Launch from the repository root:

```bash
DOCMONT_EXECUTABLE="$PWD/build/docmont" tools/docmont-studio "$PWD/examples/studio-demo" 8787
```
