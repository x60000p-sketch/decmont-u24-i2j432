#include "docmont/game_engine.hpp"
#include "docmont/engine.hpp"
#include <iostream>

int main() {
    using namespace docmont;
    using namespace docmont::game;

    engine::Registry ecs;
    const auto player = ecs.create();
    ecs.emplace<engine::Transform>(player, engine::Transform{{0, 2, 0}});

    AssetCatalog assets;
    const auto texture = assets.register_asset("demo/player-albedo", AssetKind::Texture, "Assets/player-albedo.ktx");
    const auto material = assets.register_asset("demo/player-material", AssetKind::Material, "Assets/player.mat");
    assets.add_dependency(material, texture);

    WorldPartition world(128.0f);
    world.define_cell({0,0,0}, 2);
    world.define_cell({1,0,0}, 5);
    const auto streamed = world.update_focus({8,0,8}, 0, 1, 8, 1);

    PhysicsWorld physics;
    RigidBodyDesc floor; floor.position={0,-1,0}; floor.half_extents={10,1,10}; floor.mass=0;
    physics.add_body(floor);
    RigidBodyDesc body; body.position={0,2,0}; body.mass=1;
    const auto player_body=physics.add_body(body);
    for (int frame=0; frame<60; ++frame) (void)physics.step(1.0f/60.0f);

    NavigationGrid navigation(16,16);
    navigation.set_blocked({7,4},true);
    navigation.set_blocked({7,5},true);
    const auto route=navigation.find_path({0,0},{12,12});

    BehaviorTree ai;
    const auto can_patrol=ai.condition("can-patrol", [] { return BehaviorStatus::Success; });
    const auto patrol=ai.action("patrol", [] { return BehaviorStatus::Running; });
    const auto ai_root=ai.sequence({can_patrol,patrol});

    AudioScene audio;
    audio.upsert({1,{2,0,0},1.0f,1.0f,40.0f,2,true});
    const auto voices=audio.mix({{0,0,0}},16);

    const auto snapshot=std::array<ReplicatedTransform,1>{{{1,{0,1,0}}}};
    const auto packet=SnapshotCodec::encode(1,snapshot);
    const auto render_plan=build_render_pipeline(RenderPath::Deferred);

    FrameProfiler profiler;
    profiler.record({4.2,5.1,0.6,0.3,0.2,120,64000,static_cast<std::uint64_t>(ecs.size()),32*1024*1024,64*1024*1024});

    std::cout << "DOCMONT 9.00.0 ULTRA game systems\n"
              << "ECS entities: " << ecs.size() << '\n'
              << "Assets validated: " << (assets.validate().empty() ? "yes" : "no") << '\n'
              << "World cell transitions: " << streamed.size() << '\n'
              << "Physics player Y: " << physics.body(player_body)->position.y << '\n'
              << "Navigation path nodes: " << (route ? route->size() : 0) << '\n'
              << "AI tick status: " << static_cast<int>(ai.tick(ai_root)) << '\n'
              << "Mixed audio voices: " << voices.size() << '\n'
              << "Network snapshot bytes: " << (packet ? packet->size() : 0) << '\n'
              << "Deferred render graph: " << (render_plan.ok ? "valid" : "invalid") << '\n'
              << "Frame CPU ms: " << *profiler.average_cpu_ms() << '\n';
    return render_plan.ok && route && packet ? 0 : 1;
}
