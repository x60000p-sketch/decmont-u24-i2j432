#include "docmont/engine.hpp"
#include <iostream>

struct Position { float x, y, z; };
struct Velocity { float x, y, z; };

int main() {
    docmont::engine::Registry world;
    const auto actor = world.create();
    world.emplace<Position>(actor, Position{1.0f, 2.0f, 3.0f});
    world.emplace<Velocity>(actor, Velocity{0.1f, 0.0f, 0.0f});

    for (const auto entity : world.view<Position, Velocity>()) {
        auto* position = world.get<Position>(entity);
        const auto* velocity = world.get<Velocity>(entity);
        position->x += velocity->x;
        std::cout << "actor.x=" << position->x << '\n';
    }

    docmont::engine::SceneGraph scene;
    const auto root = scene.create({{10, 0, 0}, {2, 2, 2}});
    const auto child = scene.create({{1, 0, 0}, {1, 1, 1}});
    if (!scene.set_parent(child, root)) return 1;
    const auto world_matrix = scene.world_matrix(child);
    if (!world_matrix) return 1;
    const auto world_position = docmont::math::transform_point(*world_matrix, {0, 0, 0});
    std::cout << "child.world.x=" << world_position.x << '\n';
    return 0;
}
