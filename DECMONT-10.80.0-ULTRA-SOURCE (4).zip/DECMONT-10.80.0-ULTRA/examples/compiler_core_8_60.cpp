// DOCMONT 8.60.0 core API example. Build through the project test targets.
#include "docmont/compiler_core.hpp"
#include "docmont/ownership.hpp"
#include "docmont/error_system.hpp"
#include <iostream>
int main() {
    using namespace docmont::core;
    TypeContext types;
    const auto i32 = types.primitive(TypeKind::I32);
    const auto t = types.generic_parameter("T");
    TraitSolver traits;
    traits.define_trait({"Numeric", {{"add", "(Self,Self)->Self"}}});
    traits.add_implementation({"Numeric", i32, {{"add", "(Self,Self)->Self"}}});
    GenericFunction sum{"sum", {{"T", {"Numeric"}}}, {t,t}, t};
    GenericSolver solver(types, traits);
    const auto concrete = solver.instantiate(sum, {{"T", i32}});
    if (!concrete.ok) return 1;
    std::cout << concrete.specialization_name << " -> " << types.display(concrete.concrete_return) << '\n';
    return 0;
}
