#include "docmont/rendering.hpp"
#include <iostream>

int main() {
    docmont::render::MeshData mesh;
    mesh.vertices = {
        {{-1.0f, -1.0f, 0.0f}, {0.0f, 0.0f, 1.0f}, {0.0f, 0.0f}},
        {{ 1.0f, -1.0f, 0.0f}, {0.0f, 0.0f, 1.0f}, {1.0f, 0.0f}},
        {{ 0.0f,  1.0f, 0.0f}, {0.0f, 0.0f, 1.0f}, {0.5f, 1.0f}}
    };
    mesh.indices = {0, 1, 2};

    docmont::render::MeshCatalog assets;
    const auto handle = assets.insert("demo-triangle", std::move(mesh));

    docmont::render::Camera camera;
    camera.position = {0.0f, 0.0f, 4.0f};
    camera.target = {0.0f, 0.0f, 0.0f};
    const auto view_projection = camera.projection_matrix() * camera.view_matrix();
    const auto bounds = assets.get(handle)->bounds();

    std::cout << "DOCMONT 4.6 rendering core\n"
              << "mesh assets: " << assets.size() << "\n"
              << "bounds x: " << bounds.minimum.x << " .. " << bounds.maximum.x << "\n"
              << "view-projection m00: " << view_projection.at(0, 0) << "\n";
    return 0;
}
