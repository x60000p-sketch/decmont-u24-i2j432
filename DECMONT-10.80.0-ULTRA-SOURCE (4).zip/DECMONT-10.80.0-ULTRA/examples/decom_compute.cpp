#include "docmont/decom.hpp"
#include <iostream>
#include <vector>

int main() {
    using namespace docmont::decom;
    const std::vector<double> samples{10, 20, 30, 40};
    std::cout << "DECOM " << version << "\n";
    std::cout << "mean=" << selea::mean(samples) << " variance=" << stats::variance(samples) << "\n";

    inplot::KernelConfig config;
    config.name = "compute-worker-pool";
    config.workers = 4;
    auto plan = inplot::create(config);
    inplot::reserve(plan, 4096);
    std::cout << inplot::describe(plan) << "\n";

    auto optimum = optimize::golden_section([](double x) { return (x - 3.0) * (x - 3.0); }, -10, 10);
    std::cout << "minimum x=" << optimum.x << " value=" << optimum.value << "\n";
    std::cout << "registered modules=" << abi::count() << "\n";
}
