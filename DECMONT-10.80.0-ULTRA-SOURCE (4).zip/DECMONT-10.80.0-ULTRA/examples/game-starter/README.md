# GameStarter

DOCMONT ULTRA project scaffold.

## Commands

```bash
docmont-project check .
docmont-project assets .
docmont-project build .
docmont-project package .
```
