#include "docmont/object_runtime.hpp"
#include <iostream>
#include <string>

struct Entity { int health; std::string label; };

int main() {
    docmont::objects::ObjectRuntime runtime;
    const auto entity = runtime.create<Entity>(Entity{100, "player"});
    {
        auto root = runtime.root(entity);
        if (auto* value = runtime.get<Entity>(entity)) {
            value->health -= 25;
            std::cout << value->label << " health=" << value->health << '\n';
        }
    }
    runtime.release(entity);
    std::cout << "live objects=" << runtime.stats().live_objects << '\n';
}
