# DOCMONT Android integration (4.2.0)

This is an Android Gradle/NDK project scaffold. It packages a JNI shared library for `arm64-v8a` and `x86_64`, linking the DOCMONT compiler/runtime foundation and the VLOT hybrid-engine core into the native Android library.

## Build

Install Android Studio or the Android SDK command-line tools, Android NDK, CMake 3.22.1 and a compatible JDK. Then run from this directory:

```bash
gradle :app:assembleDebug
```

The generated APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Current boundary

The Gradle/NDK/JNI source integration is implemented, including `src/vlot.cpp` in the Android native target. An APK has not been built or device-tested in this environment unless a successful SDK/NDK build is recorded separately. This is not yet an Android GPU surface/swapchain renderer, a complete Android application framework, or a Play Store release pipeline.

The VLOT 3.4 host modules are part of the native library sources. This does not imply a built APK or a GPU surface renderer; Android packaging and device execution still require the Android SDK/NDK and device validation.
