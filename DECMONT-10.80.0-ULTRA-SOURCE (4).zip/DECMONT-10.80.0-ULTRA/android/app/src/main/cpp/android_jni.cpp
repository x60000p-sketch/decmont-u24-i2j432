#include <jni.h>
extern "C" JNIEXPORT jstring JNICALL
Java_org_docmont_app_MainActivity_nativeVersion(JNIEnv* env, jclass) {
    return env->NewStringUTF("DOCMONT 4.7.0 (language compatibility 3.4.0) | VLOT hybrid modules | Android ARM64/x86_64 bridge ready");
}
