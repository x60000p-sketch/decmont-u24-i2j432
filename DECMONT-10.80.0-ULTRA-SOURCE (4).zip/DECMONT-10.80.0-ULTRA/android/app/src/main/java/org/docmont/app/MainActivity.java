package org.docmont.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public final class MainActivity extends Activity {
    static { System.loadLibrary("docmont_android"); }
    private static native String nativeVersion();
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        TextView view = new TextView(this);
        view.setText("DOCMONT Android Runtime Bridge\\n" + nativeVersion());
        view.setTextSize(20);
        view.setPadding(32, 48, 32, 32);
        setContentView(view);
    }
}
