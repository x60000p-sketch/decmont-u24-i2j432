# DECMONT 10.60.0 Changelog

- Added bounded native array-object registry in generated C11.
- Added deterministic process-exit cleanup for array headers and payload buffers.
- Made array registration failure-safe and transactional.
- Added CTest regression coverage for registry bounds, cleanup generation and atexit wiring.
- Updated CLI, project metadata, release docs and capability matrix to 10.60.0.
