# Sony SDK bridge. The licensed vendor CMake toolchain is never redistributed.
if(NOT DOCMONT_SONY_CMAKE_TOOLCHAIN)
  message(FATAL_ERROR "Set DOCMONT_SONY_CMAKE_TOOLCHAIN to the CMake toolchain supplied with your licensed Sony SDK, or use tools/docmont-console-build with a .dcsdk manifest")
endif()
if(NOT EXISTS "${DOCMONT_SONY_CMAKE_TOOLCHAIN}")
  message(FATAL_ERROR "DOCMONT_SONY_CMAKE_TOOLCHAIN does not exist")
endif()
include("${DOCMONT_SONY_CMAKE_TOOLCHAIN}")
