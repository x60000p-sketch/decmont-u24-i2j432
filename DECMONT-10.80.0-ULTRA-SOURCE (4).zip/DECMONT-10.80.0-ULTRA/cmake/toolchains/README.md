# DOCMONT 9.00.0 platform toolchains

- Linux x86_64: native host build (`linux-release`).
- Windows x64: configure on Windows with Visual Studio 2022 (`windows-msvc-release`).
- macOS: configure on macOS with Xcode (`macos-universal-release`).
- Android arm64: provide the official Android NDK in `ANDROID_NDK_HOME` or `ANDROID_NDK_ROOT` (`android-arm64-release`).
- PlayStation: use `tools/docmont-console-build` and a local `.dcsdk` manifest that points to your licensed Sony SDK's own compiler, headers, and CMake toolchain. No vendor files are included.
- Xbox: equivalent manifest flow for a licensed Microsoft GDK installation.

Only the Linux x86_64 configuration is built and tested in this release environment. Other presets/configurations require their native SDK/host and device validation.
