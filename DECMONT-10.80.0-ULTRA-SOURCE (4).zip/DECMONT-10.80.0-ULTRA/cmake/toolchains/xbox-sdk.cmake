# Microsoft GDK bridge. The licensed vendor CMake toolchain is not redistributed.
if(NOT DOCMONT_XBOX_CMAKE_TOOLCHAIN)
  message(FATAL_ERROR "Set DOCMONT_XBOX_CMAKE_TOOLCHAIN to the CMake toolchain supplied with your licensed GDK")
endif()
if(NOT EXISTS "${DOCMONT_XBOX_CMAKE_TOOLCHAIN}")
  message(FATAL_ERROR "DOCMONT_XBOX_CMAKE_TOOLCHAIN does not exist")
endif()
include("${DOCMONT_XBOX_CMAKE_TOOLCHAIN}")
