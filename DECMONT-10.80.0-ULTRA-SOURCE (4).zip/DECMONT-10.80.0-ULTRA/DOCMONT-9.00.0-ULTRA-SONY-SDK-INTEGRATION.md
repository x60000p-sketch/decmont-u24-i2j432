# DOCMONT 9.00.0 ULTRA — Sony PlayStation SDK Integration

This release adds an adapter that consumes an SDK installed and licensed by the developer. The vendor SDK, compiler, linker, CMake toolchain and devkit are not redistributed.

## 1. Prepare a private manifest

Copy `DOCMONT-9.00.0-ULTRA-PS5-SDK-MANIFEST.example` to a private path such as `~/sdk-private/ps5.dcsdk`. Replace each placeholder with paths from your installed Sony SDK:

- `sdk_root`: SDK installation root.
- `sdk_version`: exact installed SDK version.
- `compiler`: SDK compiler executable, relative to `sdk_root` or absolute inside it.
- `linker`: optional linker executable.
- `cmake_toolchain`: vendor-supplied CMake toolchain file.
- `include_dir`: SDK include directory.
- `link_libraries`: optional comma-separated libraries required by your CMake game project.
- `license_acknowledged=true`: set only when your license authorizes the integration.

The manifest should remain private if it reveals internal SDK paths or licensed installation details.

## 2. Validate the SDK manifest

```bash
build/release/docmont console-sdk-probe ps5 ~/sdk-private/ps5.dcsdk
```

## 3. Configure and build a CMake project

The source project must already contain a CMakeLists.txt that uses the vendor SDK's supported build conventions.

```bash
tools/docmont-console-build ps5 /path/to/your/cmake-game \
  --manifest ~/sdk-private/ps5.dcsdk \
  --build-dir /tmp/docmont-ps5-build \
  --config Release
```

Start with `--dry-run` to validate the manifest and inspect the CMake commands without invoking the SDK.

## 4. Official vendor steps remain required

The adapter stops after the SDK's CMake configure/build step. Use the vendor's official tools and procedures for packaging, signing, deployment, devkit testing, title requirements and certification. DOCMONT does not bypass SDK licensing, platform security or signing requirements.

## Important validation boundary

The adapter is covered by an automated test using a synthetic SDK fixture and fake CMake dispatcher. No real Sony SDK or PS5 devkit was mounted in the DOCMONT build environment for this release, so no PlayStation binary, deployment or certification result is claimed. Once you run this adapter with your real licensed SDK, its vendor-specific diagnostics become the authoritative next validation step.
