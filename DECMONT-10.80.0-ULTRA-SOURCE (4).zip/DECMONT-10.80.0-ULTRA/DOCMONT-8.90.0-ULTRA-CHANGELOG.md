# DOCMONT 8.90.0 ULTRA — Changelog

## Added
- `docmont-project` project lifecycle CLI: `new`, `check`, `assets`, `build`, and `package`.
- Complete starter game-project layout: `docmont.toml`, DOCMONT source entry, JSON scene, asset directories, README, and ignore rules.
- Asset inventory with extension classification, byte size, SHA-256, and stale-manifest detection.
- Project validation for TOML fields, safe relative paths, scene JSON shape, DOCMONT compiler diagnostics, and asset integrity.
- DVM project build workflow: compile, verify, smoke-run, and write a build manifest with artifact hash and captured output.
- Deterministic source/assets ZIP packaging with fixed timestamps, sorted file order, and build/cache exclusion.
- Visual Studio project dashboard plus Project Check, Asset Manifest, Build, and Package API actions.
- Project lifecycle and release-engineering documentation.
- CMake Release/Debug presets, installation rules for the project tool, Studio, starter template and docs.
- Python 3.11 CI setup and an end-to-end project lifecycle test.

## Improved
- Studio version/health metadata and UI actions updated to 8.90.0.
- Project names constrained to a safe portable identifier.
- Manifest, scene and asset-manifest paths are constrained to the project root; symlink escapes are rejected.
- Package generation is deterministic and excludes `build`, `dist`, `install`, `.git`, cache, node modules, and Studio backups.
- Compiler CLI exposes `project-info` for the integrated workflow.
- VS Code and compiler version contracts updated to 8.90.0.

## Compatibility
- Language compatibility remains `3.4.0`.
- DVM bytecode remains `v1`; no encoding change.
- Existing 8.80.0 ULTRA runtime, animation, network, ONNX, GPU probe, console manifest, and Studio foundations are retained.

## Validation
- CMake Release build: passed on Linux x86_64.
- CTest: 72/72 passed.
- VS Code LSP integration: 8/8 passed.
- `npm run check`: passed.
- Installed SDK smoke test: passed.
- Project scaffold/check/assets/build/verify/run/package workflow: passed.
- Deterministic packaging comparison: matching SHA-256.
