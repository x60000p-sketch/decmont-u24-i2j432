#include "gpu_backend_internal.hpp"
#import <Metal/Metal.h>
namespace docmont::gpu {
BackendStatus probe_metal_native(){
    BackendStatus s;s.backend=Backend::Metal;s.runtime_present=true;
    @autoreleasepool {
        id<MTLDevice> device=MTLCreateSystemDefaultDevice();
        if(!device){s.availability=Availability::NoDevice;s.detail="Metal framework is present but no Metal device is available";return s;}
        s.device_available=true;s.device_count=1;s.api_version=1;
        id<MTLCommandQueue> queue=[device newCommandQueue];
        if(!queue){s.availability=Availability::InitializationFailed;s.detail="Metal device found but command queue creation failed";return s;}
        s.queue_available=true;s.availability=Availability::Ready;s.detail="Metal device and command queue initialized; renderer/pipeline submission is a separate capability";
    }
    return s;
}
}
