#include "docmont/native_backend.hpp"
#include <cctype>
#include <algorithm>
#include <cstdint>
#include <limits>
#include <map>
#include <sstream>
#include <vector>
#include <set>
#include <deque>
#include <optional>
namespace docmont {
namespace {
// Resource limits keep generated native programs from creating unbounded C stack frames.
constexpr std::size_t kNativeMaxOperandStack = 4096;
constexpr std::size_t kNativeMaxInstructions = 1'000'000;
// Verify the restricted native-C instruction subset before emitting code.
// A worklist computes the stack depth at each reachable program counter. A
// control-flow merge must agree on depth; positive-growth loops are rejected.
std::string verify_native_control_flow(const ProgramIR& ir, std::size_t& max_stack) {
    const std::size_t count = ir.code.size();
    if (count > kNativeMaxInstructions)
        return "Native C backend: instruction stream exceeds safety limit (" +
            std::to_string(kNativeMaxInstructions) + ")";
    // Code generation visits every instruction, including unreachable blocks,
    // so reject unsupported opcodes and malformed branches globally first.
    for (const auto& ins : ir.code) {
        switch (ins.op) {
            case OpCode::PushInt: case OpCode::PushString: case OpCode::Load:
            case OpCode::Store: case OpCode::Print: case OpCode::Add:
            case OpCode::Sub: case OpCode::Mul: case OpCode::Div:
            case OpCode::Jump: case OpCode::JumpIfZero: case OpCode::BoolNot:
            case OpCode::Equal: case OpCode::NotEqual: case OpCode::Less:
            case OpCode::LessEqual: case OpCode::Greater: case OpCode::GreaterEqual:
            case OpCode::LogicalAnd: case OpCode::LogicalOr:
            case OpCode::MakeArray: case OpCode::ArrayGet: case OpCode::ArraySet:
            case OpCode::ArrayLength: case OpCode::ArrayPush: case OpCode::ArrayPop:
            case OpCode::NewObject: case OpCode::ObjectGet: case OpCode::ObjectSet: case OpCode::ObjectHas:
                break;
            default: return "Native C backend does not yet support opcode " +
                std::to_string(static_cast<int>(ins.op)) + "; use DVM or an implemented native lowering path";
        }
        if (ins.op == OpCode::Jump || ins.op == OpCode::JumpIfZero) {
            if (ins.integer < 0 || static_cast<std::uint64_t>(ins.integer) > count)
                return "Native C backend: jump target " + std::to_string(ins.integer) +
                    " is outside the instruction stream at source line " + std::to_string(ins.line);
        }
    }
    std::vector<std::optional<std::size_t>> depths(count + 1);
    std::deque<std::size_t> work;
    depths[0] = 0;
    work.push_back(0);
    max_stack = 0;

    auto enqueue = [&](std::size_t target, std::size_t depth, int line) -> std::string {
        if (target > count) return "Native C backend: jump target " + std::to_string(target) +
            " is outside the instruction stream at source line " + std::to_string(line);
        if (depths[target].has_value()) {
            if (*depths[target] != depth) return "Native C backend: inconsistent stack depth at control-flow merge (expected " +
                std::to_string(*depths[target]) + ", got " + std::to_string(depth) + ") at instruction " + std::to_string(target);
            return {};
        }
        depths[target] = depth;
        work.push_back(target);
        return {};
    };

    while (!work.empty()) {
        const std::size_t pc = work.front(); work.pop_front();
        if (pc == count) continue;
        const auto& ins = ir.code[pc];
        std::size_t depth = *depths[pc];
        std::size_t required = 0;
        int delta = 0;
        switch (ins.op) {
            case OpCode::PushInt: case OpCode::PushString: case OpCode::Load: delta = 1; break;
            case OpCode::Store: case OpCode::Print: required = 1; delta = -1; break;
            case OpCode::Add: case OpCode::Sub: case OpCode::Mul: case OpCode::Div: required = 2; delta = -1; break;
            case OpCode::Jump: break;
            case OpCode::JumpIfZero: required = 1; delta = -1; break;
            case OpCode::BoolNot: required = 1; break;
            case OpCode::Equal: case OpCode::NotEqual: case OpCode::Less:
            case OpCode::LessEqual: case OpCode::Greater: case OpCode::GreaterEqual:
            case OpCode::LogicalAnd: case OpCode::LogicalOr: required = 2; delta = -1; break;
            case OpCode::MakeArray:
                if (ins.integer < 0 || static_cast<std::uint64_t>(ins.integer) > depth)
                    return "Native C backend: invalid array element count at source line " + std::to_string(ins.line);
                required = static_cast<std::size_t>(ins.integer); delta = 1 - static_cast<int>(required); break;
            case OpCode::ArrayGet: required = 2; delta = -1; break;
            case OpCode::ArraySet: required = 3; delta = -3; break;
            case OpCode::ArrayLength: case OpCode::ArrayPop: required = 1; break;
            case OpCode::ArrayPush: required = 2; delta = -1; break;
            case OpCode::NewObject: delta = 1; break;
            case OpCode::ObjectGet: case OpCode::ObjectHas: required = 1; break;
            case OpCode::ObjectSet: required = 2; delta = -1; break;
            default: return "Native C backend does not yet support opcode " +
                std::to_string(static_cast<int>(ins.op)) + "; use DVM or an implemented native lowering path";
        }
        if (depth < required) return "Native C backend: operand stack underflow at source line " + std::to_string(ins.line);
        depth = static_cast<std::size_t>(static_cast<std::int64_t>(depth) + delta);
        max_stack = std::max(max_stack, depth);
        if (max_stack > kNativeMaxOperandStack)
            return "Native C backend: verified operand stack exceeds safety limit (" +
                std::to_string(kNativeMaxOperandStack) + ")";
        if (ins.op == OpCode::Jump || ins.op == OpCode::JumpIfZero) {
            if (ins.integer < 0) return "Native C backend: negative jump target at source line " + std::to_string(ins.line);
            const auto target = static_cast<std::size_t>(ins.integer);
            if (auto error = enqueue(target, depth, ins.line); !error.empty()) return error;
            if (ins.op == OpCode::Jump) continue;
        }
        if (auto error = enqueue(pc + 1, depth, ins.line); !error.empty()) return error;
    }
    return {};
}
std::string c_string(const std::string& s) {
    std::ostringstream o; o << '"';
    for (unsigned char c : s) {
        switch (c) { case '\\': o << "\\\\"; break; case '"': o << "\\\""; break;
        case '\n': o << "\\n"; break; case '\r': o << "\\r"; break; case '\t': o << "\\t"; break;
        default: if (c < 32 || c >= 127) { o << "\\" << static_cast<char>('0' + ((c >> 6) & 7)) << static_cast<char>('0' + ((c >> 3) & 7)) << static_cast<char>('0' + (c & 7)); } else o << static_cast<char>(c); }
    }
    o << '"'; return o.str();
}
}
NativeSourceResult emit_c_source(const ProgramIR& ir) {
    NativeSourceResult r;
    std::size_t verified_max_stack = 0;
    if (const auto error = verify_native_control_flow(ir, verified_max_stack); !error.empty()) {
        r.message = error;
        return r;
    }
    std::map<std::string, std::size_t> slots;
    std::set<std::size_t> labels;
    for (const auto& ins : ir.code) if (ins.op == OpCode::Jump || ins.op == OpCode::JumpIfZero) {
        if (ins.integer >= 0) labels.insert(static_cast<std::size_t>(ins.integer));
    }
    for (const auto& ins : ir.code) if (ins.op == OpCode::Store || ins.op == OpCode::Load) {
        if (!slots.count(ins.operand)) slots.emplace(ins.operand, slots.size());
    }
    std::ostringstream o;
    o << "/* DOCMONT C11 AOT source backend */\n"
      << "#include <stdint.h>\n#include <stdio.h>\n#include <stdlib.h>\n#include <stddef.h>\n#include <limits.h>\n#include <string.h>\n\n"
      << "typedef struct Value Value; typedef struct Array Array; typedef struct Object Object; typedef struct ObjectField ObjectField;\n"
      << "struct Value { int kind; int64_t i; const char *s; Array *a; };\n"
      << "struct Array { size_t len; size_t cap; Value *items; };\n"
      << "struct ObjectField { const char *key; Value value; }; struct Object { size_t len; size_t cap; ObjectField *fields; };\n"
      << "static size_t g_array_slots=0; static const size_t MAX_ARRAY_SLOTS=1000000;\n"
      << "static size_t g_array_bytes=0; static const size_t MAX_ARRAY_BYTES=64u*1024u*1024u;\n"
      << "static Array **g_arrays=NULL; static size_t g_array_count=0, g_array_capacity=0; static const size_t MAX_ARRAY_OBJECTS=65536;\n"
      << "static int array_register(Array *a) { if(g_array_count>=MAX_ARRAY_OBJECTS) return 0; if(g_array_count==g_array_capacity){ size_t nc=g_array_capacity?g_array_capacity*2:16; if(nc>MAX_ARRAY_OBJECTS) nc=MAX_ARRAY_OBJECTS; Array **q=(Array**)realloc(g_arrays,nc*sizeof(Array*)); if(!q) return 0; g_arrays=q; g_array_capacity=nc; } g_arrays[g_array_count++]=a; return 1; }\n"
      << "static void array_cleanup(void) { for(size_t i=0;i<g_array_count;++i){ if(g_arrays[i]){ free(g_arrays[i]->items); g_arrays[i]->items=NULL; free(g_arrays[i]); g_arrays[i]=NULL; } } free(g_arrays); g_arrays=NULL; g_array_count=0; g_array_capacity=0; g_array_slots=0; g_array_bytes=0; }\n"
      << "static Array *array_new(size_t n, Value *stack, size_t *sp) { if(n>MAX_ARRAY_SLOTS-g_array_slots || n>MAX_ARRAY_BYTES/sizeof(Value) || n>(MAX_ARRAY_BYTES-g_array_bytes)/sizeof(Value)) return NULL; Array *a=(Array*)calloc(1,sizeof(Array)); if(!a) return NULL; if(n){ a->items=(Value*)calloc(n,sizeof(Value)); if(!a->items){free(a);return NULL;} for(size_t i=n;i>0;--i) a->items[i-1]=stack[*sp-n+i-1]; } a->len=n; a->cap=n; if(!array_register(a)){free(a->items);free(a);return NULL;} *sp-=n; g_array_slots+=n; g_array_bytes+=n*sizeof(Value); return a; }\n"
      << "static int array_push(Array *a, Value v) { if(!a || a->len>=MAX_ARRAY_SLOTS || g_array_slots>=MAX_ARRAY_SLOTS) return 0; if(a->len==a->cap){ size_t nc=a->cap? a->cap*2:4; size_t available_slots=MAX_ARRAY_SLOTS-g_array_slots+a->cap; size_t available_bytes=(MAX_ARRAY_BYTES-g_array_bytes)/sizeof(Value)+a->cap; if(nc>available_slots) nc=available_slots; if(nc>available_bytes) nc=available_bytes; if(nc<=a->cap || nc>SIZE_MAX/sizeof(Value)) return 0; size_t added=nc-a->cap; if(added>(MAX_ARRAY_BYTES-g_array_bytes)/sizeof(Value)) return 0; Value *q=(Value*)realloc(a->items,nc*sizeof(Value)); if(!q)return 0; g_array_slots+=added; g_array_bytes+=added*sizeof(Value); a->items=q; a->cap=nc; } a->items[a->len++]=v; return 1; }\n"
      << "static Object **g_objects=NULL; static size_t g_object_count=0, g_object_capacity=0; static size_t g_object_fields=0, g_object_bytes=0; static const size_t MAX_OBJECTS=65536, MAX_OBJECT_FIELDS=1000000, MAX_OBJECT_BYTES=64u*1024u*1024u;\n"
      << "static int object_register(Object *o) { if(g_object_count>=MAX_OBJECTS) return 0; if(g_object_count==g_object_capacity){ size_t nc=g_object_capacity?g_object_capacity*2:16; if(nc>MAX_OBJECTS) nc=MAX_OBJECTS; Object **q=(Object**)realloc(g_objects,nc*sizeof(Object*)); if(!q)return 0; g_objects=q; g_object_capacity=nc; } g_objects[g_object_count++]=o; return 1; }\n"
      << "static Object *object_new(void) { Object *o=(Object*)calloc(1,sizeof(Object)); if(!o)return NULL; if(!object_register(o)){free(o);return NULL;} return o; }\n"
      << "static int object_set(Object *o,const char *key,Value v) { if(!o||!key||!*key)return 0; for(size_t i=0;i<o->len;++i) if(strcmp(o->fields[i].key,key)==0){o->fields[i].value=v;return 1;} if(o->len==o->cap){ if(g_object_fields>=MAX_OBJECT_FIELDS || g_object_bytes>MAX_OBJECT_BYTES-sizeof(ObjectField))return 0;size_t nc=o->cap?o->cap*2:4; size_t bycap=(MAX_OBJECT_BYTES-g_object_bytes)/sizeof(ObjectField); size_t fieldcap=MAX_OBJECT_FIELDS-g_object_fields; if(nc>bycap+o->cap)nc=bycap+o->cap; if(nc>fieldcap+o->cap)nc=fieldcap+o->cap; if(nc<=o->cap||nc>SIZE_MAX/sizeof(ObjectField))return 0; size_t add=nc-o->cap; if(add>(MAX_OBJECT_BYTES-g_object_bytes)/sizeof(ObjectField))return 0; ObjectField *q=(ObjectField*)realloc(o->fields,nc*sizeof(ObjectField)); if(!q)return 0; o->fields=q; o->cap=nc; g_object_fields+=add; g_object_bytes+=add*sizeof(ObjectField);} o->fields[o->len].key=key; o->fields[o->len].value=v; ++o->len; return 1; }\n"
      << "static int object_get(Object *o,const char *key,Value *out) { if(!o||!key)return 0; for(size_t i=0;i<o->len;++i)if(strcmp(o->fields[i].key,key)==0){*out=o->fields[i].value;return 1;} return 0; }\n"
      << "static int object_has(Object *o,const char *key) { if(!o||!key)return 0; for(size_t i=0;i<o->len;++i)if(strcmp(o->fields[i].key,key)==0)return 1; return 0; }\n"
      << "static void object_cleanup(void) { for(size_t i=0;i<g_object_count;++i)if(g_objects[i]){free(g_objects[i]->fields);free(g_objects[i]);g_objects[i]=NULL;} free(g_objects);g_objects=NULL;g_object_count=0;g_object_capacity=0;g_object_fields=0;g_object_bytes=0;}\n"
      << R"DOCMONT(static void print_value(Value v) { if(v.kind==1) printf("%lld",(long long)v.i); else if(v.kind==2) printf("%s",v.s?v.s:""); else if(v.kind==3 && v.a){ putchar('['); for(size_t i=0;i<v.a->len;++i){ if(i) printf(", "); print_value(v.a->items[i]); } putchar(']'); } else if(v.kind==4 && v.a){ printf("<object:%zu>",((Object*)v.a)->len); } else printf("<invalid>"); }
)DOCMONT"
      << "static int calc(int op, int64_t a, int64_t b, int64_t *out) {\n"
      << "  if (op==4) { if ((b>0 && a>INT64_MAX-b)||(b<0 && a<INT64_MIN-b)) return 0; *out=a+b; }\n"
      << "  else if (op==5) { if ((b<0 && a>INT64_MAX+b)||(b>0 && a<INT64_MIN+b)) return 0; *out=a-b; }\n"
      << "  else if (op==6) { if (a==0||b==0) *out=0; else { if ((a==-1&&b==INT64_MIN)||(b==-1&&a==INT64_MIN)) return 0;\n"
      << "    if (a>0) { if ((b>0&&a>INT64_MAX/b)||(b<0&&b<INT64_MIN/a)) return 0; }\n"
      << "    else { if ((b>0&&a<INT64_MIN/b)||(b<0&&a<INT64_MAX/b)) return 0; } *out=a*b; } }\n"
      << "  else { if (b==0 || (a==INT64_MIN&&b==-1)) return 0; *out=a/b; } return 1; }\n\n"
      << "int main(void) {\n  Value stack[" << std::max<std::size_t>(verified_max_stack, 1) << "] = {{0}};\n"
      << "  Value vars[" << (slots.empty()?1:slots.size()) << "] = {{0}};\n  size_t sp=0; int64_t result=0;\n  if(atexit(array_cleanup)!=0) return 90; if(atexit(object_cleanup)!=0) return 91;\n  (void)stack; (void)vars; (void)sp; (void)result; (void)&calc; (void)&array_new; (void)&array_push; (void)&print_value; (void)&array_register; (void)&object_new; (void)&object_set; (void)&object_get; (void)&object_has;\n";
    for (std::size_t pc = 0; pc < ir.code.size(); ++pc) {
        const auto& ins = ir.code[pc];
        if (labels.count(pc)) o << "L" << pc << ": ;\n";
        switch (ins.op) {
        case OpCode::PushInt:
            if (ins.integer == std::numeric_limits<std::int64_t>::min()) o << "  stack[sp++] = (Value){1, (-INT64_C(9223372036854775807)-1), NULL, NULL};\n";
            else if (ins.integer < 0) o << "  stack[sp++] = (Value){1, -INT64_C(" << -ins.integer << "), NULL, NULL};\n";
            else o << "  stack[sp++] = (Value){1, INT64_C(" << ins.integer << "), NULL, NULL};\n";
            break;
        case OpCode::PushString: o << "  stack[sp++] = (Value){2, 0, " << c_string(ins.operand) << ", NULL};\n"; break;
        case OpCode::Load: o << "  stack[sp++] = vars[" << slots.at(ins.operand) << "];\n"; break;
        case OpCode::Store: o << "  if (!sp) return 20;\n  vars[" << slots.at(ins.operand) << "] = stack[--sp];\n"; break;
        case OpCode::Print: o << "  if (!sp) return 21;\n  { Value v=stack[--sp]; print_value(v); putchar('\\n'); if(v.kind==0) return 22; }\n"; break;
        case OpCode::Jump: o << "  goto L" << ins.integer << ";\n"; break;
        case OpCode::JumpIfZero: o << "  if (!sp) return 25;\n  { Value v=stack[--sp]; if(v.kind!=1) return 26; if(v.i==0) goto L" << ins.integer << "; }\n"; break;
        case OpCode::BoolNot:
            o << "  if (!sp || stack[sp-1].kind!=1) { fprintf(stderr,\"DOCMONT native type error at line " << ins.line << "\\n\"); return 27; } stack[sp-1].i = (stack[sp-1].i==0);\n";
            break;
        case OpCode::Equal: case OpCode::NotEqual:
            o << "  if (sp<2) return 23; { Value b=stack[--sp], a=stack[--sp]; int eq=0; if(a.kind==b.kind) { if(a.kind==1) eq=(a.i==b.i); else if(a.kind==2) eq=(strcmp(a.s,b.s)==0); } stack[sp++]=(Value){1," << (ins.op == OpCode::Equal ? "eq" : "!eq") << ",NULL,NULL}; }\n";
            break;
        case OpCode::Less: case OpCode::LessEqual: case OpCode::Greater: case OpCode::GreaterEqual:
        case OpCode::LogicalAnd: case OpCode::LogicalOr:
            o << "  if (sp<2) return 23; { Value b=stack[--sp], a=stack[--sp]; if(a.kind!=1||b.kind!=1) { fprintf(stderr,\"DOCMONT native type error at line " << ins.line << "\\n\"); return 27; } int64_t v=0; ";
            switch (ins.op) {
                case OpCode::Less: o << "v=(a.i<b.i);"; break;
                case OpCode::LessEqual: o << "v=(a.i<=b.i);"; break;
                case OpCode::Greater: o << "v=(a.i>b.i);"; break;
                case OpCode::GreaterEqual: o << "v=(a.i>=b.i);"; break;
                case OpCode::LogicalAnd: o << "v=(a.i!=0 && b.i!=0);"; break;
                case OpCode::LogicalOr: o << "v=(a.i!=0 || b.i!=0);"; break;
                default: break;
            }
            o << " stack[sp++]=(Value){1,v,NULL,NULL}; }\n";
            break;
        case OpCode::MakeArray:
            o << "  { Array *a=array_new(" << ins.integer << ",stack,&sp); if(!a) { fprintf(stderr,\"DOCMONT native array allocation/limit error at line " << ins.line << "\\n\"); return 28; } stack[sp++]=(Value){3,0,NULL,a}; }\n";
            break;
        case OpCode::ArrayGet:
            o << "  if(sp<2) return 29; { Value ix=stack[--sp], base=stack[--sp]; if(base.kind!=3||!base.a||ix.kind!=1||ix.i<0||(uint64_t)ix.i>=base.a->len){ fprintf(stderr,\"DOCMONT native array index/type error at line " << ins.line << "\\n\"); return 30; } stack[sp++]=base.a->items[(size_t)ix.i]; }\n";
            break;
        case OpCode::ArraySet:
            o << "  if(sp<3) return 31; { Value val=stack[--sp], ix=stack[--sp], base=stack[--sp]; if(base.kind!=3||!base.a||ix.kind!=1||ix.i<0||(uint64_t)ix.i>=base.a->len){ fprintf(stderr,\"DOCMONT native array write type/bounds error at line " << ins.line << "\\n\"); return 32; } base.a->items[(size_t)ix.i]=val; }\n";
            break;
        case OpCode::ArrayLength:
            o << "  if(!sp) return 33; { Value *v=&stack[sp-1]; if(v->kind==3&&v->a) v->i=(int64_t)v->a->len; else if(v->kind==4&&v->a) v->i=(int64_t)((Object*)v->a)->len; else if(v->kind==2&&v->s) v->i=(int64_t)strlen(v->s); else { fprintf(stderr,\"DOCMONT native length type error at line " << ins.line << "\\n\"); return 34; } v->kind=1; v->s=NULL; v->a=NULL; }\n";
            break;
        case OpCode::ArrayPush:
            o << "  if(sp<2) return 35; { Value val=stack[--sp], *base=&stack[sp-1]; if(base->kind!=3||!base->a||!array_push(base->a,val)){ fprintf(stderr,\"DOCMONT native array push type/limit/allocation error at line " << ins.line << "\\n\"); return 36; } Array *a=base->a; base->kind=1; base->i=(int64_t)a->len; base->s=NULL; base->a=NULL; }\n";
            break;
        case OpCode::ArrayPop:
            o << "  if(!sp) return 37; { Value *base=&stack[sp-1]; if(base->kind!=3||!base->a||base->a->len==0){ fprintf(stderr,\"DOCMONT native array pop type/empty error at line " << ins.line << "\\n\"); return 38; } Array *a=base->a; *base=a->items[--a->len]; }\n";
            break;
        case OpCode::NewObject:
            o << "  { Object *obj=object_new(); if(!obj){ fprintf(stderr,\"DOCMONT native object allocation/limit error at line " << ins.line << "\\n\"); return 39; } stack[sp++]=(Value){4,0,NULL,(Array*)obj}; }\n";
            break;
        case OpCode::ObjectSet:
            o << "  if(sp<2) return 40; { Value val=stack[--sp]; Value *base=&stack[sp-1]; if(base->kind!=4||!base->a||!object_set((Object*)base->a," << c_string(ins.operand) << ",val)){ fprintf(stderr,\"DOCMONT native object property write type/limit/allocation error at line " << ins.line << "\\n\"); return 41; } }\n";
            break;
        case OpCode::ObjectGet:
            o << "  if(!sp) return 42; { Value *base=&stack[sp-1], value; if(base->kind!=4||!base->a||!object_get((Object*)base->a," << c_string(ins.operand) << ",&value)){ fprintf(stderr,\"DOCMONT native object property read type/missing error at line " << ins.line << "\\n\"); return 43; } *base=value; }\n";
            break;
        case OpCode::ObjectHas:
            o << "  if(!sp) return 44; { Value *base=&stack[sp-1]; if(base->kind!=4||!base->a){ fprintf(stderr,\"DOCMONT native object property test type error at line " << ins.line << "\\n\"); return 45; } base->kind=1; base->i=object_has((Object*)base->a," << c_string(ins.operand) << "); base->s=NULL; base->a=NULL; }\n";
            break;
        case OpCode::Add: case OpCode::Sub: case OpCode::Mul: case OpCode::Div:
            o << "  if (sp<2) return 23;\n  { Value b=stack[--sp], a=stack[--sp]; if(a.kind!=1||b.kind!=1||!calc(" << static_cast<int>(ins.op) << ",a.i,b.i,&result)) { fprintf(stderr,\"DOCMONT native runtime error at line " << ins.line << "\\n\"); return 24; } stack[sp++]=(Value){1,result,NULL,NULL}; }\n"; break;
        default:
            r.message = "Native C backend does not yet support opcode " + std::to_string(static_cast<int>(ins.op)) + "; use DVM or an implemented native lowering path";
            return r;
        }
    }
    if (labels.count(ir.code.size())) o << "L" << ir.code.size() << ": ;\n";
    o << "  return 0;\n}\n";
    r.ok = true; r.message = "C11 native source emitted"; r.source = o.str(); return r;
}
}
