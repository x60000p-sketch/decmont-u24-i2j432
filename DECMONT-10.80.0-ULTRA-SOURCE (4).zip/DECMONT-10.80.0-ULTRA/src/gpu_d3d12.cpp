#include "gpu_backend_internal.hpp"
#include <windows.h>
#include <d3d12.h>
#include <wrl/client.h>
namespace docmont::gpu {
BackendStatus probe_d3d12_native(){
    BackendStatus s;s.backend=Backend::Direct3D12;s.runtime_present=true;
    using Microsoft::WRL::ComPtr;
    ComPtr<ID3D12Device> device;
    HRESULT hr=D3D12CreateDevice(nullptr,D3D_FEATURE_LEVEL_11_0,IID_PPV_ARGS(&device));
    if(FAILED(hr)||!device){s.availability=Availability::InitializationFailed;s.detail="D3D12CreateDevice failed; verify the Windows graphics driver and D3D12 support";return s;}
    s.device_available=true;s.device_count=1;s.api_version=12;
    D3D12_COMMAND_QUEUE_DESC desc{};desc.Type=D3D12_COMMAND_LIST_TYPE_DIRECT;desc.Priority=D3D12_COMMAND_QUEUE_PRIORITY_NORMAL;desc.Flags=D3D12_COMMAND_QUEUE_FLAG_NONE;
    ComPtr<ID3D12CommandQueue> queue;hr=device->CreateCommandQueue(&desc,IID_PPV_ARGS(&queue));
    if(FAILED(hr)||!queue){s.availability=Availability::InitializationFailed;s.detail="D3D12 device created but direct command queue creation failed";return s;}
    s.queue_available=true;s.availability=Availability::Ready;s.detail="D3D12 device and direct command queue initialized; renderer/pipeline submission is a separate capability";return s;
}
}
