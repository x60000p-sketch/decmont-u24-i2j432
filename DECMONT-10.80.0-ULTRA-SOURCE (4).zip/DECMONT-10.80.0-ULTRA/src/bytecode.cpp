#include "docmont/bytecode.hpp"
#include <limits>
#include <string>
#include <unordered_map>
namespace docmont {
namespace {
void put_u32(std::vector<std::uint8_t>& b, std::uint32_t v){ for(int i=0;i<4;++i)b.push_back(static_cast<std::uint8_t>((v>>(i*8))&0xff)); }
void put_u64(std::vector<std::uint8_t>& b, std::uint64_t v){ for(int i=0;i<8;++i)b.push_back(static_cast<std::uint8_t>((v>>(i*8))&0xff)); }
std::uint32_t get_u32(const std::vector<std::uint8_t>& b,std::size_t& p){if(p>b.size()||b.size()-p<4)throw 1;std::uint32_t v=0;for(int i=0;i<4;++i)v|=std::uint32_t(b[p++])<<(i*8);return v;}
std::uint64_t get_u64(const std::vector<std::uint8_t>& b,std::size_t& p){if(p>b.size()||b.size()-p<8)throw 1;std::uint64_t v=0;for(int i=0;i<8;++i)v|=std::uint64_t(b[p++])<<(i*8);return v;}
}
BytecodeResult encode_bytecode(const ProgramIR& ir){
 BytecodeResult r; if(ir.code.size()>1000000){r.message="instruction count exceeds format limit";return r;}
 auto& b=r.bytes; b.insert(b.end(),{'D','V','M','B'}); put_u32(b,1);
 if(ir.name.size()>65535||ir.target.size()>255){r.message="metadata field too long";return r;}
 put_u32(b,static_cast<std::uint32_t>(ir.name.size()));b.insert(b.end(),ir.name.begin(),ir.name.end());
 put_u32(b,static_cast<std::uint32_t>(ir.target.size()));b.insert(b.end(),ir.target.begin(),ir.target.end());
 put_u32(b,static_cast<std::uint32_t>(ir.code.size()));
 for(const auto& x:ir.code){auto op=static_cast<std::uint8_t>(x.op);if(op>static_cast<std::uint8_t>(OpCode::LoadCell)||x.operand.size()>65535){r.message="invalid instruction or operand too long";r.bytes.clear();return r;}b.push_back(op);put_u32(b,static_cast<std::uint32_t>(x.line));put_u64(b,static_cast<std::uint64_t>(x.integer));put_u32(b,static_cast<std::uint32_t>(x.operand.size()));b.insert(b.end(),x.operand.begin(),x.operand.end());}
 r.ok=true;r.message="bytecode encoded";return r;
}
BytecodeResult verify_bytecode(const std::vector<std::uint8_t>& b) {
    BytecodeResult result; result.bytes = b;
    auto fail = [&](const std::string& message) { result.ok = false; result.message = message; return result; };
    if (b.size() < 20 || b[0] != 'D' || b[1] != 'V' || b[2] != 'M' || b[3] != 'B')
        return fail("invalid DVM bytecode magic");
    std::size_t p = 4;
    try {
        const auto version = get_u32(b, p);
        if (version != 1) return fail("unsupported DVM bytecode version");
        auto take_string = [&](std::uint32_t n) { if (n > b.size() - p) throw 1; p += n; };
        auto n = get_u32(b, p); if (n > 65535) return fail("application name exceeds format limit"); take_string(n);
        n = get_u32(b, p); if (n > 255) return fail("target label exceeds format limit"); take_string(n);
        const auto count = get_u32(b, p);
        if (count > 1000000) return fail("instruction count exceeds format limit");
        struct Record { OpCode op; std::uint64_t integer; std::string text; };
        std::vector<Record> records; records.reserve(count);
        std::unordered_map<std::string, std::uint64_t> function_arities;
        for (std::uint32_t i = 0; i < count; ++i) {
            if (p + 17 > b.size()) return fail("truncated instruction record");
            const auto raw_op = b[p++];
            (void)get_u32(b, p); // source line
            const auto raw_operand = get_u64(b, p);
            const auto length = get_u32(b, p);
            if (raw_op > static_cast<std::uint8_t>(OpCode::LoadCell)) return fail("unknown opcode");
            if (length > b.size() - p) return fail("truncated instruction operand");
            std::string text(b.begin() + static_cast<std::ptrdiff_t>(p), b.begin() + static_cast<std::ptrdiff_t>(p + length));
            p += length;
            const auto op = static_cast<OpCode>(raw_op);
            if ((op == OpCode::Jump || op == OpCode::JumpIfZero) && raw_operand > count)
                return fail("jump target outside instruction stream");
            if (op == OpCode::Function) {
                if (text.empty()) return fail("function declaration has an empty name");
                if (raw_operand > 1024) return fail("function arity exceeds verifier limit (1024)");
                if (!function_arities.emplace(text, raw_operand).second) return fail("duplicate function declaration: " + text);
            }
            records.push_back({op, raw_operand, std::move(text)});
        }
        if (p != b.size()) return fail("trailing bytes after bytecode program");

        // Resolve every statically named function reference before execution.
        // This prevents malformed bytecode from reaching runtime with dangling
        // function names or a mismatched direct-call signature.
        for (const auto& rec : records) {
            if (rec.op == OpCode::LoadFunction && !function_arities.contains(rec.text))
                return fail("unresolved function reference: " + rec.text);
            if (rec.op == OpCode::MakeClosure) {
                const auto separator = rec.text.find('|');
                const auto target = rec.text.substr(0, separator);
                if (!function_arities.contains(target)) return fail("unresolved closure function: " + target);
                std::size_t captures = separator == std::string::npos ? 0 : 1;
                if (separator != std::string::npos) for (std::size_t i = separator + 1; i < rec.text.size(); ++i) if (rec.text[i] == '|') ++captures;
                if (captures != rec.integer) return fail("closure capture count mismatch: " + target);
            }
            if (rec.op == OpCode::Call) {
                const auto target = function_arities.find(rec.text);
                if (target == function_arities.end()) return fail("call to undefined function: " + rec.text);
                if (rec.integer != target->second) return fail("function call arity mismatch: " + rec.text);
            }
        }

        // Verify the top-level stream and every function body independently.
        // Function entries begin with their declared arguments on the operand stack;
        // each reachable return must consume exactly one result and leave no residue.
        auto verify_region = [&](std::size_t begin, std::size_t end,
                                 std::int64_t initial_depth, bool is_function) -> bool {
            std::vector<std::int64_t> depths(end - begin + 1, -1);
            std::vector<std::size_t> worklist;
            depths[0] = initial_depth;
            worklist.push_back(begin);
            bool saw_return = false;
            while (!worklist.empty()) {
                const auto pc = worklist.back(); worklist.pop_back();
                const auto depth = depths[pc - begin];
                if (pc == end) {
                    if (is_function || depth != 0) return false;
                    continue;
                }
                const auto& rec = records[pc];
                std::int64_t next_depth = depth;
                switch (rec.op) {
                case OpCode::PushInt: case OpCode::PushString: case OpCode::Load: case OpCode::LoadCell:
                case OpCode::LoadFunction: case OpCode::NewObject: case OpCode::Dup:
                    ++next_depth; break;
                case OpCode::MakeClosure:
                    if (rec.integer > static_cast<std::uint64_t>(next_depth)) return false;
                    next_depth = next_depth - static_cast<std::int64_t>(rec.integer) + 1; break;
                case OpCode::MakeArray:
                    if (rec.integer > static_cast<std::uint64_t>(next_depth)) return false;
                    next_depth = next_depth - static_cast<std::int64_t>(rec.integer) + 1; break;
                case OpCode::ArrayGet:
                    if (next_depth < 2) return false; --next_depth; break;
                case OpCode::ArraySet:
                    if (next_depth < 3) return false; next_depth -= 3; break;
                case OpCode::ArrayLength: case OpCode::ArrayPop:
                    if (next_depth < 1) return false; break;
                case OpCode::ArrayPush:
                    if (next_depth < 2) return false; --next_depth; break;
                case OpCode::BoolNot: case OpCode::ObjectGet: case OpCode::ObjectHas:
                    if (next_depth < 1) return false; break;
                case OpCode::ObjectSet:
                    if (next_depth < 2) return false; --next_depth; break;
                case OpCode::Store: case OpCode::Print: case OpCode::JumpIfZero:
                    if (next_depth < 1) return false; --next_depth; break;
                case OpCode::Add: case OpCode::Sub: case OpCode::Mul: case OpCode::Div:
                case OpCode::Equal: case OpCode::NotEqual: case OpCode::Less:
                case OpCode::LessEqual: case OpCode::Greater: case OpCode::GreaterEqual:
                case OpCode::LogicalAnd: case OpCode::LogicalOr:
                    if (next_depth < 2) return false; --next_depth; break;
                case OpCode::Call:
                    if (rec.integer > static_cast<std::uint64_t>(next_depth)) return false;
                    next_depth = next_depth - static_cast<std::int64_t>(rec.integer) + 1; break;
                case OpCode::CallIndirect:
                    if (rec.integer < 0 || static_cast<std::uint64_t>(rec.integer) + 1 > static_cast<std::uint64_t>(next_depth)) return false;
                    next_depth -= static_cast<std::int64_t>(rec.integer); break;
                case OpCode::Function:
                    // A declaration is metadata, not executable code in a region.
                    return false;
                case OpCode::Return:
                    if (!is_function || next_depth != 1) return false;
                    saw_return = true;
                    continue;
                case OpCode::Jump: break;
                }
                auto add_edge = [&](std::size_t target) -> bool {
                    if (target < begin || target > end || (is_function && target == end)) return false;
                    auto& known = depths[target - begin];
                    if (known == -1) { known = next_depth; worklist.push_back(target); return true; }
                    return known == next_depth;
                };
                if (rec.op == OpCode::Jump) {
                    if (!add_edge(static_cast<std::size_t>(rec.integer))) return false;
                } else if (rec.op == OpCode::JumpIfZero) {
                    if (!add_edge(static_cast<std::size_t>(rec.integer)) || !add_edge(pc + 1)) return false;
                } else if (!add_edge(pc + 1)) return false;
            }
            return !is_function || saw_return;
        };

        std::vector<std::size_t> function_entries;
        for (std::size_t i = 0; i < records.size(); ++i)
            if (records[i].op == OpCode::Function) function_entries.push_back(i);
        const auto first_function = records.size();
        if (!verify_region(0, first_function, 0, false))
            return fail("inconsistent stack depth, operand stack underflow, or invalid top-level DVM control flow");
        for (std::size_t index = 0; index < function_entries.size(); ++index) {
            const auto marker = function_entries[index];
            const auto begin = marker + 1;
            const auto end = index + 1 < function_entries.size() ? function_entries[index + 1] : records.size();
            const auto arity = static_cast<std::int64_t>(records[marker].integer);
            if (begin >= end || !verify_region(begin, end, arity, true))
                return fail("inconsistent stack depth, operand stack underflow, or invalid function control flow: " + records[marker].text);
        }

    } catch (...) {
        return fail("truncated bytecode metadata");
    }
    result.ok = true; result.message = "DVM bytecode verified"; return result;
}

BytecodeResult decode_bytecode(const std::vector<std::uint8_t>& b, ProgramIR& out){
 auto verified=verify_bytecode(b); if(!verified.ok) return verified;
 BytecodeResult r; std::size_t p=4;
 auto version=get_u32(b,p); (void)version;
 auto read_string=[&](){ auto n=get_u32(b,p); std::string s(b.begin()+static_cast<std::ptrdiff_t>(p),b.begin()+static_cast<std::ptrdiff_t>(p+n));p+=n;return s; };
 try {
  ProgramIR candidate; candidate.name=read_string();candidate.target=read_string();
  const auto count=get_u32(b,p);candidate.code.reserve(count);
  for(std::uint32_t i=0;i<count;++i){
   const auto op=static_cast<OpCode>(b[p++]);const auto line=static_cast<int>(get_u32(b,p));
   const auto raw=get_u64(b,p);const auto len=get_u32(b,p);
   std::string operand(b.begin()+static_cast<std::ptrdiff_t>(p),b.begin()+static_cast<std::ptrdiff_t>(p+len));p+=len;
   candidate.code.push_back({op,std::move(operand),static_cast<std::int64_t>(raw),line});
  }
  out=std::move(candidate);r.ok=true;r.message="DVM bytecode decoded";return r;
 } catch(...) { r.message="failed to decode verified DVM bytecode";return r; }
}

}
