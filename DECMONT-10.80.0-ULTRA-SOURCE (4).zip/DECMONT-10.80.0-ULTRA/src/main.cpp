#include "docmont/lexer.hpp"
#include "docmont/parser.hpp"
#include "docmont/semantic.hpp"
#include "docmont/function_semantics.hpp"
#include "docmont/platform_contract.hpp"
#include "docmont/ir.hpp"
#include "docmont/optimizer.hpp"
#include "docmont/ssa.hpp"
#include "docmont/runtime.hpp"
#include "docmont/bytecode.hpp"
#include "docmont/native_backend.hpp"
#include "docmont/graphics.hpp"
#include "docmont/vlot.hpp"
#include "docmont/vlot_advanced.hpp"
#include "docmont/decom.hpp"
#include "docmont/interoperability.hpp"
#include "docmont/compiler_core.hpp"
#include "docmont/source_frontend.hpp"
#include "docmont/ownership.hpp"
#include "docmont/package_manager.hpp"
#include "docmont/module_system.hpp"
#include "docmont/native_object.hpp"
#include "docmont/direct_llvm_backend.hpp"
#include "docmont/game_engine.hpp"
#include "docmont/skeletal_animation.hpp"
#include "docmont/network_transport.hpp"
#include "docmont/onnx_runtime.hpp"
#include "docmont/gpu_runtime.hpp"
#include "docmont/gles_runtime.hpp"
#include "docmont/console_sdk.hpp"
#include <cstdlib>
#include <bit>
#include <cstdint>
#include <cctype>
#include <algorithm>
#include <iomanip>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <thread>
#include <functional>
static void dump_expr(const std::shared_ptr<docmont::Expr>& e, int depth) {
 if (!e) return;
 const std::string pad(static_cast<std::size_t>(depth) * 2, ' ');
 switch (e->kind) {
  case docmont::ExprKind::Integer: std::cout << pad << "Integer(" << e->text << ")\n"; break;
  case docmont::ExprKind::String: std::cout << pad << "String(\"" << e->text << "\")\n"; break;
  case docmont::ExprKind::Identifier: std::cout << pad << "Identifier(" << e->text << ")\n"; break;
  case docmont::ExprKind::Binary:
   std::cout << pad << "Binary(" << e->op << ")\n";
   dump_expr(e->left, depth + 1); dump_expr(e->right, depth + 1); break;
 }
}
static void dump_statements(const std::vector<docmont::Statement>& statements, int depth) {
 for (const auto& st : statements) {
  const std::string pad(static_cast<std::size_t>(depth) * 2, ' ');
  if (st.kind == docmont::Statement::Kind::Let) { std::cout << pad << "let " << st.name << "\n"; dump_expr(st.expression, depth + 1); }
  else if (st.kind == docmont::Statement::Kind::Output) { std::cout << pad << "output\n"; dump_expr(st.expression, depth + 1); }
  else { std::cout << pad << "if\n"; dump_expr(st.expression, depth + 1); dump_statements(st.body, depth + 1); if (!st.else_body.empty()) { std::cout << pad << "else\n"; dump_statements(st.else_body, depth + 1); } }
 }
}
static void dump_ast(const docmont::Application& app) {
 std::cout << "Application name=\"" << app.name << "\" architecture=" << app.architecture << "\n";
 for (const auto& b : app.blocks) {
  std::cout << "  Block " << b.name << "\n";
  for (const auto& p : b.properties) std::cout << "    Property " << p.key << " = " << p.value << "\n";
 }
 dump_statements(app.statements, 1);
 std::cout << "  Complete: " << (app.complete ? "true" : "false") << "\n";
}
static void diagnostics(const std::vector<docmont::Diagnostic>& ds,bool& failed){
 for(const auto& d:ds){
  std::cerr<<(d.severity==docmont::Severity::Error?"error":"warning")
   <<":"<<d.line<<":"<<d.column<<": "<<d.message<<'\n';
  if(d.severity==docmont::Severity::Error)failed=true;
 }
}

static std::string json_escape(const std::string& value) {
 std::ostringstream out;
 for (unsigned char c : value) {
  switch (c) {
   case '"': out << "\\\""; break;
   case '\\': out << "\\\\"; break;
   case '\b': out << "\\b"; break;
   case '\f': out << "\\f"; break;
   case '\n': out << "\\n"; break;
   case '\r': out << "\\r"; break;
   case '\t': out << "\\t"; break;
   default: if (c < 0x20) out << "\\u" << std::hex << std::setw(4) << std::setfill('0') << static_cast<int>(c) << std::dec; else out << static_cast<char>(c);
  }
 }
 return out.str();
}
static std::string diagnostic_code(const std::string& message) {
 if (message.find("Unknown variable") != std::string::npos) return "DSEM001";
 if (message.find("already declared") != std::string::npos) return "DSEM002";
 if (message.find("requires integer operands") != std::string::npos) return "DSEM003";
 if (message.find("if condition must") != std::string::npos) return "DSEM004";
 if (message.find("Integer literal") != std::string::npos) return "DSEM005";
 if (message.find("Duplicate property") != std::string::npos) return "DSEM010";
 if (message.find("Unknown property") != std::string::npos) return "DSEM011";
 if (message.find("memory.allocation") != std::string::npos || message.find("memory.management") != std::string::npos || message.find("memory.bounds") != std::string::npos) return "DSEM012";
 if (message.find("compute.optimization") != std::string::npos) return "DSEM013";
 if (message.find("architecture") != std::string::npos || message.find("Architecture") != std::string::npos) return "DSEM014";
 if (message.find("complete terminator") != std::string::npos) return "DPAR001";
 if (message.find("header") != std::string::npos || message.find("!docmont") != std::string::npos) return "DPAR002";
 if (message.find("Unterminated string") != std::string::npos) return "DLEX001";
 if (message.find("Unexpected character") != std::string::npos) return "DLEX002";
 if (message.find("Expected") != std::string::npos || message.find("Unclosed") != std::string::npos || message.find("Unknown statement") != std::string::npos) return "DPAR003";
 return "DDOC000";
}
static std::pair<int,int> diagnostic_end(const docmont::Diagnostic& d, const std::string& source) {
 std::istringstream input(source); std::string line; int n=1;
 while (n<d.line && std::getline(input,line)) ++n;
 if (n!=d.line) return {d.line,d.column};
 if (!std::getline(input,line) && line.empty()) return {d.line,d.column};
 std::size_t start=static_cast<std::size_t>(std::max(0,d.column-1));
 if (start>=line.size()) return {d.line,d.column};
 std::size_t end=start+1;
 const unsigned char c=static_cast<unsigned char>(line[start]);
 if (std::isalnum(c) || c=='_' || c=='!') {
  while (end<line.size()) { const unsigned char x=static_cast<unsigned char>(line[end]); if (!(std::isalnum(x)||x=='_'||x=='!')) break; ++end; }
 }
 return {d.line,static_cast<int>(end+1)};
}
static void print_diagnostics_json(const std::vector<docmont::Diagnostic>& ds, bool ok, const std::string& source) {
 std::cout << "{\"version\":\"10.80.0\",\"ok\":" << (ok ? "true" : "false") << ",\"diagnostics\":[";
 for (std::size_t i=0; i<ds.size(); ++i) {
  const auto& d=ds[i]; if (i) std::cout << ',';
  const auto end=diagnostic_end(d,source);
  std::cout << "{\"severity\":\"" << (d.severity==docmont::Severity::Error?"error":"warning")
            << "\",\"line\":" << d.line << ",\"column\":" << d.column
            << ",\"code\":\"" << diagnostic_code(d.message) << "\",\"endLine\":" << end.first
            << ",\"endColumn\":" << end.second << ",\"message\":\"" << json_escape(d.message) << "\"}";
 }
 std::cout << "]}\n";
}
static void print_language_info() {
 using docmont::TokenKind;
 const TokenKind kinds[] = {TokenKind::Identifier,TokenKind::String,TokenKind::Number,TokenKind::LBrace,TokenKind::RBrace,TokenKind::LBracket,TokenKind::RBracket,TokenKind::LParen,TokenKind::RParen,TokenKind::Equal,TokenKind::Colon,TokenKind::Comma,TokenKind::Dot,TokenKind::Plus,TokenKind::Minus,TokenKind::Star,TokenKind::Slash,TokenKind::Less,TokenKind::LessEqual,TokenKind::Greater,TokenKind::GreaterEqual,TokenKind::EqualEqual,TokenKind::BangEqual,TokenKind::Bang,TokenKind::AndAnd,TokenKind::OrOr,TokenKind::Newline,TokenKind::End};
 std::cout << "{\"version\":\"3.4.0\",\"compilerVersion\":\"10.80.0\",\"compatibleWith\":[\"3.4.0\"],"
           << "\"header\":{\"name\":\"!docmont\",\"description\":\"Declares the DOCMONT source language version.\"},"
           << "\"topLevel\":["
           << "{\"name\":\"select\",\"description\":\"Select the target architecture before the application declaration.\"},"
           << "{\"name\":\"application\",\"description\":\"Begins the application declaration and its members.\"}],"
           << "\"architectures\":["
           << "{\"name\":\"x86_64\",\"description\":\"64-bit x86 target architecture.\"},"
           << "{\"name\":\"arm64\",\"description\":\"64-bit ARM target architecture.\"},"
           << "{\"name\":\"portable\",\"description\":\"Architecture-neutral DOCMONT VM bytecode; build the VM for the destination host.\"}],"
           << "\"application\":{\"members\":["
           << "{\"name\":\"name\",\"kind\":\"property\",\"description\":\"Application name.\"},"
           << "{\"name\":\"memory\",\"kind\":\"block\",\"description\":\"Memory allocation and management policy.\",\"properties\":["
           << "{\"name\":\"allocation\",\"description\":\"Allocation strategy.\",\"values\":[\"automatic\",\"manual\"]},"
           << "{\"name\":\"management\",\"description\":\"Memory management model.\",\"values\":[\"native\",\"managed\"]},"
           << "{\"name\":\"bounds\",\"description\":\"Memory bounds policy.\",\"values\":[\"enforced\",\"unbounded\"]}]},"
           << "{\"name\":\"compute\",\"kind\":\"block\",\"description\":\"Compute and optimization policy.\",\"properties\":["
           << "{\"name\":\"algorithm\",\"description\":\"Compute algorithm identifier.\",\"suggestions\":[\"selkon\"]},"
           << "{\"name\":\"optimization\",\"description\":\"Compiler optimization level.\",\"values\":[\"O0\",\"O1\",\"O2\",\"O3\"]}]},"
           << "{\"name\":\"let\",\"kind\":\"statement\",\"description\":\"Declares an immutable local variable in the current lexical block.\"},"
           << "{\"name\":\"output\",\"kind\":\"statement\",\"description\":\"Evaluates and prints an expression.\"},"
           << "{\"name\":\"if\",\"kind\":\"statement\",\"description\":\"Conditional statement that executes a block when an boolean condition is true (integer conditions remain supported), with an optional else branch.\"},"
           << "{\"name\":\"while\",\"kind\":\"statement\",\"description\":\"Repeats a block while its boolean condition is true (integer conditions remain supported).\"},"
           << "{\"name\":\"break\",\"kind\":\"statement\",\"description\":\"Exits the nearest loop.\"},"
           << "{\"name\":\"continue\",\"kind\":\"statement\",\"description\":\"Skips to the next loop iteration.\"},"
           << "{\"name\":\"complete\",\"kind\":\"property\",\"description\":\"Mandatory application terminator.\"}]},"
           << "\"tokens\":[";
 for (std::size_t i=0;i<sizeof(kinds)/sizeof(kinds[0]);++i) { if(i) std::cout << ','; std::cout << '"' << json_escape(docmont::token_name(kinds[i])) << '"'; }
 std::cout << "]}\n";
}

int main(int argc,char** argv){
 if(argc==2 && std::string(argv[1])=="gpu-info") {
  const auto report=docmont::gpu::probe_all_backends();
  std::cout << "DOCMONT GPU Runtime 10.80.0\n";
  for(const auto& b:report.backends) std::cout << docmont::gpu::to_string(b.backend) << " | " << docmont::gpu::to_string(b.availability)
      << " | runtime=" << (b.runtime_present?"yes":"no") << " | devices=" << b.device_count << " | queue=" << (b.queue_available?"yes":"no") << " | " << b.detail << "\n";
  std::cout << "Note: Vulkan probe initializes an instance/device queue when available; native D3D12 and Metal builds now probe a real device and direct command queue. These probes do not imply a complete renderer or shader submission pipeline.\n";
  return 0;
 }
 if(argc==2 && std::string(argv[1])=="gles-info") {
  const auto info=docmont::gpu::probe_gles();
  std::cout << "DOCMONT GLES Runtime 10.80.0\nAvailable: " << (info.available?"yes":"no")
            << "\nCompute: " << (info.compute_supported?"yes":"no")
            << "\nHardware accelerated: " << (info.hardware_accelerated?"yes":"no")
            << "\nVendor: " << info.vendor << "\nRenderer: " << info.renderer
            << "\nVersion: " << info.version << "\nDetail: " << info.detail << '\n';
  return info.available?0:1;
 }
 if(argc==3 && std::string(argv[1])=="gles-render-demo") {
  const auto frame=docmont::gpu::render_triangle_offscreen(256,256);
  if(!frame.ok){std::cerr<<frame.error<<'\n';return 1;}
  std::ofstream ppm(argv[2],std::ios::binary|std::ios::trunc);
  if(!ppm){std::cerr<<"cannot create output image\n";return 2;}
  ppm<<"P6\n"<<frame.width<<" "<<frame.height<<"\n255\n";
  for(std::size_t i=0;i<frame.rgba.size();i+=4)ppm.write(reinterpret_cast<const char*>(frame.rgba.data()+i),3);
  if(!ppm){std::cerr<<"failed writing output image\n";return 2;}
  std::cout<<"Rendered 256x256 offscreen frame using "<<frame.renderer<<" -> "<<argv[2]<<'\n';return 0;
 }
 if(argc==2 && std::string(argv[1])=="gles-compute-demo") {
  using namespace docmont::gpu;
  auto add=compute_binary({1,2,3,4},{5,6,7,8},TensorBinaryOp::Add);
  auto softmax=compute_softmax({1,2,3,4,5,6},2,3);
  if(!add.ok||!softmax.ok){std::cerr<<(!add.ok?add.error:softmax.error)<<'\n';return 1;}
  std::cout<<"GLES tensor Add:";for(float v:add.values)std::cout<<" "<<v;
  std::cout<<"\nGLES row Softmax:";for(float v:softmax.values)std::cout<<" "<<v;
  std::cout<<"\nRenderer: "<<add.renderer<<'\n';return 0;
 }
 if(argc==3 && std::string(argv[1])=="onnx-info") {
  docmont::neural::OnnxModel model;std::string error;
  if(!model.load(argv[2],&error)){std::cerr<<"ONNX load failed: "<<error<<"\n";return 1;}
  const auto& info=model.info();std::cout<<"DOCMONT ONNX CPU Runtime 10.80.0\nGraph: "<<info.graph_name<<"\nInputs:";
  for(const auto& x:info.inputs)std::cout<<" "<<x;std::cout<<"\nOutputs:";for(const auto& x:info.outputs)std::cout<<" "<<x;
  std::cout<<"\nNodes: "<<info.nodes.size()<<"\nInitializers: "<<info.initializer_bytes<<" bytes\nOperators:";
  for(const auto& n:info.nodes)std::cout<<" "<<n.op_type;std::cout<<"\n";
  if(!info.unsupported_operators.empty()){std::cout<<"Unsupported operators:";for(const auto& x:info.unsupported_operators)std::cout<<" "<<x;std::cout<<"\n";}
  std::cout<<"Supported CPU operators:";for(const auto& op:docmont::neural::supported_operators())std::cout<<" "<<op;std::cout<<"\n";
  return 0;
 }
 if(argc==7 && std::string(argv[1])=="onnx-run" && std::string(argv[3])=="--shape") {
  // Usage: docmont onnx-run model.onnx --shape 1,2 --values 0.2,0.8
  docmont::neural::OnnxModel model;std::string error;if(!model.load(argv[2],&error)){std::cerr<<error<<"\n";return 1;}
  if(std::string(argv[5])!="--values"){std::cerr<<"Usage: docmont onnx-run <model.onnx> --shape 1,2 --values 0.2,0.8\n";return 2;}
  if(model.info().inputs.size()!=1||model.info().outputs.size()!=1){std::cerr<<"CLI inference currently requires one model input and one output; use the C++ API for multi-input models\n";return 2;}
  auto split=[](const std::string& text){std::vector<std::string> parts;std::istringstream in(text);std::string x;while(std::getline(in,x,','))parts.push_back(x);return parts;};
  docmont::neural::Tensor input;try{for(const auto& x:split(argv[4])){auto v=std::stoll(x);if(v<=0)throw std::invalid_argument("shape dimension must be positive");input.shape.push_back(v);}for(const auto& x:split(argv[6]))input.values.push_back(std::stof(x));}catch(const std::exception& e){std::cerr<<"invalid shape/value list: "<<e.what()<<"\n";return 2;}
  auto result=model.run({{model.info().inputs.front(),std::move(input)}});if(!result.ok){std::cerr<<"inference failed: "<<result.error<<"\n";return 1;}
  const auto& output=result.outputs.at(model.info().outputs.front());std::cout<<model.info().outputs.front()<<" shape=";for(std::size_t i=0;i<output.shape.size();++i)std::cout<<(i?",":"")<<output.shape[i];std::cout<<" values=";for(std::size_t i=0;i<output.values.size();++i)std::cout<<(i?",":"")<<output.values[i];std::cout<<"\n";return 0;
 }
 if(argc>=3 && std::string(argv[1])=="console-sdk-probe") {
  const std::string target=argv[2];docmont::platform::ConsolePlatform p;
  if(target=="ps5"||target=="playstation5")p=docmont::platform::ConsolePlatform::PlayStation5;
  else if(target=="xbox"||target=="xbox-series")p=docmont::platform::ConsolePlatform::XboxSeries;
  else {std::cerr<<"Target must be ps5 or xbox\n";return 2;}
  std::string manifest=argc>=4?argv[3]:"";if(manifest.empty()){const char* env=std::getenv(target=="ps5"?"DOCMONT_PS5_SDK_MANIFEST":"DOCMONT_XBOX_SDK_MANIFEST");if(env)manifest=env;}
  const auto r=docmont::platform::probe_console_sdk(p,manifest);
  std::cout<<"Console adapter: "<<docmont::platform::to_string(p)<<"\nManifest: "<<(r.manifest_found?"found":"missing")<<"\nSDK root: "<<(r.sdk_root_found?"found":"missing")<<"\nCompiler: "<<(r.compiler_found?"found":"missing")<<"\nCMake toolchain: "<<(r.cmake_toolchain_found?"found":"missing")<<"\nHeaders: "<<(r.headers_found?"found":"missing")<<"\nLicense acknowledged: "<<(r.license_acknowledged?"yes":"no")<<"\nAdapter configured: "<<(r.adapter_configured?"yes":"no")<<"\nHardware certified: no\n"<<r.detail<<"\n";
  return r.adapter_configured?0:1;
 }
 if(argc==2 && std::string(argv[1])=="network-info") {
  std::cout<<"DOCMONT Network Transport 10.80.0\nTCP: framed, ordered/reliable byte stream with length and CRC32 checks\nUDP: sequenced datagram with payload length and CRC32 checks\nHost adapter: POSIX IPv4 bind-any/loopback and outbound IPv4 DNS resolution in this release\nEncryption, authentication, NAT traversal and congestion control: not included\n";return 0;
 }
 if(argc==2 && std::string(argv[1])=="animation-info") {
  std::cout<<"DOCMONT Skeletal Animation 10.80.0\nSkeleton hierarchy: parent-before-child\nAnimation clips: time-sampled translation, quaternion SLERP and scale tracks\nPose blending: linear TRS and quaternion SLERP\nSkinning: CPU reference 4-influence linear blend skinning\nGPU shader sources: GLSL, HLSL, Metal (compile and submit require platform GPU backends)\n";return 0;
 }
 if(argc==2 && std::string(argv[1])=="studio-info") {
  std::cout<<"DOCMONT Visual Game Studio 10.80.0\nLaunch from source tree: tools/docmont-studio <workspace> [port]\nDefault URL: http://127.0.0.1:8787\nFeatures: project explorer, text editor, backups, validation/run, scene JSON preview, asset browser, render graph and metrics panels\n";return 0;
 }
 if(argc==2 && std::string(argv[1])=="project-info") {
  std::cout<<"DOCMONT Project Lifecycle 10.80.0\n"
           <<"Tool: docmont-project\n"
           <<"Commands: new, check, assets, build, package\n"
           <<"Workflow: scaffold -> validate -> asset manifest -> DVM build -> verify -> smoke run -> reproducible ZIP\n"
           <<"Project manifest: docmont.toml | Entry: .docm | Scene: .dscene\n";
  return 0;
 }
 if(argc==2 && std::string(argv[1])=="core-info") {
  std::cout << "DOCMONT Compiler Core 10.80.0\n"
            << "Source AST -> Typed HIR / MIR: integrated frontend v1\n"
            << "Generics: source syntax, inference, built-in trait constraints; runtime erasure\n"
            << "Ownership: explicit move/borrow source checks with supported if/match branch joins; loop-carried loans declined\n"
            << "Enums / match / Option / Result / ?: source grammar, type checks, interpreter and DVM\n"
            << "Native backend: direct verified integer MIR -> LLVM IR -> native object for a restricted subset; legacy C11/Clang path remains available\n"
            << "LLVM object targets: x86_64 Linux, AArch64 Linux, WebAssembly wasm32, RISC-V ELF (Clang target availability required)\n"
            << "DPM: manifest, lockfile and local transitive dependency resolver; registry fetching not implemented\n"
            << "Concurrency: threads, atomics, channels, TaskScheduler fixed worker pool; async/await syntax not integrated\n"
            << "See the 10.80.0 capability matrix for exact supported scope\n";
  return 0;
 }
 if(argc==3 && std::string(argv[1])=="dpm-check") {
  auto loaded=docmont::dpm::load_manifest(argv[2]);
  for(const auto& d:loaded.diagnostics) std::cerr<<d.code<<":"<<d.line<<": "<<d.message<<'\n';
  if(!loaded.ok)return 1;
  std::cout<<"DPM manifest valid: "<<loaded.manifest.name<<" "<<loaded.manifest.version
           <<" ("<<loaded.manifest.dependencies.size()<<" dependency declarations)\n";
  return 0;
 }
 if(argc==3 && std::string(argv[1])=="dpm-resolve") {
  auto loaded=docmont::dpm::load_manifest(argv[2]);
  for(const auto& d:loaded.diagnostics) std::cerr<<d.code<<":"<<d.line<<": "<<d.message<<'\n';
  if(!loaded.ok)return 1;
  auto resolved=docmont::dpm::resolve_local_dependencies(argv[2]);
  for(const auto& d:resolved.diagnostics)std::cerr<<d.code<<": "<<d.message<<'\n';
  if(!resolved.ok)return 1;
  const auto registry=std::count_if(loaded.manifest.dependencies.begin(),loaded.manifest.dependencies.end(),[](const auto& d){return d.path.empty();});
  std::cout<<"DPM local dependency graph resolved: "<<resolved.packages.size()<<" package(s); "<<registry<<" registry declaration(s) remain unfetched\n";
  for(const auto& package:resolved.packages)std::cout<<package.name<<" "<<package.version<<" | "<<package.manifest_path.generic_string()<<'\n';
  return 0;
 }
 if(argc==4 && std::string(argv[1])=="modules-check") {
  docmont::modules::Resolver resolver(argv[3]);auto resolved=resolver.resolve(argv[2]);
  for(const auto& d:resolved.diagnostics)std::cerr<<d.code<<":"<<d.source.string()<<":"<<d.line<<": "<<d.message<<'\n';
  if(!resolved.ok())return 1;
  std::cout<<"Module graph resolved: "<<resolved.order.size()<<" source files\n";
  for(const auto& path:resolved.order)std::cout<<path.generic_string()<<'\n';
  return 0;
 }
 if(argc==4 && std::string(argv[1])=="dpm-lock") {
  auto loaded=docmont::dpm::load_manifest(argv[2]);
  for(const auto& d:loaded.diagnostics) std::cerr<<d.code<<":"<<d.line<<": "<<d.message<<'\n';
  if(!loaded.ok)return 1;
  auto resolved=docmont::dpm::resolve_local_dependencies(argv[2]);
  for(const auto& d:resolved.diagnostics)std::cerr<<d.code<<": "<<d.message<<'\n';
  if(!resolved.ok)return 1;
  std::string error;if(!docmont::dpm::write_resolved_lockfile(argv[3],loaded.manifest,loaded.source_fingerprint,resolved.packages,error)){std::cerr<<error<<'\n';return 2;}
  std::cout<<"Wrote deterministic DPM v2 lockfile: "<<argv[3]<<" ("<<resolved.packages.size()<<" local package(s))\n";return 0;
 }
 if(argc==2 && std::string(argv[1])=="--version") { std::cout << "DOCMONT 10.80.0 (language compatibility: 3.4.0)\n"; return 0; }
 if(argc==2 && std::string(argv[1])=="language-info") { print_language_info(); return 0; }
 if(argc==2 && std::string(argv[1])=="targets") {
  std::cout << "DOCMONT target registry (10.80.0)\n";
  for (const auto& target : docmont::platform::targets)
   std::cout << target.name << " | " << docmont::platform::backend_status_name(target.status) << " | " << target.note << '\n';
  return 0;
 }
 if(argc==3 && std::string(argv[1])=="target-info") {
  const auto* target=docmont::platform::find_target(argv[2]);
  if(!target){std::cerr<<"Unknown target: "<<argv[2]<<"\nRun 'docmont targets' to list target identifiers.\n";return 2;}
  std::cout<<target->name<<"\nStatus: "<<docmont::platform::backend_status_name(target->status)<<"\nDetails: "<<target->note<<'\n';
  return 0;
 }
 if(argc==2 && std::string(argv[1])=="host-info") {
  std::cout<<"DOCMONT runtime host\nOS: "<<docmont::platform::host_os_name()<<"\nArchitecture: "<<docmont::platform::host_arch_name()
           <<"\nPointer width: "<<(sizeof(void*)*8)<<"-bit\nByte order: "<<(std::endian::native==std::endian::little?"little":"big")
           <<"\nPortable DVM bytecode: supported by this VM build\n";
  return 0;
 }
 if(argc==3 && std::string(argv[1])=="doctor" && std::string(argv[2])=="--json") {
  const auto gpu=docmont::gpu::probe_all_backends();
  const auto gles=docmont::gpu::probe_gles();
  std::cout << "{\"schemaVersion\":1,\"product\":\"DECMONT\",\"version\":\"10.80.0\","
            << "\"languageCompatibility\":\"3.4.0\",\"bytecodeFormat\":\"DVM-v1\","
            << "\"host\":{\"os\":\"" << json_escape(std::string(docmont::platform::host_os_name()))
            << "\",\"architecture\":\"" << json_escape(std::string(docmont::platform::host_arch_name()))
            << "\",\"pointerBits\":" << (sizeof(void*)*8)
            << ",\"logicalCpuThreads\":" << std::thread::hardware_concurrency() << "},"
            << "\"runtime\":{\"dvm\":\"available\",\"nativeCompiler\":\"restricted-mir-subset\"},"
            << "\"gles\":{\"available\":" << (gles.available?"true":"false")
            << ",\"compute\":" << (gles.compute_supported?"true":"false")
            << ",\"hardwareAccelerated\":" << (gles.hardware_accelerated?"true":"false") << "},"
            << "\"gpuBackends\":[";
  for (std::size_t i=0;i<gpu.backends.size();++i) {
   const auto& b=gpu.backends[i]; if(i) std::cout << ',';
   std::cout << "{\"backend\":\"" << json_escape(docmont::gpu::to_string(b.backend))
             << "\",\"availability\":\"" << json_escape(docmont::gpu::to_string(b.availability))
             << "\",\"runtimePresent\":" << (b.runtime_present?"true":"false")
             << ",\"deviceAvailable\":" << (b.device_available?"true":"false")
             << ",\"queueAvailable\":" << (b.queue_available?"true":"false") << '}';
  }
  std::cout << "],\"gameEngine\":{\"hostSystems\":\"available\",\"productionRendererAndAudioAdapters\":\"incomplete\"},"
            << "\"ai\":{\"onnxCpu\":\"bounded-operator-subset\",\"generalGpuProvider\":\"not-implemented\"},"
            << "\"validation\":{\"crossPlatformBuilds\":\"target-specific-validation-required\",\"diagnosticOnly\":true}}\n";
  return 0;
 }
 if(argc==2 && std::string(argv[1])=="doctor") {
  const auto gpu=docmont::gpu::probe_all_backends();
  const auto gles=docmont::gpu::probe_gles();
  std::cout << "DOCMONT 10.80.0 System Doctor\n"
            << "Host: " << docmont::platform::host_os_name() << " / " << docmont::platform::host_arch_name() << "\n"
            << "Pointer width: " << (sizeof(void*)*8) << "-bit\n"
            << "Logical CPU threads: " << std::thread::hardware_concurrency() << "\n"
            << "DVM portable runtime: available in this build\n"
            << "Native compiler: restricted MIR subset; not full-language parity\n"
            << "GLES: " << (gles.available?"available":"unavailable")
            << " | compute=" << (gles.compute_supported?"yes":"no")
            << " | hardware-accelerated=" << (gles.hardware_accelerated?"yes":"no") << "\n";
  for (const auto& b : gpu.backends) {
   std::cout << "GPU " << docmont::gpu::to_string(b.backend) << ": "
             << docmont::gpu::to_string(b.availability)
             << " | runtime=" << (b.runtime_present?"yes":"no")
             << " | device=" << (b.device_available?"yes":"no")
             << " | queue=" << (b.queue_available?"yes":"no") << "\n";
  }
  std::cout << "Game engine: host-side systems available; complete production renderer/audio adapters are platform-dependent\n"
            << "AI: bounded ONNX CPU operator subset; general GPU ONNX provider not implemented\n"
            << "Cross-platform: target registry lists requirements; each target needs its own toolchain/device validation\n"
            << "Doctor status: diagnostic only; unavailable backends do not prevent VM execution\n";
  return 0;
 }
 if(argc==2 && std::string(argv[1])=="game-info") {
  std::cout << "DOCMONT 10.80.0 ULTRA game systems\n"
            << "ECS/SceneGraph: host API foundation\n"
            << "Assets: catalog, dependency validation\n"
            << "World: cell partition and simulation tiers\n"
            << "Physics: fixed-step AABB rigid bodies\n"
            << "Navigation: weighted-grid A*\n"
            << "AI: utility selection foundation\n"
            << "Audio: spatial voice gain and priority scheduling (device playback adapter pending)\n"
            << "Network: TCP framed transport + UDP sequenced datagrams + snapshot codec\n"
            << "Graphics: Vulkan loader/instance/device-queue probe; D3D12/Metal platform adapters pending; render graph + CPU PBR\n"
            << "Animation: skeleton hierarchy, keyframe sampling, pose blending and CPU skinning\n"
            << "Neural: bounded ONNX protobuf CPU runtime for the documented operator subset; GLES compute tensor primitives available separately\n"
            << "Profiler: CPU/GPU and subsystem metrics collection\n";
  return 0;
 }
 if(argc==2 && std::string(argv[1])=="game-demo") {
  using namespace docmont::game;
  PhysicsWorld physics; RigidBodyDesc floor; floor.position={0,-1,0}; floor.half_extents={10,1,10}; floor.mass=0; physics.add_body(floor);
  RigidBodyDesc body; body.position={0,2,0}; body.mass=1; const auto id=physics.add_body(body);
  for(int frame=0;frame<60;++frame) (void)physics.step(1.0f/60.0f);
  NavigationGrid nav(12,12); const auto route=nav.find_path({0,0},{11,11});
  const auto pipeline=build_render_pipeline(RenderPath::Deferred);
  std::cout << "Physics Y: " << physics.body(id)->position.y << "\n"
            << "A* path: " << (route?std::to_string(route->size())+" nodes":"not found") << "\n"
            << "Deferred render graph: " << (pipeline.ok?"valid":"invalid") << "\n";
  return route && pipeline.ok ? 0 : 1;
 }
 if(argc==2 && std::string(argv[1])=="decom-info") { std::cout << "DOCMONT DECOM " << docmont::decom::version << "\nModules: " << docmont::decom::abi::count() << "\nDeclared API capability slots: " << docmont::decom::abi::declared_capabilities() << "\n"; for(const auto& m:docmont::decom::abi::modules) std::cout << m.name << " | ABI " << m.abi_version << " | capabilities " << m.capability_count << " | deterministic " << (m.deterministic?"yes":"no") << "\n"; return 0; }
 if(argc==2 && (std::string(argv[1])=="--help" || std::string(argv[1])=="-h")) {
  std::cout << "DOCMONT 10.80.0\nUsage: docmont <check|core-check|run|ir|ssa|ssa-range|ssa-verify|optimize|tokens|ast> <file.docm>\n       docmont check --json <file.docm>\n       docmont core-info | language-info | targets | host-info | doctor | target-info <target>\n       docmont bytecode <source.docm> <output.dvm> | verify <file.dvm> | vm-run <file.dvm>\n       docmont llvm-mir <source.docm> <output.ll>\n       docmont native-mir-object <source.docm> <output.o> <target-triple> [clang]\n       docmont-native-build <source.docm> -o <native-exe> [--target triple]\n       docmont native-c <source.docm> <output.c> | native-object <source.docm> <output.o> [clang]\n       docmont dpm-check <project.dpm> | dpm-resolve <project.dpm> | dpm-lock <project.dpm> <lockfile>\n       docmont modules-check <entry.docm> <module-root>\n       docmont java-bindings <manifest.djava> <output-directory>\n       docmont asm-check <file.dasm> | asm-emit-x86_64 <file.dasm> <output.S>\n       docmont-console-build <ps5|xbox> <cmake-project> --manifest <sdk.dcsdk> --build-dir <dir>\n       docmont-shader-build <vulkan|d3d12|metal> <shader> -o <artifact>\n       docmont doctor | game-info | game-demo | project-info | gpu-info | gles-info | gles-render-demo <out.ppm> | gles-compute-demo | onnx-info <model.onnx> | onnx-run <model.onnx> --shape 1,2 --values 0.1,0.2\n       docmont network-info | animation-info | studio-info | console-sdk-probe <ps5|xbox> [manifest]\n       docmont decom-info | graphics-demo <output.ppm> | vlot <command> ...\n       docmont --version\n"; return 0;
 }
 std::string command=argc>1?argv[1]:"";
 if(command=="java-bindings" && argc==4) {
  auto result=docmont::interop::generate_java_bindings_file(argv[2],argv[3]);
  std::cout<<result.message<<'\n';
  return result.ok?0:1;
 }
 if(command=="asm-check" && argc==3) {
  auto result=docmont::interop::check_assembly_file(argv[2]);
  std::cout<<result.message<<'\n';
  return result.ok?0:1;
 }
 if(command=="asm-emit-x86_64" && argc==4) {
  auto result=docmont::interop::emit_assembly_file(argv[2],argv[3]);
  std::cout<<result.message<<'\n';
  return result.ok?0:1;
 }
 if(command=="vlot" && argc>=4) {
  const std::string sub=argv[2];
  if(sub=="verify-package") { docmont::vlot::PackageReport report; auto r=docmont::vlot::verify_package(argv[3],report); std::cout<<r.message<<'\n'; if(r.ok)std::cout<<"Files: "<<report.files<<"\nPayload bytes: "<<report.payload_bytes<<'\n'; return r.ok?0:1; }
  if(sub=="shader-check") { std::ifstream in(argv[3]); if(!in){std::cerr<<"cannot open shader\n";return 2;} std::ostringstream ss;ss<<in.rdbuf();docmont::vlot::ShaderProgram shader;auto r=docmont::vlot::compile_shader(ss.str(),shader);std::cout<<r.message<<'\n';if(r.ok)std::cout<<"Shader: "<<shader.name<<" model="<<shader.model<<'\n';return r.ok?0:1; }
  if(sub=="shader-build" && argc==5) { auto r=docmont::vlot::compile_shader_file(argv[3],argv[4]);std::cout<<r.message<<'\n';return r.ok?0:1; }
  if(sub=="scene-check") { docmont::vlot::Scene scene;auto r=docmont::vlot::load_scene(argv[3],scene);std::cout<<r.message<<'\n';if(r.ok)std::cout<<"Nodes: "<<scene.nodes.size()<<'\n';return r.ok?0:1; }
  if(sub=="scene-render" && argc==7) { docmont::vlot::Scene scene;auto r=docmont::vlot::load_scene(argv[3],scene);if(!r.ok){std::cerr<<r.message<<'\n';return 1;}int w=std::atoi(argv[5]),h=std::atoi(argv[6]);if(w<1||h<1||w>8192||h>8192){std::cerr<<"render dimensions must be 1..8192\n";return 2;}docmont::vlot::SoftwareRenderer renderer(w,h);r=docmont::vlot::render_scene_2d(scene,renderer);if(!r.ok||!renderer.write_ppm(argv[4])){std::cerr<<(r.ok?"failed writing scene image":r.message)<<'\n';return 1;}std::cout<<"Rendered "<<scene.nodes.size()<<" scene nodes to "<<argv[4]<<'\n';return 0; }
  if(sub=="verify-material") { auto r=docmont::vlot::verify_material_file(argv[3]);std::cout<<r.message<<'\n';return r.ok?0:1; }
  docmont::vlot::ProjectConfig project;
  const auto loaded = (sub=="verify-package"||sub=="shader-check"||sub=="shader-build"||sub=="scene-check"||sub=="scene-render"||sub=="verify-material") ? docmont::vlot::Result{true,"ok"} : docmont::vlot::load_project(argv[3],project);
  if(!loaded.ok){std::cerr<<loaded.message<<'\n';return 1;}
  if(sub=="inspect") { std::cout<<"VLOT project: "<<project.name<<"\nTargets:"; for(auto target:project.targets)std::cout<<" "<<docmont::vlot::to_string(target);std::cout<<"\nQuality: "<<project.quality<<"\nAssets: "<<project.asset_root<<"\n";return 0; }
  if(sub=="plan") { docmont::vlot::ToolchainAvailability tools;tools.android_sdk=std::getenv("ANDROID_HOME")||std::getenv("ANDROID_SDK_ROOT");tools.android_ndk=std::getenv("ANDROID_NDK_HOME")||std::getenv("ANDROID_NDK_ROOT");tools.playstation_sdk=std::getenv("SCE_ROOT_DIR")!=nullptr;const auto plan=docmont::vlot::create_build_plan(project,tools);std::cout<<docmont::vlot::format_build_plan(plan);return 0; }
  if(sub=="assets") { docmont::vlot::AssetCatalog catalog;auto r=docmont::vlot::build_asset_catalog(argv[3],project,catalog);if(!r.ok){std::cerr<<r.message<<'\n';return 1;}std::cout<<r.message<<"\nFiles: "<<catalog.entries.size()<<"\nBytes: "<<catalog.total_bytes<<'\n';for(const auto& e:catalog.entries)std::cout<<e.relative_path<<" | "<<e.size<<" bytes | hash="<<e.hash<<'\n';return 0; }
  if(sub=="build" && argc==5) { docmont::vlot::PackageReport report;auto r=docmont::vlot::build_package(argv[3],argv[4],report);if(!r.ok){std::cerr<<r.message<<'\n';return 1;}std::cout<<r.message<<"\nFiles: "<<report.files<<"\nPayload bytes: "<<report.payload_bytes<<'\n';return 0; }
  std::cerr<<"VLOT command: inspect, plan, assets, build <project.vlot> <output.vpak>, verify-package <file.vpak>, shader-check <file.vshader>, shader-build <input.vshader> <output.vsm>, verify-material <file.vsm>, scene-check <file.vscene>, scene-render <file.vscene> <output.ppm> <width> <height>\n";return 2;
 }
 if(command=="vlot-render-demo" && argc==3) {
  docmont::vlot::SoftwareRenderer renderer(640,360,{15,20,31});
  renderer.rectangle(70,70,500,230,0.8f,{36,66,100});
  renderer.triangle({130,280,0.2f,{255,90,70}},{320,55,0.2f,{255,210,80}},{510,280,0.2f,{80,210,160}});
  renderer.triangle({230,210,0.1f,{80,150,255}},{410,210,0.1f,{80,150,255}},{320,105,0.1f,{210,230,255}});
  if(!renderer.write_ppm(argv[2])){std::cerr<<"Could not write VLOT render output\n";return 2;}
  std::cout<<"VLOT software renderer wrote 640x360 image to "<<argv[2]<<'\n';return 0;
 }
 if(command=="vm-run" && argc==3){std::ifstream bin(argv[2],std::ios::binary);if(!bin){std::cerr<<"Cannot open bytecode file\n";return 2;}std::vector<std::uint8_t> bytes((std::istreambuf_iterator<char>(bin)),{});auto verified=docmont::verify_bytecode(bytes);if(!verified.ok){std::cerr<<verified.message<<'\n';return 1;}return docmont::execute_bytecode(bytes);}
 if(command=="graphics-demo" && argc==3){docmont::Canvas c(320,180,{18,22,30});c.fill_rect(24,24,272,132,{40,90,140});c.line(24,24,296,156,{240,240,240});c.circle(160,90,42,{255,190,70});if(!c.write_ppm(argv[2])){std::cerr<<"Could not write image\n";return 2;}std::cout<<"Wrote 320x180 PPM image to "<<argv[2]<<'\n';return 0;}
 if(command=="verify" && argc==3){std::ifstream bin(argv[2],std::ios::binary);if(!bin){std::cerr<<"Cannot open bytecode file\n";return 2;}std::vector<std::uint8_t> bytes((std::istreambuf_iterator<char>(bin)),{});auto result=docmont::verify_bytecode(bytes);std::cout<<result.message<<'\n';return result.ok?0:1;}
 bool json_check = command=="check" && argc==4 && std::string(argv[2])=="--json";
 if(command=="bytecode" && argc==4){} else if(command=="native-c" && argc==4){} else if(command=="native-object" && (argc==4||argc==5)){} else if(command=="llvm-ir" && (argc==4||argc==5)){} else if(command=="llvm-mir" && argc==4){} else if(command=="native-mir-object" && (argc==5||argc==6)){} else if(json_check){} else if(argc!=3){std::cerr<<"DOCMONT 10.80.0\nUsage: docmont <check|core-check|run|ir|ssa|ssa-range|ssa-verify|optimize|tokens|ast> <file.docm>\n       docmont check --json <file.docm>\n       docmont core-info\n       docmont language-info | targets | host-info | target-info <target>\n       docmont bytecode <source.docm> <output.dvm> | verify <file.dvm> | vm-run <file.dvm>\n       docmont llvm-mir <source.docm> <output.ll>\n       docmont native-mir-object <source.docm> <output.o> <target-triple> [clang]\n       docmont-native-build <source.docm> -o <native-exe> [--target triple]\n       docmont native-c <source.docm> <output.c> | native-object <source.docm> <output.o> [clang]\n       docmont dpm-check <project.dpm> | dpm-resolve <project.dpm> | dpm-lock <project.dpm> <lockfile>\n       docmont modules-check <entry.docm> <module-root>\n       docmont java-bindings <manifest.djava> <output-directory>\n       docmont asm-check <file.dasm> | asm-emit-x86_64 <file.dasm> <output.S>\n       docmont gpu-info | gles-info | gles-render-demo <out.ppm> | gles-compute-demo | onnx-info <model.onnx> | onnx-run <model.onnx> --shape 1,2 --values 0.1,0.2\n       docmont console-sdk-probe <ps5|xbox> [manifest] | studio-info | network-info | animation-info\n";return 2;}
 std::string source_path=json_check?argv[3]:argv[2];std::ifstream in(source_path,std::ios::binary);
 if(!in){std::cerr<<"Cannot open source file: "<<argv[2]<<'\n';return 2;}
 std::ostringstream ss;ss<<in.rdbuf();docmont::Lexer lexer(ss.str());auto lex=lexer.scan();
 if(command=="tokens"){
  for(const auto& t:lex.tokens)std::cout<<t.line<<':'<<t.column<<" "<<docmont::token_name(t.kind)<<" ["<<t.text<<"]\n";
  bool failed=false;diagnostics(lex.diagnostics,failed);return failed?1:0;
 }
 docmont::Parser parser(std::move(lex.tokens));auto parsed=parser.parse();
 auto sem=docmont::validate(parsed.app);
 auto function_sem=docmont::validate_function_contracts(parsed.app);
 auto ownership_sem=docmont::ownership::validate_source(parsed.app);
 bool failed=false;
 if(!json_check) { diagnostics(lex.diagnostics,failed);diagnostics(parsed.diagnostics,failed);diagnostics(sem,failed);diagnostics(function_sem,failed); for(const auto& d:ownership_sem){std::cerr<<"error:"<<d.line<<":1: ["<<d.code<<"] "<<d.message<<"\n";failed=true;} }
 if(json_check) { auto all=lex.diagnostics; all.insert(all.end(),parsed.diagnostics.begin(),parsed.diagnostics.end()); all.insert(all.end(),sem.begin(),sem.end()); all.insert(all.end(),function_sem.begin(),function_sem.end()); for(const auto& d:ownership_sem)all.push_back({docmont::Severity::Error,static_cast<int>(d.line),1,d.code+": "+d.message}); bool ok=std::none_of(all.begin(),all.end(),[](const auto& d){return d.severity==docmont::Severity::Error;}); print_diagnostics_json(all,ok,ss.str()); return ok?0:1; }
 if(failed)return 1;
 auto ir=docmont::lower_to_ir(parsed.app);
 if(command=="ast"){dump_ast(parsed.app);return 0;}
 if(command=="check"){std::cout<<"DOCMONT: source, type and ownership checks passed.\n";return 0;}
 if(command=="core-check") {
   auto lowered=docmont::frontend::lower_to_hir_mir(parsed.app);
   for(const auto& d:lowered.diagnostics) std::cerr<<d.code<<": "<<d.message<<'\n';
   if(!lowered.diagnostics.empty()) return 1;
   std::cout<<"Typed HIR verified: "<<lowered.hir.functions.size()<<" functions, "<<lowered.types.size()<<" interned types\n";
   std::size_t blocks=0,ops=0;for(const auto& fn:lowered.mir.functions)for(const auto& b:fn.blocks){++blocks;ops+=b.operations.size();}
   std::cout<<"MIR verified: "<<blocks<<" basic blocks, "<<ops<<" operations\n"; return 0;
 }
 if(command=="llvm-mir" || command=="native-mir-object") {
   auto lowered=docmont::frontend::lower_to_hir_mir(parsed.app);
   for(const auto& d:lowered.diagnostics) std::cerr<<d.code<<": "<<d.message<<'\n';
   if(!lowered.diagnostics.empty()) return 1;
   if(command=="llvm-mir") {
     auto generated=docmont::core::emit_direct_llvm_ir(lowered.mir,lowered.hir,lowered.types,"x86_64-unknown-linux-gnu");
     if(!generated.ok){std::cerr<<generated.message<<'\n';return 1;}
     std::ofstream out(argv[3],std::ios::binary);if(!out){std::cerr<<"Cannot create LLVM IR output\n";return 2;}
     out<<generated.ir;if(!out){std::cerr<<"Failed writing LLVM IR\n";return 2;}
     std::cout<<generated.message<<": "<<argv[3]<<'\n';return 0;
   }
   const std::string target=argv[4]; const std::string clang_path=argc==6?argv[5]:"clang";
   auto compiled=docmont::core::compile_direct_llvm_object(lowered.mir,lowered.hir,lowered.types,argv[3],target,clang_path);
   if(!compiled.ok){std::cerr<<compiled.message<<'\n'<<compiled.compiler_output;return 1;}
   std::cout<<compiled.message<<": "<<argv[3]<<'\n';return 0;
 }
 if(command=="run")return docmont::execute_application(parsed.app);
 if(command=="ir"){std::cout<<docmont::dump_ir(ir);return 0;}
 if(command=="ssa"){auto ssa=docmont::build_ssa(ir);std::cout<<docmont::dump_ssa(ssa);return 0;}
 if(command=="ssa-range"){
  auto ssa=docmont::build_ssa(ir);auto verified=docmont::verify_ssa(ssa,ir);
  if(!verified.ok){for(const auto& error:verified.errors)std::cerr<<"SSA verification error: "<<error<<'\n';return 1;}
  std::cout<<"DOCMONT integer range analysis\n";
  for(const auto& range:ssa.integer_ranges){
   std::cout<<"v"<<range.value<<" in ["<<range.minimum<<", "<<range.maximum<<"]";
   auto definition=std::find_if(ssa.value_definitions.begin(),ssa.value_definitions.end(),[&](const docmont::SSAValueDefinition& item){return item.id==range.value;});
   if(definition!=ssa.value_definitions.end()&&definition->instruction!=static_cast<std::size_t>(-1))std::cout<<" @i"<<definition->instruction;
   std::cout<<'\n';
  }
  std::cout<<"Proven ranges: "<<ssa.integer_ranges.size()<<"\n";return 0;
 }
 if(command=="ssa-verify"){auto ssa=docmont::build_ssa(ir);auto verified=docmont::verify_ssa(ssa,ir);if(!verified.ok){for(const auto& e:verified.errors)std::cerr<<"SSA verification error: "<<e<<'\n';return 1;}std::cout<<"SSA verification passed: "<<ssa.blocks.size()<<" blocks, "<<ssa.phi_count<<" Phi nodes, "<<ssa.definitions.size()<<" definitions, "<<ssa.uses.size()<<" variable uses, "<<ssa.value_definitions.size()<<" value definitions, "<<ssa.value_uses.size()<<" value uses, "<<ssa.stack_phis.size()<<" stack Phis, "<<ssa.memory_definitions.size()<<" partitioned memory definitions, "<<ssa.memory_uses.size()<<" partitioned memory uses, "<<ssa.memory_phis.size()<<" partitioned memory Phis, "<<ssa.alias_accesses.size()<<" alias accesses, "<<ssa.functions.size()<<" function regions.\n";return 0;}
 if(command=="optimize"){auto stats=docmont::optimize_ir(ir);std::cout<<"DOCMONT optimizer O3 + SSA\nInstructions: "<<stats.instructions_before<<" -> "<<stats.instructions_after<<"\nConstants folded: "<<stats.constants_folded<<"\nAlgebraic simplifications: "<<stats.algebraic_simplifications<<"\nConstant propagations: "<<stats.constant_propagations<<"\nUnreachable instructions removed: "<<stats.unreachable_instructions_removed<<"\nConstant branches folded: "<<stats.constant_branches_folded<<"\nJump threads: "<<stats.jump_threads<<"\nSSA GVN expressions eliminated: "<<stats.ssa_gvn_eliminations<<"\nSSA GVN cross-block eliminations: "<<stats.ssa_gvn_cross_block_eliminations<<"\nSSA memory reads eliminated: "<<stats.ssa_memory_load_eliminations<<"\nSSA memory cross-block reads eliminated: "<<stats.ssa_memory_load_cross_block_eliminations<<"\nSSA heap stores removed: "<<stats.ssa_heap_stores_removed<<"\nSSA dead stores removed: "<<stats.ssa_dead_stores_removed<<"\nSSA Global DCE instructions removed: "<<stats.ssa_global_dce_instructions_removed<<"\n"<<docmont::dump_ir(ir);return 0;}
 if(command=="native-object" && (argc==4||argc==5)){const std::string clang_path=argc==5?argv[4]:"clang";auto compiled=docmont::compile_native_object(ir,argv[3],clang_path);if(!compiled.ok){std::cerr<<compiled.message<<"\n"<<compiled.compiler_output;return 1;}std::cout<<compiled.message<<": "<<argv[3]<<"\n";return 0;}
 if(command=="llvm-ir" && (argc==4||argc==5)){const std::string clang_path=argc==5?argv[4]:"clang";auto emitted=docmont::emit_llvm_ir(ir,argv[3],clang_path);if(!emitted.ok){std::cerr<<emitted.message<<"\n"<<emitted.compiler_output;return 1;}std::cout<<emitted.message<<": "<<argv[3]<<"\n";return 0;}
 if(command=="native-c" && argc==4){auto generated=docmont::emit_c_source(ir);if(!generated.ok){std::cerr<<generated.message<<'\n';return 1;}std::ofstream out(argv[3],std::ios::binary);if(!out){std::cerr<<"Cannot create C output\n";return 2;}out<<generated.source;if(!out){std::cerr<<"Failed writing C output\n";return 2;}std::cout<<"Wrote portable C11 source to "<<argv[3]<<'\n';return 0;}
 if(command=="bytecode" && argc==4){auto encoded=docmont::encode_bytecode(ir);if(!encoded.ok){std::cerr<<encoded.message<<'\n';return 1;}std::ofstream out(argv[3],std::ios::binary);if(!out){std::cerr<<"Cannot create output bytecode\n";return 2;}out.write(reinterpret_cast<const char*>(encoded.bytes.data()),static_cast<std::streamsize>(encoded.bytes.size()));if(!out){std::cerr<<"Failed writing bytecode\n";return 2;}std::cout<<"Wrote "<<encoded.bytes.size()<<" bytes to "<<argv[3]<<'\n';return 0;}
 std::cerr<<"Unknown command: "<<command<<'\n';return 2;
}
