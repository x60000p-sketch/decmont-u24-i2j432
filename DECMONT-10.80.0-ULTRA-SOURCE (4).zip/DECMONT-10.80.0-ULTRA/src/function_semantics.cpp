#include "docmont/function_semantics.hpp"
#include <algorithm>
#include <cctype>
#include <cstdint>
#include <limits>
#include <sstream>
#include <unordered_map>
#include <unordered_set>

namespace docmont {
namespace {
enum class TypeKind { Invalid, Any, Int, Bool, String, Array, Object, Function, Void, Generic, Option, Result, Enum, Reference, MutableReference };
struct Type {
    TypeKind kind{TypeKind::Invalid};
    std::string function_name;
    std::vector<Type> arguments;
};
struct Signature {
    const FunctionDecl* declaration{};
    std::vector<Type> parameters;
    std::vector<GenericTypeParameter> generic_parameters;
    std::size_t required{};
    Type result{TypeKind::Any, {}};
};
using Variables = std::unordered_map<std::string, Type>;
using Signatures = std::unordered_map<std::string, Signature>;

std::vector<std::string> split_type_arguments(const std::string& text) {
    std::vector<std::string> out; std::size_t start=0; int depth=0;
    for (std::size_t i=0;i<text.size();++i) {
        if(text[i]=='<')++depth; else if(text[i]=='>')--depth;
        else if(text[i]==','&&depth==0){out.push_back(text.substr(start,i-start));start=i+1;}
    }
    if(start<text.size())out.push_back(text.substr(start));
    return out;
}
Type parse_type(const std::string& raw, const std::unordered_set<std::string>& generic_names = {},
                const std::unordered_set<std::string>& enum_names = {}) {
    std::string name; for(char c:raw)if(!std::isspace(static_cast<unsigned char>(c)))name+=c;
    if(name.empty())return {TypeKind::Any,{},{}};
    if(name.rfind("&mut",0)==0)return {TypeKind::MutableReference,name.substr(4),{parse_type(name.substr(4),generic_names,enum_names)}};
    if(name[0]=='&')return {TypeKind::Reference,name.substr(1),{parse_type(name.substr(1),generic_names,enum_names)}};
    const auto angle=name.find('<'); std::string base=angle==std::string::npos?name:name.substr(0,angle);
    std::vector<std::string> args;
    if(angle!=std::string::npos&&name.back()=='>')args=split_type_arguments(name.substr(angle+1,name.size()-angle-2));
    if(generic_names.contains(base))return {TypeKind::Generic,base,{}};
    Type result;
    if(base=="Int"||base=="Integer"||base=="i32"||base=="i64"||base=="Number")result.kind=TypeKind::Int;
    else if(base=="Bool"||base=="Boolean"||base=="bool")result.kind=TypeKind::Bool;
    else if(base=="String"||base=="string"||base=="utf8")result.kind=TypeKind::String;
    else if(base=="Array")result.kind=TypeKind::Array;
    else if(base=="Object")result.kind=TypeKind::Object;
    else if(base=="Function")result.kind=TypeKind::Function;
    else if(base=="Void"||base=="Unit"||base=="void")result.kind=TypeKind::Void;
    else if(base=="Option")result.kind=TypeKind::Option;
    else if(base=="Result")result.kind=TypeKind::Result;
    else if(enum_names.contains(base)){result.kind=TypeKind::Enum;result.function_name=base;}
    else return {TypeKind::Invalid,name,{}};
    for(const auto& arg:args)result.arguments.push_back(parse_type(arg,generic_names,enum_names));
    if((result.kind==TypeKind::Option&&result.arguments.size()!=1)||(result.kind==TypeKind::Result&&result.arguments.size()!=2))return {TypeKind::Invalid,name,{}};
    if((result.kind==TypeKind::Option||result.kind==TypeKind::Result)&&result.arguments.empty())return {TypeKind::Invalid,name,{}};
    return result;
}

bool compatible(Type expected, Type actual);

bool unify_generic(const Type& expected,const Type& actual,std::unordered_map<std::string,Type>& substitutions) {
    if(expected.kind==TypeKind::Generic){auto it=substitutions.find(expected.function_name);if(it==substitutions.end()){substitutions.emplace(expected.function_name,actual);return actual.kind!=TypeKind::Invalid;}return compatible(it->second,actual);}
    if(expected.kind!=actual.kind)return expected.kind==TypeKind::Any||actual.kind==TypeKind::Any||expected.kind==TypeKind::Invalid||actual.kind==TypeKind::Invalid;
    if(expected.kind==TypeKind::Enum&&!expected.function_name.empty()&&expected.function_name!=actual.function_name)return false;
    if(expected.arguments.size()!=actual.arguments.size())return expected.arguments.empty()||actual.arguments.empty();
    for(std::size_t i=0;i<expected.arguments.size();++i)if(!unify_generic(expected.arguments[i],actual.arguments[i],substitutions))return false;
    return true;
}
Type substitute_type(const Type& type,const std::unordered_map<std::string,Type>& substitutions) {
    if(type.kind==TypeKind::Generic){auto it=substitutions.find(type.function_name);return it==substitutions.end()?Type{TypeKind::Any,{},{}}:it->second;}
    Type out=type;out.arguments.clear();for(const auto& arg:type.arguments)out.arguments.push_back(substitute_type(arg,substitutions));return out;
}

const char* type_name(Type t) {
    switch (t.kind) {
    case TypeKind::Any: return "Any"; case TypeKind::Int: return "Int"; case TypeKind::Bool: return "Bool";
    case TypeKind::String: return "String"; case TypeKind::Array: return "Array"; case TypeKind::Object: return "Object";
    case TypeKind::Function: return "Function"; case TypeKind::Void: return "Void"; case TypeKind::Generic: return "Generic";
    case TypeKind::Option: return "Option"; case TypeKind::Result: return "Result"; case TypeKind::Enum: return "Enum";
    case TypeKind::Reference: return "Reference"; case TypeKind::MutableReference: return "MutableReference";
    case TypeKind::Invalid: return "Invalid";
    }
    return "Invalid";
}

bool compatible(Type expected, Type actual) {
    if (expected.kind == TypeKind::Any || actual.kind == TypeKind::Any || expected.kind == TypeKind::Invalid || actual.kind == TypeKind::Invalid) return true;
    if (expected.kind != actual.kind) return false;
    if ((expected.kind == TypeKind::Function || expected.kind == TypeKind::Enum) && !expected.function_name.empty() && !actual.function_name.empty() && expected.function_name != actual.function_name) return false;
    if (expected.arguments.empty() || actual.arguments.empty()) return true;
    if (expected.arguments.size() != actual.arguments.size()) return false;
    for (std::size_t i=0;i<expected.arguments.size();++i) if(!compatible(expected.arguments[i],actual.arguments[i])) return false;
    return true;
}

bool truthy_type(Type t) { return t.kind == TypeKind::Bool || t.kind == TypeKind::Int || t.kind == TypeKind::Any || t.kind == TypeKind::Invalid; }

class TypeChecker {
public:
    explicit TypeChecker(const Application& app) : app_(app) {
        for (const auto& e : app.enums) enums_.emplace(e.name, &e);
        build_signatures();
    }

    std::vector<Diagnostic> run() {
        for (const auto& fn : app_.functions) check_function(fn);
        Variables globals;
        for (const auto& [name, sig] : functions_) {
            (void)sig;
            globals.emplace(name, Type{TypeKind::Function, name});
        }
        check_statements(app_.statements, globals, {TypeKind::Any, {}}, false, 0, true);
        return diagnostics_;
    }

private:
    const Application& app_;
    Signatures functions_;
    std::unordered_map<std::string,const EnumDecl*> enums_;
    std::unordered_set<std::string> generic_scope_;
    Type current_return_type_{TypeKind::Any,{},{}};
    std::vector<Diagnostic> diagnostics_;

    void error(int line, int column, std::string message) {
        diagnostics_.push_back({Severity::Error, line, column, std::move(message)});
    }

    void build_signatures() {
        for (const auto& enum_decl : app_.enums) {
            if (enum_decl.name.empty()) error(enum_decl.line,1,"Enum name cannot be empty");
            std::unordered_set<std::string> variants;
            for(const auto& variant:enum_decl.variants)if(!variants.insert(variant.name).second)error(variant.line,1,"Duplicate enum variant '"+variant.name+"' in enum '"+enum_decl.name+"'");
        }
        for (const auto& fn : app_.functions) {
            if (fn.name.empty()) { error(fn.line, 1, "Function name cannot be empty"); continue; }
            Signature sig; sig.declaration=&fn; sig.required=fn.parameters.size(); sig.generic_parameters=fn.type_parameters;
            std::unordered_set<std::string> generic_names;
            for(const auto& generic:fn.type_parameters)if(!generic_names.insert(generic.name).second)error(generic.line,1,"Duplicate generic type parameter '"+generic.name+"'");
            sig.result=parse_type(fn.return_type,generic_names,enum_names());
            if(!fn.return_type.empty()&&sig.result.kind==TypeKind::Invalid)error(fn.line,1,"Unknown or malformed return type '"+fn.return_type+"' in function '"+fn.name+"'");
            std::unordered_set<std::string> parameters; bool saw_default=false;
            for(const auto& param:fn.parameters){
                Type type=parse_type(param.type,generic_names,enum_names());
                if(type.kind==TypeKind::Invalid)error(param.line,1,"Unknown or malformed parameter type '"+param.type+"' in function '"+fn.name+"'");
                if(!parameters.insert(param.name).second)error(param.line,1,"Duplicate parameter '"+param.name+"' in function '"+fn.name+"'");
                sig.parameters.push_back(type);
                if(param.default_value){if(!saw_default)sig.required=sig.parameters.size()-1;saw_default=true;}else if(saw_default)error(param.line,1,"Required parameter cannot follow a parameter with a default value");
            }
            if(!functions_.emplace(fn.name,std::move(sig)).second)error(fn.line,1,"Duplicate function '"+fn.name+"' (overloading is not enabled)");
        }
    }

    std::unordered_set<std::string> enum_names() const {
        std::unordered_set<std::string> names; for(const auto& item:enums_)names.insert(item.first); return names;
    }

    Type check_expr(const std::shared_ptr<Expr>& expr, const Variables& vars) {
        if (!expr) return {TypeKind::Any, {}};
        switch (expr->kind) {
        case ExprKind::Integer:
            try { (void)std::stoll(expr->text); }
            catch (...) { error(expr->line, expr->column, "Integer literal is outside signed 64-bit range"); return {}; }
            return {TypeKind::Int, {}};
        case ExprKind::Boolean: return {TypeKind::Bool, {}};
        case ExprKind::String: return {TypeKind::String, {}};
        case ExprKind::Identifier: {
            auto variable = vars.find(expr->text);
            if (variable != vars.end()) return variable->second;
            auto function = functions_.find(expr->text);
            if (function != functions_.end()) return {TypeKind::Function, expr->text};
            error(expr->line, expr->column, "Unknown variable '" + expr->text + "'");
            return {};
        }
        case ExprKind::ArrayLiteral:
            for (const auto& item : expr->elements) (void)check_expr(item, vars);
            return {TypeKind::Array, {}};
        case ExprKind::ObjectLiteral:
            for (const auto& property : expr->properties) (void)check_expr(property.second, vars);
            return {TypeKind::Object, {}};
        case ExprKind::Member: {
            Type base = check_expr(expr->left, vars);
            if (base.kind != TypeKind::Object && base.kind != TypeKind::Any && base.kind != TypeKind::Invalid)
                error(expr->line, expr->column, "Property access requires an Object, got " + std::string(type_name(base)));
            return {TypeKind::Any, {}};
        }
        case ExprKind::Index: {
            Type base = check_expr(expr->left, vars);
            Type index = check_expr(expr->right, vars);
            if (base.kind != TypeKind::Array && base.kind != TypeKind::Any && base.kind != TypeKind::Invalid)
                error(expr->line, expr->column, "Indexing requires an Array, got " + std::string(type_name(base)));
            if (index.kind != TypeKind::Int && index.kind != TypeKind::Any && index.kind != TypeKind::Invalid)
                error(expr->line, expr->column, "Array index must be Int, got " + std::string(type_name(index)));
            return {TypeKind::Any, {}};
        }
        case ExprKind::Lambda:
            if (expr->lambda_function) {
                Variables local = vars;
                for (const auto& p : expr->lambda_function->parameters) local[p.name] = parse_type(p.type, {}, enum_names());
                check_statements(expr->lambda_function->body, local, parse_type(expr->lambda_function->return_type, {}, enum_names()), true, 0, false);
            }
            return {TypeKind::Function, {}};
        case ExprKind::Call:
            return check_call(*expr, vars);
        case ExprKind::Try: {
            Type wrapped=check_expr(expr->left,vars);
            if(wrapped.kind!=TypeKind::Option&&wrapped.kind!=TypeKind::Result){error(expr->line,expr->column,"postfix '?' requires Option<T> or Result<T,E>");return {};}
            if(current_return_type_.kind!=wrapped.kind){error(expr->line,expr->column,"postfix '?' requires the enclosing function to return the same Option/Result family");}
            else if(wrapped.kind==TypeKind::Result&&current_return_type_.arguments.size()==2&&wrapped.arguments.size()==2&&!compatible(current_return_type_.arguments[1],wrapped.arguments[1]))error(expr->line,expr->column,"postfix '?' error type does not match the enclosing Result error type");
            return wrapped.arguments.empty()?Type{TypeKind::Any,{},{}}:wrapped.arguments.front();
        }
        case ExprKind::Unary: {
            Type operand = check_expr(expr->left, vars);
            if (expr->op == "move") return operand;
            if (expr->op == "&" || expr->op == "&mut") return {expr->op=="&"?TypeKind::Reference:TypeKind::MutableReference,{}, {operand}};
            if (expr->op == "!") {
                if (!truthy_type(operand)) error(expr->line, expr->column, "Logical negation requires Bool or Int, got " + std::string(type_name(operand)));
                return {TypeKind::Bool, {}};
            }
            if (operand.kind != TypeKind::Int && operand.kind != TypeKind::Any && operand.kind != TypeKind::Invalid)
                error(expr->line, expr->column, "Unary '-' requires Int, got " + std::string(type_name(operand)));
            return {TypeKind::Int, {}};
        }
        case ExprKind::Binary: {
            Type left = check_expr(expr->left, vars);
            if (expr->op == "&&" && expr->left && expr->left->kind == ExprKind::Boolean && expr->left->text == "false") return {TypeKind::Bool, {}};
            if (expr->op == "||" && expr->left && expr->left->kind == ExprKind::Boolean && expr->left->text == "true") return {TypeKind::Bool, {}};
            if (expr->op == "&&" && expr->left && expr->left->kind == ExprKind::Integer && expr->left->text == "0") return {TypeKind::Bool, {}};
            if (expr->op == "||" && expr->left && expr->left->kind == ExprKind::Integer && expr->left->text != "0") return {TypeKind::Bool, {}};
            Type right = check_expr(expr->right, vars);
            if (expr->op == "&&" || expr->op == "||") {
                if (!truthy_type(left) || !truthy_type(right))
                    error(expr->line, expr->column, "Logical operators require Bool or Int operands");
                return {TypeKind::Bool, {}};
            }
            if (expr->op == "==" || expr->op == "!=") {
                if (!compatible(left, right)) error(expr->line, expr->column, "Equality operands have incompatible types: " + std::string(type_name(left)) + " and " + type_name(right));
                return {TypeKind::Bool, {}};
            }
            if (expr->op == "<" || expr->op == "<=" || expr->op == ">" || expr->op == ">=") {
                if (left.kind != TypeKind::Int || right.kind != TypeKind::Int) {
                    if (left.kind != TypeKind::Any && left.kind != TypeKind::Invalid && right.kind != TypeKind::Any && right.kind != TypeKind::Invalid)
                        error(expr->line, expr->column, "Ordering comparisons require Int operands");
                }
                return {TypeKind::Bool, {}};
            }
            if (expr->op == "+" && left.kind == TypeKind::String && right.kind == TypeKind::String)
                return {TypeKind::String, {}};
            if (left.kind != TypeKind::Int || right.kind != TypeKind::Int) {
                if (left.kind != TypeKind::Any && left.kind != TypeKind::Invalid && right.kind != TypeKind::Any && right.kind != TypeKind::Invalid)
                    error(expr->line, expr->column, "Operator '" + expr->op + "' requires two Int operands (or two String operands for '+')");
            }
            return {TypeKind::Int, {}};
        }
        }
        return {};
    }

    Type check_call(const Expr& expr, const Variables& vars) {
        std::vector<Type> actual;
        actual.reserve(expr.elements.size());
        for (const auto& arg : expr.elements) actual.push_back(check_expr(arg, vars));
        const auto separator=expr.callee.find("::");
        if(separator!=std::string::npos){
            const std::string enum_name=expr.callee.substr(0,separator), variant_name=expr.callee.substr(separator+2);
            if(enum_name=="Option"){
                if(variant_name=="None"){if(!actual.empty())error(expr.line,expr.column,"Option::None expects no payload");return {TypeKind::Option,{},{{TypeKind::Any,{},{}}}};}
                if(variant_name=="Some"){if(actual.size()!=1)error(expr.line,expr.column,"Option::Some expects one payload");return {TypeKind::Option,{},{{actual.empty()?Type{TypeKind::Any,{},{}}:actual.front()}}};}
                error(expr.line,expr.column,"Unknown Option variant '"+variant_name+"'");return {};
            }
            if(enum_name=="Result"){
                if(actual.size()!=1)error(expr.line,expr.column,"Result variants expect one payload");
                Type payload=actual.empty()?Type{TypeKind::Any,{},{}}:actual.front();
                if(variant_name=="Ok")return {TypeKind::Result,{}, {payload,Type{TypeKind::Any,{},{}}}};
                if(variant_name=="Err")return {TypeKind::Result,{},{{TypeKind::Any,{},{}},payload}};
                error(expr.line,expr.column,"Unknown Result variant '"+variant_name+"'");return {};
            }
            auto found=enums_.find(enum_name);
            if(found==enums_.end()){error(expr.line,expr.column,"Unknown enum type '"+enum_name+"'");return {};}
            auto variant=std::find_if(found->second->variants.begin(),found->second->variants.end(),[&](const EnumVariantDecl& v){return v.name==variant_name;});
            if(variant==found->second->variants.end()){error(expr.line,expr.column,"Unknown variant '"+variant_name+"' in enum '"+enum_name+"'");return {};}
            if(actual.size()!=variant->payload_types.size())error(expr.line,expr.column,"Enum variant '"+variant_name+"' expects "+std::to_string(variant->payload_types.size())+" payload argument(s)");
            for(std::size_t i=0;i<std::min(actual.size(),variant->payload_types.size());++i){auto expected=parse_type(variant->payload_types[i],{},enum_names());if(!compatible(expected,actual[i]))error(expr.line,expr.column,"Enum payload type mismatch for variant '"+variant_name+"'");}
            return {TypeKind::Enum,enum_name,{}};
        }
        auto arity = [&](std::size_t expected) {
            if (actual.size() != expected)
                error(expr.line, expr.column, expr.callee + "() expects " + std::to_string(expected) + " argument(s), got " + std::to_string(actual.size()));
        };
        auto require = [&](std::size_t index, TypeKind kind, const char* label) {
            if (index < actual.size() && actual[index].kind != kind && actual[index].kind != TypeKind::Any && actual[index].kind != TypeKind::Invalid)
                error(expr.line, expr.column, expr.callee + "() argument " + std::to_string(index + 1) + " must be " + label + ", got " + type_name(actual[index]));
        };
        if (expr.callee == "print") return {TypeKind::Int, {}};
        if (expr.callee == "len" || expr.callee == "length") {
            arity(1);
            if (!actual.empty() && actual[0].kind != TypeKind::Array && actual[0].kind != TypeKind::Object && actual[0].kind != TypeKind::String && actual[0].kind != TypeKind::Any && actual[0].kind != TypeKind::Invalid)
                error(expr.line, expr.column, expr.callee + "() requires Array, Object or String");
            return {TypeKind::Int, {}};
        }
        if (expr.callee == "type") { arity(1); return {TypeKind::String, {}}; }
        if (expr.callee == "keys") { arity(1); require(0, TypeKind::Object, "Object"); return {TypeKind::Array, {}}; }
        if (expr.callee == "has") { arity(2); require(0, TypeKind::Object, "Object"); require(1, TypeKind::String, "String"); return {TypeKind::Bool, {}}; }
        if (expr.callee == "push") { arity(2); require(0, TypeKind::Array, "Array"); return {TypeKind::Int, {}}; }
        if (expr.callee == "pop") { arity(1); require(0, TypeKind::Array, "Array"); return {TypeKind::Any, {}}; }

        auto signature = functions_.find(expr.callee);
        if (signature == functions_.end()) {
            auto callable = vars.find(expr.callee);
            if (callable != vars.end() && callable->second.kind == TypeKind::Function) {
                if (!callable->second.function_name.empty()) {
                    signature = functions_.find(callable->second.function_name);
                    if (signature != functions_.end()) return check_signature_call(expr, actual, signature->second);
                }
                return {TypeKind::Any, {}}; // dynamically typed closure; runtime still validates its arity.
            }
            error(expr.line, expr.column, "Call to undefined function '" + expr.callee + "'");
            return {};
        }
        return check_signature_call(expr, actual, signature->second);
    }

    Type check_signature_call(const Expr& expr, const std::vector<Type>& actual, const Signature& sig) {
        if (actual.size() < sig.required || actual.size() > sig.parameters.size())
            error(expr.line, expr.column, "Function '" + expr.callee + "' expects " + std::to_string(sig.required) + ".." + std::to_string(sig.parameters.size()) + " argument(s), got " + std::to_string(actual.size()));
        std::unordered_map<std::string,Type> substitutions;
        const auto count=std::min(actual.size(),sig.parameters.size());
        for(std::size_t i=0;i<count;++i)if(!unify_generic(sig.parameters[i],actual[i],substitutions))error(expr.line,expr.column,"Generic inference failed for argument "+std::to_string(i+1)+" of '"+expr.callee+"'");
        for(const auto& parameter:sig.generic_parameters){
            auto value=substitutions.find(parameter.name);
            if(value==substitutions.end()){error(expr.line,expr.column,"Cannot infer generic parameter '"+parameter.name+"' for '"+expr.callee+"'");continue;}
            for(const auto& bound:parameter.trait_bounds){
                bool satisfied=false;
                if(bound=="Numeric")satisfied=value->second.kind==TypeKind::Int;
                else if(bound=="Display")satisfied=value->second.kind==TypeKind::Int||value->second.kind==TypeKind::Bool||value->second.kind==TypeKind::String;
                else if(bound=="Equatable")satisfied=value->second.kind!=TypeKind::Invalid&&value->second.kind!=TypeKind::Void;
                else if(bound=="Clone")satisfied=value->second.kind==TypeKind::Int||value->second.kind==TypeKind::Bool||value->second.kind==TypeKind::String;
                if(!satisfied)error(expr.line,expr.column,"Type argument for '"+parameter.name+"' does not satisfy trait bound '"+bound+"'");
            }
        }
        for(std::size_t i=0;i<count;++i){Type expected=substitute_type(sig.parameters[i],substitutions);if(!compatible(expected,actual[i]))error(expr.line,expr.column,"Function '"+expr.callee+"' argument "+std::to_string(i+1)+" expects "+type_name(expected)+", got "+type_name(actual[i]));}
        return substitute_type(sig.result,substitutions);
    }

    void check_statements(const std::vector<Statement>& statements, Variables& vars, Type expected_return,
                          bool in_function, int loop_depth, bool top_level) {
        for (const auto& st : statements) {
            switch (st.kind) {
            case Statement::Kind::Let: {
                Type value = check_expr(st.expression, vars);
                if (vars.contains(st.name)) error(st.line, 1, "Variable '" + st.name + "' is already declared in this scope");
                else vars.emplace(st.name, value);
                break;
            }
            case Statement::Kind::Assign: {
                Type value = check_expr(st.expression, vars);
                if (st.target_index) {
                    Type base = check_expr(st.target_index->left, vars);
                    Type index = check_expr(st.target_index->right, vars);
                    if (base.kind != TypeKind::Array && base.kind != TypeKind::Any && base.kind != TypeKind::Invalid)
                        error(st.line, 1, "Indexed assignment requires an Array");
                    if (index.kind != TypeKind::Int && index.kind != TypeKind::Any && index.kind != TypeKind::Invalid)
                        error(st.line, 1, "Array assignment index must be Int");
                } else if (st.target_member) {
                    Type base = check_expr(st.target_member->left, vars);
                    if (base.kind != TypeKind::Object && base.kind != TypeKind::Any && base.kind != TypeKind::Invalid)
                        error(st.line, 1, "Object property assignment requires an Object");
                } else {
                    auto found = vars.find(st.name);
                    if (found == vars.end()) error(st.line, 1, "Assignment to unknown variable '" + st.name + "'");
                    else if (!compatible(found->second, value)) error(st.line, 1, "Cannot assign " + std::string(type_name(value)) + " to " + type_name(found->second) + " variable '" + st.name + "'");
                }
                break;
            }
            case Statement::Kind::Output:
            case Statement::Kind::Expression:
                (void)check_expr(st.expression, vars);
                break;
            case Statement::Kind::If:
            case Statement::Kind::While: {
                Type condition = check_expr(st.expression, vars);
                if (!truthy_type(condition)) error(st.line, 1, "Control-flow condition must be Bool or Int, got " + std::string(type_name(condition)));
                Variables branch = vars;
                check_statements(st.body, branch, expected_return, in_function,
                    loop_depth + (st.kind == Statement::Kind::While ? 1 : 0), false);
                if (st.kind == Statement::Kind::If) {
                    Variables otherwise = vars;
                    check_statements(st.else_body, otherwise, expected_return, in_function, loop_depth, false);
                }
                break;
            }
            case Statement::Kind::ForEach: {
                Type iterable = check_expr(st.expression, vars);
                if (iterable.kind != TypeKind::Array && iterable.kind != TypeKind::Any && iterable.kind != TypeKind::Invalid)
                    error(st.line, 1, "for-in requires an Array, got " + std::string(type_name(iterable)));
                Variables loop_vars = vars;
                if (loop_vars.contains(st.name)) error(st.line, 1, "Loop variable '" + st.name + "' shadows an existing variable");
                else loop_vars.emplace(st.name, Type{TypeKind::Any, {}});
                check_statements(st.body, loop_vars, expected_return, in_function, loop_depth + 1, false);
                break;
            }
            case Statement::Kind::Match: {
                Type matched=check_expr(st.expression,vars);
                std::vector<std::string> variants; std::string enum_name;
                if(matched.kind==TypeKind::Enum){enum_name=matched.function_name;auto it=enums_.find(enum_name);if(it!=enums_.end())for(const auto& v:it->second->variants)variants.push_back(v.name);}
                else if(matched.kind==TypeKind::Option){enum_name="Option";variants={"Some","None"};}
                else if(matched.kind==TypeKind::Result){enum_name="Result";variants={"Ok","Err"};}
                else if(matched.kind!=TypeKind::Any&&matched.kind!=TypeKind::Invalid)error(st.line,1,"match requires an enum, Option or Result value");
                std::unordered_set<std::string> seen; bool wildcard=false;
                for(const auto& arm:st.match_arms){if(!arm)continue;if(arm->wildcard){if(wildcard)error(arm->line,1,"Duplicate wildcard match arm");wildcard=true;}
                    else {if(!arm->enum_name.empty()&&!enum_name.empty()&&arm->enum_name!=enum_name)error(arm->line,1,"Match arm enum qualifier does not match the scrutinee type");if(!variants.empty()&&std::find(variants.begin(),variants.end(),arm->variant)==variants.end())error(arm->line,1,"Unknown match variant '"+arm->variant+"'");if(!seen.insert(arm->variant).second)error(arm->line,1,"Duplicate match variant '"+arm->variant+"'");}
                    Variables branch=vars;
                    if(!arm->binding.empty()){Type payload{TypeKind::Any,{},{}};if(enum_name=="Option"&&arm->variant=="Some"&&!matched.arguments.empty())payload=matched.arguments[0];else if(enum_name=="Result"&&matched.arguments.size()==2)payload=arm->variant=="Ok"?matched.arguments[0]:matched.arguments[1];else if(auto en=enums_.find(enum_name);en!=enums_.end()){auto var=std::find_if(en->second->variants.begin(),en->second->variants.end(),[&](const auto& x){return x.name==arm->variant;});if(var!=en->second->variants.end()&&!var->payload_types.empty())payload=parse_type(var->payload_types.front(),{},enum_names());}branch[arm->binding]=payload;}
                    check_statements(arm->body,branch,expected_return,in_function,loop_depth,false);
                }
                if(!wildcard&&!variants.empty())for(const auto& variant:variants)if(!seen.contains(variant))error(st.line,1,"Non-exhaustive match: missing variant '"+variant+"'");
                break;
            }
            case Statement::Kind::Return: {
                if (!in_function) error(st.line, 1, "return is only valid inside a function");
                Type actual = st.expression ? check_expr(st.expression, vars) : Type{TypeKind::Void, {}};
                if (expected_return.kind != TypeKind::Any && !compatible(expected_return, actual))
                    error(st.line, 1, "Function return type mismatch: expected " + std::string(type_name(expected_return)) + ", got " + type_name(actual));
                break;
            }
            case Statement::Kind::Break:
            case Statement::Kind::Continue:
                if (loop_depth == 0) error(st.line, 1, st.kind == Statement::Kind::Break ? "break is only valid inside a loop" : "continue is only valid inside a loop");
                break;
            }
        }
        (void)top_level;
    }

    bool definitely_returns(const std::vector<Statement>& statements) const {
        for (const auto& st : statements) {
            if (st.kind == Statement::Kind::Return) return true;
            if (st.kind == Statement::Kind::If && !st.else_body.empty() &&
                definitely_returns(st.body) && definitely_returns(st.else_body)) return true;
        }
        return false;
    }

    void check_function(const FunctionDecl& fn) {
        Variables local;
        for (const auto& [name, sig] : functions_) {
            (void)sig;
            local.emplace(name, Type{TypeKind::Function, name});
        }
        const auto signature = functions_.find(fn.name);
        if (signature == functions_.end()) return;
        for (std::size_t i = 0; i < fn.parameters.size(); ++i) {
            const auto& p = fn.parameters[i];
            if (p.default_value) {
                Type actual = check_expr(p.default_value, local);
                if (!compatible(signature->second.parameters[i], actual))
                    error(p.line, 1, "Default value for parameter '" + p.name + "' expects " + type_name(signature->second.parameters[i]) + ", got " + type_name(actual));
            }
            local.emplace(p.name, signature->second.parameters[i]);
        }
        const auto previous_return=current_return_type_; current_return_type_=signature->second.result;
        check_statements(fn.body, local, signature->second.result, true, 0, false);
        current_return_type_=previous_return;
        if (signature->second.result.kind != TypeKind::Any && signature->second.result.kind != TypeKind::Void &&
            !definitely_returns(fn.body))
            error(fn.line, 1, "Function '" + fn.name + "' may complete without returning " + type_name(signature->second.result));
    }
};
} // namespace

std::vector<Diagnostic> validate_function_contracts(const Application& app) {
    return TypeChecker(app).run();
}
} // namespace docmont
