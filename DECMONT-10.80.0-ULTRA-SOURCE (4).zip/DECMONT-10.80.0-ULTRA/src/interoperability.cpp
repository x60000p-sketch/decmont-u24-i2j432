#include "docmont/interoperability.hpp"

#include <algorithm>
#include <cctype>
#include <cstddef>
#include <filesystem>
#include <fstream>
#include <regex>
#include <set>
#include <sstream>
#include <unordered_set>

namespace docmont::interop {
namespace {

std::string trim(std::string value) {
    const auto first = value.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = value.find_last_not_of(" \t\r\n");
    return value.substr(first, last - first + 1);
}

bool identifier(const std::string& value) {
    if (value.empty() || !(std::isalpha(static_cast<unsigned char>(value[0])) || value[0] == '_')) return false;
    return std::all_of(value.begin() + 1, value.end(), [](unsigned char c) {
        return std::isalnum(c) || c == '_';
    });
}

bool qualified_name(const std::string& value) {
    if (value.empty()) return false;
    std::size_t start = 0;
    while (start < value.size()) {
        const auto end = value.find('.', start);
        const auto segment = value.substr(start, end == std::string::npos ? std::string::npos : end - start);
        if (!identifier(segment)) return false;
        if (end == std::string::npos) return true;
        start = end + 1;
    }
    return false;
}

std::vector<std::string> split(const std::string& value, char separator) {
    std::vector<std::string> items;
    std::stringstream stream(value);
    std::string item;
    while (std::getline(stream, item, separator)) items.push_back(trim(item));
    if (!value.empty() && value.back() == separator) items.emplace_back();
    return items;
}

std::string java_type(const std::string& type) {
    if (type == "i64") return "long";
    if (type == "i32") return "int";
    if (type == "f64") return "double";
    if (type == "bool") return "boolean";
    if (type == "utf8") return "String";
    if (type == "void") return "void";
    return {};
}

std::string jni_type(const std::string& type) {
    if (type == "i64") return "jlong";
    if (type == "i32") return "jint";
    if (type == "f64") return "jdouble";
    if (type == "bool") return "jboolean";
    if (type == "utf8") return "jstring";
    if (type == "void") return "void";
    return {};
}

std::string c_type(const std::string& type) {
    if (type == "i64") return "int64_t";
    if (type == "i32") return "int32_t";
    if (type == "f64") return "double";
    if (type == "bool") return "bool";
    if (type == "utf8") return "const char*";
    if (type == "void") return "void";
    return {};
}

std::string jni_escape(const std::string& value) {
    std::string out;
    for (char c : value) {
        if (c == '.') out += '_';
        else if (c == '_') out += "_1";
        else if (c == ';') out += "_2";
        else if (c == '[') out += "_3";
        else if (std::isalnum(static_cast<unsigned char>(c))) out += c;
        else {
            static constexpr char hex[] = "0123456789abcdef";
            const auto u = static_cast<unsigned char>(c);
            out += "_0";
            out += hex[(u >> 12) & 0xf];
            out += hex[(u >> 8) & 0xf];
            out += hex[(u >> 4) & 0xf];
            out += hex[u & 0xf];
        }
    }
    return out;
}

bool valid_type(const std::string& type) {
    return type == "i64" || type == "i32" || type == "f64" || type == "bool" || type == "utf8" || type == "void";
}

struct JavaFunction {
    std::string name;
    std::string symbol;
    std::vector<std::string> parameters;
    std::string result;
};

Result read_file(const std::string& path, std::string& out) {
    std::ifstream input(path, std::ios::binary);
    if (!input) return {false, "cannot open input file: " + path};
    std::ostringstream buffer;
    buffer << input.rdbuf();
    if (!input.good() && !input.eof()) return {false, "failed reading input file: " + path};
    out = buffer.str();
    return {true, "read " + path};
}

Result write_file(const std::filesystem::path& path, const std::string& contents) {
    std::ofstream output(path, std::ios::binary);
    if (!output) return {false, "cannot create output file: " + path.string()};
    output.write(contents.data(), static_cast<std::streamsize>(contents.size()));
    if (!output) return {false, "failed writing output file: " + path.string()};
    return {true, "wrote " + path.string()};
}

bool allowed_register(const std::string& value) {
    static const std::unordered_set<std::string> regs = {
        "rax", "rcx", "rdx", "rsi", "rdi", "r8", "r9", "r10", "r11"
    };
    return regs.contains(value);
}

bool parse_register_or_imm(const std::string& operand, bool allow_immediate) {
    if (allowed_register(operand)) return true;
    if (!allow_immediate || operand.empty()) return false;
    std::size_t pos = 0;
    if (operand[0] == '-' || operand[0] == '+') pos = 1;
    if (pos == operand.size()) return false;
    return std::all_of(operand.begin() + static_cast<std::ptrdiff_t>(pos), operand.end(), [](unsigned char c) {
        return std::isdigit(c);
    });
}

Result validate_instruction(const std::string& line, std::string& normalized) {
    static const std::unordered_set<std::string> two_reg = {"mov", "add", "sub", "imul", "and", "or", "xor"};
    static const std::unordered_set<std::string> reg_imm = {"mov", "add", "sub", "and", "or", "xor"};
    static const std::unordered_set<std::string> one_reg = {"neg", "not", "inc", "dec"};
    static const std::unordered_set<std::string> shifts = {"shl", "shr", "sar"};

    std::istringstream input(line);
    std::string op;
    input >> op;
    if (op.empty()) return {false, "empty assembly instruction"};
    std::string rest;
    std::getline(input, rest);
    rest = trim(rest);
    if (op == "ret") {
        if (!rest.empty()) return {false, "ret does not accept operands"};
        normalized = "ret";
        return {true, "valid ret"};
    }
    if (one_reg.contains(op)) {
        if (!allowed_register(rest)) return {false, op + " requires one volatile 64-bit register"};
        normalized = op + " " + rest;
        return {true, "valid unary instruction"};
    }
    if (two_reg.contains(op) || reg_imm.contains(op)) {
        const auto comma = rest.find(',');
        if (comma == std::string::npos || rest.find(',', comma + 1) != std::string::npos)
            return {false, op + " requires exactly two operands"};
        const auto left = trim(rest.substr(0, comma));
        const auto right = trim(rest.substr(comma + 1));
        if (!allowed_register(left)) return {false, op + " destination must be a volatile 64-bit register"};
        if (!(allowed_register(right) || (reg_imm.contains(op) && parse_register_or_imm(right, true))))
            return {false, op + " source must be a volatile 64-bit register or signed decimal immediate"};
        if (!allowed_register(right)) {
            try {
                const auto immediate = std::stoll(right);
                if (op != "mov" && (immediate < -2147483648LL || immediate > 2147483647LL))
                    return {false, op + " immediate must fit signed 32-bit encoding"};
            } catch (...) { return {false, "immediate is outside signed 64-bit range"}; }
        }
        if (op == "imul" && !allowed_register(right))
            return {false, "imul immediate form is not part of the restricted DOCMONT assembly subset"};
        normalized = op + " " + left + ", " + right;
        return {true, "valid binary instruction"};
    }
    if (shifts.contains(op)) {
        const auto comma = rest.find(',');
        if (comma == std::string::npos || rest.find(',', comma + 1) != std::string::npos)
            return {false, op + " requires a register and a shift count"};
        const auto reg = trim(rest.substr(0, comma));
        const auto count = trim(rest.substr(comma + 1));
        if (!allowed_register(reg) || !parse_register_or_imm(count, true))
            return {false, op + " requires a volatile register and an immediate count"};
        try {
            const long value = std::stol(count);
            if (value < 0 || value > 63) return {false, "shift count must be in range 0..63"};
        } catch (...) { return {false, "invalid shift count"}; }
        normalized = op + " " + reg + ", " + count;
        return {true, "valid shift instruction"};
    }
    return {false, "instruction is not allowed in the restricted DOCMONT assembly subset: " + op};
}

} // namespace

Result generate_java_artifacts(const std::string& manifest, JavaArtifacts& out) {
    out = {};
    std::istringstream input(manifest);
    std::string line;
    std::size_t line_number = 0;
    bool saw_magic = false, saw_package = false, saw_class = false, saw_library = false;
    std::vector<JavaFunction> functions;
    std::set<std::string> names, symbols;
    const std::regex function_re(R"(^function\s+([A-Za-z_][A-Za-z0-9_]*)\s+symbol=([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)\s*->\s*([A-Za-z_][A-Za-z0-9_]*)$)");

    while (std::getline(input, line)) {
        ++line_number;
        line = trim(line);
        if (line.empty() || line[0] == '#') continue;
        if (!saw_magic) {
            if (line != "DOCMONT_JAVA 1") return {false, "line " + std::to_string(line_number) + ": expected DOCMONT_JAVA 1"};
            saw_magic = true;
            continue;
        }
        if (line.rfind("package ", 0) == 0) {
            if (saw_package) return {false, "duplicate package declaration"};
            out.package_name = trim(line.substr(8));
            if (!qualified_name(out.package_name)) return {false, "invalid Java package name"};
            saw_package = true;
        } else if (line.rfind("class ", 0) == 0) {
            if (saw_class) return {false, "duplicate class declaration"};
            out.class_name = trim(line.substr(6));
            if (!identifier(out.class_name)) return {false, "invalid Java class name"};
            saw_class = true;
        } else if (line.rfind("library ", 0) == 0) {
            if (saw_library) return {false, "duplicate library declaration"};
            out.library_name = trim(line.substr(8));
            if (out.library_name.empty() || !std::all_of(out.library_name.begin(), out.library_name.end(), [](unsigned char c) {
                return std::isalnum(c) || c == '_' || c == '-' || c == '.';
            })) return {false, "library name must contain only letters, digits, dot, underscore or hyphen"};
            saw_library = true;
        } else if (line.rfind("function ", 0) == 0) {
            std::smatch match;
            if (!std::regex_match(line, match, function_re))
                return {false, "line " + std::to_string(line_number) + ": invalid function declaration"};
            JavaFunction fn;
            fn.name = match[1].str();
            fn.symbol = match[2].str();
            fn.result = match[4].str();
            const auto params = trim(match[3].str());
            if (!params.empty()) fn.parameters = split(params, ',');
            if (!names.insert(fn.name).second) return {false, "duplicate Java method: " + fn.name};
            if (!symbols.insert(fn.symbol).second) return {false, "duplicate native symbol: " + fn.symbol};
            if (!valid_type(fn.result)) return {false, "unsupported return type in " + fn.name};
            for (const auto& type : fn.parameters) {
                if (!valid_type(type) || type == "void") return {false, "unsupported parameter type in " + fn.name + ": " + type};
            }
            functions.push_back(std::move(fn));
        } else {
            return {false, "line " + std::to_string(line_number) + ": unrecognized manifest directive"};
        }
    }
    if (!saw_magic || !saw_package || !saw_class || !saw_library)
        return {false, "manifest requires DOCMONT_JAVA 1, package, class and library declarations"};
    if (functions.empty()) return {false, "manifest must declare at least one function"};

    std::ostringstream java;
    java << "package " << out.package_name << ";\n\n";
    java << "/** Generated by DOCMONT 8.60.0. Do not edit by hand. */\n";
    java << "public final class " << out.class_name << " {\n";
    java << "    static { System.loadLibrary(\"" << out.library_name << "\"); }\n";
    java << "    private " << out.class_name << "() {}\n\n";
    for (const auto& fn : functions) {
        java << "    public static native " << java_type(fn.result) << " " << fn.name << "(";
        for (std::size_t i = 0; i < fn.parameters.size(); ++i) {
            if (i) java << ", ";
            java << java_type(fn.parameters[i]) << " p" << i;
        }
        java << ");\n";
    }
    java << "}\n";
    out.java_source = java.str();

    std::ostringstream header;
    header << "// Generated by DOCMONT 8.60.0. C ABI contract for JNI bridge.\n#pragma once\n#include <cstdint>\n\nextern \"C\" {\n";
    for (const auto& fn : functions) {
        header << c_type(fn.result) << " " << fn.symbol << "(";
        if (fn.parameters.empty()) header << "void";
        for (std::size_t i = 0; i < fn.parameters.size(); ++i) {
            if (i) header << ", ";
            header << c_type(fn.parameters[i]) << " a" << i;
        }
        header << ");\n";
    }
    header << "}\n";
    out.abi_header = header.str();

    const auto jni_class = jni_escape(out.package_name + "." + out.class_name);
    std::ostringstream glue;
    glue << "// Generated by DOCMONT 8.60.0. Requires a JDK JNI include path.\n"
         << "#include <jni.h>\n#include <cstdint>\n#include <string>\n#include \"" << out.class_name << "_abi.h\"\n\n"
         << "static std::string docmont_jni_utf8(JNIEnv* env, jstring value) {\n"
         << "    if (value == nullptr) return {};\n"
         << "    const char* chars = env->GetStringUTFChars(value, nullptr);\n"
         << "    if (chars == nullptr) return {};\n"
         << "    std::string result(chars);\n"
         << "    env->ReleaseStringUTFChars(value, chars);\n"
         << "    return result;\n}\n\n";
    for (const auto& fn : functions) {
        glue << "extern \"C\" JNIEXPORT " << jni_type(fn.result) << " JNICALL Java_" << jni_class << "_" << jni_escape(fn.name)
             << "(JNIEnv* env, jclass clazz";
        for (std::size_t i = 0; i < fn.parameters.size(); ++i) glue << ", " << jni_type(fn.parameters[i]) << " p" << i;
        glue << ") {\n    (void)clazz;\n";
        std::vector<std::string> args;
        for (std::size_t i = 0; i < fn.parameters.size(); ++i) {
            const auto& type = fn.parameters[i];
            if (type == "utf8") {
                glue << "    const std::string s" << i << " = docmont_jni_utf8(env, p" << i << ");\n";
                args.push_back("(p" + std::to_string(i) + " == nullptr ? nullptr : s" + std::to_string(i) + ".c_str())");
            } else if (type == "bool") args.push_back("(p" + std::to_string(i) + " == JNI_TRUE)");
            else args.push_back("static_cast<" + c_type(type) + ">(p" + std::to_string(i) + ")");
        }
        std::string invocation = fn.symbol + "(";
        for (std::size_t i = 0; i < args.size(); ++i) { if (i) invocation += ", "; invocation += args[i]; }
        invocation += ")";
        if (fn.result == "void") {
            glue << "    " << invocation << ";\n}\n\n";
        } else if (fn.result == "utf8") {
            glue << "    const char* result = " << invocation << ";\n"
                 << "    return result == nullptr ? nullptr : env->NewStringUTF(result);\n}\n\n";
        } else if (fn.result == "bool") {
            glue << "    return " << invocation << " ? JNI_TRUE : JNI_FALSE;\n}\n\n";
        } else {
            glue << "    return static_cast<" << jni_type(fn.result) << ">(" << invocation << ");\n}\n\n";
        }
    }
    out.jni_source = glue.str();
    return {true, "generated Java wrapper and JNI/C ABI bridge for " + std::to_string(functions.size()) + " functions"};
}

Result parse_assembly(const std::string& source, AssemblyModule& out) {
    out = {};
    std::istringstream input(source);
    std::string line;
    std::size_t line_number = 0;
    bool saw_magic = false, saw_target = false;
    AssemblyFunction* current = nullptr;
    std::set<std::string> function_names;
    const std::regex signature(R"(^function\s+([A-Za-z_][A-Za-z0-9_]*)\s*\(([^)]*)\)\s*->\s*([A-Za-z_][A-Za-z0-9_]*)$)");
    while (std::getline(input, line)) {
        ++line_number;
        line = trim(line);
        if (line.empty() || line[0] == '#' || line.rfind(";", 0) == 0) continue;
        if (!saw_magic) {
            if (line != "DOCMONT_ASM 1") return {false, "line " + std::to_string(line_number) + ": expected DOCMONT_ASM 1"};
            saw_magic = true;
            continue;
        }
        if (current == nullptr && line.rfind("target ", 0) == 0) {
            if (saw_target) return {false, "duplicate target declaration"};
            out.target = trim(line.substr(7));
            if (out.target != "x86_64-sysv") return {false, "8.60.0 assembly backend supports only x86_64-sysv"};
            saw_target = true;
            continue;
        }
        if (current == nullptr) {
            std::smatch match;
            if (!std::regex_match(line, match, signature))
                return {false, "line " + std::to_string(line_number) + ": expected function name(i64, ...) -> i64"};
            AssemblyFunction fn;
            fn.name = match[1].str();
            fn.return_type = match[3].str();
            if (!identifier(fn.name) || !function_names.insert(fn.name).second) return {false, "invalid or duplicate assembly function name: " + fn.name};
            if (fn.return_type != "i64") return {false, "assembly return type must be i64 in 8.60.0"};
            const auto params = trim(match[2].str());
            if (!params.empty()) fn.parameter_types = split(params, ',');
            if (fn.parameter_types.size() > 6) return {false, "x86_64 System V subset supports at most six integer arguments"};
            for (const auto& param : fn.parameter_types) if (param != "i64") return {false, "assembly parameters must be i64 in 8.60.0"};
            out.functions.push_back(std::move(fn));
            current = &out.functions.back();
            continue;
        }
        if (line == "end") {
            if (current->instructions.empty() || current->instructions.back() != "ret")
                return {false, "function '" + current->name + "' must end with ret"};
            current = nullptr;
            continue;
        }
        std::string normalized;
        auto checked = validate_instruction(line, normalized);
        if (!checked.ok) return {false, "line " + std::to_string(line_number) + ": " + checked.message};
        if (!current->instructions.empty() && current->instructions.back() == "ret")
            return {false, "line " + std::to_string(line_number) + ": ret must be the final instruction"};
        current->instructions.push_back(std::move(normalized));
    }
    if (!saw_magic || !saw_target || out.functions.empty()) return {false, "assembly module requires header, target and at least one function"};
    if (current != nullptr) return {false, "unterminated function: " + current->name};
    return {true, "validated " + std::to_string(out.functions.size()) + " x86_64 System V leaf functions"};
}

Result emit_gas_x86_64(const AssemblyModule& module, std::string& output) {
    if (module.target != "x86_64-sysv" || module.functions.empty()) return {false, "invalid or empty x86_64-sysv assembly module"};
    std::ostringstream out;
    out << ".intel_syntax noprefix\n.text\n";
    for (const auto& fn : module.functions) {
        if (!identifier(fn.name) || fn.return_type != "i64" || fn.instructions.empty() || fn.instructions.back() != "ret")
            return {false, "assembly module contains an invalid function"};
        out << ".globl " << fn.name << "\n.type " << fn.name << ", @function\n" << fn.name << ":\n";
        for (const auto& instruction : fn.instructions) out << "    " << instruction << "\n";
        out << ".size " << fn.name << ", .-" << fn.name << "\n\n";
    }
    out << ".section .note.GNU-stack,\"\",@progbits\n";
    output = out.str();
    return {true, "emitted GNU assembler source for " + std::to_string(module.functions.size()) + " functions"};
}

Result generate_java_bindings_file(const std::string& manifest_path, const std::string& output_directory) {
    std::string manifest;
    auto read = read_file(manifest_path, manifest);
    if (!read.ok) return read;
    JavaArtifacts artifacts;
    auto generated = generate_java_artifacts(manifest, artifacts);
    if (!generated.ok) return generated;
    std::error_code ec;
    const std::filesystem::path dir(output_directory);
    std::filesystem::create_directories(dir, ec);
    if (ec) return {false, "cannot create output directory: " + ec.message()};
    auto a = write_file(dir / (artifacts.class_name + ".java"), artifacts.java_source);
    if (!a.ok) return a;
    auto b = write_file(dir / (artifacts.class_name + "_abi.h"), artifacts.abi_header);
    if (!b.ok) return b;
    auto c = write_file(dir / (artifacts.class_name + "_jni.cpp"), artifacts.jni_source);
    if (!c.ok) return c;
    return {true, generated.message + " in " + dir.string()};
}

Result emit_assembly_file(const std::string& source_path, const std::string& output_path) {
    std::string source;
    auto read = read_file(source_path, source);
    if (!read.ok) return read;
    AssemblyModule module;
    auto parsed = parse_assembly(source, module);
    if (!parsed.ok) return parsed;
    std::string output;
    auto emitted = emit_gas_x86_64(module, output);
    if (!emitted.ok) return emitted;
    auto written = write_file(output_path, output);
    if (!written.ok) return written;
    return {true, emitted.message + " to " + output_path};
}

Result check_assembly_file(const std::string& source_path) {
    std::string source;
    auto read = read_file(source_path, source);
    if (!read.ok) return read;
    AssemblyModule module;
    return parse_assembly(source, module);
}

} // namespace docmont::interop
