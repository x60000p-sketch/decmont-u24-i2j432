#include "docmont/native_object.hpp"
#include <cstdlib>
#include <fstream>
#include <iterator>
#include <sstream>

namespace docmont {
namespace {
std::string shell_quote(const std::string& value){std::string out="'";for(char c:value){if(c=='\'')out+="'\\''";else out+=c;}out+="'";return out;}
}

NativeObjectResult emit_llvm_ir(const ProgramIR& ir,const std::filesystem::path& output,const std::string& clang,const std::string& target){
    if(target!="x86_64-unknown-linux-gnu")return {false,"8.60.0 Clang/LLVM IR adapter currently supports x86_64-unknown-linux-gnu only",{}};
    if(clang.empty())return {false,"Clang executable path is empty",{}};
    auto generated=emit_c_source(ir);if(!generated.ok)return {false,"cannot lower source to native C: "+generated.message,{}};
    std::error_code ec;auto parent=output.parent_path();if(!parent.empty())std::filesystem::create_directories(parent,ec);if(ec)return {false,"cannot create LLVM IR output directory: "+ec.message(),{}};
    const auto c_path=output.string()+".docmont-tmp.c";const auto log_path=output.string()+".docmont-tmp.log";
    {std::ofstream c(c_path,std::ios::binary|std::ios::trunc);if(!c)return {false,"cannot create temporary C translation unit",{}};c<<generated.source;if(!c)return {false,"failed writing temporary C translation unit",{}};}
    const std::string command=shell_quote(clang)+" -target "+shell_quote(target)+" -std=c11 -O2 -S -emit-llvm "+shell_quote(c_path)+" -o "+shell_quote(output.string())+" > "+shell_quote(log_path)+" 2>&1";
    const int status=std::system(command.c_str());std::ifstream log(log_path,std::ios::binary);std::string compiler_output((std::istreambuf_iterator<char>(log)),{});
    std::filesystem::remove(c_path,ec);std::filesystem::remove(log_path,ec);
    if(status!=0){std::filesystem::remove(output,ec);return {false,"Clang failed to emit LLVM IR (exit status "+std::to_string(status)+")",compiler_output};}
    if(!std::filesystem::exists(output)||std::filesystem::file_size(output,ec)==0||ec){std::filesystem::remove(output,ec);return {false,"Clang reported success but no LLVM IR file was produced",compiler_output};}
    return {true,"emitted LLVM IR via Clang from DOCMONT's restricted C lowering",compiler_output};
}

NativeObjectResult compile_native_object(const ProgramIR& ir,const std::filesystem::path& output,const std::string& clang,const std::string& target){
    if(target!="x86_64-unknown-linux-gnu")return {false,"8.60.0 Clang object adapter currently supports x86_64-unknown-linux-gnu only",{}};
    if(clang.empty())return {false,"Clang executable path is empty",{}};
    auto generated=emit_c_source(ir);if(!generated.ok)return {false,"cannot lower source to native C: "+generated.message,{}};
    std::error_code ec;auto parent=output.parent_path();if(!parent.empty())std::filesystem::create_directories(parent,ec);if(ec)return {false,"cannot create object output directory: "+ec.message(),{}};
    const auto c_path=output.string()+".docmont-tmp.c";const auto log_path=output.string()+".docmont-tmp.log";
    {std::ofstream c(c_path,std::ios::binary|std::ios::trunc);if(!c)return {false,"cannot create temporary C translation unit",{}};c<<generated.source;if(!c)return {false,"failed writing temporary C translation unit",{}};}
    const std::string command=shell_quote(clang)+" -target "+shell_quote(target)+" -std=c11 -O2 -fPIC -c "+shell_quote(c_path)+" -o "+shell_quote(output.string())+" > "+shell_quote(log_path)+" 2>&1";
    const int status=std::system(command.c_str());std::ifstream log(log_path,std::ios::binary);std::string compiler_output((std::istreambuf_iterator<char>(log)),{});
    std::filesystem::remove(c_path,ec);std::filesystem::remove(log_path,ec);
    if(status!=0){std::filesystem::remove(output,ec);return {false,"Clang failed to emit native object (exit status "+std::to_string(status)+")",compiler_output};}
    if(!std::filesystem::exists(output)||std::filesystem::file_size(output,ec)==0||ec){std::filesystem::remove(output,ec);return {false,"Clang reported success but no object file was produced",compiler_output};}
    return {true,"emitted x86-64 ELF relocatable object through Clang/LLVM code generation",compiler_output};
}
} // namespace docmont
