#include "docmont/gles_runtime.hpp"
#include <algorithm>
#include <cstring>
#include <dlfcn.h>
#include <limits>
#include <memory>
#include <sstream>
#include <string_view>

namespace docmont::gpu {
namespace {
using EGLDisplay=void*; using EGLConfig=void*; using EGLContext=void*; using EGLSurface=void*;
using EGLint=int; using EGLBoolean=unsigned int; using EGLenum=unsigned int;
using GLchar=char; using GLenum=unsigned int; using GLuint=unsigned int; using GLint=int;
using GLsizei=int; using GLbitfield=unsigned int; using GLfloat=float; using GLubyte=unsigned char;
constexpr EGLint EGL_NONE=0x3038, EGL_SURFACE_TYPE=0x3033, EGL_PBUFFER_BIT=0x0001;
constexpr EGLint EGL_RENDERABLE_TYPE=0x3040, EGL_OPENGL_ES3_BIT=0x0040;
constexpr EGLint EGL_RED_SIZE=0x3024, EGL_GREEN_SIZE=0x3023, EGL_BLUE_SIZE=0x3022, EGL_ALPHA_SIZE=0x3021;
constexpr EGLint EGL_WIDTH=0x3057, EGL_HEIGHT=0x3056, EGL_CONTEXT_CLIENT_VERSION=0x3098;
constexpr EGLenum EGL_OPENGL_ES_API=0x30A0, EGL_PLATFORM_SURFACELESS_MESA=0x31DD;
constexpr GLenum GL_VERSION=0x1F02, GL_VENDOR=0x1F00, GL_RENDERER=0x1F01;
constexpr GLenum GL_VERTEX_SHADER=0x8B31, GL_FRAGMENT_SHADER=0x8B30, GL_COMPUTE_SHADER=0x91B9;
constexpr GLenum GL_COMPILE_STATUS=0x8B81, GL_LINK_STATUS=0x8B82, GL_INFO_LOG_LENGTH=0x8B84;
constexpr GLenum GL_COLOR_BUFFER_BIT=0x00004000, GL_TRIANGLES=0x0004, GL_RGBA=0x1908, GL_UNSIGNED_BYTE=0x1401;
constexpr GLenum GL_SHADER_STORAGE_BUFFER=0x90D2, GL_DYNAMIC_COPY=0x88EA;
constexpr GLbitfield GL_SHADER_STORAGE_BARRIER_BIT=0x00002000, GL_BUFFER_UPDATE_BARRIER_BIT=0x00000200;
constexpr GLbitfield GL_MAP_READ_BIT=0x0001;

struct EGLApi {
    void* lib{};
    EGLDisplay (*getDisplay)(void*){};
    EGLBoolean (*initialize)(EGLDisplay,EGLint*,EGLint*){};
    EGLBoolean (*bindAPI)(EGLenum){};
    EGLBoolean (*chooseConfig)(EGLDisplay,const EGLint*,EGLConfig*,EGLint,EGLint*){};
    EGLSurface (*createPbufferSurface)(EGLDisplay,EGLConfig,const EGLint*){};
    EGLContext (*createContext)(EGLDisplay,EGLConfig,EGLContext,const EGLint*){};
    EGLBoolean (*makeCurrent)(EGLDisplay,EGLSurface,EGLSurface,EGLContext){};
    EGLBoolean (*destroyContext)(EGLDisplay,EGLContext){};
    EGLBoolean (*destroySurface)(EGLDisplay,EGLSurface){};
    EGLBoolean (*terminate)(EGLDisplay){};
    EGLint (*getError)(){};
    void* (*getProcAddress)(const char*){};
    EGLDisplay (*getPlatformDisplay)(EGLenum,void*,const EGLint*){};
    template<class T> T load(const char* name) { return reinterpret_cast<T>(dlsym(lib,name)); }
    template<class T> T gl(const char* name) const {
        auto p=getProcAddress?getProcAddress(name):nullptr;
        if(!p) { void* g=dlopen("libGLESv2.so.2",RTLD_NOW|RTLD_LOCAL); if(g)p=dlsym(g,name); }
        return reinterpret_cast<T>(p);
    }
};

class Context {
public:
    EGLApi e; EGLDisplay display{}; EGLSurface surface{}; EGLContext context{};
    std::string error;
    Context(std::uint32_t width,std::uint32_t height) {
        e.lib=dlopen("libEGL.so.1",RTLD_NOW|RTLD_LOCAL);
        if(!e.lib){error="libEGL.so.1 is unavailable";return;}
        e.getDisplay=e.load<decltype(e.getDisplay)>("eglGetDisplay");
        e.initialize=e.load<decltype(e.initialize)>("eglInitialize");
        e.bindAPI=e.load<decltype(e.bindAPI)>("eglBindAPI");
        e.chooseConfig=e.load<decltype(e.chooseConfig)>("eglChooseConfig");
        e.createPbufferSurface=e.load<decltype(e.createPbufferSurface)>("eglCreatePbufferSurface");
        e.createContext=e.load<decltype(e.createContext)>("eglCreateContext");
        e.makeCurrent=e.load<decltype(e.makeCurrent)>("eglMakeCurrent");
        e.destroyContext=e.load<decltype(e.destroyContext)>("eglDestroyContext");
        e.destroySurface=e.load<decltype(e.destroySurface)>("eglDestroySurface");
        e.terminate=e.load<decltype(e.terminate)>("eglTerminate");
        e.getError=e.load<decltype(e.getError)>("eglGetError");
        e.getProcAddress=e.load<decltype(e.getProcAddress)>("eglGetProcAddress");
        if(!e.getDisplay||!e.initialize||!e.bindAPI||!e.chooseConfig||!e.createPbufferSurface||!e.createContext||!e.makeCurrent){error="EGL entry points are incomplete";return;}
        auto platform=reinterpret_cast<EGLDisplay(*)(EGLenum,void*,const EGLint*)>(e.getProcAddress("eglGetPlatformDisplayEXT"));
        if(platform) display=platform(EGL_PLATFORM_SURFACELESS_MESA,nullptr,nullptr);
        if(!display) display=e.getDisplay(nullptr);
        EGLint major=0,minor=0;
        if(!display||!e.initialize(display,&major,&minor)){fail("eglInitialize failed");return;}
        if(!e.bindAPI(EGL_OPENGL_ES_API)){fail("eglBindAPI(OpenGL ES) failed");return;}
        const EGLint cfg[]={EGL_SURFACE_TYPE,EGL_PBUFFER_BIT,EGL_RENDERABLE_TYPE,EGL_OPENGL_ES3_BIT,
                            EGL_RED_SIZE,8,EGL_GREEN_SIZE,8,EGL_BLUE_SIZE,8,EGL_ALPHA_SIZE,8,EGL_NONE};
        EGLConfig config{}; EGLint count=0;
        if(!e.chooseConfig(display,cfg,&config,1,&count)||count<1){fail("no EGL OpenGL ES 3 pbuffer config");return;}
        const EGLint pbuf[]={EGL_WIDTH,static_cast<EGLint>(width),EGL_HEIGHT,static_cast<EGLint>(height),EGL_NONE};
        surface=e.createPbufferSurface(display,config,pbuf);
        const EGLint ctx[]={EGL_CONTEXT_CLIENT_VERSION,3,EGL_NONE};
        context=e.createContext(display,config,nullptr,ctx);
        if(!surface||!context||!e.makeCurrent(display,surface,surface,context)){fail("EGL pbuffer/context initialization failed");return;}
    }
    bool ok()const{return display&&surface&&context&&error.empty();}
    void fail(const char* why){std::ostringstream s;s<<why;if(e.getError)s<<" (EGL error 0x"<<std::hex<<e.getError()<<")";error=s.str();}
    ~Context(){if(e.lib){if(display&&context&&e.destroyContext)e.destroyContext(display,context);if(display&&surface&&e.destroySurface)e.destroySurface(display,surface);if(display&&e.terminate)e.terminate(display);dlclose(e.lib);}}
};

template<class T> bool required(T p,const char* name,std::string& err){if(p)return true;err=std::string("missing GLES entry point: ")+name;return false;}
std::string gl_string(const Context& c,GLenum what){auto f=c.e.gl<const GLubyte*(*)(GLenum)>("glGetString");if(!f)return {};auto p=f(what);return p?reinterpret_cast<const char*>(p):"";}
GLuint compile_shader(const Context& c,GLenum kind,const char* source,std::string& error){
    auto create=c.e.gl<GLuint(*)(GLenum)>("glCreateShader");auto src=c.e.gl<void(*)(GLuint,GLsizei,const GLchar*const*,const GLint*)>("glShaderSource");
    auto comp=c.e.gl<void(*)(GLuint)>("glCompileShader");auto get=c.e.gl<void(*)(GLuint,GLenum,GLint*)>("glGetShaderiv");auto log=c.e.gl<void(*)(GLuint,GLsizei,GLsizei*,GLchar*)>("glGetShaderInfoLog");
    if(!create||!src||!comp||!get||!log){error="shader compiler functions unavailable";return 0;}
    GLuint shader=create(kind);src(shader,1,&source,nullptr);comp(shader);GLint status=0;get(shader,GL_COMPILE_STATUS,&status);
    if(!status){GLint len=0;get(shader,GL_INFO_LOG_LENGTH,&len);std::string text(static_cast<std::size_t>(std::max(1,len)),0);log(shader,static_cast<GLsizei>(text.size()),nullptr,text.data());error="shader compilation failed: "+text;return 0;}return shader;
}
GLuint link_program(const Context& c,const std::vector<GLuint>& shaders,std::string& error){
    auto create=c.e.gl<GLuint(*)()>("glCreateProgram");auto attach=c.e.gl<void(*)(GLuint,GLuint)>("glAttachShader");auto link=c.e.gl<void(*)(GLuint)>("glLinkProgram");
    auto get=c.e.gl<void(*)(GLuint,GLenum,GLint*)>("glGetProgramiv");auto log=c.e.gl<void(*)(GLuint,GLsizei,GLsizei*,GLchar*)>("glGetProgramInfoLog");
    if(!create||!attach||!link||!get||!log){error="program linker functions unavailable";return 0;}GLuint p=create();for(auto s:shaders)attach(p,s);link(p);GLint status=0;get(p,GL_LINK_STATUS,&status);
    if(!status){GLint len=0;get(p,GL_INFO_LOG_LENGTH,&len);std::string text(static_cast<std::size_t>(std::max(1,len)),0);log(p,static_cast<GLsizei>(text.size()),nullptr,text.data());error="program link failed: "+text;return 0;}return p;
}
}

GlesDeviceInfo probe_gles(){GlesDeviceInfo out;Context ctx(8,8);if(!ctx.ok()){out.detail=ctx.error;return out;}out.available=true;out.vendor=gl_string(ctx,GL_VENDOR);out.renderer=gl_string(ctx,GL_RENDERER);out.version=gl_string(ctx,GL_VERSION);out.hardware_accelerated=out.renderer.find("llvmpipe")==std::string::npos&&out.renderer.find("softpipe")==std::string::npos&&out.renderer.find("Software") == std::string::npos;out.compute_supported=out.version.find("OpenGL ES 3.1")!=std::string::npos||out.version.find("OpenGL ES 3.2")!=std::string::npos;out.detail=out.hardware_accelerated?"OpenGL ES context initialized on a hardware renderer":"OpenGL ES context initialized on a software renderer; GPU features execute through Mesa software rasterization";return out;}

GlesFrame render_triangle_offscreen(std::uint32_t width,std::uint32_t height){GlesFrame out;out.width=width;out.height=height;if(!width||!height||width>4096||height>4096){out.error="frame dimensions must be within 1..4096";return out;}Context ctx(width,height);if(!ctx.ok()){out.error=ctx.error;return out;}out.renderer=gl_string(ctx,GL_RENDERER);
    const char* vs="#version 300 es\nvoid main(){vec2 p[3]=vec2[3](vec2(-1.0,-1.0),vec2(1.0,-1.0),vec2(0.0,1.0));gl_Position=vec4(p[gl_VertexID],0.0,1.0);}";
    const char* fs="#version 300 es\nprecision highp float;out vec4 color;void main(){color=vec4(0.9,0.15,0.05,1.0);} ";std::string error;
    auto v=compile_shader(ctx,GL_VERTEX_SHADER,vs,error);if(!v){out.error=error;return out;}auto f=compile_shader(ctx,GL_FRAGMENT_SHADER,fs,error);if(!f){out.error=error;return out;}auto p=link_program(ctx,{v,f},error);if(!p){out.error=error;return out;}
    auto use=ctx.e.gl<void(*)(GLuint)>("glUseProgram");auto vp=ctx.e.gl<void(*)(GLint,GLint,GLsizei,GLsizei)>("glViewport");auto clearc=ctx.e.gl<void(*)(GLfloat,GLfloat,GLfloat,GLfloat)>("glClearColor");auto clear=ctx.e.gl<void(*)(GLbitfield)>("glClear");auto draw=ctx.e.gl<void(*)(GLenum,GLint,GLsizei)>("glDrawArrays");auto read=ctx.e.gl<void(*)(GLint,GLint,GLsizei,GLsizei,GLenum,GLenum,void*)>("glReadPixels");auto finish=ctx.e.gl<void(*)()>("glFinish");
    if(!use||!vp||!clearc||!clear||!draw||!read||!finish){out.error="required GLES draw entry points unavailable";return out;}use(p);vp(0,0,static_cast<GLsizei>(width),static_cast<GLsizei>(height));clearc(0,0,0,1);clear(GL_COLOR_BUFFER_BIT);draw(GL_TRIANGLES,0,3);finish();
    if(static_cast<std::size_t>(width)*height>std::numeric_limits<std::size_t>::max()/4){out.error="frame buffer size overflow";return out;}out.rgba.resize(static_cast<std::size_t>(width)*height*4);read(0,0,static_cast<GLsizei>(width),static_cast<GLsizei>(height),GL_RGBA,GL_UNSIGNED_BYTE,out.rgba.data());
    const auto center=(static_cast<std::size_t>(height/2)*width+width/2)*4;out.ok=out.rgba[center]>150&&out.rgba[center+1]<100&&out.rgba[center+3]>200;if(!out.ok)out.error="offscreen render completed but center pixel did not match the expected triangle color";return out;}

GpuTensorResult compute_matmul(const std::vector<float>& a,std::uint32_t m,std::uint32_t k,const std::vector<float>& b,std::uint32_t n,bool relu){GpuTensorResult out;out.renderer="";if(!m||!n||!k||m>4096||n>4096||k>4096||a.size()!=static_cast<std::size_t>(m)*k||b.size()!=static_cast<std::size_t>(k)*n){out.error="invalid MatMul tensor shape or size";return out;}Context ctx(std::max<std::uint32_t>(8,n),std::max<std::uint32_t>(8,m));if(!ctx.ok()){out.error=ctx.error;return out;}out.renderer=gl_string(ctx,GL_RENDERER);const auto ver=gl_string(ctx,GL_VERSION);if(ver.find("OpenGL ES 3.1")==std::string::npos&&ver.find("OpenGL ES 3.2")==std::string::npos){out.error="OpenGL ES 3.1 compute shaders are not supported by this context";return out;}
    const char* cs=relu?R"GLSL(#version 310 es
layout(local_size_x=8,local_size_y=8) in;
layout(std430,binding=0) readonly buffer A { float av[]; };
layout(std430,binding=1) readonly buffer B { float bv[]; };
layout(std430,binding=2) writeonly buffer C { float cv[]; };
uniform uint M; uniform uint N; uniform uint K;
void main(){uint r=gl_GlobalInvocationID.y,c=gl_GlobalInvocationID.x;if(r>=M||c>=N)return;float s=0.0;for(uint i=0u;i<K;++i)s+=av[r*K+i]*bv[i*N+c];cv[r*N+c]=max(s,0.0);}
)GLSL":R"GLSL(#version 310 es
layout(local_size_x=8,local_size_y=8) in;
layout(std430,binding=0) readonly buffer A { float av[]; };
layout(std430,binding=1) readonly buffer B { float bv[]; };
layout(std430,binding=2) writeonly buffer C { float cv[]; };
uniform uint M; uniform uint N; uniform uint K;
void main(){uint r=gl_GlobalInvocationID.y,c=gl_GlobalInvocationID.x;if(r>=M||c>=N)return;float s=0.0;for(uint i=0u;i<K;++i)s+=av[r*K+i]*bv[i*N+c];cv[r*N+c]=s;}
)GLSL";
    std::string error;auto shader=compile_shader(ctx,GL_COMPUTE_SHADER,cs,error);if(!shader){out.error=error;return out;}auto program=link_program(ctx,{shader},error);if(!program){out.error=error;return out;}
    auto gen=ctx.e.gl<void(*)(GLsizei,GLuint*)>("glGenBuffers");auto bind=ctx.e.gl<void(*)(GLenum,GLuint)>("glBindBuffer");auto data=ctx.e.gl<void(*)(GLenum,std::ptrdiff_t,const void*,GLenum)>("glBufferData");auto bindbase=ctx.e.gl<void(*)(GLenum,GLuint,GLuint)>("glBindBufferBase");auto loc=ctx.e.gl<GLint(*)(GLuint,const GLchar*)>("glGetUniformLocation");auto u1=ctx.e.gl<void(*)(GLint,GLuint)>("glUniform1ui");auto dispatch=ctx.e.gl<void(*)(GLuint,GLuint,GLuint)>("glDispatchCompute");auto barrier=ctx.e.gl<void(*)(GLbitfield)>("glMemoryBarrier");auto map=ctx.e.gl<void*(*)(GLenum,std::ptrdiff_t,std::ptrdiff_t,GLbitfield)>("glMapBufferRange");auto unmap=ctx.e.gl<unsigned char(*)(GLenum)>("glUnmapBuffer");auto finish=ctx.e.gl<void(*)()>("glFinish");auto use=ctx.e.gl<void(*)(GLuint)>("glUseProgram");auto del=ctx.e.gl<void(*)(GLsizei,const GLuint*)>("glDeleteBuffers");
    if(!gen||!bind||!data||!bindbase||!loc||!u1||!dispatch||!barrier||!map||!unmap||!finish||!use||!del){out.error="required GLES 3.1 compute entry points unavailable";return out;}
    GLuint buffers[3]{};gen(3,buffers);const std::size_t bytesA=a.size()*sizeof(float),bytesB=b.size()*sizeof(float),bytesC=static_cast<std::size_t>(m)*n*sizeof(float);
    bind(GL_SHADER_STORAGE_BUFFER,buffers[0]);data(GL_SHADER_STORAGE_BUFFER,static_cast<std::ptrdiff_t>(bytesA),a.data(),GL_DYNAMIC_COPY);bindbase(GL_SHADER_STORAGE_BUFFER,0,buffers[0]);
    bind(GL_SHADER_STORAGE_BUFFER,buffers[1]);data(GL_SHADER_STORAGE_BUFFER,static_cast<std::ptrdiff_t>(bytesB),b.data(),GL_DYNAMIC_COPY);bindbase(GL_SHADER_STORAGE_BUFFER,1,buffers[1]);
    bind(GL_SHADER_STORAGE_BUFFER,buffers[2]);data(GL_SHADER_STORAGE_BUFFER,static_cast<std::ptrdiff_t>(bytesC),nullptr,GL_DYNAMIC_COPY);bindbase(GL_SHADER_STORAGE_BUFFER,2,buffers[2]);
    use(program);u1(loc(program,"M"),m);u1(loc(program,"N"),n);u1(loc(program,"K"),k);dispatch((n+7)/8,(m+7)/8,1);barrier(GL_SHADER_STORAGE_BARRIER_BIT|GL_BUFFER_UPDATE_BARRIER_BIT);finish();bind(GL_SHADER_STORAGE_BUFFER,buffers[2]);void* mapped=map(GL_SHADER_STORAGE_BUFFER,0,static_cast<std::ptrdiff_t>(bytesC),GL_MAP_READ_BIT);
    if(!mapped){out.error="could not map compute result buffer";del(3,buffers);return out;}out.values.resize(static_cast<std::size_t>(m)*n);std::memcpy(out.values.data(),mapped,bytesC);unmap(GL_SHADER_STORAGE_BUFFER);del(3,buffers);out.ok=true;return out;}

namespace {
GpuTensorResult dispatch_vector_kernel(const std::vector<float>& a,const std::vector<float>* b,
                                       std::uint32_t rows,std::uint32_t columns,
                                       const char* shader_source,bool row_kernel) {
    GpuTensorResult out;
    const std::uint64_t count=static_cast<std::uint64_t>(rows)*columns;
    if(!rows||!columns||count>16u*1024u*1024u||a.size()!=count||(b&&b->size()!=count)){
        out.error="invalid tensor dimensions or element count";return out;
    }
    Context ctx(std::max<std::uint32_t>(8,std::min<std::uint32_t>(columns,4096)),
                std::max<std::uint32_t>(8,std::min<std::uint32_t>(rows,4096)));
    if(!ctx.ok()){out.error=ctx.error;return out;}
    out.renderer=gl_string(ctx,GL_RENDERER);
    const auto version=gl_string(ctx,GL_VERSION);
    if(version.find("OpenGL ES 3.1")==std::string::npos&&version.find("OpenGL ES 3.2")==std::string::npos){
        out.error="OpenGL ES 3.1 compute shaders are unavailable";return out;
    }
    std::string error;const auto shader=compile_shader(ctx,GL_COMPUTE_SHADER,shader_source,error);
    if(!shader){out.error=error;return out;}
    const auto program=link_program(ctx,{shader},error);if(!program){out.error=error;return out;}
    auto gen=ctx.e.gl<void(*)(GLsizei,GLuint*)>("glGenBuffers");
    auto bind=ctx.e.gl<void(*)(GLenum,GLuint)>("glBindBuffer");
    auto data=ctx.e.gl<void(*)(GLenum,std::ptrdiff_t,const void*,GLenum)>("glBufferData");
    auto bindbase=ctx.e.gl<void(*)(GLenum,GLuint,GLuint)>("glBindBufferBase");
    auto loc=ctx.e.gl<GLint(*)(GLuint,const GLchar*)>("glGetUniformLocation");
    auto u1=ctx.e.gl<void(*)(GLint,GLuint)>("glUniform1ui");
    auto dispatch=ctx.e.gl<void(*)(GLuint,GLuint,GLuint)>("glDispatchCompute");
    auto barrier=ctx.e.gl<void(*)(GLbitfield)>("glMemoryBarrier");
    auto map=ctx.e.gl<void*(*)(GLenum,std::ptrdiff_t,std::ptrdiff_t,GLbitfield)>("glMapBufferRange");
    auto unmap=ctx.e.gl<unsigned char(*)(GLenum)>("glUnmapBuffer");
    auto finish=ctx.e.gl<void(*)()>("glFinish");auto use=ctx.e.gl<void(*)(GLuint)>("glUseProgram");
    auto del=ctx.e.gl<void(*)(GLsizei,const GLuint*)>("glDeleteBuffers");
    if(!gen||!bind||!data||!bindbase||!loc||!u1||!dispatch||!barrier||!map||!unmap||!finish||!use||!del){
        out.error="required GLES compute/buffer entry points unavailable";return out;
    }
    GLuint buffers[3]{};gen(3,buffers);const auto bytes=static_cast<std::ptrdiff_t>(count*sizeof(float));
    bind(GL_SHADER_STORAGE_BUFFER,buffers[0]);data(GL_SHADER_STORAGE_BUFFER,bytes,a.data(),GL_DYNAMIC_COPY);bindbase(GL_SHADER_STORAGE_BUFFER,0,buffers[0]);
    if(b){bind(GL_SHADER_STORAGE_BUFFER,buffers[1]);data(GL_SHADER_STORAGE_BUFFER,bytes,b->data(),GL_DYNAMIC_COPY);bindbase(GL_SHADER_STORAGE_BUFFER,1,buffers[1]);}
    bind(GL_SHADER_STORAGE_BUFFER,buffers[2]);data(GL_SHADER_STORAGE_BUFFER,bytes,nullptr,GL_DYNAMIC_COPY);bindbase(GL_SHADER_STORAGE_BUFFER,2,buffers[2]);
    use(program);u1(loc(program,"ROWS"),rows);u1(loc(program,"COLS"),columns);
    dispatch(row_kernel?rows:(static_cast<GLuint>((count+127)/128)),1,1);
    barrier(GL_SHADER_STORAGE_BARRIER_BIT|GL_BUFFER_UPDATE_BARRIER_BIT);finish();bind(GL_SHADER_STORAGE_BUFFER,buffers[2]);
    void* mapped=map(GL_SHADER_STORAGE_BUFFER,0,bytes,GL_MAP_READ_BIT);
    if(!mapped){out.error="could not map compute output buffer";del(3,buffers);return out;}
    out.values.resize(static_cast<std::size_t>(count));std::memcpy(out.values.data(),mapped,static_cast<std::size_t>(bytes));
    const auto unmapped=unmap(GL_SHADER_STORAGE_BUFFER);del(3,buffers);
    if(!unmapped){out.values.clear();out.error="compute output buffer became invalid while unmapping";return out;}
    out.ok=true;return out;
}
}

GpuTensorResult compute_binary(const std::vector<float>& a,const std::vector<float>& b,TensorBinaryOp op){
    const char* expression=nullptr;
    switch(op){case TensorBinaryOp::Add:expression="av[i]+bv[i]";break;case TensorBinaryOp::Subtract:expression="av[i]-bv[i]";break;
        case TensorBinaryOp::Multiply:expression="av[i]*bv[i]";break;case TensorBinaryOp::Divide:expression="av[i]/bv[i]";break;
        case TensorBinaryOp::Maximum:expression="max(av[i],bv[i])";break;case TensorBinaryOp::Minimum:expression="min(av[i],bv[i])";break;}
    if(a.empty()||a.size()!=b.size()||a.size()>16u*1024u*1024u)return {false,{},"","binary tensor inputs must have equal nonzero bounded sizes"};
    const std::string shader=std::string(R"GLSL(#version 310 es
layout(local_size_x=128) in;
layout(std430,binding=0) readonly buffer A{float av[];};
layout(std430,binding=1) readonly buffer B{float bv[];};
layout(std430,binding=2) writeonly buffer C{float cv[];};
uniform uint ROWS;uniform uint COLS;
void main(){uint i=gl_GlobalInvocationID.x;uint n=ROWS*COLS;if(i<n)cv[i]=)GLSL")+expression+";}";
    return dispatch_vector_kernel(a,&b,1,static_cast<std::uint32_t>(a.size()),shader.c_str(),false);
}

GpuTensorResult compute_softmax(const std::vector<float>& input,std::uint32_t rows,std::uint32_t columns){
    const char* shader=R"GLSL(#version 310 es
layout(local_size_x=1) in;
layout(std430,binding=0) readonly buffer A{float av[];};
layout(std430,binding=2) writeonly buffer C{float cv[];};
uniform uint ROWS;uniform uint COLS;
void main(){uint r=gl_GlobalInvocationID.x;if(r>=ROWS)return;uint base=r*COLS;float mx=-3.402823e38;for(uint i=0u;i<COLS;++i)mx=max(mx,av[base+i]);float sum=0.0;for(uint i=0u;i<COLS;++i)sum+=exp(av[base+i]-mx);for(uint i=0u;i<COLS;++i)cv[base+i]=exp(av[base+i]-mx)/sum;}
)GLSL";
    return dispatch_vector_kernel(input,nullptr,rows,columns,shader,true);
}

} // namespace docmont::gpu
