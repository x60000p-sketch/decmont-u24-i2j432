#include "gpu_backend_internal.hpp"
namespace docmont::gpu {
BackendStatus probe_metal_native(){BackendStatus s;s.backend=Backend::Metal;s.availability=Availability::UnsupportedPlatform;s.detail="Metal device probing is available only in an Apple build with the Metal SDK";return s;}
}
