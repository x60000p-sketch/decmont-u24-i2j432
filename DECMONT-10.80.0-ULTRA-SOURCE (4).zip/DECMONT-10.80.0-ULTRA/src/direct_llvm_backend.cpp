#include "docmont/direct_llvm_backend.hpp"
#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <iterator>
#include <sstream>
#include <system_error>

namespace docmont::core {
namespace {
std::string shell_quote(const std::string& value) {
    std::string out="'";
    for(char c:value) { if(c=='\'') out+="'\\''"; else out+=c; }
    out+='\''; return out;
}
bool supported_target(const std::string& target) {
    return target=="x86_64-unknown-linux-gnu" || target=="aarch64-unknown-linux-gnu" ||
           target=="wasm32-unknown-unknown" || target=="riscv64-unknown-elf";
}
}

DirectLLVMResult emit_direct_llvm_ir(const MIRModule& mir,const TypedHIRModule& hir,
                                     const TypeContext& types,const std::string& target) {
    if(!supported_target(target)) return {false,"unsupported direct LLVM target triple: "+target,{},{}};
    const auto hir_errors=verify_typed_hir(hir,types);
    if(!hir_errors.empty()) return {false,"Typed HIR verification failed: "+hir_errors.front().code+": "+hir_errors.front().message,{},{}};
    const auto mir_errors=verify_mir(mir,types);
    if(!mir_errors.empty()) return {false,"MIR verification failed: "+mir_errors.front().code+": "+mir_errors.front().message,{},{}};
    const auto fn=std::find_if(mir.functions.begin(),mir.functions.end(),[](const MIRFunction& f){return f.name=="main";});
    if(fn==mir.functions.end()) return {false,"direct LLVM backend requires a main function",{},{}};
    if(!fn->native_integer_supported) return {false,"main is outside the direct LLVM integer MIR subset (supported: let, return, i64 literal/local, unary -, +, -, *); use DVM or the restricted C backend",{},{}};
    const auto hfn=std::find_if(hir.functions.begin(),hir.functions.end(),[](const HIRFunction& f){return f.name=="main";});
    if(hfn==hir.functions.end()) return {false,"typed HIR has no main function",{},{}};
    if(hfn->has_return_value) {
        const auto* result_type=types.get(hfn->return_type);
        if(!result_type || (result_type->kind!=TypeKind::I32 && result_type->kind!=TypeKind::I64))
            return {false,"direct LLVM main return type must be Int/i32/i64",{},{}};
    }
    std::ostringstream out;
    out<<"; DOCMONT 8.70.0 direct MIR-to-LLVM lowering\n"
       <<"target triple = \""<<target<<"\"\n\n"
       <<"define i32 @main() {\nentry:\n";
    bool emitted_return=false;
    std::string return_value;
    for(const auto& op:fn->native_integer_ops) {
        switch(op.kind) {
        case MIRValueOpKind::ConstantI64:
            out<<"  "<<op.result<<" = add i64 0, "<<op.immediate<<"\n"; break;
        case MIRValueOpKind::AddI64:
            out<<"  "<<op.result<<" = add i64 "<<op.lhs<<", "<<op.rhs<<"\n"; break;
        case MIRValueOpKind::SubI64:
            out<<"  "<<op.result<<" = sub i64 "<<op.lhs<<", "<<op.rhs<<"\n"; break;
        case MIRValueOpKind::MulI64:
            out<<"  "<<op.result<<" = mul i64 "<<op.lhs<<", "<<op.rhs<<"\n"; break;
        case MIRValueOpKind::ReturnI64:
            out<<"  %docmont.return = trunc i64 "<<op.lhs<<" to i32\n"
               <<"  ret i32 %docmont.return\n";
            emitted_return=true; break;
        }
    }
    if(!emitted_return) return {false,"verified native MIR has no return operation",{},{}};
    out<<"}\n";
    return {true,"directly emitted LLVM IR from verified Typed HIR/MIR",out.str(),{}};
}

DirectLLVMResult compile_direct_llvm_object(const MIRModule& mir,const TypedHIRModule& hir,
                                             const TypeContext& types,const std::filesystem::path& output,
                                             const std::string& target,const std::string& clang) {
    auto generated=emit_direct_llvm_ir(mir,hir,types,target);
    if(!generated.ok) return generated;
    if(clang.empty()) return {false,"Clang executable path is empty",{}, {}};
    std::error_code ec;
    if(!output.parent_path().empty()) std::filesystem::create_directories(output.parent_path(),ec);
    if(ec) return {false,"cannot create output directory: "+ec.message(),{}, {}};
    const auto ir_path=output.string()+".docmont-direct.ll";
    const auto log_path=output.string()+".docmont-direct.log";
    { std::ofstream file(ir_path,std::ios::binary|std::ios::trunc); if(!file)return {false,"cannot create temporary LLVM IR file",{}, {}}; file<<generated.ir; if(!file)return {false,"failed writing temporary LLVM IR file",{}, {}}; }
    const std::string command=shell_quote(clang)+" -target "+shell_quote(target)+" -x ir -O2 -c "+shell_quote(ir_path)+" -o "+shell_quote(output.string())+" > "+shell_quote(log_path)+" 2>&1";
    const int status=std::system(command.c_str());
    std::ifstream log(log_path,std::ios::binary); std::string compiler_output((std::istreambuf_iterator<char>(log)),{});
    std::filesystem::remove(ir_path,ec); std::filesystem::remove(log_path,ec);
    if(status!=0) { std::filesystem::remove(output,ec); return {false,"Clang failed to compile direct LLVM MIR object",{},compiler_output}; }
    if(!std::filesystem::exists(output)||std::filesystem::file_size(output,ec)==0||ec) { std::filesystem::remove(output,ec); return {false,"Clang reported success but no object was created",{},compiler_output}; }
    generated.message="compiled direct MIR-to-LLVM object for "+target;
    generated.compiler_output=std::move(compiler_output);
    return generated;
}
} // namespace docmont::core
