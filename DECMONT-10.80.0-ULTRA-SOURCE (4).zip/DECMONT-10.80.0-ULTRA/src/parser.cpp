#include "docmont/parser.hpp"
#include <utility>
namespace docmont {
Parser::Parser(std::vector<Token> t):tokens_(std::move(t)){}
const Token& Parser::current() const { return tokens_[pos_]; }
Token Parser::advance(){ Token t=current(); if(current().kind!=TokenKind::End) ++pos_; return t; }
bool Parser::accept(TokenKind k){ if(current().kind==k){advance();return true;} return false; }
bool Parser::expect(TokenKind k,const std::string& m,std::vector<Diagnostic>& d){ if(accept(k))return true; d.push_back({Severity::Error,current().line,current().column,m}); return false; }
void Parser::skip_newlines(){ while(accept(TokenKind::Newline)){} }
std::string Parser::scalar(std::vector<Diagnostic>& d){ if(current().kind==TokenKind::String||current().kind==TokenKind::Identifier||current().kind==TokenKind::Number)return advance().text; d.push_back({Severity::Error,current().line,current().column,"Expected a string, identifier or number"}); return {}; }
std::string Parser::parse_type_name(std::vector<Diagnostic>& d) {
    std::string prefix;
    if (accept(TokenKind::Ampersand)) {
        prefix = "&";
        if (current().kind == TokenKind::Identifier && current().text == "mut") { prefix += "mut "; advance(); }
    }
    if (current().kind != TokenKind::Identifier) {
        d.push_back({Severity::Error,current().line,current().column,"Expected type name"});
        return prefix + "Any";
    }
    std::string name = advance().text;
    if (accept(TokenKind::Less)) {
        name += "<";
        bool first = true;
        while (current().kind != TokenKind::Greater && current().kind != TokenKind::End) {
            if (!first) name += ",";
            name += parse_type_name(d);
            first = false;
            if (!accept(TokenKind::Comma)) break;
        }
        if (!expect(TokenKind::Greater,"Expected '>' after generic type arguments",d)) return prefix + name;
        name += ">";
    }
    return prefix + name;
}

EnumDecl Parser::parse_enum(std::vector<Diagnostic>& d) {
    EnumDecl result; const Token start = advance(); result.line = start.line;
    if (current().kind == TokenKind::Identifier) result.name = advance().text;
    else d.push_back({Severity::Error,current().line,current().column,"Expected enum name"});
    if (!expect(TokenKind::LBrace,"Expected '{' after enum name",d)) return result;
    skip_newlines();
    while (current().kind != TokenKind::RBrace && current().kind != TokenKind::End) {
        if (current().kind != TokenKind::Identifier) {
            d.push_back({Severity::Error,current().line,current().column,"Expected enum variant name"});
            advance(); skip_newlines(); continue;
        }
        EnumVariantDecl variant; const auto token = advance(); variant.name = token.text; variant.line = token.line;
        if (accept(TokenKind::LParen)) {
            if (current().kind != TokenKind::RParen) {
                do { variant.payload_types.push_back(parse_type_name(d)); } while (accept(TokenKind::Comma));
            }
            expect(TokenKind::RParen,"Expected ')' after enum variant payload types",d);
        }
        result.variants.push_back(std::move(variant));
        if (!accept(TokenKind::Comma)) skip_newlines(); else skip_newlines();
    }
    expect(TokenKind::RBrace,"Unclosed enum declaration",d);
    if (result.variants.empty()) d.push_back({Severity::Error,start.line,start.column,"Enum must declare at least one variant"});
    return result;
}

Statement Parser::parse_match(std::vector<Diagnostic>& d, const Token& start) {
    Statement st; st.kind = Statement::Kind::Match; st.line = start.line;
    st.expression = expression(d);
    if (!expect(TokenKind::LBrace,"Expected '{' after match value",d)) return st;
    skip_newlines();
    while (current().kind != TokenKind::RBrace && current().kind != TokenKind::End) {
        auto arm = std::make_shared<MatchArm>(); arm->line = current().line;
        if (current().kind != TokenKind::Identifier) {
            d.push_back({Severity::Error,current().line,current().column,"Expected enum variant or '_' in match arm"});
            advance(); skip_newlines(); continue;
        }
        const Token first = advance();
        if (first.text == "_") arm->wildcard = true;
        else {
            arm->enum_name = first.text;
            if (accept(TokenKind::DoubleColon)) {
                if (current().kind != TokenKind::Identifier) d.push_back({Severity::Error,current().line,current().column,"Expected variant name after '::'"});
                else arm->variant = advance().text;
            } else {
                arm->variant = first.text;
                arm->enum_name.clear();
            }
            if (accept(TokenKind::LParen)) {
                if (current().kind == TokenKind::Identifier) arm->binding = advance().text;
                else d.push_back({Severity::Error,current().line,current().column,"Expected payload binding name"});
                expect(TokenKind::RParen,"Expected ')' after match payload binding",d);
            }
        }
        expect(TokenKind::Arrow,"Expected '=>' after match pattern",d);
        skip_newlines(); arm->body = parse_statement_block(d);
        st.match_arms.push_back(std::move(arm));
        if (accept(TokenKind::Comma)) skip_newlines(); else skip_newlines();
    }
    expect(TokenKind::RBrace,"Unclosed match expression",d);
    if (st.match_arms.empty()) d.push_back({Severity::Error,start.line,start.column,"Match must contain at least one arm"});
    return st;
}

std::shared_ptr<Expr> Parser::primary(std::vector<Diagnostic>& d){
 Token t=current(); auto e=std::make_shared<Expr>(); e->line=t.line;e->column=t.column;
 if(accept(TokenKind::Number)){e->kind=ExprKind::Integer;e->text=t.text;return e;}
 if(accept(TokenKind::String)){e->kind=ExprKind::String;e->text=t.text;return e;}
 if(accept(TokenKind::Identifier)){
   if (t.text == "fn") {
     auto fn = std::make_shared<FunctionDecl>(); fn->line=t.line;
     expect(TokenKind::LParen,"Expected '(' after fn in lambda",d);
     if(current().kind!=TokenKind::RParen) {
       do { Parameter p; Token n=current();
         if(!expect(TokenKind::Identifier,"Expected lambda parameter name",d)) break;
         p.name=n.text; p.line=n.line;
         expect(TokenKind::Colon,"Expected ':' after lambda parameter",d);
         if(current().kind==TokenKind::Identifier) p.type=advance().text;
         else d.push_back({Severity::Error,current().line,current().column,"Expected lambda parameter type"});
         if(accept(TokenKind::Equal)) p.default_value=expression(d);
         if(!p.default_value) for(const auto& prior:fn->parameters) if(prior.default_value)
           d.push_back({Severity::Error,n.line,n.column,"Required lambda parameter cannot follow a default parameter"});
         fn->parameters.push_back(std::move(p));
       } while(accept(TokenKind::Comma));
     }
     expect(TokenKind::RParen,"Expected ')' after lambda parameters",d);
     if(accept(TokenKind::Colon)){ if(current().kind==TokenKind::Identifier) fn->return_type=advance().text; else d.push_back({Severity::Error,current().line,current().column,"Expected lambda return type"}); }
     skip_newlines(); fn->body=parse_statement_block(d);
     e->kind=ExprKind::Lambda; e->lambda_function=std::move(fn); return e;
   }
   if (t.text == "object" && accept(TokenKind::LBrace)) {
     e->kind=ExprKind::ObjectLiteral; skip_newlines();
     while(current().kind!=TokenKind::RBrace && current().kind!=TokenKind::End) {
       Token key=current(); if(!expect(TokenKind::Identifier,"Expected object property name",d)) break;
       expect(TokenKind::Equal,"Expected '=' after object property",d);
       e->properties.emplace_back(key.text, expression(d));
       if(!accept(TokenKind::Comma)) skip_newlines(); else skip_newlines();
     }
     expect(TokenKind::RBrace,"Unclosed object literal",d); return e;
   }
   if (t.text == "true" || t.text == "false") { e->kind=ExprKind::Boolean; e->text=t.text; return e; }
   e->kind=ExprKind::Identifier;e->text=t.text;
   std::string qualified = t.text;
   if (accept(TokenKind::DoubleColon)) {
     if (current().kind != TokenKind::Identifier) d.push_back({Severity::Error,current().line,current().column,"Expected variant or associated item after '::'"});
     else qualified += "::" + advance().text;
     e->kind=ExprKind::Call; e->callee=qualified;
     if (accept(TokenKind::LParen)) {
       if(current().kind!=TokenKind::RParen) { do { e->elements.push_back(expression(d)); } while(accept(TokenKind::Comma)); }
       expect(TokenKind::RParen,"Expected ')' after enum variant arguments",d);
     }
   } else if (accept(TokenKind::LParen)) { e->kind=ExprKind::Call; e->callee=t.text;
     if(current().kind!=TokenKind::RParen) { do { e->elements.push_back(expression(d)); } while(accept(TokenKind::Comma)); }
     expect(TokenKind::RParen,"Expected ')' after function arguments",d);
   }
   return e;
 }
 if(accept(TokenKind::LBracket)){ e->kind=ExprKind::ArrayLiteral;
   if(current().kind!=TokenKind::RBracket){ do { e->elements.push_back(expression(d)); } while(accept(TokenKind::Comma)); }
   expect(TokenKind::RBracket,"Expected ']' after array literal",d); return e;
 }
 if(accept(TokenKind::LParen)){e=expression(d);expect(TokenKind::RParen,"Expected ')' after expression",d);return e;}
 d.push_back({Severity::Error,t.line,t.column,"Expected expression (integer, string, identifier or parenthesized expression)"}); if(t.kind!=TokenKind::End)advance(); return e;
}
std::shared_ptr<Expr> Parser::unary(std::vector<Diagnostic>& d){
 if(current().kind==TokenKind::Bang || current().kind==TokenKind::Minus || current().kind==TokenKind::Ampersand || (current().kind==TokenKind::Identifier && current().text=="move")){
  Token op=advance(); auto n=std::make_shared<Expr>(); n->kind=ExprKind::Unary;
  n->op=op.kind==TokenKind::Ampersand?"&":op.text;
  if (op.kind==TokenKind::Ampersand && current().kind==TokenKind::Identifier && current().text=="mut") { advance(); n->op="&mut"; }
  n->left=unary(d); n->line=op.line; n->column=op.column; return n;
 }
 return primary(d);
}
std::shared_ptr<Expr> Parser::multiplicative(std::vector<Diagnostic>& d){ auto lhs=unary(d); while(current().kind==TokenKind::Star||current().kind==TokenKind::Slash){Token op=advance();auto rhs=unary(d);auto n=std::make_shared<Expr>();n->kind=ExprKind::Binary;n->op=op.text;n->left=lhs;n->right=rhs;n->line=op.line;n->column=op.column;lhs=n;}return lhs; }
std::shared_ptr<Expr> Parser::additive(std::vector<Diagnostic>& d){ auto lhs=multiplicative(d); while(current().kind==TokenKind::Plus||current().kind==TokenKind::Minus){Token op=advance();auto rhs=multiplicative(d);auto n=std::make_shared<Expr>();n->kind=ExprKind::Binary;n->op=op.text;n->left=lhs;n->right=rhs;n->line=op.line;n->column=op.column;lhs=n;}return lhs; }
std::shared_ptr<Expr> Parser::comparison(std::vector<Diagnostic>& d){
 auto lhs=additive(d);
 while(current().kind==TokenKind::Less||current().kind==TokenKind::LessEqual||current().kind==TokenKind::Greater||current().kind==TokenKind::GreaterEqual||current().kind==TokenKind::EqualEqual||current().kind==TokenKind::BangEqual){
  Token op=advance(); auto rhs=additive(d); auto n=std::make_shared<Expr>(); n->kind=ExprKind::Binary; n->op=op.text; n->left=lhs; n->right=rhs; n->line=op.line; n->column=op.column; lhs=n;
 }
 return lhs;
}
std::shared_ptr<Expr> Parser::logical_and(std::vector<Diagnostic>& d){ auto lhs=comparison(d); while(current().kind==TokenKind::AndAnd){Token op=advance();auto rhs=comparison(d);auto n=std::make_shared<Expr>();n->kind=ExprKind::Binary;n->op=op.text;n->left=lhs;n->right=rhs;n->line=op.line;n->column=op.column;lhs=n;}return lhs;}
std::shared_ptr<Expr> Parser::logical_or(std::vector<Diagnostic>& d){ auto lhs=logical_and(d); while(current().kind==TokenKind::OrOr){Token op=advance();auto rhs=logical_and(d);auto n=std::make_shared<Expr>();n->kind=ExprKind::Binary;n->op=op.text;n->left=lhs;n->right=rhs;n->line=op.line;n->column=op.column;lhs=n;}return lhs;}
std::shared_ptr<Expr> Parser::expression(std::vector<Diagnostic>& d){
 auto lhs=logical_or(d);
 while(true) {
   if(accept(TokenKind::LBracket)) { auto idx=expression(d); expect(TokenKind::RBracket,"Expected ']' after array index",d); auto n=std::make_shared<Expr>(); n->kind=ExprKind::Index; n->left=lhs; n->right=idx; n->line=lhs?lhs->line:current().line; lhs=n; }
   else if(accept(TokenKind::Dot)) { Token key=current(); if(!expect(TokenKind::Identifier,"Expected property name after '.'",d)) break; auto n=std::make_shared<Expr>(); n->kind=ExprKind::Member; n->left=lhs; n->text=key.text; n->line=key.line; lhs=n; }
   else if (accept(TokenKind::Question)) { auto n=std::make_shared<Expr>(); n->kind=ExprKind::Try; n->left=lhs; n->line=lhs?lhs->line:current().line; lhs=n; }
   else break;
 }
 return lhs;
}
void Parser::parse_block(Application& app,const Token& start,std::vector<Diagnostic>& d){
 Block b;b.name=start.text;b.line=start.line;if(!expect(TokenKind::Equal,"Expected '=' after block name",d)||!expect(TokenKind::LBrace,"Expected '{' after block assignment",d))return;skip_newlines();
 while(current().kind!=TokenKind::RBrace&&current().kind!=TokenKind::End){if(current().kind!=TokenKind::Identifier){d.push_back({Severity::Error,current().line,current().column,"Expected property inside block"});advance();skip_newlines();continue;}Token key=advance();expect(TokenKind::Equal,"Expected '=' after property name",d);std::string value=scalar(d);b.properties.push_back({key.text,value,key.line});skip_newlines();}
 expect(TokenKind::RBrace,"Unclosed block",d);app.blocks.push_back(std::move(b));
}
Statement Parser::parse_statement(std::vector<Diagnostic>& d) {
    Statement st;
    const Token key = advance();
    st.line = key.line;
    if (key.text == "match") return parse_match(d, key);
    if (key.text == "let") {
        st.kind = Statement::Kind::Let;
        Token name = current();
        if (!expect(TokenKind::Identifier, "Expected variable name after let", d)) return st;
        st.name = name.text;
        expect(TokenKind::Equal, "Expected '=' after variable name", d);
        st.expression = expression(d);
        return st;
    }
    if (key.text == "return") {
        st.kind = Statement::Kind::Return;
        if (current().kind != TokenKind::Newline && current().kind != TokenKind::RBrace && current().kind != TokenKind::End) st.expression = expression(d);
        return st;
    }
    if (key.text == "output") {
        st.kind = Statement::Kind::Output;
        expect(TokenKind::Equal, "Expected '=' after output", d);
        st.expression = expression(d);
        return st;
    }
    if (key.text == "break") { st.kind=Statement::Kind::Break; return st; }
    if (key.text == "continue") { st.kind=Statement::Kind::Continue; return st; }
    if (key.text == "while") { st.kind=Statement::Kind::While; expect(TokenKind::LParen, "Expected '(' after while", d); st.expression=expression(d); expect(TokenKind::RParen, "Expected ')' after while condition", d); skip_newlines(); st.body=parse_statement_block(d); return st; }
    if (key.text == "for") {
        st.kind = Statement::Kind::ForEach;
        Token variable=current();
        if (!expect(TokenKind::Identifier,"Expected loop variable after for",d)) return st;
        st.name=variable.text;
        if (!(current().kind==TokenKind::Identifier && current().text=="in")) d.push_back({Severity::Error,current().line,current().column,"Expected 'in' after loop variable"});
        else advance();
        st.expression=expression(d);
        skip_newlines(); st.body=parse_statement_block(d);
        return st;
    }
    if (key.text == "if") {
        st.kind = Statement::Kind::If;
        expect(TokenKind::LParen, "Expected '(' after if", d);
        st.expression = expression(d);
        expect(TokenKind::RParen, "Expected ')' after if condition", d);
        skip_newlines();
        st.body = parse_statement_block(d);
        skip_newlines();
        if (current().kind == TokenKind::Identifier && current().text == "else") {
            advance(); skip_newlines();
            st.else_body = parse_statement_block(d);
        }
        return st;
    }
    if (current().kind == TokenKind::Equal) {
        st.kind=Statement::Kind::Assign; st.name=key.text; advance(); st.expression=expression(d); return st;
    }
    if (current().kind == TokenKind::Dot) {
        st.kind = Statement::Kind::Assign;
        auto target = std::make_shared<Expr>();
        target->kind = ExprKind::Identifier; target->text = key.text;
        target->line = key.line; target->column = key.column;
        while (accept(TokenKind::Dot)) {
            Token property = current();
            if (!expect(TokenKind::Identifier, "Expected property name after '.'", d)) break;
            auto member = std::make_shared<Expr>(); member->kind = ExprKind::Member;
            member->left = target; member->text = property.text;
            member->line = property.line; member->column = property.column;
            target = std::move(member);
        }
        st.target_member = std::move(target);
        expect(TokenKind::Equal, "Expected '=' after object property target", d);
        st.expression = expression(d);
        return st;
    }
    if (current().kind == TokenKind::LBracket) {
        st.kind = Statement::Kind::Assign;
        st.name = key.text;
        auto base = std::make_shared<Expr>();
        base->kind = ExprKind::Identifier; base->text = key.text;
        base->line = key.line; base->column = key.column;
        while (accept(TokenKind::LBracket)) {
            auto index = expression(d);
            expect(TokenKind::RBracket, "Expected ']' after assignment index", d);
            auto indexed = std::make_shared<Expr>();
            indexed->kind = ExprKind::Index; indexed->left = base; indexed->right = index;
            indexed->line = key.line; indexed->column = key.column;
            base = std::move(indexed);
        }
        st.target_index = std::move(base);
        expect(TokenKind::Equal, "Expected '=' after indexed target", d);
        st.expression = expression(d);
        return st;
    }
    d.push_back({Severity::Error, key.line, key.column, "Unknown statement: " + key.text});
    return st;
}

std::vector<Statement> Parser::parse_statement_block(std::vector<Diagnostic>& d) {
    std::vector<Statement> body;
    if (!expect(TokenKind::LBrace, "Expected '{' to begin statement block", d)) return body;
    skip_newlines();
    while (current().kind != TokenKind::RBrace && current().kind != TokenKind::End) {
        if (current().kind != TokenKind::Identifier) {
            d.push_back({Severity::Error, current().line, current().column, "Expected statement in block"});
            advance(); skip_newlines(); continue;
        }
        body.push_back(parse_statement(d));
        skip_newlines();
    }
    expect(TokenKind::RBrace, "Unclosed statement block", d);
    return body;
}

FunctionDecl Parser::parse_function(std::vector<Diagnostic>& d) {
    FunctionDecl fn; Token start=advance(); fn.line=start.line;
    if(current().kind==TokenKind::Identifier) fn.name=advance().text;
    else d.push_back({Severity::Error,current().line,current().column,"Expected function name"});
    if (accept(TokenKind::Less)) {
      do {
        GenericTypeParameter parameter; const Token token=current();
        if (!expect(TokenKind::Identifier,"Expected generic type parameter",d)) break;
        parameter.name=token.text; parameter.line=token.line;
        if (accept(TokenKind::Colon)) {
          do {
            if (current().kind != TokenKind::Identifier) { d.push_back({Severity::Error,current().line,current().column,"Expected trait bound name"}); break; }
            parameter.trait_bounds.push_back(advance().text);
          } while (accept(TokenKind::Plus));
        }
        fn.type_parameters.push_back(std::move(parameter));
      } while (accept(TokenKind::Comma));
      expect(TokenKind::Greater,"Expected '>' after generic type parameters",d);
    }
    expect(TokenKind::LParen,"Expected '(' after function name or generic parameters",d);
    if(current().kind!=TokenKind::RParen) {
      do { Parameter p; Token n=current(); if(!expect(TokenKind::Identifier,"Expected parameter name",d)) break; p.name=n.text; p.line=n.line;
        expect(TokenKind::Colon,"Expected ':' after parameter name",d);
        p.type=parse_type_name(d);
        if (accept(TokenKind::Equal)) p.default_value = expression(d);
        if (p.default_value) {
          // Once a default appears, every following parameter must also have one.
          fn.parameters.push_back(std::move(p));
        } else {
          for (const auto& prior : fn.parameters) if (prior.default_value)
            d.push_back({Severity::Error,n.line,n.column,"Required parameter cannot follow a parameter with a default value"});
          fn.parameters.push_back(std::move(p));
        }
      } while(accept(TokenKind::Comma));
    }
    expect(TokenKind::RParen,"Expected ')' after parameters",d);
    if(accept(TokenKind::Colon)) fn.return_type=parse_type_name(d);
    skip_newlines(); fn.body=parse_statement_block(d); return fn;
}

void Parser::parse_property_or_block(Application& app, std::vector<Diagnostic>& d) {
    if (current().text == "enum") { app.enums.push_back(parse_enum(d)); return; }
    if (current().text == "fn") { app.functions.push_back(parse_function(d)); return; }
    if (current().text == "module" || current().text == "import") {
        const Token declaration = advance();
        std::string qualified;
        if (current().kind != TokenKind::Identifier) {
            d.push_back({Severity::Error,current().line,current().column,"Expected module name"});
            return;
        }
        qualified = advance().text;
        while (accept(TokenKind::Dot)) {
            if (current().kind != TokenKind::Identifier) {
                d.push_back({Severity::Error,current().line,current().column,"Expected identifier after '.'"});
                return;
            }
            qualified += "." + advance().text;
        }
        if (declaration.text == "module") {
            if (!app.module_name.empty()) d.push_back({Severity::Error,declaration.line,declaration.column,"Duplicate module declaration"});
            else app.module_name = qualified;
        } else {
            ImportDecl item; item.module = qualified; item.line = declaration.line;
            if (current().kind == TokenKind::Identifier && current().text == "as") {
                advance();
                if (current().kind != TokenKind::Identifier) d.push_back({Severity::Error,current().line,current().column,"Expected import alias after 'as'"});
                else item.alias = advance().text;
            }
            app.imports.push_back(std::move(item));
        }
        return;
    }
    if (current().text == "complete") { advance(); app.complete = true; return; }
    if (current().text == "let" || current().text == "output" || current().text == "if" || current().text == "return" || current().text == "while" || current().text == "for" || current().text == "break" || current().text == "continue" || current().text == "match" || (current().text != "name" && ((tokens_[pos_+1].kind == TokenKind::Equal && tokens_[pos_+2].kind != TokenKind::LBrace) || tokens_[pos_+1].kind == TokenKind::Dot || tokens_[pos_+1].kind == TokenKind::LBracket))) {
        Statement st = parse_statement(d);
        if (st.kind == Statement::Kind::Output && st.expression && st.expression->kind == ExprKind::String)
            app.outputs.push_back(st.expression->text);
        app.statements.push_back(std::move(st));
        return;
    }
    Token key = advance();
    if (key.text == "name") { expect(TokenKind::Equal, "Expected '=' after name", d); app.name = scalar(d); return; }
    if (current().kind == TokenKind::Equal) { parse_block(app, key, d); return; }
    d.push_back({Severity::Error, key.line, key.column, "Unknown application member: " + key.text});
}
ParseResult Parser::parse(){
 ParseResult r;skip_newlines();if(current().kind==TokenKind::Identifier&&current().text=="!docmont"){advance();expect(TokenKind::LBracket,"Expected '[' after !docmont",r.diagnostics);if(current().kind==TokenKind::Number)advance();else r.diagnostics.push_back({Severity::Error,current().line,current().column,"Expected language version"});expect(TokenKind::RBracket,"Expected ']'",r.diagnostics);skip_newlines();}else r.diagnostics.push_back({Severity::Error,current().line,current().column,"Missing !docmont[version] header"});
 if(current().kind==TokenKind::Identifier&&current().text=="select"){advance();if(current().kind==TokenKind::Identifier&&current().text=="architecture")advance();else r.diagnostics.push_back({Severity::Error,current().line,current().column,"Expected architecture after select"});expect(TokenKind::Equal,"Expected '=' after architecture",r.diagnostics);r.app.architecture=scalar(r.diagnostics);skip_newlines();}
 if(current().kind==TokenKind::Identifier&&current().text=="application")advance();else r.diagnostics.push_back({Severity::Error,current().line,current().column,"Expected application declaration"});expect(TokenKind::Equal,"Expected '=' after application",r.diagnostics);expect(TokenKind::LBrace,"Expected '{' to open application",r.diagnostics);skip_newlines();
 while(current().kind!=TokenKind::RBrace&&current().kind!=TokenKind::End){if(current().kind==TokenKind::Identifier)parse_property_or_block(r.app,r.diagnostics);else{r.diagnostics.push_back({Severity::Error,current().line,current().column,"Unexpected token in application"});advance();}skip_newlines();}
 expect(TokenKind::RBrace,"Unclosed application block",r.diagnostics);return r;
}
}
