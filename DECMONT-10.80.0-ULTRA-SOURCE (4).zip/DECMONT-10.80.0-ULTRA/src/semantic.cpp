#include "docmont/semantic.hpp"
#include <algorithm>
#include <cstdint>
#include <limits>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <functional>
namespace docmont {
namespace {
const std::string* find_value(const Block& b,const std::string& k){for(const auto& p:b.properties)if(p.key==k)return &p.value;return nullptr;}
void validate_unique_properties(const Block& b,std::vector<Diagnostic>& d){std::unordered_set<std::string>s;for(const auto&p:b.properties)if(!s.insert(p.key).second)d.push_back({Severity::Error,p.line,1,"Duplicate property '"+p.key+"' in block '"+b.name+"'"});}
void validate_allowed_properties(const Block& b,const std::unordered_set<std::string>& a,std::vector<Diagnostic>&d){for(const auto&p:b.properties)if(!a.contains(p.key))d.push_back({Severity::Error,p.line,1,"Unknown property '"+p.key+"' in block '"+b.name+"'"});}
enum class Type{Integer,String,Object,Boolean,Array,Function,Any,Invalid};
Type check_expr(const std::shared_ptr<Expr>& e,const std::unordered_map<std::string,Type>& vars,std::vector<Diagnostic>& d){
 if(!e)return Type::Invalid;
 if(e->kind==ExprKind::Integer){try{(void)std::stoll(e->text);}catch(...){d.push_back({Severity::Error,e->line,e->column,"Integer literal is outside signed 64-bit range"});return Type::Invalid;}return Type::Integer;}
 if(e->kind==ExprKind::String)return Type::String;
 if(e->kind==ExprKind::Boolean)return Type::Boolean;
 if(e->kind==ExprKind::ArrayLiteral){for(const auto& item:e->elements)check_expr(item,vars,d);return Type::Array;}
 if(e->kind==ExprKind::Call){for(const auto& arg:e->elements)check_expr(arg,vars,d);if(e->callee=="len"||e->callee=="length"||e->callee=="push"||e->callee=="print")return Type::Integer;if(e->callee=="type")return Type::String;if(e->callee=="has")return Type::Boolean;if(e->callee=="keys")return Type::Array;if(e->callee=="pop")return Type::Any;auto it=vars.find(e->callee);return it!=vars.end()&&it->second==Type::Function?Type::Any:Type::Invalid;}
 if(e->kind==ExprKind::Lambda)return Type::Function;
 if(e->kind==ExprKind::ObjectLiteral){ for(const auto& property:e->properties) check_expr(property.second,vars,d); return Type::Object; }
 if(e->kind==ExprKind::Member){ auto base=check_expr(e->left,vars,d); if(base!=Type::Object && base!=Type::Any && base!=Type::Invalid){d.push_back({Severity::Error,e->line,e->column,"Property access requires an object"});return Type::Invalid;} return Type::Any; }
 if(e->kind==ExprKind::Index){auto base=check_expr(e->left,vars,d),index=check_expr(e->right,vars,d);if(base!=Type::Array&&base!=Type::Any&&base!=Type::Invalid)d.push_back({Severity::Error,e->line,e->column,"Indexing requires an array"});if(index!=Type::Integer&&index!=Type::Any&&index!=Type::Invalid)d.push_back({Severity::Error,e->line,e->column,"Array index must be an integer"});return Type::Any;}
 if(e->kind==ExprKind::Identifier){auto it=vars.find(e->text);if(it==vars.end()){d.push_back({Severity::Error,e->line,e->column,"Unknown variable '"+e->text+"'"});return Type::Invalid;}return it->second;}
 if(e->kind==ExprKind::Unary){auto operand=check_expr(e->left,vars,d);if(e->op=="!"){if(operand!=Type::Integer&&operand!=Type::Boolean&&operand!=Type::Any&&operand!=Type::Invalid)d.push_back({Severity::Error,e->line,e->column,"Logical negation requires an integer or boolean operand"});return Type::Boolean;}if(operand!=Type::Integer&&operand!=Type::Any&&operand!=Type::Invalid)d.push_back({Severity::Error,e->line,e->column,"Unary '-' requires an integer operand"});return Type::Integer;}
 auto l=check_expr(e->left,vars,d);
 if(e->op=="&&"&&e->left&&((e->left->kind==ExprKind::Boolean&&e->left->text=="false")||(e->left->kind==ExprKind::Integer&&e->left->text=="0")))return Type::Boolean;
 if(e->op=="||"&&e->left&&((e->left->kind==ExprKind::Boolean&&e->left->text=="true")||(e->left->kind==ExprKind::Integer&&e->left->text!="0")))return Type::Boolean;
 auto r=check_expr(e->right,vars,d);
 if(e->op=="&&"||e->op=="||"){if((l!=Type::Integer&&l!=Type::Boolean&&l!=Type::Any&&l!=Type::Invalid)||(r!=Type::Integer&&r!=Type::Boolean&&r!=Type::Any&&r!=Type::Invalid))d.push_back({Severity::Error,e->line,e->column,"Logical operators require integer or boolean operands"});return Type::Boolean;}
 if(e->op=="=="||e->op=="!="){if(l!=r&&l!=Type::Any&&r!=Type::Any&&l!=Type::Invalid&&r!=Type::Invalid)d.push_back({Severity::Error,e->line,e->column,"Equality operands must have compatible types"});return Type::Boolean;}
 if(e->op=="<"||e->op=="<="||e->op==">"||e->op==">="){if((l!=Type::Integer||r!=Type::Integer)&&l!=Type::Any&&r!=Type::Any&&l!=Type::Invalid&&r!=Type::Invalid)d.push_back({Severity::Error,e->line,e->column,"Ordering comparisons require integer operands"});return Type::Boolean;}
 if(e->op=="+"&&((l==Type::String||l==Type::Any)&&(r==Type::String||r==Type::Any)))return (l==Type::String&&r==Type::String)?Type::String:Type::Any;
 if(l!=Type::Integer||r!=Type::Integer){if(l!=Type::Any&&r!=Type::Any&&l!=Type::Invalid&&r!=Type::Invalid)d.push_back({Severity::Error,e->line,e->column,"Operator '"+e->op+"' requires integer operands (or two strings for '+')"});return (l==Type::Any||r==Type::Any)?Type::Any:Type::Invalid;}return Type::Integer;
}
}
std::vector<Diagnostic> validate(const Application& app){
 std::vector<Diagnostic>d;if(app.name.empty())d.push_back({Severity::Error,1,1,"application.name is required"});
 if(app.architecture!="x86_64"&&app.architecture!="arm64"&&app.architecture!="aarch64"&&app.architecture!="riscv64"&&app.architecture!="wasm32"&&app.architecture!="portable"&&app.architecture!="host")d.push_back({Severity::Error,1,1,"Architecture must be a known target label or 'portable'"});
 if(!app.complete)d.push_back({Severity::Error,1,1,"Missing mandatory complete terminator"});
 std::unordered_set<std::string> blocks;for(const auto&b:app.blocks){if(!blocks.insert(b.name).second)d.push_back({Severity::Error,b.line,1,"Duplicate block '"+b.name+"' in application scope"});validate_unique_properties(b,d);
 if(b.name=="memory"){validate_allowed_properties(b,{"allocation","management","bounds"},d);auto a=find_value(b,"allocation"),m=find_value(b,"management"),bounds=find_value(b,"bounds");if(!a)d.push_back({Severity::Error,b.line,1,"memory.allocation is required"});else if(*a!="automatic"&&*a!="manual")d.push_back({Severity::Error,b.line,1,"memory.allocation must be automatic or manual"});if(!m)d.push_back({Severity::Error,b.line,1,"memory.management is required"});else if(*m!="native"&&*m!="managed")d.push_back({Severity::Error,b.line,1,"memory.management must be native or managed"});if(bounds&&*bounds!="enforced"&&*bounds!="unbounded")d.push_back({Severity::Error,b.line,1,"memory.bounds must be enforced or unbounded"});}
 if(b.name=="compute"){validate_allowed_properties(b,{"algorithm","optimization"},d);auto a=find_value(b,"algorithm"),o=find_value(b,"optimization");if(!a||a->empty())d.push_back({Severity::Warning,b.line,1,"compute.algorithm is not specified"});if(o&&*o!="O0"&&*o!="O1"&&*o!="O2"&&*o!="O3")d.push_back({Severity::Error,b.line,1,"compute.optimization must be O0, O1, O2 or O3"});}}
 std::function<void(const std::vector<Statement>&, std::unordered_map<std::string,Type>&)> check_statements;
 check_statements = [&](const std::vector<Statement>& statements, std::unordered_map<std::string,Type>& vars) {
  for (const auto& statement : statements) {
   Type t = check_expr(statement.expression, vars, d);
   if (statement.kind == Statement::Kind::Let) {
    if (vars.contains(statement.name)) d.push_back({Severity::Error,statement.line,1,"Variable '"+statement.name+"' is already declared"});
    else if (t != Type::Invalid) vars.emplace(statement.name,t);
   } else if (statement.kind == Statement::Kind::If || statement.kind == Statement::Kind::While) {
    if (t != Type::Integer && t != Type::Boolean && t != Type::Any && t != Type::Invalid) d.push_back({Severity::Error,statement.line,1,"control-flow condition must be Bool or Int"});
    auto then_vars = vars; check_statements(statement.body, then_vars);
    auto else_vars = vars; check_statements(statement.else_body, else_vars);
   } else if (statement.kind == Statement::Kind::ForEach) {
    if (t != Type::Array && t != Type::Any && t != Type::Invalid) d.push_back({Severity::Error,statement.line,1,"for-in expression must be an array"});
    auto loop_vars = vars; loop_vars.emplace(statement.name, Type::Any); check_statements(statement.body, loop_vars);
   }
  }
 };
 std::unordered_map<std::string,Type> vars; for (const auto& fn : app.functions) vars.emplace(fn.name, Type::Function); check_statements(app.statements, vars);
 return d;
}
}
