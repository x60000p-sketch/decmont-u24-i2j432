#include "docmont/runtime.hpp"
#include "docmont/heap.hpp"
#include <cstdint>
#include <iostream>
#include <functional>
#include <limits>
#include <memory>
#include <memory_resource>
#include <map>
#include <string>
#include <unordered_map>
#include <variant>
#include <vector>

namespace docmont {
int execute(const ProgramIR& ir) {
    // Runtime containers share one bounded heap. Declaration order is intentional:
    // stack/vars and all array references are destroyed before HeapResource/Heap.
    memory::Heap heap(64U * 1024U * 1024U);
    memory::HeapResource heap_resource(heap);
    struct Value;
    struct CellRef { std::shared_ptr<Value> cell; };
    struct FunctionRef { std::string name; std::shared_ptr<std::unordered_map<std::string, std::shared_ptr<Value>>> captures; };
    using Array = std::pmr::vector<Value>;
    using Object = std::map<std::string, Value, std::less<>>;
    struct Value { std::variant<std::int64_t, std::string, std::shared_ptr<Array>, std::shared_ptr<Object>, FunctionRef, CellRef> data; };
    std::vector<Value> stack;
    struct Frame { std::size_t return_pc{0}; std::size_t stack_base{0}; std::unordered_map<std::string, std::shared_ptr<Value>> locals; };
    std::vector<Frame> frames(1);
    struct FunctionInfo { std::size_t entry; std::size_t arity; };
    std::unordered_map<std::string, FunctionInfo> functions;
    for (std::size_t i=0;i<ir.code.size();++i) if (ir.code[i].op==OpCode::Function) {
        if (ir.code[i].integer < 0 || !functions.emplace(ir.code[i].operand, FunctionInfo{i+1,static_cast<std::size_t>(ir.code[i].integer)}).second)
            return 1;
    }
    auto fail = [](int line, const std::string& message) {
        std::cerr << "runtime error:" << line << ": " << message << '\n';
        return 1;
    };
    std::function<void(const Value&)> print_value = [&](const Value& value) {
        if (const auto* n = std::get_if<std::int64_t>(&value.data)) std::cout << *n;
        else if (const auto* text = std::get_if<std::string>(&value.data)) std::cout << *text;
        else if (const auto* array_ptr = std::get_if<std::shared_ptr<Array>>(&value.data)) {
            const auto& array = **array_ptr;
            std::cout << "[";
            for (std::size_t i = 0; i < array.size(); ++i) { if (i) std::cout << ", "; print_value(array[i]); }
            std::cout << "]";
        } else if (const auto* fn = std::get_if<FunctionRef>(&value.data)) { std::cout << "<function " << fn->name << ">";
        } else if (std::holds_alternative<CellRef>(value.data)) { std::cout << "<internal-cell>";
        } else {
            const auto& object = *std::get<std::shared_ptr<Object>>(value.data);
            std::cout << "{"; bool first = true;
            for (const auto& [key, item] : object) { if (!first) std::cout << ", "; first = false; std::cout << key << ": "; print_value(item); }
            std::cout << "}";
        }
    };

    std::uint64_t executed_steps = 0;
    constexpr std::uint64_t max_steps = 1000000;
    constexpr std::size_t max_operand_stack = 65536;
    for (std::size_t pc = 0; pc < ir.code.size();) {
        if (++executed_steps > max_steps) return fail(0, "DVM instruction limit exceeded");
        if (stack.size() > max_operand_stack) return fail(ir.code[pc].line, "DVM operand stack limit exceeded (65536 values)");
        const auto& instruction = ir.code[pc];
        switch (instruction.op) {
        case OpCode::Dup:
            if (stack.empty()) return fail(instruction.line, "stack underflow during dup");
            stack.push_back(stack.back());
            break;
        case OpCode::PushInt:
            stack.push_back(Value{instruction.integer});
            break;
        case OpCode::PushString:
            stack.push_back(Value{instruction.operand});
            break;
        case OpCode::Load: {
            auto it = frames.back().locals.find(instruction.operand);
            if (it != frames.back().locals.end()) stack.push_back(*it->second);
            else if (frames.size()>1 && frames.front().locals.contains(instruction.operand)) stack.push_back(*frames.front().locals.at(instruction.operand));
            else return fail(instruction.line, "undefined variable '" + instruction.operand + "'");
            break;
        }
        case OpCode::Store: {
            if (stack.empty()) return fail(instruction.line, "stack underflow during store");
            auto& cell = frames.back().locals[instruction.operand];
            if (!cell) cell = std::make_shared<Value>(stack.back());
            else *cell = stack.back();
            stack.pop_back();
            break;
        }
        case OpCode::LoadCell: {
            auto it = frames.back().locals.find(instruction.operand);
            std::shared_ptr<Value> cell;
            if (it != frames.back().locals.end()) cell = it->second;
            else if (frames.size() > 1) {
                auto global = frames.front().locals.find(instruction.operand);
                if (global != frames.front().locals.end()) cell = global->second;
            }
            if (!cell) return fail(instruction.line, "cannot capture undefined variable '" + instruction.operand + "'");
            stack.push_back(Value{CellRef{std::move(cell)}});
            break;
        }
        case OpCode::BoolNot:
            if (stack.empty() || !std::holds_alternative<std::int64_t>(stack.back().data)) return fail(instruction.line, "logical not requires a boolean/integer value");
            stack.back() = Value{std::int64_t(std::get<std::int64_t>(stack.back().data) == 0 ? 1 : 0)};
            break;
        case OpCode::MakeArray: {
            if (instruction.integer < 0 || static_cast<std::uint64_t>(instruction.integer) > stack.size()) return fail(instruction.line, "invalid array element count");
            try {
                auto array = std::allocate_shared<Array>(
                    std::pmr::polymorphic_allocator<Array>(&heap_resource));
                array->resize(static_cast<std::size_t>(instruction.integer));
                for (std::size_t i = array->size(); i > 0; --i) { (*array)[i-1] = std::move(stack.back()); stack.pop_back(); }
                stack.push_back(Value{std::move(array)});
            } catch (const std::bad_alloc&) { return fail(instruction.line, "DOCMONT heap budget exceeded while creating array"); }
            break;
        }
        case OpCode::ArrayGet: {
            if (stack.size() < 2) return fail(instruction.line, "stack underflow during array read");
            auto index = std::move(stack.back()); stack.pop_back(); auto base = std::move(stack.back()); stack.pop_back();
            auto a = std::get_if<std::shared_ptr<Array>>(&base.data); auto n = std::get_if<std::int64_t>(&index.data);
            if (!a || !n) return fail(instruction.line, "array read requires an array and integer index");
            if (*n < 0 || static_cast<std::uint64_t>(*n) >= (*a)->size()) return fail(instruction.line, "array index out of bounds");
            stack.push_back((**a)[static_cast<std::size_t>(*n)]); break;
        }
        case OpCode::ArraySet: {
            if (stack.size() < 3) return fail(instruction.line, "stack underflow during array write");
            auto value = std::move(stack.back()); stack.pop_back(); auto index = std::move(stack.back()); stack.pop_back(); auto base = std::move(stack.back()); stack.pop_back();
            auto a = std::get_if<std::shared_ptr<Array>>(&base.data); auto n = std::get_if<std::int64_t>(&index.data);
            if (!a || !n) return fail(instruction.line, "array write requires an array and integer index");
            if (*n < 0 || static_cast<std::uint64_t>(*n) >= (*a)->size()) return fail(instruction.line, "array index out of bounds");
            (**a)[static_cast<std::size_t>(*n)] = std::move(value); break;
        }
        case OpCode::ArrayLength: {
            if (stack.empty()) return fail(instruction.line, "stack underflow during length");
            std::size_t length = 0;
            if (const auto* array = std::get_if<std::shared_ptr<Array>>(&stack.back().data)) length = (*array)->size();
            else if (const auto* text = std::get_if<std::string>(&stack.back().data)) length = text->size();
            else if (const auto* object = std::get_if<std::shared_ptr<Object>>(&stack.back().data)) length = (*object)->size();
            else return fail(instruction.line, "length requires an array, object or string");
            if (length > static_cast<std::size_t>(std::numeric_limits<std::int64_t>::max())) return fail(instruction.line, "length exceeds integer range");
            stack.back() = Value{static_cast<std::int64_t>(length)}; break;
        }
        case OpCode::ArrayPush: {
            if (stack.size() < 2) return fail(instruction.line, "stack underflow during array push");
            Value value = std::move(stack.back()); stack.pop_back();
            auto a = std::get_if<std::shared_ptr<Array>>(&stack.back().data);
            if (!a) return fail(instruction.line, "push requires an array as first argument");
            if ((*a)->size() >= 1000000) return fail(instruction.line, "array element limit exceeded");
            try { (*a)->push_back(std::move(value)); }
            catch (const std::bad_alloc&) { return fail(instruction.line, "DOCMONT heap budget exceeded while growing array"); }
            stack.back() = Value{static_cast<std::int64_t>((*a)->size())}; break;
        }
        case OpCode::ArrayPop: {
            if (stack.empty()) return fail(instruction.line, "stack underflow during array pop");
            auto a = std::get_if<std::shared_ptr<Array>>(&stack.back().data);
            if (!a) return fail(instruction.line, "pop requires an array");
            if ((*a)->empty()) return fail(instruction.line, "cannot pop from an empty array");
            Value value = std::move((*a)->back()); (*a)->pop_back(); stack.back() = std::move(value); break;
        }
        case OpCode::NewObject:
            stack.push_back(Value{std::make_shared<Object>()});
            break;
        case OpCode::ObjectSet: {
            if (stack.size() < 2) return fail(instruction.line, "stack underflow during object property write");
            Value value = std::move(stack.back()); stack.pop_back();
            auto object = std::get_if<std::shared_ptr<Object>>(&stack.back().data);
            if (!object || !*object) return fail(instruction.line, "property write requires an object");
            if (instruction.operand.empty()) return fail(instruction.line, "object property name cannot be empty");
            (*object)->insert_or_assign(instruction.operand, std::move(value));
            break;
        }
        case OpCode::ObjectGet: {
            if (stack.empty()) return fail(instruction.line, "stack underflow during object property read");
            auto object = std::get_if<std::shared_ptr<Object>>(&stack.back().data);
            if (!object || !*object) return fail(instruction.line, "property read requires an object");
            auto found = (*object)->find(instruction.operand);
            if (found == (*object)->end()) return fail(instruction.line, "object has no property '" + instruction.operand + "'");
            stack.back() = found->second;
            break;
        }
        case OpCode::ObjectHas: {
            if (stack.empty()) return fail(instruction.line, "stack underflow during object property test");
            auto object = std::get_if<std::shared_ptr<Object>>(&stack.back().data);
            if (!object || !*object) return fail(instruction.line, "property test requires an object");
            stack.back() = Value{static_cast<std::int64_t>((*object)->find(instruction.operand) != (*object)->end())};
            break;
        }
        case OpCode::Function:
            break;
        case OpCode::LoadFunction: {
            if (!functions.contains(instruction.operand)) return fail(instruction.line, "unknown DVM function reference '" + instruction.operand + "'");
            stack.push_back(Value{FunctionRef{instruction.operand, {}}});
            break;
        }
        case OpCode::MakeClosure: {
            if (instruction.integer < 0 || static_cast<std::uint64_t>(instruction.integer) > stack.size()) return fail(instruction.line, "invalid closure capture count");
            const auto separator = instruction.operand.find('|');
            const auto function_name = instruction.operand.substr(0, separator);
            if (!functions.contains(function_name)) return fail(instruction.line, "unknown closure function '" + function_name + "'");
            const auto count = static_cast<std::size_t>(instruction.integer);
            if (stack.size() < frames.back().stack_base + count) return fail(instruction.line, "closure capture window crosses frame boundary");
            std::vector<std::string> names;
            std::size_t begin = separator == std::string::npos ? instruction.operand.size() : separator + 1;
            while (begin < instruction.operand.size()) { auto end = instruction.operand.find('|', begin); if (end == std::string::npos) end = instruction.operand.size(); names.push_back(instruction.operand.substr(begin, end - begin)); begin = end + 1; }
            if (names.size() != count) return fail(instruction.line, "closure capture metadata mismatch");
            auto captures = std::make_shared<std::unordered_map<std::string, std::shared_ptr<Value>>>();
            for (std::size_t i = count; i > 0; --i) {
                auto* cell_ref = std::get_if<CellRef>(&stack.back().data);
                if (!cell_ref || !cell_ref->cell) return fail(instruction.line, "closure capture requires a live variable cell");
                (*captures)[names[i - 1]] = std::move(cell_ref->cell);
                stack.pop_back();
            }
            stack.push_back(Value{FunctionRef{function_name, std::move(captures)}});
            break;
        }
        case OpCode::CallIndirect: {
            const auto argc = instruction.integer < 0 ? std::numeric_limits<std::size_t>::max() : static_cast<std::size_t>(instruction.integer);
            if (argc == std::numeric_limits<std::size_t>::max() || stack.size() < argc + 1) return fail(instruction.line, "invalid indirect function argument count");
            const auto function_index = stack.size() - argc - 1;
            if (frames.empty() || function_index < frames.back().stack_base)
                return fail(instruction.line, "indirect call argument window crosses the current frame boundary");
            const auto* function_ref_ptr = std::get_if<FunctionRef>(&stack[function_index].data);
            if (!function_ref_ptr) return fail(instruction.line, "indirect call target is not a function");
            // Copy the callable before erasing its stack slot; vector erase may
            // invalidate pointers into the operand stack.
            const FunctionRef function_ref = *function_ref_ptr;
            const auto found = functions.find(function_ref.name);
            if (found == functions.end()) return fail(instruction.line, "unknown indirect DVM function");
            if (argc != found->second.arity) return fail(instruction.line, "function argument count mismatch for '" + function_ref.name + "'");
            if (frames.size() >= 1024) return fail(instruction.line, "DVM call frame limit exceeded (1024 frames)");
            const auto base = function_index;
            stack.erase(stack.begin() + static_cast<std::ptrdiff_t>(function_index));
            Frame frame; frame.return_pc=pc+1; frame.stack_base=base;
            if (function_ref.captures) frame.locals = *function_ref.captures;
            frames.push_back(std::move(frame)); pc=found->second.entry; continue;
        }
        case OpCode::Call: {
            if (instruction.integer < 0 || static_cast<std::uint64_t>(instruction.integer) > stack.size()) return fail(instruction.line, "invalid function argument count");
            const auto found = functions.find(instruction.operand);
            if (found == functions.end()) return fail(instruction.line, "unknown DVM function '" + instruction.operand + "'");
            const auto argc = static_cast<std::size_t>(instruction.integer);
            if (frames.empty() || stack.size() - argc < frames.back().stack_base)
                return fail(instruction.line, "direct call argument window crosses the current frame boundary");
            if (argc != found->second.arity) return fail(instruction.line, "function argument count mismatch for '" + instruction.operand + "'");
            if (frames.size() >= 1024) return fail(instruction.line, "DVM call frame limit exceeded (1024 frames)");
            Frame frame; frame.return_pc=pc+1; frame.stack_base=stack.size()-argc;
            const auto param_start=stack.end()-static_cast<std::ptrdiff_t>(argc);
            (void)param_start;
            frames.push_back(std::move(frame));
            pc=found->second.entry;
            continue;
        }
        case OpCode::Return: {
            if (frames.size()<=1) return fail(instruction.line, "return outside a DVM function");
            if (stack.size() != frames.back().stack_base + 1)
                return fail(instruction.line, "function return requires exactly one value in its own frame");
            Value result=std::move(stack.back());
            const auto return_pc=frames.back().return_pc;
            const auto base=frames.back().stack_base;
            frames.pop_back();
            stack.resize(base); stack.push_back(std::move(result));
            pc=return_pc; continue;
        }
        case OpCode::Print:
            if (stack.empty()) return fail(instruction.line, "stack underflow during output");
            print_value(stack.back());
            std::cout << '\n';
            stack.pop_back();
            break;
        case OpCode::Jump:
            if (instruction.integer < 0 || static_cast<std::uint64_t>(instruction.integer) > ir.code.size()) return fail(instruction.line, "invalid jump target");
            pc = static_cast<std::size_t>(instruction.integer);
            continue;
        case OpCode::JumpIfZero: {
            if (stack.empty()) return fail(instruction.line, "stack underflow during conditional branch");
            if (!std::holds_alternative<std::int64_t>(stack.back().data)) return fail(instruction.line, "if condition must be an integer");
            const auto condition = std::get<std::int64_t>(stack.back().data); stack.pop_back();
            if (condition == 0) {
                if (instruction.integer < 0 || static_cast<std::uint64_t>(instruction.integer) > ir.code.size()) return fail(instruction.line, "invalid conditional jump target");
                pc = static_cast<std::size_t>(instruction.integer); continue;
            }
            break;
        }
        default: {
            if (stack.size() < 2) return fail(instruction.line, "stack underflow during arithmetic");
            const Value rhs = stack.back(); stack.pop_back();
            const Value lhs = stack.back(); stack.pop_back();
            if (instruction.op == OpCode::Add && std::holds_alternative<std::string>(lhs.data) &&
                std::holds_alternative<std::string>(rhs.data)) {
                const auto& left = std::get<std::string>(lhs.data);
                const auto& right = std::get<std::string>(rhs.data);
                constexpr std::size_t max_string_bytes = 16U * 1024U * 1024U;
                if (right.size() > max_string_bytes - std::min(left.size(), max_string_bytes))
                    return fail(instruction.line, "string concatenation exceeds 16 MiB limit");
                std::string combined;
                combined.reserve(left.size() + right.size());
                combined.append(left);
                combined.append(right);
                stack.push_back(Value{std::move(combined)});
                break;
            }
            if (instruction.op == OpCode::Equal || instruction.op == OpCode::NotEqual) {
                bool equal = false;
                if (lhs.data.index() == rhs.data.index()) {
                    if (const auto* left = std::get_if<std::int64_t>(&lhs.data)) equal = *left == std::get<std::int64_t>(rhs.data);
                    else if (const auto* left = std::get_if<std::string>(&lhs.data)) equal = *left == std::get<std::string>(rhs.data);
                    else if (const auto* left = std::get_if<std::shared_ptr<Array>>(&lhs.data)) equal = *left == std::get<std::shared_ptr<Array>>(rhs.data);
                    else if (const auto* left = std::get_if<std::shared_ptr<Object>>(&lhs.data)) equal = *left == std::get<std::shared_ptr<Object>>(rhs.data);
                    else if (const auto* left = std::get_if<FunctionRef>(&lhs.data)) equal = left->name == std::get<FunctionRef>(rhs.data).name && left->captures == std::get<FunctionRef>(rhs.data).captures;
                    else if (const auto* left = std::get_if<CellRef>(&lhs.data)) equal = left->cell == std::get<CellRef>(rhs.data).cell;
                }
                stack.push_back(Value{static_cast<std::int64_t>(instruction.op == OpCode::Equal ? equal : !equal)});
                break;
            }
            if (!std::holds_alternative<std::int64_t>(lhs.data) || !std::holds_alternative<std::int64_t>(rhs.data))
                return fail(instruction.line, "arithmetic operands must be integers");
            const auto x = std::get<std::int64_t>(lhs.data);
            const auto y = std::get<std::int64_t>(rhs.data);
            std::int64_t result = 0;
            bool overflow = false;
            bool is_comparison = true;
            switch (instruction.op) {
            case OpCode::Equal: result = x == y; break;
            case OpCode::NotEqual: result = x != y; break;
            case OpCode::Less: result = x < y; break;
            case OpCode::LessEqual: result = x <= y; break;
            case OpCode::Greater: result = x > y; break;
            case OpCode::GreaterEqual: result = x >= y; break;
            case OpCode::LogicalAnd: result = (x != 0 && y != 0); break;
            case OpCode::LogicalOr: result = (x != 0 || y != 0); break;
            default: is_comparison = false; break;
            }
            if (is_comparison) { stack.push_back(Value{result}); break; }
            // Portable checked arithmetic: avoid signed-overflow undefined behavior
            // on every compiler, including MSVC where GCC overflow builtins do not exist.
            constexpr auto min = std::numeric_limits<std::int64_t>::min();
            constexpr auto max = std::numeric_limits<std::int64_t>::max();
            if (instruction.op == OpCode::Add) {
                if ((y > 0 && x > max - y) || (y < 0 && x < min - y)) overflow = true;
                else result = x + y;
            } else if (instruction.op == OpCode::Sub) {
                if ((y < 0 && x > max + y) || (y > 0 && x < min + y)) overflow = true;
                else result = x - y;
            } else if (instruction.op == OpCode::Mul) {
                if (x == 0 || y == 0) result = 0;
                else if ((x == -1 && y == min) || (y == -1 && x == min)) overflow = true;
                else if (x > 0) {
                    if ((y > 0 && x > max / y) || (y < 0 && y < min / x)) overflow = true;
                    else result = x * y;
                } else {
                    if ((y > 0 && x < min / y) || (y < 0 && x < max / y)) overflow = true;
                    else result = x * y;
                }
            } else if (instruction.op == OpCode::Div) {
                if (y == 0) return fail(instruction.line, "division by zero");
                if (x == min && y == -1) overflow = true;
                else result = x / y;
            }
            if (overflow) return fail(instruction.line, "signed 64-bit arithmetic overflow");
            stack.push_back(Value{result});
            break;
        }
        }
        if (stack.size() > max_operand_stack) return fail(instruction.line, "DVM operand stack limit exceeded (65536 values)");
        ++pc;
    }
    return 0;
}
}

#include "docmont/bytecode.hpp"
namespace docmont {
int execute_bytecode(const std::vector<std::uint8_t>& bytes) {
    ProgramIR program;
    const auto decoded = decode_bytecode(bytes, program);
    if (!decoded.ok) { std::cerr << "DVM load error: " << decoded.message << '\n'; return 2; }
    return execute(program);
}
}
