#include "docmont/ownership.hpp"
#include "docmont/diagnostic.hpp"

#include <algorithm>
#include <deque>
#include <map>
#include <set>
#include <sstream>
#include <unordered_map>
#include <unordered_set>
#include <functional>

namespace docmont::ownership {
namespace {
enum class ValueState { Uninitialized, Live, Moved, MaybeMoved };
enum class LoanKind { Shared, Mutable };
struct Loan { std::string place; LoanKind kind; friend bool operator==(const Loan&, const Loan&) = default; };
struct State {
    std::map<std::string, ValueState> values;
    std::map<std::string, Loan> loans;
    bool operator==(const State&) const = default;
};
std::string state_name(ValueState s) { switch(s){case ValueState::Uninitialized:return "uninitialized";case ValueState::Live:return "live";case ValueState::Moved:return "moved";case ValueState::MaybeMoved:return "maybe moved";}return "unknown"; }
ValueState merge_value(ValueState a, ValueState b) {
    if(a==b)return a;
    if(a==ValueState::Uninitialized&&b==ValueState::Uninitialized)return a;
    return ValueState::MaybeMoved;
}
State merge(const State& a,const State& b) {
    State out;std::set<std::string> keys;for(const auto& p:a.values)keys.insert(p.first);for(const auto& p:b.values)keys.insert(p.first);
    for(const auto& key:keys){auto ai=a.values.find(key),bi=b.values.find(key);auto av=ai==a.values.end()?ValueState::Uninitialized:ai->second;auto bv=bi==b.values.end()?ValueState::Uninitialized:bi->second;out.values[key]=merge_value(av,bv);}
    // A loan present on either predecessor is considered active at the join.
    out.loans=a.loans;for(const auto& p:b.loans)out.loans.emplace(p.first,p.second);return out;
}
}

AnalysisResult analyze(const Function& fn) {
    AnalysisResult result;
    auto report=[&](std::set<std::string>& seen,const Operation& op,const std::string& code,const std::string& message){std::ostringstream key;key<<op.line<<':'<<code<<':'<<message;if(seen.insert(key.str()).second)result.diagnostics.push_back({code,message,op.line});};
    std::unordered_map<std::uint32_t,std::size_t> index;
    for(std::size_t i=0;i<fn.blocks.size();++i)if(!index.emplace(fn.blocks[i].id,i).second)result.diagnostics.push_back({"OWN001","duplicate basic block id",0});
    if(!index.contains(fn.entry))result.diagnostics.push_back({"OWN002","entry basic block does not exist",0});
    for(const auto& b:fn.blocks)for(auto succ:b.successors)if(!index.contains(succ))result.diagnostics.push_back({"OWN003","successor basic block does not exist",0});
    if(!result.diagnostics.empty()){result.ok=false;return result;}

    const auto n=fn.blocks.size();std::vector<State> in(n),out(n);std::vector<bool> reachable(n,false);reachable[index.at(fn.entry)]=true;
    std::deque<std::size_t> work;work.push_back(index.at(fn.entry));std::set<std::string> emitted;
    const std::size_t iteration_limit=std::max<std::size_t>(64,n*n*16);
    while(!work.empty()&&result.dataflow_iterations<iteration_limit){auto bi=work.front();work.pop_front();++result.dataflow_iterations;State state=in[bi];const auto& block=fn.blocks[bi];
        auto value=[&](const std::string& place){auto it=state.values.find(place);return it==state.values.end()?ValueState::Uninitialized:it->second;};
        auto active=[&](const std::string& place){std::vector<std::pair<std::string,LoanKind>> found;for(const auto& p:state.loans)if(p.second.place==place)found.emplace_back(p.first,p.second.kind);return found;};
        for(const auto& op:block.operations){const auto current=value(op.place);switch(op.kind){
            case OpKind::Declare:
                if(current==ValueState::Live)report(emitted,op,"OWN010","place is already initialized: "+op.place);
                state.values[op.place]=ValueState::Live;break;
            case OpKind::Read:
                if(current!=ValueState::Live) report(emitted,op,"OWN011","cannot read '"+op.place+"': value is "+state_name(current));
                else { auto loans=active(op.place); if(std::any_of(loans.begin(),loans.end(),[](const auto& loan){return loan.second==LoanKind::Mutable;})) report(emitted,op,"OWN023","cannot read '"+op.place+"' while it is mutably borrowed"); }
                break;
            case OpKind::Move:
                if(current!=ValueState::Live){report(emitted,op,"OWN012","cannot move '"+op.place+"': value is "+state_name(current));break;}
                if(!active(op.place).empty()){report(emitted,op,"OWN013","cannot move '"+op.place+"' while it is borrowed");break;}
                state.values[op.place]=ValueState::Moved;break;
            case OpKind::BorrowShared:
            case OpKind::BorrowMutable: {
                if(current!=ValueState::Live){report(emitted,op,"OWN014","cannot borrow '"+op.place+"': value is "+state_name(current));break;}
                if(op.loan.empty()){report(emitted,op,"OWN015","borrow operation requires a loan identifier");break;}
                if(state.loans.contains(op.loan)){report(emitted,op,"OWN016","duplicate active loan id: "+op.loan);break;}
                auto loans=active(op.place);bool conflict=std::any_of(loans.begin(),loans.end(),[&](const auto& l){return op.kind==OpKind::BorrowMutable||l.second==LoanKind::Mutable;});
                if(conflict){report(emitted,op,"OWN017","borrow conflicts with an active borrow of '"+op.place+"'");break;}
                state.loans.emplace(op.loan,Loan{op.place,op.kind==OpKind::BorrowMutable?LoanKind::Mutable:LoanKind::Shared});break;
            }
            case OpKind::EndBorrow: {
                auto it=state.loans.find(op.loan);if(it==state.loans.end())report(emitted,op,"OWN018","cannot end unknown or inactive loan: "+op.loan);else state.loans.erase(it);break;
            }
            case OpKind::Assign:
                if(!active(op.place).empty())report(emitted,op,"OWN019","cannot assign to '"+op.place+"' while borrowed");else state.values[op.place]=ValueState::Live;break;
            case OpKind::Drop:
                if(current!=ValueState::Live)report(emitted,op,"OWN020","cannot drop '"+op.place+"': value is "+state_name(current));
                else if(!active(op.place).empty())report(emitted,op,"OWN021","cannot drop '"+op.place+"' while borrowed");
                else { state.values[op.place]=ValueState::Moved; }
                break;
            case OpKind::ReturnReference:
                if(op.source_region>op.target_region) report(emitted,op,"OWN022","returned reference outlives its source region: "+op.place);
                break;
        }}
        if(!(state==out[bi]))out[bi]=state;
        for(auto succ:block.successors){auto si=index.at(succ);State joined=reachable[si]?merge(in[si],state):state;if(!reachable[si]||!(joined==in[si])){in[si]=std::move(joined);reachable[si]=true;work.push_back(si);}}
    }
    if(!work.empty())result.diagnostics.push_back({"OWN099","ownership dataflow did not converge within the safety limit",0});
    result.ok=result.diagnostics.empty();return result;
}

AnalysisResult analyze(const core::MIRFunction& mir) {
    Function function; function.name=mir.name; function.entry=mir.entry;
    for(const auto& block:mir.blocks){BasicBlock lowered;lowered.id=block.id;lowered.successors=block.successors;for(const auto& op:block.operations){Operation item;item.place=op.place;item.loan=op.loan;item.source_region=op.source_region;item.target_region=op.target_region;switch(op.kind){case core::MIROpKind::Declare:item.kind=OpKind::Declare;break;case core::MIROpKind::Read:item.kind=OpKind::Read;break;case core::MIROpKind::Write:item.kind=OpKind::Assign;break;case core::MIROpKind::Move:item.kind=OpKind::Move;break;case core::MIROpKind::BorrowShared:item.kind=OpKind::BorrowShared;break;case core::MIROpKind::BorrowMutable:item.kind=OpKind::BorrowMutable;break;case core::MIROpKind::EndBorrow:item.kind=OpKind::EndBorrow;break;case core::MIROpKind::Drop:item.kind=OpKind::Drop;break;case core::MIROpKind::ReturnReference:item.kind=OpKind::ReturnReference;break;case core::MIROpKind::Return:continue;}lowered.operations.push_back(std::move(item));}function.blocks.push_back(std::move(lowered));}
    return analyze(function);
}


namespace {
bool contains_ownership_expr(const std::shared_ptr<Expr>& expr) {
    if(!expr) return false;
    if(expr->kind==ExprKind::Unary && (expr->op=="move"||expr->op=="&"||expr->op=="&mut")) return true;
    if(contains_ownership_expr(expr->left)||contains_ownership_expr(expr->right)) return true;
    for(const auto& child:expr->elements) if(contains_ownership_expr(child)) return true;
    for(const auto& property:expr->properties) if(contains_ownership_expr(property.second)) return true;
    return false;
}

}

std::vector<Diagnostic> validate_source(const Application& app) {
    std::vector<Diagnostic> diagnostics;
    std::unordered_set<std::string> function_names;
    for(const auto& fn:app.functions) function_names.insert(fn.name);
    for(const auto& fn:app.functions) {
        bool has_ownership=false;
        std::function<void(const std::vector<Statement>&)> scan=[&](const auto& statements){
            for(const auto& st:statements){
                has_ownership=has_ownership||contains_ownership_expr(st.expression);
                scan(st.body);scan(st.else_body);
                for(const auto& arm:st.match_arms)if(arm)scan(arm->body);
            }
        };
        scan(fn.body);
        if(!has_ownership) continue;

        bool has_loop=false;
        std::function<void(const std::vector<Statement>&)> find_loops=[&](const auto& statements){
            for(const auto& st:statements){
                if(st.kind==Statement::Kind::While||st.kind==Statement::Kind::ForEach)has_loop=true;
                find_loops(st.body);find_loops(st.else_body);
                for(const auto& arm:st.match_arms)if(arm)find_loops(arm->body);
            }
        };
        find_loops(fn.body);
        if(has_loop) {
            diagnostics.push_back({"OWN093","source Ownership checking with loops is not enabled yet; use explicit MIR CFG analysis for loop-carried loans",static_cast<std::size_t>(fn.line)});
            continue;
        }

        Function lowered; lowered.name=fn.name; lowered.entry=0;
        std::vector<std::string> active_loans;
        std::uint32_t next_block=0;
        auto make_block=[&]() -> std::size_t {
            BasicBlock block;block.id=next_block++;lowered.blocks.push_back(std::move(block));return lowered.blocks.size()-1;
        };
        auto add_edge=[&](std::size_t from,std::size_t to){
            auto& successors=lowered.blocks[from].successors;
            const auto id=lowered.blocks[to].id;
            if(std::find(successors.begin(),successors.end(),id)==successors.end())successors.push_back(id);
        };
        const auto entry=make_block();
        for(const auto& parameter:fn.parameters)
            lowered.blocks[entry].operations.push_back({OpKind::Declare,parameter.name,{},0,0,static_cast<std::size_t>(std::max(0,parameter.line))});

        std::function<void(const std::shared_ptr<Expr>&,const std::string&,std::size_t)> expression;
        expression=[&](const std::shared_ptr<Expr>& expr,const std::string& destination,std::size_t block_index) {
            if(!expr)return;
            auto& operations=lowered.blocks[block_index].operations;
            if(expr->kind==ExprKind::Identifier) {
                if(!function_names.contains(expr->text))operations.push_back({OpKind::Read,expr->text,{},0,0,static_cast<std::size_t>(expr->line)});
                return;
            }
            if(expr->kind==ExprKind::Call) { for(const auto& arg:expr->elements)expression(arg,{},block_index);return; }
            if(expr->kind==ExprKind::Unary&&(expr->op=="move"||expr->op=="&"||expr->op=="&mut")) {
                if(!expr->left||expr->left->kind!=ExprKind::Identifier) {
                    diagnostics.push_back({"OWN091","move/borrow requires a local variable place",static_cast<std::size_t>(expr->line)});return;
                }
                const auto place=expr->left->text;
                if(expr->op=="move")operations.push_back({OpKind::Move,place,{},0,0,static_cast<std::size_t>(expr->line)});
                else {
                    if(destination.empty()){diagnostics.push_back({"OWN092","borrow must initialize a named local binding",static_cast<std::size_t>(expr->line)});return;}
                    operations.push_back({expr->op=="&"?OpKind::BorrowShared:OpKind::BorrowMutable,place,destination,0,0,static_cast<std::size_t>(expr->line)});
                    active_loans.push_back(destination);
                }
                return;
            }
            expression(expr->left,{},block_index);expression(expr->right,{},block_index);
            for(const auto& child:expr->elements)expression(child,{},block_index);
            for(const auto& property:expr->properties)expression(property.second,{},block_index);
        };

        std::function<bool(const std::vector<Statement>&,std::size_t&)> lower_statements;
        lower_statements=[&](const std::vector<Statement>& statements,std::size_t& current)->bool {
            for(const auto& st:statements) {
                switch(st.kind) {
                    case Statement::Kind::Let:
                        expression(st.expression,st.name,current);
                        lowered.blocks[current].operations.push_back({OpKind::Declare,st.name,{},0,0,static_cast<std::size_t>(st.line)});
                        break;
                    case Statement::Kind::Assign:
                        expression(st.expression,{},current);
                        if(!st.name.empty())lowered.blocks[current].operations.push_back({OpKind::Assign,st.name,{},0,0,static_cast<std::size_t>(st.line)});
                        else {expression(st.target_index,{},current);expression(st.target_member,{},current);}
                        break;
                    case Statement::Kind::Output: case Statement::Kind::Expression:
                        expression(st.expression,{},current);break;
                    case Statement::Kind::Return:
                        if(st.expression && st.expression->kind==ExprKind::Identifier &&
                           std::find(active_loans.begin(),active_loans.end(),st.expression->text)!=active_loans.end())
                            diagnostics.push_back({"OWN022","cannot return a reference borrowed from a local value without a proven external lifetime: "+st.expression->text,static_cast<std::size_t>(st.line)});
                        expression(st.expression,{},current);return true;
                    case Statement::Kind::If: {
                        expression(st.expression,{},current);
                        const auto branch_loan_base=active_loans.size();
                        const auto then_block=make_block(),else_block=make_block(),join_block=make_block();
                        add_edge(current,then_block);add_edge(current,else_block);
                        std::size_t then_end=then_block;
                        const bool then_terminated=lower_statements(st.body,then_end);
                        for(std::size_t i=active_loans.size();i>branch_loan_base;--i)
                            lowered.blocks[then_end].operations.push_back({OpKind::EndBorrow,{},active_loans[i-1],0,0,static_cast<std::size_t>(st.line)});
                        active_loans.resize(branch_loan_base);
                        std::size_t else_end=else_block;
                        const bool else_terminated=lower_statements(st.else_body,else_end);
                        for(std::size_t i=active_loans.size();i>branch_loan_base;--i)
                            lowered.blocks[else_end].operations.push_back({OpKind::EndBorrow,{},active_loans[i-1],0,0,static_cast<std::size_t>(st.line)});
                        active_loans.resize(branch_loan_base);
                        if(!then_terminated)add_edge(then_end,join_block);
                        if(!else_terminated)add_edge(else_end,join_block);
                        current=join_block;
                        if(then_terminated&&else_terminated)return true;
                        break;
                    }
                    case Statement::Kind::Match: {
                        expression(st.expression,{},current);
                        const auto branch_loan_base=active_loans.size();
                        const auto join_block=make_block();bool any_fallthrough=false;
                        if(st.match_arms.empty()){add_edge(current,join_block);any_fallthrough=true;}
                        for(const auto& arm:st.match_arms)if(arm) {
                            const auto arm_block=make_block();add_edge(current,arm_block);
                            std::size_t arm_end=arm_block;
                            const bool terminated=lower_statements(arm->body,arm_end);
                            for(std::size_t i=active_loans.size();i>branch_loan_base;--i)
                                lowered.blocks[arm_end].operations.push_back({OpKind::EndBorrow,{},active_loans[i-1],0,0,static_cast<std::size_t>(arm->line)});
                            active_loans.resize(branch_loan_base);
                            if(!terminated){add_edge(arm_end,join_block);any_fallthrough=true;}
                        }
                        current=join_block;
                        if(!any_fallthrough)return true;
                        break;
                    }
                    case Statement::Kind::While: case Statement::Kind::ForEach:
                        return true; // rejected above if this function contains ownership annotations
                    case Statement::Kind::Break: case Statement::Kind::Continue:
                        return true;
                }
            }
            return false;
        };
        std::size_t current=entry;
        const bool terminated=lower_statements(fn.body,current);
        (void)terminated;
        for(auto it=active_loans.rbegin();it!=active_loans.rend();++it)
            lowered.blocks[current].operations.push_back({OpKind::EndBorrow,{},*it,0,0,static_cast<std::size_t>(fn.line)});
        auto result=analyze(lowered);
        for(const auto& item:result.diagnostics)diagnostics.push_back({item.code,item.message,item.line});
    }
    return diagnostics;
}

} // namespace docmont::ownership
