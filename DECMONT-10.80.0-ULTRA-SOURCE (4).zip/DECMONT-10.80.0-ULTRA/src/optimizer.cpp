#include "docmont/optimizer.hpp"
#include "docmont/ssa.hpp"
#include <cstdint>
#include <limits>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <functional>
#include <algorithm>
#include <optional>
namespace docmont { namespace {
bool evaluate(OpCode op, std::int64_t a, std::int64_t b, std::int64_t& out) {
 switch(op) {
 case OpCode::Add:
#if defined(__GNUC__) || defined(__clang__)
 return !__builtin_add_overflow(a,b,&out);
#else
 if ((b>0 && a>INT64_MAX-b)||(b<0 && a<INT64_MIN-b)) return false; out=a+b; return true;
#endif
 case OpCode::Sub:
#if defined(__GNUC__) || defined(__clang__)
 return !__builtin_sub_overflow(a,b,&out);
#else
 if ((b<0 && a>INT64_MAX+b)||(b>0 && a<INT64_MIN+b)) return false; out=a-b; return true;
#endif
 case OpCode::Mul:
#if defined(__GNUC__) || defined(__clang__)
 return !__builtin_mul_overflow(a,b,&out);
#else
 if(a==0||b==0){out=0;return true;} if((a==-1&&b==INT64_MIN)||(b==-1&&a==INT64_MIN))return false; long double x=static_cast<long double>(a)*b; if(x>INT64_MAX||x<INT64_MIN)return false;out=a*b;return true;
#endif
 case OpCode::Div: if(b==0||(a==INT64_MIN&&b==-1))return false;out=a/b;return true;
 case OpCode::Equal:out=a==b;return true; case OpCode::NotEqual:out=a!=b;return true;
 case OpCode::Less:out=a<b;return true; case OpCode::LessEqual:out=a<=b;return true;
 case OpCode::Greater:out=a>b;return true; case OpCode::GreaterEqual:out=a>=b;return true;
 case OpCode::LogicalAnd:out=(a!=0&&b!=0);return true; case OpCode::LogicalOr:out=(a!=0||b!=0);return true;
 default:return false;
 }
}
bool binary(OpCode op){switch(op){case OpCode::Add:case OpCode::Sub:case OpCode::Mul:case OpCode::Div:case OpCode::Equal:case OpCode::NotEqual:case OpCode::Less:case OpCode::LessEqual:case OpCode::Greater:case OpCode::GreaterEqual:case OpCode::LogicalAnd:case OpCode::LogicalOr:return true;default:return false;}}
std::optional<std::int64_t> constant_ssa_value(const SSAProgram& ssa,std::size_t id,std::size_t depth=0) {
 if(depth>64) return std::nullopt;
 auto range=std::lower_bound(ssa.integer_ranges.begin(),ssa.integer_ranges.end(),id,
  [](const SSAIntegerRange& item,std::size_t candidate){return item.value<candidate;});
 if(range!=ssa.integer_ranges.end() && range->value==id && range->minimum==range->maximum)
  return range->minimum;
 auto d=std::find_if(ssa.value_definitions.begin(),ssa.value_definitions.end(),[&](const SSAValueDefinition& x){return x.id==id;});
 if(d==ssa.value_definitions.end()||d->kind!=SSAValueKind::Instruction) return std::nullopt;
 if(d->op==OpCode::PushInt) return d->integer;
 if(d->operands.size()!=2) return std::nullopt;
 auto a=constant_ssa_value(ssa,d->operands[0],depth+1),b=constant_ssa_value(ssa,d->operands[1],depth+1);
 if(!a||!b) return std::nullopt;
 std::int64_t value{}; if(!evaluate(d->op,*a,*b,value)) return std::nullopt; return value;
}
}
using Constants = std::unordered_map<std::string, std::int64_t>;
struct BasicBlock { std::size_t begin{}, end{}; std::vector<std::size_t> successors, predecessors; };

std::vector<BasicBlock> build_blocks(const ProgramIR& p, std::vector<std::size_t>& block_for) {
 const std::size_t n=p.code.size(); std::vector<bool> leader(n+1,false); leader[0]=true;
 for(std::size_t i=0;i<n;++i){const auto& x=p.code[i];
  if((x.op==OpCode::Jump||x.op==OpCode::JumpIfZero)&&x.integer>=0&&static_cast<std::uint64_t>(x.integer)<n) leader[static_cast<std::size_t>(x.integer)]=true;
  if(x.op==OpCode::Jump||x.op==OpCode::JumpIfZero||x.op==OpCode::Return){if(i+1<n)leader[i+1]=true;}
 }
 std::vector<BasicBlock> b; for(std::size_t i=0;i<n;){std::size_t j=i+1;while(j<n&&!leader[j])++j;b.push_back({i,j,{},{}});i=j;}
 block_for.assign(n,0);for(std::size_t k=0;k<b.size();++k)for(std::size_t i=b[k].begin;i<b[k].end;++i)block_for[i]=k;
 auto edge=[&](std::size_t from,std::size_t to){if(to<n){auto a=block_for[from],z=block_for[to];if(std::find(b[a].successors.begin(),b[a].successors.end(),z)==b[a].successors.end()){b[a].successors.push_back(z);b[z].predecessors.push_back(a);}}};
 for(std::size_t k=0;k<b.size();++k){auto last=b[k].end-1;const auto& x=p.code[last];
  if(x.op==OpCode::Jump){if(x.integer>=0&&static_cast<std::uint64_t>(x.integer)<n)edge(last,static_cast<std::size_t>(x.integer));}
  else if(x.op==OpCode::JumpIfZero){if(x.integer>=0&&static_cast<std::uint64_t>(x.integer)<n)edge(last,static_cast<std::size_t>(x.integer));if(b[k].end<n)edge(last,b[k].end);}
  else if(x.op!=OpCode::Return&&b[k].end<n)edge(last,b[k].end);
 }
 return b;
}

// Redirect branches through chains of unconditional jumps. Cycles are left
// untouched: following one would otherwise make the target ambiguous.
std::size_t thread_jumps(ProgramIR& p) {
 const std::size_t n = p.code.size();
 std::size_t changed = 0;
 for (std::size_t i = 0; i < n; ++i) {
  auto& branch = p.code[i];
  if (branch.op != OpCode::Jump && branch.op != OpCode::JumpIfZero) continue;
  if (branch.integer < 0 || static_cast<std::uint64_t>(branch.integer) >= n) continue;
  const auto original = branch.integer;
  std::size_t target = static_cast<std::size_t>(original);
  std::vector<bool> visited(n, false);
  bool cycle = false;
  while (target < n && p.code[target].op == OpCode::Jump) {
   if (visited[target] || target == i) { cycle = true; break; }
   visited[target] = true;
   const auto next = p.code[target].integer;
   if (next < 0 || static_cast<std::uint64_t>(next) >= n) break;
   target = static_cast<std::size_t>(next);
  }
  if (!cycle && target != static_cast<std::size_t>(original)) {
   branch.integer = static_cast<std::int64_t>(target);
   ++changed;
  }
 }
 return changed;
}

std::size_t eliminate_unreachable(ProgramIR& p) {
 const auto n = p.code.size();
 if (n == 0) return 0;
 std::vector<std::size_t> block_for;
 const auto blocks = build_blocks(p, block_for);
 std::vector<bool> reachable(blocks.size(), false);
 std::vector<std::size_t> work{0}; reachable[0] = true;
 for (std::size_t cursor = 0; cursor < work.size(); ++cursor)
  for (auto succ : blocks[work[cursor]].successors)
   if (!reachable[succ]) { reachable[succ] = true; work.push_back(succ); }
 std::vector<std::size_t> remap(n + 1, 0);
 std::vector<Instruction> compact; compact.reserve(n);
 for (std::size_t b = 0; b < blocks.size(); ++b) {
  if (!reachable[b]) continue;
  for (std::size_t i = blocks[b].begin; i < blocks[b].end; ++i) {
   remap[i] = compact.size(); compact.push_back(p.code[i]);
  }
 }
 remap[n] = compact.size();
 const auto removed = n - compact.size();
 if (removed != 0) {
  for (auto& x : compact)
   if ((x.op == OpCode::Jump || x.op == OpCode::JumpIfZero) && x.integer >= 0 &&
       static_cast<std::uint64_t>(x.integer) <= n)
    x.integer = static_cast<std::int64_t>(remap[static_cast<std::size_t>(x.integer)]);
  p.code = std::move(compact);
 }
 return removed;
}

enum class LatticeKind : unsigned char { Top, Constant, Overdefined };
struct LatticeValue { LatticeKind kind{LatticeKind::Top}; std::int64_t value{}; };
using FlowState = std::unordered_map<std::string, LatticeValue>;

LatticeValue join_value(const LatticeValue& a, const LatticeValue& b) {
 if (a.kind == LatticeKind::Top) return b;
 if (b.kind == LatticeKind::Top) return a;
 if (a.kind == LatticeKind::Overdefined || b.kind == LatticeKind::Overdefined) return {LatticeKind::Overdefined, 0};
 return a.value == b.value ? a : LatticeValue{LatticeKind::Overdefined, 0};
}
bool same_state(const FlowState& a, const FlowState& b) {
 if (a.size() != b.size()) return false;
 for (const auto& item : a) {
  auto it = b.find(item.first);
  if (it == b.end() || item.second.kind != it->second.kind ||
      (item.second.kind == LatticeKind::Constant && item.second.value != it->second.value)) return false;
 }
 return true;
}
void invalidate_all(FlowState& state) {
 for (auto& item : state) item.second = {LatticeKind::Overdefined, 0};
}
void transfer_instruction(const ProgramIR& p, std::size_t i, FlowState& state, std::size_t block_begin) {
 const auto& x = p.code[i];
 if (x.op == OpCode::Store) {
  auto& value = state[x.operand];
  if (i > block_begin && p.code[i - 1].op == OpCode::PushInt)
   value = {LatticeKind::Constant, p.code[i - 1].integer};
  else value = {LatticeKind::Overdefined, 0};
 }
 if (x.op == OpCode::Function || x.op == OpCode::Call || x.op == OpCode::CallIndirect ||
     x.op == OpCode::Return || x.op == OpCode::MakeClosure || x.op == OpCode::LoadCell)
  invalidate_all(state);
}

std::vector<FlowState> analyze_constants(const ProgramIR& p, const std::vector<BasicBlock>& blocks) {
 std::vector<FlowState> before(p.code.size());
 if (blocks.empty()) return before;
 std::unordered_set<std::string> variables;
 for (const auto& x : p.code) if (x.op == OpCode::Store || x.op == OpCode::Load) variables.insert(x.operand);
 FlowState top;
 for (const auto& name : variables) top.emplace(name, LatticeValue{});
 std::vector<bool> reachable(blocks.size(), false);
 std::vector<std::size_t> work{0}; reachable[0] = true;
 for (std::size_t cursor = 0; cursor < work.size(); ++cursor)
  for (auto succ : blocks[work[cursor]].successors) if (!reachable[succ]) { reachable[succ] = true; work.push_back(succ); }

 // Forward must-analysis with a three-point lattice. Non-entry blocks start at
 // TOP, allowing loop-carried facts to converge instead of killing every back edge.
 std::vector<FlowState> in(blocks.size(), top), out(blocks.size(), top);
 FlowState entry = top; invalidate_all(entry); in[0] = entry;
 bool changed = true; std::size_t rounds = 0;
 const std::size_t max_rounds = std::max<std::size_t>(64, blocks.size() * (variables.size() + 2) * 4);
 while (changed && rounds++ < max_rounds) {
  changed = false;
  for (std::size_t k = 0; k < blocks.size(); ++k) {
   if (!reachable[k]) continue;
   FlowState next_in = (k == 0) ? entry : top;
   if (k != 0) {
    bool first = true;
    for (auto pred : blocks[k].predecessors) {
     if (!reachable[pred]) continue;
     if (first) { next_in = out[pred]; first = false; }
     else for (const auto& name : variables) next_in[name] = join_value(next_in[name], out[pred][name]);
    }
    if (first) continue;
   }
   FlowState next_out = next_in;
   for (std::size_t i = blocks[k].begin; i < blocks[k].end; ++i)
    transfer_instruction(p, i, next_out, blocks[k].begin);
   if (!same_state(in[k], next_in)) { in[k] = std::move(next_in); changed = true; }
   if (!same_state(out[k], next_out)) { out[k] = std::move(next_out); changed = true; }
  }
 }
 // If an unusually complex graph does not converge within the safety bound,
 // fail closed: no facts are propagated from it.
 if (changed) return before;
 for (std::size_t k = 0; k < blocks.size(); ++k) {
  if (!reachable[k]) continue;
  FlowState state = in[k];
  for (std::size_t i = blocks[k].begin; i < blocks[k].end; ++i) {
   before[i] = state;
   transfer_instruction(p, i, state, blocks[k].begin);
  }
 }
 return before;
}

// SSA-backed available-expression numbering across basic blocks. Expression
// operands are keyed by the exact variable SSA versions, so a redefinition or
// Phi merge changes the key. Availability is a forward must-analysis: an
// expression may cross a CFG join only when every reachable predecessor has
// the same materialized representative and no intervening effect barrier.
std::size_t run_ssa_gvn(ProgramIR& p, std::size_t& cross_block_eliminations) {
 if (p.code.empty()) return 0;
 const auto ssa = build_ssa(p);
 if (!verify_ssa(ssa, p).ok) return 0;
 std::unordered_map<std::size_t, std::size_t> load_versions;
 for (const auto& use : ssa.uses) load_versions.emplace(use.instruction, use.version);
 std::vector<bool> branch_targets(p.code.size() + 1, false);
 for (const auto& ins : p.code)
  if ((ins.op == OpCode::Jump || ins.op == OpCode::JumpIfZero) && ins.integer >= 0 &&
      static_cast<std::uint64_t>(ins.integer) <= p.code.size())
   branch_targets[static_cast<std::size_t>(ins.integer)] = true;
 auto pure_binary = [](OpCode op) {
  switch (op) {
   case OpCode::Add: case OpCode::Sub: case OpCode::Mul: case OpCode::Div:
   case OpCode::Equal: case OpCode::NotEqual: case OpCode::Less:
   case OpCode::LessEqual: case OpCode::Greater: case OpCode::GreaterEqual:
   case OpCode::LogicalAnd: case OpCode::LogicalOr: return true;
   default: return false;
  }
 };
 auto commutative = [](OpCode op) {
  return op == OpCode::Add || op == OpCode::Mul || op == OpCode::Equal ||
         op == OpCode::NotEqual || op == OpCode::LogicalAnd || op == OpCode::LogicalOr;
 };
 auto value_id = [&](std::size_t index) -> std::string {
  const auto& ins = p.code[index];
  if (ins.op == OpCode::PushInt) return "C" + std::to_string(ins.integer);
  auto it = load_versions.find(index);
  if (it == load_versions.end()) return {};
  return "V" + std::to_string(ins.operand.size()) + ":" + ins.operand + "#" + std::to_string(it->second);
 };
 std::unordered_set<std::string> used_names;
 for (const auto& ins : p.code)
  if (ins.op == OpCode::Load || ins.op == OpCode::Store) used_names.insert(ins.operand);

 constexpr std::size_t no_origin = std::numeric_limits<std::size_t>::max();
 struct AvailableValue { std::string temp; std::size_t origin{no_origin}; };
 using AvailableMap = std::unordered_map<std::string, AvailableValue>;
 auto same_map = [](const AvailableMap& a, const AvailableMap& b) {
  if (a.size() != b.size()) return false;
  for (const auto& [key, value] : a) {
   auto it = b.find(key);
   if (it == b.end() || it->second.origin != value.origin || it->second.temp != value.temp) return false;
  }
  return true;
 };
 auto is_barrier = [](OpCode op) {
  switch (op) {
   case OpCode::Call: case OpCode::CallIndirect: case OpCode::Function:
   case OpCode::Return: case OpCode::MakeClosure: case OpCode::LoadCell:
   case OpCode::ArraySet: case OpCode::ArrayPush: case OpCode::ArrayPop:
   case OpCode::ObjectSet: return true;
   default: return false;
  }
 };

 const auto count = p.code.size();
 std::vector<std::string> candidate_keys(count), candidate_temps(count);
 std::unordered_set<std::string> universe;
 std::size_t temp_id = 0;
 // Discover candidate expressions once. Branch targets cannot point into a
 // three-instruction expression that may be replaced as one stack operation.
 for (const auto& block : ssa.blocks) {
  if (block.dominators.empty()) continue;
  for (std::size_t i = block.begin; i + 2 < block.end; ++i) {
   const bool candidate =
    (p.code[i].op == OpCode::PushInt || p.code[i].op == OpCode::Load) &&
    (p.code[i + 1].op == OpCode::PushInt || p.code[i + 1].op == OpCode::Load) &&
    pure_binary(p.code[i + 2].op) &&
    !branch_targets[i] && !branch_targets[i + 1] && !branch_targets[i + 2];
   if (!candidate) continue;
   auto lhs = value_id(i), rhs = value_id(i + 1);
   if (lhs.empty() || rhs.empty()) continue;
   const auto op = p.code[i + 2].op;
   if (commutative(op) && rhs < lhs) std::swap(lhs, rhs);
   const std::string key = std::to_string(static_cast<int>(op)) + ":" +
    std::to_string(lhs.size()) + ":" + lhs + ":" + std::to_string(rhs.size()) + ":" + rhs;
   candidate_keys[i] = key;
   universe.insert(key);
   std::string temp;
   do { temp = "__docmont_ssa_gvn_" + std::to_string(temp_id++); }
   while (used_names.contains(temp));
   used_names.insert(temp);
   candidate_temps[i] = std::move(temp);
  }
 }
 if (universe.empty()) return 0;

 // TOP is represented by every candidate key mapped to the sentinel origin.
 // Starting non-entry blocks at TOP computes the greatest fixed point of this
 // must-analysis; entry remains the empty boundary condition.
 AvailableMap top;
 for (const auto& key : universe) top.emplace(key, AvailableValue{});
 const auto block_count = ssa.blocks.size();
 std::vector<AvailableMap> in(block_count), out(block_count);
 for (std::size_t b = 1; b < block_count; ++b) {
  if (!ssa.blocks[b].dominators.empty()) { in[b] = top; out[b] = top; }
 }
 auto transfer = [&](const SSABlock& block, AvailableMap state) {
  for (std::size_t i = block.begin; i < block.end; ++i) {
   if (!candidate_keys[i].empty()) {
    auto found = state.find(candidate_keys[i]);
    if (found == state.end() || found->second.origin == no_origin)
     state[candidate_keys[i]] = {candidate_temps[i], i};
   }
   if (is_barrier(p.code[i].op)) state.clear();
  }
  return state;
 };
 bool changed = true;
 std::size_t iterations = 0;
 const std::size_t iteration_limit = std::max<std::size_t>(32, block_count * (universe.size() + 2) * 4);
 while (changed && iterations++ < iteration_limit) {
  changed = false;
  for (std::size_t b = 0; b < block_count; ++b) {
   const auto& block = ssa.blocks[b];
   if (block.dominators.empty()) continue;
   AvailableMap next_in;
   if (b != 0) {
    bool first = true;
    for (auto pred : block.predecessors) {
     if (pred >= block_count || ssa.blocks[pred].dominators.empty()) continue;
     if (first) { next_in = out[pred]; first = false; }
     else {
      for (auto it = next_in.begin(); it != next_in.end();) {
       auto other = out[pred].find(it->first);
       if (other == out[pred].end() || other->second.origin != it->second.origin ||
           other->second.temp != it->second.temp) it = next_in.erase(it);
       else ++it;
      }
     }
    }
    if (first) next_in.clear();
   }
   auto next_out = transfer(block, next_in);
   if (!same_map(next_in, in[b]) || !same_map(next_out, out[b])) {
    in[b] = std::move(next_in);
    out[b] = std::move(next_out);
    changed = true;
   }
  }
 }
 // If a malformed or unusual CFG does not converge within the conservative
 // bound, skip this optimization rather than applying an uncertain rewrite.
 if (changed) return 0;

 std::vector<std::string> reuse_from(count);
 std::vector<bool> representative_needed(count, false);
 std::vector<std::size_t> block_for(count, no_origin);
 for (const auto& block : ssa.blocks)
  for (std::size_t i = block.begin; i < block.end; ++i) block_for[i] = block.id;
 std::size_t eliminated = 0;
 // Record the exact available representative at each occurrence before
 // rewriting, including occurrences reached through multiple CFG paths.
 for (const auto& block : ssa.blocks) {
  if (block.dominators.empty()) continue;
  auto state = in[block.id];
  for (std::size_t i = block.begin; i < block.end; ++i) {
   if (!candidate_keys[i].empty()) {
    auto found = state.find(candidate_keys[i]);
    if (found != state.end() && found->second.origin != no_origin) {
     reuse_from[i] = found->second.temp;
     representative_needed[found->second.origin] = true;
     if (block_for[found->second.origin] != no_origin && block_for[found->second.origin] != block.id)
      ++cross_block_eliminations;
     ++eliminated;
    } else {
     state[candidate_keys[i]] = {candidate_temps[i], i};
    }
   }
   if (is_barrier(p.code[i].op)) state.clear();
  }
 }
 if (eliminated == 0) return 0;

 std::vector<Instruction> rewritten;
 rewritten.reserve(count + eliminated * 2);
 std::vector<std::size_t> remap(count + 1, 0);
 for (const auto& block : ssa.blocks) {
  if (block.dominators.empty()) continue;
  for (std::size_t i = block.begin; i < block.end;) {
   remap[i] = rewritten.size();
   if (!reuse_from[i].empty()) {
    remap[i + 1] = rewritten.size();
    remap[i + 2] = rewritten.size();
    rewritten.push_back({OpCode::Load, reuse_from[i], 0, p.code[i + 2].line});
    i += 3;
    continue;
   }
   if (!candidate_keys[i].empty()) {
    rewritten.push_back(p.code[i]);
    remap[i + 1] = rewritten.size(); rewritten.push_back(p.code[i + 1]);
    remap[i + 2] = rewritten.size(); rewritten.push_back(p.code[i + 2]);
    if (representative_needed[i]) {
     // Spill only representatives that are actually reused, avoiding extra
     // temporary traffic for expressions with no common-subexpression use.
     const auto& temp = candidate_temps[i];
     rewritten.push_back({OpCode::Store, temp, 0, p.code[i + 2].line});
     rewritten.push_back({OpCode::Load, temp, 0, p.code[i + 2].line});
    }
    i += 3;
    continue;
   }
   rewritten.push_back(p.code[i]);
   ++i;
  }
 }
 remap[count] = rewritten.size();
 for (auto& ins : rewritten)
  if ((ins.op == OpCode::Jump || ins.op == OpCode::JumpIfZero) && ins.integer >= 0 &&
      static_cast<std::uint64_t>(ins.integer) <= count)
   ins.integer = static_cast<std::int64_t>(remap[static_cast<std::size_t>(ins.integer)]);
 p.code = std::move(rewritten);
 return eliminated;
}

// Memory-read CSE uses allocation-site provenance from Points-to Analysis.
// It rewrites only stack-balanced read idioms whose base is a single known
// object/array allocation. Unknown aliases, dynamic calls and writes that may
// touch the same site invalidate the cached value. The pass is block-local so
// cached values never need to cross a CFG edge or an unproven dominance path.
std::size_t run_ssa_memory_read_cse(ProgramIR& p, std::size_t& cross_block_eliminations) {
 if (p.code.empty()) return 0;
 const auto ssa = build_ssa(p);
 if (!ssa.stack_ssa_valid || !verify_ssa(ssa, p).ok) return 0;
 constexpr auto none = std::numeric_limits<std::size_t>::max();
 std::unordered_map<std::size_t, const SSAPointsToSet*> points_by_value;
 for (const auto& points : ssa.points_to_sets) points_by_value.emplace(points.value, &points);
 std::unordered_map<std::size_t, const SSAValueDefinition*> definitions_by_instruction;
 std::unordered_map<std::size_t, const SSAValueDefinition*> definitions_by_value;
 for (const auto& definition : ssa.value_definitions) {
  definitions_by_value.emplace(definition.id, &definition);
  if (definition.kind == SSAValueKind::Instruction)
   definitions_by_instruction.emplace(definition.instruction, &definition);
 }
 std::unordered_map<std::size_t, std::vector<const SSAValueUse*>> uses_by_instruction;
 for (const auto& use : ssa.value_uses) uses_by_instruction[use.instruction].push_back(&use);
 std::unordered_map<std::string, const SSAFunctionRegion*> functions_by_name;
 for (const auto& function : ssa.functions) functions_by_name[function.name] = &function;
 std::unordered_map<std::size_t, SSAAllocationKind> allocation_kinds;
 for (const auto& site : ssa.allocation_sites) allocation_kinds[site.instruction] = site.kind;
 std::vector<bool> branch_targets(p.code.size() + 1, false);
 for (const auto& instruction : p.code)
  if ((instruction.op == OpCode::Jump || instruction.op == OpCode::JumpIfZero) &&
      instruction.integer >= 0 && static_cast<std::uint64_t>(instruction.integer) <= p.code.size())
   branch_targets[static_cast<std::size_t>(instruction.integer)] = true;
 std::unordered_set<std::string> used_names;
 for (const auto& instruction : p.code)
  if (instruction.op == OpCode::Load || instruction.op == OpCode::Store) used_names.insert(instruction.operand);
 std::size_t next_temp = 0;
 auto points_for_value = [&](std::size_t value) -> const SSAPointsToSet* {
  auto found = points_by_value.find(value);
  return found == points_by_value.end() ? nullptr : found->second;
 };
 auto use_value = [&](std::size_t instruction, std::size_t operand) -> std::size_t {
  auto found = uses_by_instruction.find(instruction);
  if (found == uses_by_instruction.end()) return none;
  for (const auto* use : found->second) if (use->operand_index == operand) return use->value;
  return none;
 };
 auto value_points_at = [&](std::size_t instruction, std::size_t operand) -> const SSAPointsToSet* {
  const auto value = use_value(instruction, operand);
  return value == none ? nullptr : points_for_value(value);
 };
 enum class ReadKind { ObjectField, ArrayRead };
 struct CacheEntry { std::string temp; std::size_t site{}; ReadKind kind{}; std::string selector; std::size_t defining_block{}; };
 struct Candidate { std::size_t span{}; std::string key; CacheEntry entry; };
 std::vector<std::optional<Candidate>> candidates(p.code.size());
 std::vector<std::string> reuse(p.code.size());
 std::vector<std::size_t> reuse_spans(p.code.size(), 0);
 std::vector<bool> spill(p.code.size(), false);
 std::size_t eliminated = 0;
 auto make_temp = [&]() {
  std::string name;
  do { name = "__docmont_mem_cse_" + std::to_string(next_temp++); }
  while (used_names.contains(name));
  used_names.insert(name);
  return name;
 };
 auto candidate_at = [&](std::size_t i, std::size_t block_end) -> std::optional<Candidate> {
  if (i + 1 >= block_end || p.code[i].op != OpCode::Load || branch_targets[i + 1]) return std::nullopt;
  const auto op = p.code[i + 1].op;
  std::size_t memory_instruction = i + 1;
  std::size_t span = 2;
  ReadKind kind{};
  std::string selector;
  if (op == OpCode::ObjectGet || op == OpCode::ObjectHas) {
   kind = ReadKind::ObjectField;
   selector = std::to_string(static_cast<int>(op)) + ":" + p.code[i + 1].operand;
  } else if (op == OpCode::ArrayLength) {
   kind = ReadKind::ArrayRead;
   selector = "length";
  } else if (i + 2 < block_end &&
             (p.code[i + 1].op == OpCode::PushInt || p.code[i + 1].op == OpCode::Load) &&
             p.code[i + 2].op == OpCode::ArrayGet && !branch_targets[i + 1] && !branch_targets[i + 2]) {
   std::optional<std::int64_t> resolved_index;
   if (p.code[i + 1].op == OpCode::PushInt) resolved_index = p.code[i + 1].integer;
   else {
    const auto index_value = use_value(i + 2, 1);
    if (index_value != none) resolved_index = constant_ssa_value(ssa, index_value);
   }
   if (!resolved_index) return std::nullopt;
   kind = ReadKind::ArrayRead;
   memory_instruction = i + 2;
   span = 3;
   selector = "index:" + std::to_string(*resolved_index);
  } else {
   return std::nullopt;
  }
  // Memory CSE is allowed only when partitioned Memory SSA supplied a
  // concrete heap token for this read. Alias-site invalidation below provides
  // the finer disjoint-object reasoning; the token is the verifier-backed
  // dependency that prevents optimizing an unmodeled memory operation.
  const auto* points = value_points_at(memory_instruction, 0);
  if (!points || points->unknown || !points->parameter_indices.empty() || points->allocation_sites.size() != 1)
   return std::nullopt;
  const auto site = points->allocation_sites.front();
  const std::string expected_partition = (kind == ReadKind::ArrayRead && selector.rfind("index:", 0) == 0)
      ? "array:" + std::to_string(site) + ":" + selector.substr(6) : std::string{};
  const bool has_heap_memory_token = std::any_of(ssa.memory_uses.begin(), ssa.memory_uses.end(),
   [&](const SSAMemoryUse& use) {
    if (use.instruction != memory_instruction || use.region != SSAAliasRegion::HeapAggregate) return false;
    if (kind == ReadKind::ArrayRead) return use.partition_key == expected_partition || (selector == "length" && use.partition_key.empty());
    return use.partition_key.rfind("object:", 0) == 0;
   });
  if (!has_heap_memory_token) return std::nullopt;
  auto allocation = allocation_kinds.find(site);
  if (allocation == allocation_kinds.end()) return std::nullopt;
  if (kind == ReadKind::ObjectField && allocation->second != SSAAllocationKind::Object) return std::nullopt;
  if (kind == ReadKind::ArrayRead && allocation->second != SSAAllocationKind::Array) return std::nullopt;
  std::string key = std::to_string(static_cast<int>(kind)) + ":" + std::to_string(site) + ":" + selector;
  return Candidate{span, std::move(key), CacheEntry{{}, site, kind, std::move(selector), 0}};
 };
 auto invalidate_site = [&](std::unordered_map<std::string, CacheEntry>& available,
                            std::size_t site, const Instruction& write,
                            std::optional<std::int64_t> array_index = std::nullopt) {
  for (auto it = available.begin(); it != available.end();) {
   bool kill = it->second.site == site;
   if (kill && write.op == OpCode::ObjectSet) {
    kill = it->second.kind == ReadKind::ObjectField &&
           (write.operand.empty() || it->second.selector == std::to_string(static_cast<int>(OpCode::ObjectGet)) + ":" + write.operand ||
            it->second.selector == std::to_string(static_cast<int>(OpCode::ObjectHas)) + ":" + write.operand);
   } else if (kill && write.op == OpCode::ArraySet && array_index && it->second.kind == ReadKind::ArrayRead) {
    kill = it->second.selector == "index:" + std::to_string(*array_index);
   }
   if (kill) it = available.erase(it); else ++it;
  }
 };
 auto invalidate_write = [&](std::unordered_map<std::string, CacheEntry>& available,
                             std::size_t instruction, const Instruction& write) {
  const SSAPointsToSet* points = value_points_at(instruction, 0);
  std::optional<std::int64_t> array_index;
  if (write.op == OpCode::ArraySet) {
   auto base_use = std::find_if(ssa.value_uses.begin(), ssa.value_uses.end(), [&](const SSAValueUse& item) {
    return item.instruction == instruction && item.operand_index == 0;
   });
   auto index_use = std::find_if(ssa.value_uses.begin(), ssa.value_uses.end(), [&](const SSAValueUse& item) {
    return item.instruction == instruction && item.operand_index == 1;
   });
   if (base_use != ssa.value_uses.end()) points = points_for_value(base_use->value);
   if (index_use != ssa.value_uses.end()) array_index = constant_ssa_value(ssa, index_use->value);
  }
  if (!points || points->unknown || !points->parameter_indices.empty()) {
   available.clear();
   return;
  }
  if (points->allocation_sites.empty()) {
   // A memory write without an identifiable base must never preserve cached reads.
   available.clear();
   return;
  }
  for (auto site : points->allocation_sites) invalidate_site(available, site, write, array_index);
 };
 auto invalidate_call = [&](std::unordered_map<std::string, CacheEntry>& available,
                            std::size_t instruction, const Instruction& call) {
  if (call.op == OpCode::CallIndirect) { available.clear(); return; }
  auto function = functions_by_name.find(call.operand);
  auto call_definition = definitions_by_instruction.find(instruction);
  if (function == functions_by_name.end() || call_definition == definitions_by_instruction.end() ||
      function->second->has_unknown_effects) { available.clear(); return; }
  const auto& callee = *function->second;
  if (!callee.may_write_memory) return;
  // Inspect the callee's direct write sites. A write through a formal is
  // mapped to the caller's actual argument using the 7.70 parameter summary.
  // Unknown/global writes and nested unresolved effects fail closed.
  if (!callee.analysis) { available.clear(); return; }
  const auto& local = *callee.analysis;
  std::unordered_map<std::size_t, const SSAPointsToSet*> local_points;
  for (const auto& points : local.points_to_sets) local_points.emplace(points.value, &points);
  auto local_base_points = [&](std::size_t local_instruction) -> const SSAPointsToSet* {
   auto use = std::find_if(local.value_uses.begin(), local.value_uses.end(), [&](const SSAValueUse& item) {
    return item.instruction == local_instruction && item.operand_index == 0;
   });
   if (use == local.value_uses.end()) return nullptr;
   auto found = local_points.find(use->value);
   return found == local_points.end() ? nullptr : found->second;
  };
  bool saw_write = false;
  for (const auto& access : local.alias_accesses) {
   if (!access.write) continue;
   saw_write = true;
   const auto nested_call = std::find_if(local.value_definitions.begin(), local.value_definitions.end(),
    [&](const SSAValueDefinition& item) {
     return item.kind == SSAValueKind::Instruction && item.instruction == access.instruction &&
            (item.op == OpCode::Call || item.op == OpCode::CallIndirect);
    });
   if (nested_call != local.value_definitions.end()) { available.clear(); return; }
   const auto* base = local_base_points(access.instruction);
   if (!base || base->unknown) { available.clear(); return; }
   if (!base->parameter_indices.empty()) {
    for (auto parameter : base->parameter_indices) {
     auto effect = std::find_if(callee.parameter_effects.begin(), callee.parameter_effects.end(),
       [&](const SSAParameterEffect& item) { return item.parameter_index == parameter; });
     if (effect == callee.parameter_effects.end() || (!effect->may_write_memory && !effect->may_escape) ||
         parameter >= call_definition->second->operands.size()) { available.clear(); return; }
     const auto* actual = points_for_value(call_definition->second->operands[parameter]);
     if (!actual || actual->unknown || !actual->parameter_indices.empty()) { available.clear(); return; }
     for (auto site : actual->allocation_sites) invalidate_site(available, site, Instruction{OpCode::ArraySet, {}, 0, call.line});
    }
   } else if (!base->allocation_sites.empty()) {
    for (auto site : base->allocation_sites) invalidate_site(available, callee.begin + site, Instruction{OpCode::ArraySet, {}, 0, call.line});
   } else {
    available.clear(); return;
   }
  }
  // A memory-writing summary without a corresponding local write record means
  // an effect was propagated from a nested call; do not guess its alias set.
  if (!saw_write && callee.may_write_memory) available.clear();
 };
 // Materialize all eligible reads once. A later data-flow pass intersects
 // predecessor facts, allowing a dominating read to be reused after a diamond
 // join while rejecting facts killed on even one incoming path.
 for (const auto& block : ssa.blocks) {
  if (block.dominators.empty()) continue;
  for (std::size_t i = block.begin; i < block.end;) {
   auto candidate = candidate_at(i, block.end);
   if (candidate) {
    candidate->entry.temp = make_temp();
    candidate->entry.defining_block = block.id;
    candidates[i] = *candidate;
    i += candidate->span;
   } else ++i;
  }
 }
 using Available = std::unordered_map<std::string, CacheEntry>;
 std::vector<Available> available_in(ssa.blocks.size()), available_out(ssa.blocks.size());
 auto same_entry = [](const CacheEntry& a, const CacheEntry& b) {
  return a.temp == b.temp && a.site == b.site && a.kind == b.kind && a.selector == b.selector && a.defining_block == b.defining_block;
 };
 auto same_state = [&](const Available& a, const Available& b) {
  if (a.size() != b.size()) return false;
  for (const auto& item : a) {
   auto found = b.find(item.first);
   if (found == b.end() || !same_entry(item.second, found->second)) return false;
  }
  return true;
 };
 auto merge_predecessors = [&](std::size_t block_id) {
  Available merged;
  if (block_id == 0 || block_id >= ssa.blocks.size()) return merged;
  bool first = true;
  for (auto pred : ssa.blocks[block_id].predecessors) {
   if (pred >= ssa.blocks.size() || ssa.blocks[pred].dominators.empty()) continue;
   if (first) { merged = available_out[pred]; first = false; continue; }
   for (auto it = merged.begin(); it != merged.end();) {
    auto found = available_out[pred].find(it->first);
    if (found == available_out[pred].end() || !same_entry(it->second, found->second)) it = merged.erase(it);
    else ++it;
   }
  }
  if (first) merged.clear();
  return merged;
 };
 auto transfer_block = [&](const SSABlock& block, Available& available) {
  for (std::size_t i = block.begin; i < block.end;) {
   if (candidates[i]) {
    const auto& candidate = *candidates[i];
    if (!available.contains(candidate.key)) available.emplace(candidate.key, candidate.entry);
    i += candidate.span;
    continue;
   }
   const auto& instruction = p.code[i];
   if (instruction.op == OpCode::ArraySet || instruction.op == OpCode::ArrayPush ||
       instruction.op == OpCode::ArrayPop || instruction.op == OpCode::ObjectSet)
    invalidate_write(available, i, instruction);
   else if (instruction.op == OpCode::Call || instruction.op == OpCode::CallIndirect)
    invalidate_call(available, i, instruction);
   ++i;
  }
 };
 const std::size_t dataflow_limit = std::max<std::size_t>(8, ssa.blocks.size() * 8 + 8);
 bool dataflow_changed = true;
 for (std::size_t round = 0; dataflow_changed && round < dataflow_limit; ++round) {
  dataflow_changed = false;
  for (const auto& block : ssa.blocks) {
   if (block.dominators.empty()) continue;
   auto incoming = merge_predecessors(block.id);
   auto outgoing = incoming;
   transfer_block(block, outgoing);
   if (!same_state(incoming, available_in[block.id]) || !same_state(outgoing, available_out[block.id])) {
    available_in[block.id] = std::move(incoming);
    available_out[block.id] = std::move(outgoing);
    dataflow_changed = true;
   }
  }
 }
 // If loops or malformed flow fail to converge, abandon this optimization.
 if (dataflow_changed) return 0;
 std::vector<bool> primary_candidate(p.code.size(), false);
 for (const auto& block : ssa.blocks) {
  if (block.dominators.empty()) continue;
  auto available = available_in[block.id];
  for (std::size_t i = block.begin; i < block.end;) {
   if (candidates[i]) {
    const auto& candidate = *candidates[i];
    auto found = available.find(candidate.key);
    if (found != available.end()) {
     reuse[i] = found->second.temp;
     reuse_spans[i] = candidate.span;
     ++eliminated;
     if (found->second.defining_block != block.id) ++cross_block_eliminations;
    } else {
     available.emplace(candidate.key, candidate.entry);
     primary_candidate[i] = true;
    }
    i += candidate.span;
    continue;
   }
   const auto& instruction = p.code[i];
   if (instruction.op == OpCode::ArraySet || instruction.op == OpCode::ArrayPush ||
       instruction.op == OpCode::ArrayPop || instruction.op == OpCode::ObjectSet)
    invalidate_write(available, i, instruction);
   else if (instruction.op == OpCode::Call || instruction.op == OpCode::CallIndirect)
    invalidate_call(available, i, instruction);
   ++i;
  }
 }
 if (!eliminated) return 0;
 // Only path-leading reads that actually feed a replacement need a spill.
 for (std::size_t i = 0; i < candidates.size(); ++i) if (primary_candidate[i]) {
  for (std::size_t j = 0; j < reuse.size(); ++j) {
   if (reuse[j] == candidates[i]->entry.temp) { spill[i] = true; break; }
  }
 }
 std::vector<Instruction> rewritten;
 rewritten.reserve(p.code.size() + eliminated);
 std::vector<std::size_t> remap(p.code.size() + 1, 0);
 std::size_t cursor = 0;
 while (cursor < p.code.size()) {
  remap[cursor] = rewritten.size();
  if (!reuse[cursor].empty()) {
   const auto span = reuse_spans[cursor];
   if (span < 2 || cursor + span > p.code.size()) return 0;
   for (std::size_t k = 1; k < span; ++k) remap[cursor + k] = rewritten.size();
   rewritten.push_back({OpCode::Load, reuse[cursor], 0, p.code[cursor].line});
   cursor += span;
   continue;
  }
  if (candidates[cursor] && primary_candidate[cursor]) {
   const auto candidate = *candidates[cursor];
   for (std::size_t k = 0; k < candidate.span; ++k) {
    if (k) remap[cursor + k] = rewritten.size();
    rewritten.push_back(p.code[cursor + k]);
   }
   if (spill[cursor]) {
    rewritten.push_back({OpCode::Store, candidate.entry.temp, 0, p.code[cursor + candidate.span - 1].line});
    rewritten.push_back({OpCode::Load, candidate.entry.temp, 0, p.code[cursor + candidate.span - 1].line});
   }
   cursor += candidate.span;
   continue;
  }
  rewritten.push_back(p.code[cursor]);
  ++cursor;
 }
 remap[p.code.size()] = rewritten.size();
 for (auto& instruction : rewritten)
  if ((instruction.op == OpCode::Jump || instruction.op == OpCode::JumpIfZero) && instruction.integer >= 0 &&
      static_cast<std::uint64_t>(instruction.integer) <= p.code.size())
   instruction.integer = static_cast<std::int64_t>(remap[static_cast<std::size_t>(instruction.integer)]);
 p.code = std::move(rewritten);
 return eliminated;
}

// Heap DSE removes only a previous literal store to the same proven object
// field or statically in-bounds array slot when a later adjacent store in the
// same basic block overwrites it before any intervening instruction. Unknown
// aliases, calls, reads, branches, and non-literal value producers terminate
// the pending set. This narrow rule avoids changing traps or observable reads.
std::size_t run_ssa_heap_dead_store_elimination(ProgramIR& p) {
 if (p.code.empty()) return 0;
 const auto ssa = build_ssa(p);
 if (!ssa.stack_ssa_valid || !verify_ssa(ssa, p).ok) return 0;
 std::unordered_map<std::size_t, const SSAPointsToSet*> points_by_value;
 for (const auto& points : ssa.points_to_sets) points_by_value.emplace(points.value, &points);
 std::unordered_map<std::size_t, SSAAllocationKind> allocation_kinds;
 for (const auto& site : ssa.allocation_sites) allocation_kinds.emplace(site.instruction, site.kind);
 std::vector<bool> branch_targets(p.code.size() + 1, false);
 for (const auto& instruction : p.code)
  if ((instruction.op == OpCode::Jump || instruction.op == OpCode::JumpIfZero) && instruction.integer >= 0 &&
      static_cast<std::uint64_t>(instruction.integer) <= p.code.size())
   branch_targets[static_cast<std::size_t>(instruction.integer)] = true;
 std::unordered_set<std::string> loaded_variables;
 for (const auto& instruction : p.code) if (instruction.op == OpCode::Load || instruction.op == OpCode::LoadCell) loaded_variables.insert(instruction.operand);
 auto base_points_at = [&](std::size_t instruction) -> const SSAPointsToSet* {
  for (const auto& use : ssa.value_uses) if (use.instruction == instruction && use.operand_index == 0) {
   auto found = points_by_value.find(use.value);
   return found == points_by_value.end() ? nullptr : found->second;
  }
  return nullptr;
 };
 struct HeapWrite { std::size_t begin{}, span{}; std::string key; };
 std::vector<bool> removed(p.code.size(), false);
 std::size_t eliminated = 0;
 for (const auto& block : ssa.blocks) {
  if (block.dominators.empty()) continue;
  std::unordered_map<std::string, HeapWrite> pending;
  for (std::size_t i = block.begin; i < block.end;) {
   std::optional<HeapWrite> candidate;
   // ObjectSet leaves its receiver on the stack. The trailing Store must be
   // dead (never loaded) before the complete stack-balanced write sequence can
   // be removed. The receiver is a proven NewObject allocation.
   if (i + 3 < block.end && p.code[i].op == OpCode::Load &&
       (p.code[i + 1].op == OpCode::PushInt || p.code[i + 1].op == OpCode::PushString) &&
       p.code[i + 2].op == OpCode::ObjectSet && p.code[i + 3].op == OpCode::Store &&
       !loaded_variables.contains(p.code[i + 3].operand) && !p.code[i + 2].operand.empty()) {
    const auto* points = base_points_at(i + 2);
    if (points && !points->unknown && points->parameter_indices.empty() && points->allocation_sites.size() == 1) {
     const auto site = points->allocation_sites.front();
     auto kind = allocation_kinds.find(site);
     if (kind != allocation_kinds.end() && kind->second == SSAAllocationKind::Object) {
      candidate = HeapWrite{i, 4, "object:" + std::to_string(site) + ":" + p.code[i + 2].operand};
     }
    }
   }
   // ArraySet is stack-balanced. Restrict it to a literal value and a proven
   // in-range constant index, so removing an earlier store cannot suppress an
   // out-of-bounds trap.
   if (!candidate && i + 3 < block.end && p.code[i].op == OpCode::Load &&
       p.code[i + 1].op == OpCode::PushInt && p.code[i + 2].op == OpCode::PushInt &&
       p.code[i + 3].op == OpCode::ArraySet) {
    const auto* points = base_points_at(i + 3);
    if (points && !points->unknown && points->parameter_indices.empty() && points->allocation_sites.size() == 1) {
     const auto site = points->allocation_sites.front();
     auto kind = allocation_kinds.find(site);
     if (kind != allocation_kinds.end() && kind->second == SSAAllocationKind::Array && site < p.code.size()) {
      const auto length = p.code[site].integer;
      const auto index = p.code[i + 1].integer;
      if (length >= 0 && index >= 0 && index < length)
       candidate = HeapWrite{i, 4, "array:" + std::to_string(site) + ":" + std::to_string(index)};
     }
    }
   }
   if (candidate) {
    bool target_inside = false;
    for (std::size_t k = 0; k < candidate->span; ++k) target_inside = target_inside || branch_targets[i + k];
    if (!target_inside) {
     auto previous = pending.find(candidate->key);
     if (previous != pending.end()) {
      for (std::size_t k = 0; k < previous->second.span; ++k) removed[previous->second.begin + k] = true;
      ++eliminated;
     }
     pending[candidate->key] = *candidate;
     i += candidate->span;
     continue;
    }
   }
   // Any non-candidate instruction may observe, escape, throw, or otherwise
   // alter the object; do not carry pending stores past it.
   pending.clear();
   ++i;
  }
 }
 if (!eliminated) return 0;
 std::vector<Instruction> compact;
 compact.reserve(p.code.size());
 std::vector<std::size_t> remap(p.code.size() + 1, 0);
 for (std::size_t i = 0; i < p.code.size(); ++i) {
  remap[i] = compact.size();
  if (!removed[i]) compact.push_back(p.code[i]);
 }
 remap[p.code.size()] = compact.size();
 for (auto& instruction : compact)
  if ((instruction.op == OpCode::Jump || instruction.op == OpCode::JumpIfZero) && instruction.integer >= 0 &&
      static_cast<std::uint64_t>(instruction.integer) <= p.code.size())
   instruction.integer = static_cast<std::int64_t>(remap[static_cast<std::size_t>(instruction.integer)]);
 p.code = std::move(compact);
 return eliminated;
}

// Dead-store elimination is deliberately restricted to definitions whose
// value is a directly adjacent literal. Removing a Store must also remove its
// stack-producing literal; arbitrary expressions are left intact so their
// stack effects and possible traps are never changed.
std::size_t eliminate_ssa_dead_stores(ProgramIR& p, std::size_t& instructions_removed) {
 if (p.code.empty()) return 0;
 const auto ssa = build_ssa(p);
 if (!verify_ssa(ssa, p).ok || !ssa.stack_ssa_valid) return 0;
 auto key = [](const std::string& name, std::size_t version) {
  return std::to_string(name.size()) + ":" + name + "#" + std::to_string(version);
 };
 std::unordered_set<std::string> live;
 std::vector<std::string> work;
 for (const auto& use : ssa.uses) {
  auto k=key(use.variable,use.version);
  if(live.insert(k).second)work.push_back(std::move(k));
 }
 // A Phi's incoming values are live only when that Phi result reaches a Load.
 // This fixed-point is the variable-SSA portion of global dead-code analysis.
 std::unordered_map<std::string,const SSAPhi*> phis_by_result;
 for(const auto& block:ssa.blocks)for(const auto& phi:block.phis)
  phis_by_result.emplace(key(phi.variable,phi.result_version),&phi);
 for(std::size_t q=0;q<work.size();++q){
  auto found=phis_by_result.find(work[q]);
  if(found==phis_by_result.end())continue;
  for(const auto& incoming:found->second->incoming){
   auto k=key(found->second->variable,incoming.second);
   if(live.insert(k).second)work.push_back(std::move(k));
  }
 }
 std::vector<bool> targets(p.code.size(),false);
 for(const auto& ins:p.code)
  if((ins.op==OpCode::Jump||ins.op==OpCode::JumpIfZero)&&ins.integer>=0&&
     static_cast<std::uint64_t>(ins.integer)<p.code.size())targets[static_cast<std::size_t>(ins.integer)]=true;
 std::unordered_map<std::size_t,const SSAValueDefinition*> values;
 for(const auto& def:ssa.value_definitions)values.emplace(def.id,&def);
 std::unordered_map<std::size_t,std::vector<const SSAValueUse*>> uses_by_value;
 for(const auto& use:ssa.value_uses)uses_by_value[use.value].push_back(&use);
 std::vector<bool> remove(p.code.size(),false);
 std::size_t removed_stores=0;
 for(const auto& def:ssa.definitions){
  if(def.instruction==static_cast<std::size_t>(-1)||def.instruction>=p.code.size()||
     live.contains(key(def.variable,def.version)))continue;
  const auto store_at=def.instruction;
  if(targets[store_at])continue;
  auto store_use=std::find_if(ssa.value_uses.begin(),ssa.value_uses.end(),[&](const SSAValueUse& u){
   return u.instruction==store_at&&u.operand_index==0;
  });
  if(store_use==ssa.value_uses.end())continue;
  std::vector<std::size_t> expression_instructions;
  std::unordered_set<std::size_t> visiting;
  std::function<bool(std::size_t,std::size_t)> collect_constant_tree =
   [&](std::size_t value_id,std::size_t consumer)->bool{
    auto use_it=uses_by_value.find(value_id);
    if(use_it==uses_by_value.end()||use_it->second.size()!=1||use_it->second.front()->instruction!=consumer)return false;
    auto value_it=values.find(value_id);
    if(value_it==values.end())return false;
    const auto& value=*value_it->second;
    if(value.kind!=SSAValueKind::Instruction||value.instruction>=p.code.size()||
       !visiting.insert(value_id).second)return false;
    const auto op=p.code[value.instruction].op;
    if(op==OpCode::PushInt){
     if(!value.operands.empty())return false;
     expression_instructions.push_back(value.instruction);return true;
    }
    if(op==OpCode::BoolNot){
     if(value.operands.size()!=1||!collect_constant_tree(value.operands[0],value.instruction))return false;
     expression_instructions.push_back(value.instruction);return true;
    }
    if(binary(op)){
     if(value.operands.size()!=2)return false;
     if(!collect_constant_tree(value.operands[0],value.instruction)||
        !collect_constant_tree(value.operands[1],value.instruction))return false;
     // Refuse to erase arithmetic unless constant evaluation proves it is
     // defined (e.g. no divide-by-zero and no signed overflow).
     const auto& lhs=*values.at(value.operands[0]);
     const auto& rhs=*values.at(value.operands[1]);
     std::int64_t a=0,b=0,result=0;
     std::function<bool(const SSAValueDefinition&,std::int64_t&)> literal_value;
     literal_value=[&](const SSAValueDefinition& v,std::int64_t& out){
      if(v.op==OpCode::PushInt){out=v.integer;return true;}
      if(v.op==OpCode::BoolNot&&v.operands.size()==1){const auto it=values.find(v.operands[0]);if(it==values.end())return false;std::int64_t x=0;if(!literal_value(*it->second,x))return false;out=x==0?1:0;return true;}
      if(binary(v.op)&&v.operands.size()==2){const auto l=values.find(v.operands[0]),r=values.find(v.operands[1]);if(l==values.end()||r==values.end())return false;std::int64_t x=0,y=0;if(!literal_value(*l->second,x)||!literal_value(*r->second,y))return false;return evaluate(v.op,x,y,out);}
      return false;
     };
     if(!literal_value(lhs,a)||!literal_value(rhs,b)||!evaluate(op,a,b,result))return false;
     expression_instructions.push_back(value.instruction);return true;
    }
    return false;
   };
  if(!collect_constant_tree(store_use->value,store_at))continue;
  // A branch may enter at the first instruction of the whole expression: the
  // expression and Store are removed together and the edge is remapped to the
  // next instruction. Branches into an interior producer remain a hard stop.
  const auto expression_begin=*std::min_element(expression_instructions.begin(),expression_instructions.end());
  bool interior_target=false;
  for(auto instruction:expression_instructions)if(targets[instruction]&&instruction!=expression_begin)interior_target=true;
  if(interior_target)continue;
  // The store consumes the computed value; removing the entire constant-only
  // producer tree and Store keeps the operand-stack height unchanged.
  for(auto instruction:expression_instructions)remove[instruction]=true;
  remove[store_at]=true;
  ++removed_stores;
 }
 if(removed_stores==0)return 0;
 std::vector<std::size_t> remap(p.code.size()+1,0);
 std::vector<Instruction> compact;compact.reserve(p.code.size());
 for(std::size_t i=0;i<p.code.size();++i){remap[i]=compact.size();if(!remove[i])compact.push_back(p.code[i]);}
 remap[p.code.size()]=compact.size();
 instructions_removed=p.code.size()-compact.size();
 if(instructions_removed==0)return 0;
 for(auto& ins:compact)
  if((ins.op==OpCode::Jump||ins.op==OpCode::JumpIfZero)&&ins.integer>=0&&
     static_cast<std::uint64_t>(ins.integer)<=p.code.size())
   ins.integer=static_cast<std::int64_t>(remap[static_cast<std::size_t>(ins.integer)]);
 p.code=std::move(compact);
 return removed_stores;
}

OptimizationStats optimize_ir(ProgramIR& p){
 OptimizationStats s; s.instructions_before=p.code.size();
 // O3 jump threading reduces redundant unconditional branch hops before CFG cleanup.
 s.jump_threads = thread_jumps(p);
 // O2 CFG reachability cleanup.
 s.unreachable_instructions_removed += eliminate_unreachable(p);
 // O3 constant-branch folding: a literal condition immediately consumed by
 // JumpIfZero can be resolved without evaluating or suppressing side effects.
 {
  const auto count = p.code.size();
  std::vector<bool> targets(count + 1, false);
  for (const auto& x : p.code)
   if ((x.op == OpCode::Jump || x.op == OpCode::JumpIfZero) && x.integer >= 0 &&
       static_cast<std::uint64_t>(x.integer) <= count)
    targets[static_cast<std::size_t>(x.integer)] = true;
  std::vector<Instruction> folded; folded.reserve(count);
  std::vector<std::size_t> remap(count + 1, 0);
  for (std::size_t i = 0; i < count;) {
   remap[i] = folded.size();
   if (i + 1 < count && !targets[i] && !targets[i + 1] &&
       p.code[i].op == OpCode::PushInt && p.code[i + 1].op == OpCode::JumpIfZero &&
       p.code[i + 1].integer >= 0 && static_cast<std::uint64_t>(p.code[i + 1].integer) <= count) {
    if (p.code[i].integer == 0) {
     folded.push_back({OpCode::Jump, {}, p.code[i + 1].integer, p.code[i + 1].line});
     ++s.constant_branches_folded;
    } else {
     ++s.constant_branches_folded;
    }
    remap[i + 1] = folded.size();
    i += 2;
    continue;
   }
   folded.push_back(p.code[i]); ++i;
  }
  remap[count] = folded.size();
  for (auto& x : folded)
   if ((x.op == OpCode::Jump || x.op == OpCode::JumpIfZero) && x.integer >= 0 &&
       static_cast<std::uint64_t>(x.integer) <= count)
    x.integer = static_cast<std::int64_t>(remap[static_cast<std::size_t>(x.integer)]);
  if (s.constant_branches_folded != 0) p.code = std::move(folded);
 }
 // Branch folding can make additional blocks unreachable.
 s.unreachable_instructions_removed += eliminate_unreachable(p);
 const auto n=p.code.size();
 std::vector<bool> targets(n+1,false);
 for(const auto& x:p.code) if((x.op==OpCode::Jump||x.op==OpCode::JumpIfZero)&&x.integer>=0&&static_cast<std::uint64_t>(x.integer)<=n)targets[static_cast<std::size_t>(x.integer)]=true;
 std::vector<Instruction> out;out.reserve(n);std::vector<std::size_t> remap(n+1,0);
 std::vector<std::size_t> block_for; auto blocks=build_blocks(p,block_for); auto known_at=analyze_constants(p,blocks);
 for(std::size_t i=0;i<n;){remap[i]=out.size();
  const auto& current=p.code[i];
  if(current.op==OpCode::Load && i<known_at.size()){
   auto found=known_at[i].find(current.operand);
   if(found!=known_at[i].end() && found->second.kind==LatticeKind::Constant){
    out.push_back({OpCode::PushInt,{},found->second.value,current.line});
    ++s.constant_propagations; ++i; continue;
   }
  }
  // O2 local unary folding: only fold a literal immediately consumed by a
  // side-effect-free unary opcode. Branch targets are never removed.
  if(i+1<n&&!targets[i+1]&&p.code[i].op==OpCode::PushInt&&p.code[i+1].op==OpCode::BoolNot){
   remap[i+1]=out.size();
   out.push_back({OpCode::PushInt,{},p.code[i].integer==0?1:0,p.code[i+1].line});
   ++s.constants_folded;i+=2;continue;
  }
  if(i+2<n&&!targets[i+1]&&!targets[i+2]&&p.code[i].op==OpCode::PushInt&&p.code[i+1].op==OpCode::PushInt&&binary(p.code[i+2].op)){
   std::int64_t v{};if(evaluate(p.code[i+2].op,p.code[i].integer,p.code[i+1].integer,v)){remap[i+1]=out.size();remap[i+2]=out.size();out.push_back({OpCode::PushInt,{},v,p.code[i+2].line});++s.constants_folded;i+=3;continue;}}
  // Safe identities when the literal is the right operand on the stack.
  // Never remove a potentially effectful left operand.
  if(i+1<n&&!targets[i]&&!targets[i+1]&&p.code[i].op==OpCode::PushInt){
   const auto op=p.code[i+1].op; const auto value=p.code[i].integer;
   const bool identity=((op==OpCode::Add||op==OpCode::Sub)&&value==0)||
                       ((op==OpCode::Mul||op==OpCode::Div)&&value==1);
   if(identity){remap[i+1]=out.size();++s.algebraic_simplifications;i+=2;continue;}
  }
  // Commutative identities when a literal precedes a simple variable load.
  // Restrict the producer to Load so removing the literal cannot reorder or
  // suppress calls, mutations, or other effectful expressions.
  if(i+2<n&&!targets[i]&&!targets[i+1]&&!targets[i+2]&&
     p.code[i].op==OpCode::PushInt&&p.code[i+1].op==OpCode::Load){
   const auto op=p.code[i+2].op; const auto value=p.code[i].integer;
   const bool identity=(op==OpCode::Add&&value==0)||(op==OpCode::Mul&&value==1);
   if(identity){remap[i+1]=out.size();out.push_back(p.code[i+1]);remap[i+2]=out.size();++s.algebraic_simplifications;i+=3;continue;}
  }
  out.push_back(p.code[i]);++i;
 }
 remap[n]=out.size();
 for(auto& x:out)if(x.op==OpCode::Jump||x.op==OpCode::JumpIfZero)if(x.integer>=0&&static_cast<std::uint64_t>(x.integer)<=n)x.integer=static_cast<std::int64_t>(remap[static_cast<std::size_t>(x.integer)]);
 p.code=std::move(out);
 // SSA O4: eliminate repeated pure expressions within a single basic block,
 // then remove unobserved literal-only local stores.
 s.ssa_gvn_eliminations = run_ssa_gvn(p, s.ssa_gvn_cross_block_eliminations);
 s.ssa_memory_load_eliminations = run_ssa_memory_read_cse(p, s.ssa_memory_load_cross_block_eliminations);
 s.ssa_heap_stores_removed = run_ssa_heap_dead_store_elimination(p);
 s.ssa_dead_stores_removed = eliminate_ssa_dead_stores(p, s.ssa_global_dce_instructions_removed);
 s.instructions_after=p.code.size();return s;
}
}
