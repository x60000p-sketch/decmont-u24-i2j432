#include "docmont/gles_runtime.hpp"
namespace docmont::gpu {
GlesDeviceInfo probe_gles(){GlesDeviceInfo r;r.detail="dynamic EGL/OpenGL ES backend is currently implemented for Linux/Unix builds";return r;}
GlesFrame render_triangle_offscreen(std::uint32_t w,std::uint32_t h){GlesFrame r;r.width=w;r.height=h;r.error="EGL/OpenGL ES offscreen renderer is unavailable on this build target";return r;}
GpuTensorResult compute_matmul(const std::vector<float>&,std::uint32_t,std::uint32_t,const std::vector<float>&,std::uint32_t,bool){GpuTensorResult r;r.error="OpenGL ES compute backend is unavailable on this build target";return r;}
GpuTensorResult compute_binary(const std::vector<float>&,const std::vector<float>&,TensorBinaryOp){GpuTensorResult r;r.error="OpenGL ES compute backend is unavailable on this build target";return r;}
GpuTensorResult compute_softmax(const std::vector<float>&,std::uint32_t,std::uint32_t){GpuTensorResult r;r.error="OpenGL ES compute backend is unavailable on this build target";return r;}
}
