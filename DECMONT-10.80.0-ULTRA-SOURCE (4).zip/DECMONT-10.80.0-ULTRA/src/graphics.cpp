#include "docmont/graphics.hpp"
#include <algorithm>
#include <cstdlib>
#include <fstream>
namespace docmont {
Canvas::Canvas(int w, int h, Color bg) : width_(w), height_(h) {
    if (w <= 0 || h <= 0 || static_cast<long long>(w)*h > 64000000LL) { width_=height_=0; return; }
    pixels_.assign(static_cast<std::size_t>(w)*static_cast<std::size_t>(h), bg);
}
void Canvas::pixel(int x,int y,Color c) { if(x>=0&&y>=0&&x<width_&&y<height_) pixels_[static_cast<std::size_t>(y)*width_+x]=c; }
void Canvas::fill_rect(int x,int y,int w,int h,Color c) {
    if(w<=0||h<=0) return;
    const int x0=std::max(0,x), y0=std::max(0,y);
    const int x1=static_cast<int>(std::min<long long>(width_,static_cast<long long>(x)+w));
    const int y1=static_cast<int>(std::min<long long>(height_,static_cast<long long>(y)+h));
    for(int py=y0;py<y1;++py) for(int px=x0;px<x1;++px) pixel(px,py,c);
}
void Canvas::line(int x0,int y0,int x1,int y1,Color c) {
    const int dx=std::abs(x1-x0), sx=x0<x1?1:-1, dy=-std::abs(y1-y0), sy=y0<y1?1:-1; int err=dx+dy;
    for(;;){pixel(x0,y0,c);if(x0==x1&&y0==y1)break;const int e2=2*err;if(e2>=dy){err+=dy;x0+=sx;}if(e2<=dx){err+=dx;y0+=sy;}}
}
void Canvas::circle(int cx,int cy,int r,Color c) {
    if(r<0||r>100000) return;
    int x=r,y=0,err=0;
    while(x>=y){pixel(cx+x,cy+y,c);pixel(cx+y,cy+x,c);pixel(cx-y,cy+x,c);pixel(cx-x,cy+y,c);pixel(cx-x,cy-y,c);pixel(cx-y,cy-x,c);pixel(cx+y,cy-x,c);pixel(cx+x,cy-y,c);++y;if(err<=0)err+=2*y+1;if(err>0){--x;err-=2*x+1;}}
}
bool Canvas::write_ppm(const std::string& path) const {
    if(width_<=0||height_<=0) return false;
    std::ofstream out(path,std::ios::binary);
    if(!out) return false;
    out<<"P6\n"<<width_<<" "<<height_<<"\n255\n";for(const auto& p:pixels_){out.put(static_cast<char>(p.r));out.put(static_cast<char>(p.g));out.put(static_cast<char>(p.b));}return static_cast<bool>(out);
}
}
