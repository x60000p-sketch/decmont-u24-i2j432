#include "docmont/compiler_core.hpp"

#include <algorithm>
#include <sstream>
#include <unordered_set>

namespace docmont::core {

static const char* kind_name(TypeKind kind) {
    switch (kind) {
        case TypeKind::Unit: return "unit"; case TypeKind::Bool: return "bool";
        case TypeKind::I32: return "i32"; case TypeKind::I64: return "i64";
        case TypeKind::U32: return "u32"; case TypeKind::U64: return "u64";
        case TypeKind::F32: return "f32"; case TypeKind::F64: return "f64";
        case TypeKind::String: return "string"; case TypeKind::Named: return "named";
        case TypeKind::GenericParameter: return "generic"; case TypeKind::Tuple: return "tuple";
        case TypeKind::Reference: return "ref"; case TypeKind::MutableReference: return "mutref";
        case TypeKind::Array: return "array"; case TypeKind::Option: return "option";
        case TypeKind::Result: return "result"; case TypeKind::Function: return "fn";
        case TypeKind::Enum: return "enum";
    }
    return "invalid";
}

TypeContext::TypeContext() {
    for (auto kind : {TypeKind::Unit, TypeKind::Bool, TypeKind::I32, TypeKind::I64,
                      TypeKind::U32, TypeKind::U64, TypeKind::F32, TypeKind::F64,
                      TypeKind::String}) {
        Type type; type.kind = kind;
        primitives_[kind] = intern(std::move(type));
    }
}

std::string TypeContext::key(const Type& type) const {
    std::ostringstream out;
    out << static_cast<unsigned>(type.kind) << ':' << type.name << ':' << type.array_length;
    for (auto arg : type.arguments) out << ':' << arg;
    return out.str();
}

TypeId TypeContext::intern(Type type) {
    auto k = key(type);
    if (auto found = ids_.find(k); found != ids_.end()) return found->second;
    const auto id = static_cast<TypeId>(types_.size() + 1);
    types_.push_back(std::move(type)); ids_.emplace(std::move(k), id); return id;
}

TypeId TypeContext::primitive(TypeKind kind) const {
    auto it = primitives_.find(kind); return it == primitives_.end() ? 0 : it->second;
}
TypeId TypeContext::named(std::string name) { Type t; t.kind=TypeKind::Named; t.name=std::move(name); return intern(std::move(t)); }
TypeId TypeContext::enumeration(std::string name) { Type t; t.kind=TypeKind::Enum; t.name=std::move(name); return intern(std::move(t)); }
TypeId TypeContext::generic_parameter(std::string name) { Type t; t.kind=TypeKind::GenericParameter; t.name=std::move(name); return intern(std::move(t)); }
TypeId TypeContext::tuple(std::vector<TypeId> fields) { Type t; t.kind=TypeKind::Tuple; t.arguments=std::move(fields); return intern(std::move(t)); }
TypeId TypeContext::reference(TypeId target, bool mut) { Type t; t.kind=mut?TypeKind::MutableReference:TypeKind::Reference; t.arguments={target}; return intern(std::move(t)); }
TypeId TypeContext::array(TypeId element, std::uint64_t length) { Type t; t.kind=TypeKind::Array; t.arguments={element}; t.array_length=length; return intern(std::move(t)); }
TypeId TypeContext::option(TypeId value) { Type t; t.kind=TypeKind::Option; t.arguments={value}; return intern(std::move(t)); }
TypeId TypeContext::result(TypeId ok, TypeId error) { Type t; t.kind=TypeKind::Result; t.arguments={ok,error}; return intern(std::move(t)); }
TypeId TypeContext::function(std::vector<TypeId> params, TypeId result_type) { Type t; t.kind=TypeKind::Function; t.arguments=std::move(params); t.arguments.push_back(result_type); return intern(std::move(t)); }
const Type* TypeContext::get(TypeId id) const noexcept { return id && id <= types_.size() ? &types_[id-1] : nullptr; }
TypeId TypeContext::substitute(TypeId id, const std::unordered_map<std::string, TypeId>& substitutions) {
    const auto* ptr=get(id); if(!ptr)return 0; const Type original=*ptr;
    if(original.kind==TypeKind::GenericParameter){auto it=substitutions.find(original.name);return it==substitutions.end()?id:it->second;}
    if(original.arguments.empty())return id;
    std::vector<TypeId> args;args.reserve(original.arguments.size());bool changed=false;
    for(auto child:original.arguments){auto replaced=substitute(child,substitutions);args.push_back(replaced);changed=changed||replaced!=child;}
    if(!changed)return id;
    switch(original.kind){
      case TypeKind::Tuple:return tuple(std::move(args));
      case TypeKind::Reference:return reference(args[0],false);
      case TypeKind::MutableReference:return reference(args[0],true);
      case TypeKind::Array:return array(args[0],original.array_length);
      case TypeKind::Option:return option(args[0]);
      case TypeKind::Result:return result(args[0],args[1]);
      case TypeKind::Function:{auto ret=args.back();args.pop_back();return function(std::move(args),ret);}
      default:return id;
    }
}
bool TypeContext::contains_generic_parameter(TypeId id) const {
    const auto* type=get(id);if(!type)return false;if(type->kind==TypeKind::GenericParameter)return true;
    for(auto child:type->arguments) if(contains_generic_parameter(child)) return true;
    return false;
}
std::string TypeContext::display(TypeId id) const {
    const auto* t=get(id); if(!t)return "<invalid-type>";
    if(t->kind==TypeKind::Named||t->kind==TypeKind::GenericParameter)return t->name;
    if(t->kind==TypeKind::Reference||t->kind==TypeKind::MutableReference)return std::string(t->kind==TypeKind::MutableReference?"&mut ":"&")+display(t->arguments.at(0));
    if(t->kind==TypeKind::Array)return "["+display(t->arguments.at(0))+"; "+std::to_string(t->array_length)+"]";
    if(t->kind==TypeKind::Option)return "Option<"+display(t->arguments.at(0))+">";
    if(t->kind==TypeKind::Result)return "Result<"+display(t->arguments.at(0))+", "+display(t->arguments.at(1))+">";
    if(t->kind==TypeKind::Tuple||t->kind==TypeKind::Function){std::string s=t->kind==TypeKind::Function?"fn(":"(";for(std::size_t i=0;i<t->arguments.size();++i){if(i)s+=", ";s+=display(t->arguments[i]);}return s+(t->kind==TypeKind::Function?")":")");}
    return kind_name(t->kind);
}

SolverResult TraitSolver::define_trait(TraitDefinition trait) {
    if(trait.name.empty())return {false,"trait name is empty"};
    std::unordered_set<std::string> seen;
    for(const auto& method:trait.required_methods){if(method.name.empty()||method.signature.empty())return {false,"trait method name and signature are required"};if(!seen.insert(method.name).second)return {false,"duplicate trait method: "+method.name};}
    if(traits_.contains(trait.name))return {false,"trait already defined: "+trait.name};
    traits_.emplace(trait.name,std::move(trait));return {};
}
SolverResult TraitSolver::add_implementation(TraitImplementation implementation) {
    auto trait=traits_.find(implementation.trait_name);if(trait==traits_.end())return {false,"unknown trait: "+implementation.trait_name};
    if(!implementation.for_type)return {false,"implementation has invalid type id"};
    for(const auto& current:implementations_)if(current.trait_name==implementation.trait_name&&current.for_type==implementation.for_type)return {false,"conflicting trait implementation"};
    for(const auto& required:trait->second.required_methods){auto method=implementation.methods.find(required.name);if(method==implementation.methods.end())return {false,"implementation is missing method: "+required.name};if(method->second!=required.signature)return {false,"signature mismatch for trait method: "+required.name};}
    for(const auto& method:implementation.methods){auto required=std::find_if(trait->second.required_methods.begin(),trait->second.required_methods.end(),[&](const auto& item){return item.name==method.first;});if(required==trait->second.required_methods.end())return {false,"implementation has unknown method: "+method.first};}
    implementations_.push_back(std::move(implementation));return {};
}
SolverResult TraitSolver::satisfies(TypeId type,const std::string& trait_name) const {
    if(!traits_.contains(trait_name))return {false,"unknown trait: "+trait_name};
    for(const auto& impl:implementations_)if(impl.for_type==type&&impl.trait_name==trait_name)return {};
    return {false,"type does not implement trait '"+trait_name+"'"};
}

GenericInstantiation GenericSolver::instantiate(const GenericFunction& fn,const std::unordered_map<std::string,TypeId>& substitutions) {
    GenericInstantiation out;out.specialization_name=fn.name;
    std::unordered_map<std::string,TypeId> checked;
    std::unordered_set<std::string> parameter_names;
    for(const auto& param:fn.type_parameters){if(!parameter_names.insert(param.name).second){out.message="duplicate generic parameter: "+param.name;return out;}auto it=substitutions.find(param.name);if(it==substitutions.end()||!it->second){out.message="missing generic type argument: "+param.name;return out;}if(!types_.get(it->second)){out.message="invalid TypeId for generic argument: "+param.name;return out;}checked[param.name]=it->second;out.specialization_name+="$"+std::to_string(it->second);for(const auto& trait:param.required_traits){auto result=traits_.satisfies(it->second,trait);if(!result.ok){out.message="generic constraint failed for "+param.name+": "+result.message;return out;}}}
    if(checked.size()!=substitutions.size()){out.message="unexpected generic type argument";return out;}
    out.concrete_parameters.reserve(fn.parameter_types.size());for(auto id:fn.parameter_types){if(!types_.get(id)){out.message="generic function contains an invalid parameter TypeId";return out;}auto concrete=types_.substitute(id,checked);if(!concrete||types_.contains_generic_parameter(concrete)){out.message="generic parameter type remains unresolved after substitution";return out;}out.concrete_parameters.push_back(concrete);}
    if(!types_.get(fn.return_type)){out.message="generic function contains an invalid return TypeId";return out;}
    out.concrete_return=types_.substitute(fn.return_type,checked);if(!out.concrete_return||types_.contains_generic_parameter(out.concrete_return)){out.message="generic return type remains unresolved after substitution";return out;}
    out.ok=true;out.message="generic constraints satisfied";specializations_.insert(out.specialization_name);return out;
}

PatternCheck check_enum_patterns(const EnumDefinition& def,const std::vector<Pattern>& patterns) {
    PatternCheck result;std::set<std::string> expected(def.variants.begin(),def.variants.end()),seen;bool wildcard=false;
    for(const auto& p:patterns){if(p.kind==Pattern::Kind::Wildcard){wildcard=true;continue;}if(!expected.contains(p.variant)){result.unknown_variants.push_back(p.variant);continue;}if(!seen.insert(p.variant).second)result.duplicate_variants.push_back(p.variant);}
    if(!wildcard)for(const auto& variant:expected)if(!seen.contains(variant))result.missing_variants.push_back(variant);
    result.exhaustive=result.unknown_variants.empty()&&result.duplicate_variants.empty()&&(wildcard||result.missing_variants.empty());return result;
}

std::vector<CoreDiagnostic> verify_typed_hir(const TypedHIRModule& module,const TypeContext& types) {
    std::vector<CoreDiagnostic> ds;std::unordered_set<std::string> names;
    for(const auto& fn:module.functions){if(fn.name.empty())ds.push_back({"HIR001","function name is empty"});if(!names.insert(fn.name).second)ds.push_back({"HIR002","duplicate function: "+fn.name});if(!types.get(fn.return_type))ds.push_back({"HIR003","function has invalid return type: "+fn.name});std::unordered_set<std::string> locals;auto check=[&](const HIRLocal& local){if(local.name.empty())ds.push_back({"HIR004","local name is empty in "+fn.name});if(!locals.insert(local.name).second)ds.push_back({"HIR005","duplicate local: "+local.name});if(!types.get(local.type))ds.push_back({"HIR006","local has invalid TypeId: "+local.name});};for(const auto& p:fn.parameters)check(p);for(const auto& l:fn.locals)check(l);if(fn.return_type&&types.get(fn.return_type)&&types.get(fn.return_type)->kind==TypeKind::Unit&&fn.has_return_value)ds.push_back({"HIR007","unit function cannot declare a value return: "+fn.name});}
    return ds;
}

std::vector<CoreDiagnostic> verify_mir(const MIRModule& module,const TypeContext& types) {
    std::vector<CoreDiagnostic> ds;
    for(const auto& fn:module.functions){std::unordered_set<std::uint32_t> ids;for(const auto& block:fn.blocks)if(!ids.insert(block.id).second)ds.push_back({"MIR001","duplicate basic block id in "+fn.name});if(!ids.contains(fn.entry))ds.push_back({"MIR002","entry block is missing in "+fn.name});for(const auto& block:fn.blocks){for(auto successor:block.successors)if(!ids.contains(successor))ds.push_back({"MIR003","successor block does not exist in "+fn.name});for(const auto& op:block.operations){if((op.kind==MIROpKind::Declare||op.kind==MIROpKind::Write)&&!types.get(op.type))ds.push_back({"MIR004","typed MIR write has invalid type in "+fn.name});if(op.place.empty())ds.push_back({"MIR005","MIR operation has empty place in "+fn.name});if((op.kind==MIROpKind::BorrowShared||op.kind==MIROpKind::BorrowMutable||op.kind==MIROpKind::EndBorrow)&&op.loan.empty())ds.push_back({"MIR006","borrow operation has empty loan id in "+fn.name});}}
      if(fn.native_integer_supported){std::unordered_set<std::string> values;bool returned=false;for(const auto& op:fn.native_integer_ops){if(returned){ds.push_back({"MIR007","native integer MIR contains operations after return in "+fn.name});break;}switch(op.kind){case MIRValueOpKind::ConstantI64:if(op.result.empty()||!values.insert(op.result).second)ds.push_back({"MIR008","native MIR constant has empty or duplicate result in "+fn.name});break;case MIRValueOpKind::AddI64:case MIRValueOpKind::SubI64:case MIRValueOpKind::MulI64:if(op.result.empty()||!values.insert(op.result).second)ds.push_back({"MIR009","native MIR arithmetic has empty or duplicate result in "+fn.name});if(!values.contains(op.lhs)||!values.contains(op.rhs))ds.push_back({"MIR010","native MIR arithmetic uses an undefined value in "+fn.name});break;case MIRValueOpKind::ReturnI64:if(!values.contains(op.lhs))ds.push_back({"MIR011","native MIR return uses an undefined value in "+fn.name});returned=true;break;}}if(fn.native_integer_ops.empty()||fn.native_integer_ops.back().kind!=MIRValueOpKind::ReturnI64)ds.push_back({"MIR012","native integer MIR must end with return in "+fn.name});}
    }
    return ds;
}

} // namespace docmont::core
