#pragma once
#include "docmont/gpu_runtime.hpp"
namespace docmont::gpu {
BackendStatus probe_d3d12_native();
BackendStatus probe_metal_native();
}
