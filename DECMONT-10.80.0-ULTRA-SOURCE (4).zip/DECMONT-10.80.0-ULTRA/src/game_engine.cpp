#include "docmont/game_engine.hpp"
#include "docmont/platform_contract.hpp"
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstring>
#include <limits>
#include <queue>
#include <set>
#include <tuple>
#include <unordered_set>

namespace docmont::game {
namespace {
AssetId stable_asset_id(std::string_view name) {
    std::uint64_t hash = 1469598103934665603ULL;
    for (unsigned char c : name) { hash ^= c; hash *= 1099511628211ULL; }
    return hash == 0 ? 1 : hash;
}
bool finite(math::Vec3 v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); }
float distance_squared(math::Vec3 a, math::Vec3 b) {
    const auto d = a - b;
    return math::dot(d, d);
}
std::uint32_t crc32(std::span<const std::uint8_t> bytes) {
    std::uint32_t crc = 0xffffffffU;
    for (auto byte : bytes) {
        crc ^= byte;
        for (int bit = 0; bit < 8; ++bit) crc = (crc >> 1U) ^ (0xedb88320U & (0U - (crc & 1U)));
    }
    return ~crc;
}
void put_u16(std::vector<std::uint8_t>& out, std::uint16_t value) {
    out.push_back(static_cast<std::uint8_t>(value >> 8U)); out.push_back(static_cast<std::uint8_t>(value));
}
void put_u32(std::vector<std::uint8_t>& out, std::uint32_t value) {
    for (int shift = 24; shift >= 0; shift -= 8) out.push_back(static_cast<std::uint8_t>(value >> shift));
}
void put_u64(std::vector<std::uint8_t>& out, std::uint64_t value) {
    for (int shift = 56; shift >= 0; shift -= 8) out.push_back(static_cast<std::uint8_t>(value >> shift));
}
bool get_u16(std::span<const std::uint8_t> in, std::size_t& offset, std::uint16_t& value) {
    if (offset + 2 > in.size()) return false;
    value = static_cast<std::uint16_t>((static_cast<std::uint16_t>(in[offset]) << 8U) | in[offset + 1]); offset += 2; return true;
}
bool get_u32(std::span<const std::uint8_t> in, std::size_t& offset, std::uint32_t& value) {
    if (offset + 4 > in.size()) return false;
    value = 0; for (int i = 0; i < 4; ++i) value = (value << 8U) | in[offset++]; return true;
}
bool get_u64(std::span<const std::uint8_t> in, std::size_t& offset, std::uint64_t& value) {
    if (offset + 8 > in.size()) return false;
    value = 0; for (int i = 0; i < 8; ++i) value = (value << 8U) | in[offset++]; return true;
}
}

AssetId AssetCatalog::register_asset(std::string name, AssetKind kind, std::string source_path, std::string content_hash) {
    if (name.empty()) throw std::invalid_argument("asset name must not be empty");
    if (by_name_.count(name)) throw std::invalid_argument("asset name already registered");
    const auto id = stable_asset_id(name);
    if (by_id_.count(id)) throw std::invalid_argument("asset identifier collision");
    AssetRecord record{id, std::move(name), kind, std::move(source_path), std::move(content_hash), AssetState::Registered, {}};
    by_name_.emplace(record.name, id);
    by_id_.emplace(id, std::move(record));
    return id;
}
bool AssetCatalog::add_dependency(AssetId asset, AssetId dependency) {
    auto it = by_id_.find(asset); if (it == by_id_.end() || !by_id_.count(dependency) || asset == dependency) return false;
    auto& deps = it->second.dependencies;
    if (std::find(deps.begin(), deps.end(), dependency) != deps.end()) return false;
    deps.push_back(dependency); std::sort(deps.begin(), deps.end()); return true;
}
bool AssetCatalog::set_state(AssetId asset, AssetState state) {
    auto it = by_id_.find(asset); if (it == by_id_.end()) return false; it->second.state = state; return true;
}
const AssetRecord* AssetCatalog::find(AssetId id) const noexcept {
    const auto it = by_id_.find(id); return it == by_id_.end() ? nullptr : &it->second;
}
const AssetRecord* AssetCatalog::find(std::string_view name) const {
    const auto it = by_name_.find(std::string(name)); return it == by_name_.end() ? nullptr : find(it->second);
}
std::vector<AssetIssue> AssetCatalog::validate() const {
    std::vector<AssetIssue> issues;
    enum class Mark : std::uint8_t { None, Visiting, Done };
    std::unordered_map<AssetId, Mark> marks;
    std::function<void(AssetId)> visit = [&](AssetId id) {
        auto mark = marks[id];
        if (mark == Mark::Done) return;
        if (mark == Mark::Visiting) { issues.push_back({"ASSET_CYCLE", "asset dependency cycle detected at id " + std::to_string(id)}); return; }
        marks[id] = Mark::Visiting;
        const auto* record = find(id);
        if (record) {
            if (record->state == AssetState::Failed) issues.push_back({"ASSET_FAILED", "asset failed validation: " + record->name});
            for (auto dependency : record->dependencies) {
                if (!find(dependency)) issues.push_back({"ASSET_MISSING", "missing dependency id " + std::to_string(dependency)});
                else visit(dependency);
            }
        }
        marks[id] = Mark::Done;
    };
    std::vector<AssetId> ids; ids.reserve(by_id_.size());
    for (const auto& [id, record] : by_id_) { (void)record; ids.push_back(id); }
    std::sort(ids.begin(), ids.end());
    for (auto id : ids) visit(id);
    std::sort(issues.begin(), issues.end(), [](const auto& a, const auto& b) { return std::tie(a.code, a.message) < std::tie(b.code, b.message); });
    issues.erase(std::unique(issues.begin(), issues.end(), [](const auto& a, const auto& b) { return a.code == b.code && a.message == b.message; }), issues.end());
    return issues;
}

std::size_t WorldPartition::CoordHash::operator()(CellCoord c) const noexcept {
    auto mix = [](std::uint32_t x) { std::uint64_t z = x; z = (z ^ (z >> 16U)) * 0x7feb352dU; z = (z ^ (z >> 15U)) * 0x846ca68bU; return z ^ (z >> 16U); };
    const auto a = mix(static_cast<std::uint32_t>(c.x));
    const auto b = mix(static_cast<std::uint32_t>(c.y));
    const auto d = mix(static_cast<std::uint32_t>(c.z));
    return static_cast<std::size_t>(a ^ (b << 1U) ^ (d << 2U));
}
WorldPartition::WorldPartition(float cell_size) : cell_size_(cell_size) {
    if (!std::isfinite(cell_size) || cell_size <= 0.0f) throw std::invalid_argument("world partition cell size must be finite and positive");
}
bool WorldPartition::define_cell(CellCoord coord, std::size_t asset_count) {
    return cells_.emplace(coord, CellInfo{coord, CellState::Unloaded, 0, asset_count}).second;
}
std::vector<CellTransition> WorldPartition::update_focus(math::Vec3 focus, std::int32_t active_radius,
                                                           std::int32_t simulation_radius,
                                                           std::size_t transition_budget,
                                                           std::uint64_t frame) {
    if (!finite(focus) || active_radius < 0 || simulation_radius < active_radius) throw std::invalid_argument("invalid world partition focus or radii");
    const auto cell_axis = [this](float v) {
        const double q = std::floor(static_cast<double>(v) / cell_size_);
        if (q < std::numeric_limits<std::int32_t>::min() || q > std::numeric_limits<std::int32_t>::max()) throw std::out_of_range("world coordinate exceeds cell range");
        return static_cast<std::int32_t>(q);
    };
    const CellCoord center{cell_axis(focus.x), cell_axis(focus.y), cell_axis(focus.z)};
    std::vector<CellCoord> coords; coords.reserve(cells_.size());
    for (const auto& [coord, info] : cells_) { (void)info; coords.push_back(coord); }
    std::sort(coords.begin(), coords.end(), [](auto a, auto b) { return std::tie(a.x,a.y,a.z) < std::tie(b.x,b.y,b.z); });
    std::vector<CellTransition> transitions;
    for (auto coord : coords) {
        if (transitions.size() >= transition_budget) break;
        const auto dx = std::llabs(static_cast<long long>(coord.x) - center.x);
        const auto dy = std::llabs(static_cast<long long>(coord.y) - center.y);
        const auto dz = std::llabs(static_cast<long long>(coord.z) - center.z);
        const auto distance = std::max({dx,dy,dz});
        const auto desired = distance <= active_radius ? CellState::Active :
                             distance <= simulation_radius ? CellState::SimulationOnly : CellState::Dormant;
        auto& info = cells_.at(coord);
        if (info.state != desired) { transitions.push_back({coord, info.state, desired}); info.state = desired; info.last_transition_frame = frame; }
    }
    return transitions;
}
const CellInfo* WorldPartition::find(CellCoord coord) const noexcept {
    const auto it = cells_.find(coord); return it == cells_.end() ? nullptr : &it->second;
}

BodyId PhysicsWorld::add_body(RigidBodyDesc desc) {
    if (!finite(desc.position) || !finite(desc.velocity) || !finite(desc.half_extents) ||
        desc.half_extents.x <= 0 || desc.half_extents.y <= 0 || desc.half_extents.z <= 0 ||
        !std::isfinite(desc.mass) || desc.mass < 0 || !std::isfinite(desc.restitution) || desc.restitution < 0 || desc.restitution > 1)
        throw std::invalid_argument("invalid rigid body description");
    if (next_id_ == 0) throw std::overflow_error("rigid body identifier space exhausted");
    const auto id = next_id_++;
    bodies_.emplace(id, std::move(desc)); return id;
}
bool PhysicsWorld::remove_body(BodyId id) { return bodies_.erase(id) != 0; }
const RigidBodyDesc* PhysicsWorld::body(BodyId id) const noexcept { const auto it=bodies_.find(id); return it==bodies_.end()?nullptr:&it->second; }
RigidBodyDesc* PhysicsWorld::body(BodyId id) noexcept { const auto it=bodies_.find(id); return it==bodies_.end()?nullptr:&it->second; }
PhysicsStepResult PhysicsWorld::step(float dt, math::Vec3 gravity) {
    if (!std::isfinite(dt) || dt <= 0 || dt > 0.25f || !finite(gravity)) throw std::invalid_argument("physics dt must be in (0, 0.25] and gravity must be finite");
    PhysicsStepResult result{};
    std::vector<BodyId> ids; ids.reserve(bodies_.size()); for (const auto& [id, body] : bodies_) { (void)body; ids.push_back(id); }
    std::sort(ids.begin(), ids.end());
    for (auto id : ids) { auto& b=bodies_.at(id); if (b.mass > 0) { b.velocity = b.velocity + gravity*dt; b.position = b.position + b.velocity*dt; ++result.bodies_integrated; } }
    for (std::size_t i=0;i<ids.size();++i) for (std::size_t j=i+1;j<ids.size();++j) {
        auto& a=bodies_.at(ids[i]); auto& b=bodies_.at(ids[j]);
        ++result.broadphase_pairs;
        const auto delta=b.position-a.position;
        const float px=a.half_extents.x+b.half_extents.x-std::abs(delta.x);
        const float py=a.half_extents.y+b.half_extents.y-std::abs(delta.y);
        const float pz=a.half_extents.z+b.half_extents.z-std::abs(delta.z);
        if (px<=0 || py<=0 || pz<=0) continue;
        if (a.mass==0 && b.mass==0) continue;
        ++result.contacts;
        const float inv_a=a.mass>0?1.0f/a.mass:0.0f, inv_b=b.mass>0?1.0f/b.mass:0.0f;
        const float inv_sum=inv_a+inv_b;
        int axis=0; float penetration=px;
        if (py<penetration) {axis=1;penetration=py;} if (pz<penetration) {axis=2;penetration=pz;}
        const float sign = axis==0?(delta.x>=0?1.0f:-1.0f):axis==1?(delta.y>=0?1.0f:-1.0f):(delta.z>=0?1.0f:-1.0f);
        math::Vec3 normal = axis==0?math::Vec3{sign,0,0}:axis==1?math::Vec3{0,sign,0}:math::Vec3{0,0,sign};
        const auto correction=normal*(penetration/inv_sum);
        if(inv_a>0)a.position=a.position-correction*inv_a;
        if(inv_b>0)b.position=b.position+correction*inv_b;
        const float relative=math::dot(b.velocity-a.velocity,normal);
        if(relative<0) {
            const float restitution=std::min(a.restitution,b.restitution);
            const float impulse=-(1.0f+restitution)*relative/inv_sum;
            if(inv_a>0)a.velocity=a.velocity-normal*(impulse*inv_a);
            if(inv_b>0)b.velocity=b.velocity+normal*(impulse*inv_b);
        }
    }
    return result;
}

NavigationGrid::NavigationGrid(std::uint32_t width, std::uint32_t height, float cell_size)
    : width_(width), height_(height), cell_size_(cell_size) {
    if (!width || !height || static_cast<std::uint64_t>(width)*height > 16'000'000ULL || !std::isfinite(cell_size) || cell_size<=0)
        throw std::invalid_argument("invalid navigation grid dimensions or cell size");
    blocked_.resize(static_cast<std::size_t>(width)*height,false); costs_.resize(blocked_.size(),1.0f);
}
std::optional<std::size_t> NavigationGrid::index(GridPoint p) const noexcept {
    if(p.x<0||p.y<0||static_cast<std::uint32_t>(p.x)>=width_||static_cast<std::uint32_t>(p.y)>=height_)return std::nullopt;
    return static_cast<std::size_t>(p.y)*width_+static_cast<std::size_t>(p.x);
}
bool NavigationGrid::set_blocked(GridPoint p,bool blocked){auto i=index(p);if(!i)return false;blocked_[*i]=blocked;return true;}
bool NavigationGrid::set_cost(GridPoint p,float cost){auto i=index(p);if(!i||!std::isfinite(cost)||cost<0.001f||cost>1'000'000.0f)return false;costs_[*i]=cost;return true;}
bool NavigationGrid::walkable(GridPoint p)const noexcept{auto i=index(p);return i&&!blocked_[*i];}
std::optional<std::vector<GridPoint>> NavigationGrid::find_path(GridPoint start,GridPoint goal)const{
    const auto si=index(start),gi=index(goal);if(!si||!gi||blocked_[*si]||blocked_[*gi])return std::nullopt;
    const auto total=blocked_.size();const float infinity=std::numeric_limits<float>::infinity();
    struct Node{float f;std::size_t i;};struct Greater{bool operator()(const Node&a,const Node&b)const{return a.f==b.f?a.i>b.i:a.f>b.f;}};
    std::priority_queue<Node,std::vector<Node>,Greater> open;std::vector<float> g(total,infinity);std::vector<std::size_t> parent(total,total);std::vector<bool> closed(total,false);
    auto point=[this](std::size_t i){return GridPoint{static_cast<std::int32_t>(i%width_),static_cast<std::int32_t>(i/width_)};};
    const float minimum_cost = *std::min_element(costs_.begin(), costs_.end());
    auto h=[&](std::size_t i){auto p=point(i);return static_cast<float>(std::abs(p.x-goal.x)+std::abs(p.y-goal.y))*minimum_cost;};
    g[*si]=0;open.push({h(*si),*si});constexpr std::array<GridPoint,4> dirs{{{0,-1},{-1,0},{1,0},{0,1}}};
    while(!open.empty()){
        auto current=open.top();open.pop();if(closed[current.i])continue;closed[current.i]=true;if(current.i==*gi)break;
        const auto cp=point(current.i);
        for(auto d:dirs){GridPoint np{cp.x+d.x,cp.y+d.y};auto ni=index(np);if(!ni||blocked_[*ni]||closed[*ni])continue;
            const float tentative=g[current.i]+costs_[*ni];if(tentative<g[*ni]){g[*ni]=tentative;parent[*ni]=current.i;open.push({tentative+h(*ni),*ni});}}
    }
    if (!closed[*gi]) return std::nullopt;
    std::vector<GridPoint> path;
    for (std::size_t at=*gi; at!=total; at=parent[at]) { path.push_back(point(at)); if (at==*si) break; }
    if (path.empty() || !(path.back()==start)) return std::nullopt;
    std::reverse(path.begin(),path.end());
    return path;
}

std::optional<UtilityChoice> choose_utility(std::span<const UtilityOption> options) {
    std::optional<UtilityChoice> best;
    for(std::size_t i=0;i<options.size();++i){const auto& option=options[i];if(option.name.empty()||!std::isfinite(option.score))continue;
        if(!best||option.score>best->score)best=UtilityChoice{i,option.name,option.score};}
    return best;
}

BehaviorNodeId BehaviorTree::add_composite(BehaviorKind kind, std::vector<BehaviorNodeId> children) {
    if (kind != BehaviorKind::Sequence && kind != BehaviorKind::Selector) throw std::invalid_argument("invalid behavior composite kind");
    if (children.empty()) throw std::invalid_argument("behavior composite must contain children");
    const auto id = static_cast<BehaviorNodeId>(nodes_.size());
    for (auto child : children) if (child >= id) throw std::invalid_argument("behavior children must be existing nodes");
    nodes_.push_back(Node{kind, kind == BehaviorKind::Sequence ? "sequence" : "selector", std::move(children), {}});
    return id;
}
BehaviorNodeId BehaviorTree::sequence(std::vector<BehaviorNodeId> children) { return add_composite(BehaviorKind::Sequence, std::move(children)); }
BehaviorNodeId BehaviorTree::selector(std::vector<BehaviorNodeId> children) { return add_composite(BehaviorKind::Selector, std::move(children)); }
BehaviorNodeId BehaviorTree::condition(std::string name, std::function<BehaviorStatus()> test) {
    if (name.empty() || !test) throw std::invalid_argument("behavior condition requires a name and callback");
    const auto id = static_cast<BehaviorNodeId>(nodes_.size()); nodes_.push_back(Node{BehaviorKind::Condition, std::move(name), {}, std::move(test)}); return id;
}
BehaviorNodeId BehaviorTree::action(std::string name, std::function<BehaviorStatus()> execute) {
    if (name.empty() || !execute) throw std::invalid_argument("behavior action requires a name and callback");
    const auto id = static_cast<BehaviorNodeId>(nodes_.size()); nodes_.push_back(Node{BehaviorKind::Action, std::move(name), {}, std::move(execute)}); return id;
}
std::optional<std::string> BehaviorTree::validate(BehaviorNodeId root) const {
    if (root >= nodes_.size()) return "behavior root is invalid";
    for (std::size_t i = 0; i < nodes_.size(); ++i) {
        const auto& node = nodes_[i];
        if ((node.kind == BehaviorKind::Sequence || node.kind == BehaviorKind::Selector) && node.children.empty()) return "behavior composite has no children";
        if ((node.kind == BehaviorKind::Condition || node.kind == BehaviorKind::Action) && (!node.callback || !node.children.empty())) return "behavior leaf contract is invalid";
        for (auto child : node.children) if (child >= i) return "behavior graph contains a forward edge or cycle";
    }
    return std::nullopt;
}
BehaviorStatus BehaviorTree::evaluate(BehaviorNodeId id) const {
    const auto& node = nodes_.at(id);
    if (node.kind == BehaviorKind::Condition || node.kind == BehaviorKind::Action) return node.callback();
    if (node.kind == BehaviorKind::Sequence) {
        for (auto child : node.children) { const auto status=evaluate(child); if(status!=BehaviorStatus::Success)return status; }
        return BehaviorStatus::Success;
    }
    for (auto child : node.children) { const auto status=evaluate(child); if(status!=BehaviorStatus::Failure)return status; }
    return BehaviorStatus::Failure;
}
BehaviorStatus BehaviorTree::tick(BehaviorNodeId root) const {
    if (const auto error=validate(root)) throw std::invalid_argument(*error);
    return evaluate(root);
}
std::optional<std::vector<AnimationWeight>> normalize_animation_weights(std::span<const AnimationWeight> weights) {
    if (weights.empty()) return std::nullopt;
    std::vector<AnimationWeight> result; result.reserve(weights.size()); double total=0.0;
    std::unordered_set<std::string> names;
    for (const auto& item : weights) {
        if (item.clip.empty() || !std::isfinite(item.weight) || item.weight<0.0f || !names.insert(item.clip).second) return std::nullopt;
        if (item.weight>0.0f) { result.push_back(item); total+=item.weight; }
    }
    if (total<=0.0) return std::nullopt;
    for (auto& item : result) item.weight=static_cast<float>(static_cast<double>(item.weight)/total);
    return result;
}
WorldClock::WorldClock(double seconds_per_day) : seconds_per_day_(seconds_per_day) {
    if (!std::isfinite(seconds_per_day) || seconds_per_day<=0.0) throw std::invalid_argument("world clock day duration must be finite and positive");
}
void WorldClock::advance(double delta_seconds) {
    if (!std::isfinite(delta_seconds) || delta_seconds<0.0) throw std::invalid_argument("world clock delta must be finite and non-negative");
    day_fraction_=std::fmod(day_fraction_+delta_seconds/seconds_per_day_,1.0);
}
bool WorldClock::set_day_fraction(double fraction) noexcept {
    if (!std::isfinite(fraction) || fraction < 0.0 || fraction >= 1.0) return false;
    day_fraction_ = fraction;
    return true;
}
bool WorldClock::set_weather(float temperature_c,float wind_speed,float precipitation,float cloud_cover) noexcept {
    if(!std::isfinite(temperature_c)||!std::isfinite(wind_speed)||!std::isfinite(precipitation)||!std::isfinite(cloud_cover)||wind_speed<0||precipitation<0||precipitation>1||cloud_cover<0||cloud_cover>1)return false;
    temperature_c_=temperature_c;wind_speed_=wind_speed;precipitation_=precipitation;cloud_cover_=cloud_cover;return true;
}
float WorldClock::sunlight() const noexcept {
    const double phase=(day_fraction_-0.25)*2.0*3.14159265358979323846;
    const float daylight=static_cast<float>(std::max(0.0,std::sin(phase)));
    return daylight*(1.0f-0.65f*cloud_cover_);
}

bool AudioScene::upsert(AudioEmitter emitter) {
    if(!emitter.id||!finite(emitter.position)||!std::isfinite(emitter.gain)||emitter.gain<0||emitter.gain>4||
       !std::isfinite(emitter.min_distance)||!std::isfinite(emitter.max_distance)||emitter.min_distance<0||emitter.max_distance<=emitter.min_distance)return false;
    emitters_[emitter.id]=std::move(emitter);return true;
}
bool AudioScene::remove(std::uint64_t id){return emitters_.erase(id)!=0;}
std::vector<MixedVoice> AudioScene::mix(const AudioListener& listener,std::size_t voice_budget)const{
    if(!finite(listener.position))throw std::invalid_argument("audio listener position must be finite");
    std::vector<MixedVoice> result;result.reserve(emitters_.size());
    for(const auto&[id,e]:emitters_){const float d=std::sqrt(distance_squared(listener.position,e.position));if(d>=e.max_distance)continue;
        const float t=std::clamp((d-e.min_distance)/(e.max_distance-e.min_distance),0.0f,1.0f);
        const float gain=e.gain*(1.0f-t)*(1.0f-t);if(gain>0)result.push_back({id,gain,e.priority,e.looping});}
    std::sort(result.begin(),result.end(),[](const auto&a,const auto&b){if(a.priority!=b.priority)return a.priority>b.priority;if(a.gain!=b.gain)return a.gain>b.gain;return a.id<b.id;});
    if (result.size()>voice_budget) result.resize(voice_budget);
    return result;
}

std::optional<std::vector<std::uint8_t>> SnapshotCodec::encode(std::uint64_t sequence,
                                                                std::span<const ReplicatedTransform> entities,
                                                                std::string* error) {
    auto fail=[&](std::string message)->std::optional<std::vector<std::uint8_t>>{if(error)*error=std::move(message);return std::nullopt;};
    if(entities.size()>1'000'000)return fail("snapshot entity count exceeds limit");
    std::vector<ReplicatedTransform> sorted(entities.begin(),entities.end());
    for(const auto&e:sorted)if(!e.entity||!finite(e.position))return fail("snapshot contains zero entity id or non-finite position");
    std::sort(sorted.begin(),sorted.end(),[](const auto&a,const auto&b){return a.entity<b.entity;});
    for(std::size_t i=1;i<sorted.size();++i)if(sorted[i-1].entity==sorted[i].entity)return fail("snapshot contains duplicate entity id");
    std::vector<std::uint8_t> out;out.reserve(22+sorted.size()*20);out.insert(out.end(),{'D','N','E','T'});put_u16(out,1);put_u64(out,sequence);put_u32(out,static_cast<std::uint32_t>(sorted.size()));
    for(const auto&e:sorted){put_u64(out,e.entity);put_u32(out,std::bit_cast<std::uint32_t>(e.position.x));put_u32(out,std::bit_cast<std::uint32_t>(e.position.y));put_u32(out,std::bit_cast<std::uint32_t>(e.position.z));}
    put_u32(out,crc32(out));if(error)error->clear();return out;
}
CodecResult SnapshotCodec::decode(std::span<const std::uint8_t> bytes,std::size_t max_entities){
    CodecResult result;if(bytes.size()<22){result.error="snapshot packet is shorter than header";return result;}
    if(!(bytes[0]=='D'&&bytes[1]=='N'&&bytes[2]=='E'&&bytes[3]=='T')){result.error="snapshot magic mismatch";return result;}
    const std::size_t payload_end=bytes.size()-4;std::size_t checksum_offset=payload_end;std::uint32_t stored_crc{};
    if(!get_u32(bytes,checksum_offset,stored_crc)||stored_crc!=crc32(bytes.first(payload_end))){result.error="snapshot checksum mismatch";return result;}
    std::size_t offset=4;std::uint16_t version{};std::uint32_t count{};
    if(!get_u16(bytes,offset,version)||version!=1||!get_u64(bytes,offset,result.snapshot.sequence)||!get_u32(bytes,offset,count)){result.error="unsupported or truncated snapshot header";return result;}
    if(count>max_entities||static_cast<std::uint64_t>(offset)+static_cast<std::uint64_t>(count)*20ULL!=payload_end){result.error="snapshot count or packet length is invalid";return result;}
    result.snapshot.entities.reserve(count);std::uint64_t previous=0;
    for(std::uint32_t i=0;i<count;++i){ReplicatedTransform e;std::uint32_t x{},y{},z{};
        if(!get_u64(bytes,offset,e.entity)||!get_u32(bytes,offset,x)||!get_u32(bytes,offset,y)||!get_u32(bytes,offset,z)){result.error="truncated snapshot record";return result;}
        e.position={std::bit_cast<float>(x),std::bit_cast<float>(y),std::bit_cast<float>(z)};
        if(!e.entity||(i&&e.entity<=previous)||!finite(e.position)){result.error="snapshot entity ordering or transform is invalid";return result;}
        previous=e.entity;result.snapshot.entities.push_back(e);
    }
    result.ok=true;return result;
}

std::optional<GraphicsSelection> select_graphics_api(const DeviceCapabilities& caps,std::span<const GraphicsAPI> preference,bool allow_software_fallback){
    for(auto api:preference){bool available=false;switch(api){case GraphicsAPI::Vulkan:available=caps.vulkan;break;case GraphicsAPI::Direct3D12:available=caps.direct3d12;break;case GraphicsAPI::Metal:available=caps.metal;break;case GraphicsAPI::OpenGL:available=caps.opengl;break;case GraphicsAPI::Software:available=true;break;}
        if(api==GraphicsAPI::Software && !allow_software_fallback) continue;
        if(available)return GraphicsSelection{api,api!=GraphicsAPI::Software,api==GraphicsAPI::Software?"software fallback selected":"selected from caller-provided device capability profile"};}
    if(allow_software_fallback)return GraphicsSelection{GraphicsAPI::Software,false,"no preferred hardware API was reported available; CPU/software fallback selected"};
    return std::nullopt;
}

RenderPipelinePlan build_render_pipeline(RenderPath path){
    render::RenderGraph graph;const auto depth=graph.resource("depth");const auto hdr=graph.resource("hdr-color");const auto ldr=graph.resource("ldr-color");const auto swap=graph.resource("swapchain",true);
    if(path==RenderPath::Forward){graph.pass({"depth-prepass",{}, {depth},{}});graph.pass({"forward-shading",{depth},{hdr},{}});}
    else{const auto gbuffer=graph.resource("gbuffer");graph.pass({"gbuffer",{}, {depth,gbuffer},{}});graph.pass({"deferred-lighting",{depth,gbuffer},{hdr},{}});}
    graph.pass({"post-process",{hdr},{ldr},{}});graph.pass({"present",{ldr},{swap},{}});
    const auto compiled=graph.compile();RenderPipelinePlan plan;plan.ok=compiled.ok;plan.error=compiled.error;
    if(compiled.ok){const std::vector<std::string> names=path==RenderPath::Forward?std::vector<std::string>{"depth-prepass","forward-shading","post-process","present"}:std::vector<std::string>{"gbuffer","deferred-lighting","post-process","present"};plan.ordered_passes=names;}
    return plan;
}

FrameProfiler::FrameProfiler(std::size_t history):capacity_(history){if(!history)throw std::invalid_argument("frame profiler history must be non-zero");}
void FrameProfiler::record(FrameMetrics sample){const double values[]={sample.cpu_ms,sample.gpu_ms,sample.physics_ms,sample.ai_ms,sample.audio_ms};for(double v:values)if(!std::isfinite(v)||v<0)throw std::invalid_argument("frame timing values must be finite and non-negative");if(history_.size()==capacity_)history_.erase(history_.begin());history_.push_back(sample);}
std::optional<FrameMetrics> FrameProfiler::latest()const{return history_.empty()?std::nullopt:std::optional<FrameMetrics>(history_.back());}
std::optional<double> FrameProfiler::average_cpu_ms()const{if(history_.empty())return std::nullopt;double total=0;for(const auto&s:history_)total+=s.cpu_ms;return total/static_cast<double>(history_.size());}

ProjectValidation validate_project(const GameProjectConfig& config,const AssetCatalog& assets){
    ProjectValidation result;
    if(config.name.empty())result.errors.push_back("project name must not be empty");
    if(config.asset_schema==0)result.errors.push_back("asset schema version must be non-zero");
    if(config.target.empty())result.errors.push_back("target must not be empty");
    if (!platform::find_target(config.target)) result.errors.push_back("unknown build target: " + config.target);
    for(const auto& issue:assets.validate())result.errors.push_back(issue.code+": "+issue.message);
    result.ok=result.errors.empty();return result;
}

} // namespace docmont::game
