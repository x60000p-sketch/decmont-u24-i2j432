#include "docmont/ssa.hpp"
#include <algorithm>
#include <functional>
#include <map>
#include <optional>
#include <limits>
#include <set>
#include <sstream>
#include <tuple>
#include <unordered_map>
#include <unordered_set>

namespace docmont { namespace {
constexpr std::size_t none = static_cast<std::size_t>(-1);
std::vector<SSABlock> make_cfg(const ProgramIR& p) {
 const auto n=p.code.size(); if(!n) return {};
 std::vector<bool> leader(n,false); leader[0]=true;
 for(std::size_t i=0;i<n;++i){const auto& x=p.code[i];
  if((x.op==OpCode::Jump||x.op==OpCode::JumpIfZero)&&x.integer>=0&&static_cast<std::uint64_t>(x.integer)<n) leader[static_cast<std::size_t>(x.integer)]=true;
  if((x.op==OpCode::Jump||x.op==OpCode::JumpIfZero||x.op==OpCode::Return)&&i+1<n) leader[i+1]=true;
 }
 std::vector<SSABlock> b;
 for(std::size_t i=0;i<n;){std::size_t j=i+1;while(j<n&&!leader[j])++j;SSABlock x;x.id=b.size();x.begin=i;x.end=j;b.push_back(std::move(x));i=j;}
 std::vector<std::size_t> owner(n);for(auto& x:b)for(std::size_t i=x.begin;i<x.end;++i)owner[i]=x.id;
 auto edge=[&](std::size_t from,std::size_t to){if(to>=n)return;auto a=owner[from],z=owner[to];auto& s=b[a].successors;if(std::find(s.begin(),s.end(),z)==s.end()){s.push_back(z);b[z].predecessors.push_back(a);}};
 for(auto& x:b){const auto last=x.end-1;const auto& ins=p.code[last];
  if(ins.op==OpCode::Jump){if(ins.integer>=0)edge(last,static_cast<std::size_t>(ins.integer));}
  else if(ins.op==OpCode::JumpIfZero){if(ins.integer>=0)edge(last,static_cast<std::size_t>(ins.integer));if(x.end<n)edge(last,x.end);}
  else if(ins.op!=OpCode::Return&&x.end<n)edge(last,x.end);
 }
 return b;
}
}

namespace {
struct StackEffect { std::int64_t pop{0}; std::int64_t push{0}; bool terminal{false}; };
bool stack_effect(const Instruction& ins, StackEffect& e) {
 switch (ins.op) {
  case OpCode::PushInt: case OpCode::PushString: case OpCode::Load: case OpCode::LoadCell:
  case OpCode::LoadFunction: case OpCode::NewObject: e.push=1; return true;
  case OpCode::Dup: e.pop=1; e.push=2; return true;
  case OpCode::BoolNot: case OpCode::ArrayLength: case OpCode::ArrayPop:
  case OpCode::ObjectGet: case OpCode::ObjectHas: e.pop=1; e.push=1; return true;
  case OpCode::ArrayGet: e.pop=2; e.push=1; return true;
  case OpCode::ArraySet: e.pop=3; return true;
  case OpCode::ArrayPush: case OpCode::ObjectSet: e.pop=2; e.push=1; return true;
  case OpCode::MakeArray: case OpCode::MakeClosure:
   if (ins.integer < 0) return false;
   e.pop=ins.integer; e.push=1; return true;
  case OpCode::Call:
   if (ins.integer < 0) return false;
   e.pop=ins.integer; e.push=1; return true;
  case OpCode::CallIndirect:
   if (ins.integer < 0 || ins.integer==std::numeric_limits<std::int64_t>::max()) return false;
   e.pop=ins.integer+1; e.push=1; return true;
  case OpCode::Store: case OpCode::Print: case OpCode::JumpIfZero: e.pop=1; return true;
  case OpCode::Add: case OpCode::Sub: case OpCode::Mul: case OpCode::Div:
  case OpCode::Equal: case OpCode::NotEqual: case OpCode::Less: case OpCode::LessEqual:
  case OpCode::Greater: case OpCode::GreaterEqual: case OpCode::LogicalAnd: case OpCode::LogicalOr:
   e.pop=2; e.push=1; return true;
  case OpCode::Return: e.pop=1; e.terminal=true; return true;
  case OpCode::Jump: case OpCode::Function: return true;
 }
 return false;
}
void build_stack_value_ssa(SSAProgram& result, const ProgramIR& p, std::size_t initial_stack_depth) {
 const auto& blocks=result.blocks; const auto count=blocks.size();
 if (count==0) return;
 auto fail=[&](const std::string& message){result.stack_ssa_valid=false;result.stack_ssa_errors.push_back(message);};
 std::vector<bool> reachable(count,false); std::vector<std::size_t> work{0}; reachable[0]=true;
 for (std::size_t i=0;i<work.size();++i) for (auto succ:blocks[work[i]].successors)
  if (succ<count&&!reachable[succ]) {reachable[succ]=true;work.push_back(succ);}
 std::vector<std::int64_t> in_depth(count,-1),out_depth(count,-1); in_depth[0]=static_cast<std::int64_t>(initial_stack_depth);
 work={0};
 while(!work.empty()) {
  const auto bi=work.back();work.pop_back();std::int64_t depth=in_depth[bi];
  for(std::size_t i=blocks[bi].begin;i<blocks[bi].end;++i){StackEffect effect;
   if(!stack_effect(p.code[i],effect)){fail("invalid stack effect at instruction "+std::to_string(i));return;}
   if(depth<effect.pop){fail("operand stack underflow at instruction "+std::to_string(i));return;}
   depth=depth-effect.pop+effect.push;
  }
  out_depth[bi]=depth;
  for(auto succ:blocks[bi].successors) if(succ<count&&reachable[succ]) {
   if(in_depth[succ]<0){in_depth[succ]=depth;work.push_back(succ);}
   else if(in_depth[succ]!=depth){fail("inconsistent operand stack depth at CFG join block "+std::to_string(succ));return;}
  }
 }
 std::unordered_map<std::size_t,std::size_t> load_versions;
 for(const auto& use:result.uses)load_versions[use.instruction]=use.version;
 std::size_t next_id=1;
 std::vector<std::size_t> entry_values;
 for(std::size_t slot=0;slot<initial_stack_depth;++slot) {
  Instruction marker{OpCode::PushInt,{},0,1};
  const auto id=next_id++;
  SSAValueDefinition entry; entry.id=id; entry.instruction=static_cast<std::size_t>(-1);
  entry.block=0; entry.op=OpCode::PushInt; entry.kind=SSAValueKind::Entry;
  entry.text="<argument-stack-"+std::to_string(slot)+">";
  result.value_definitions.push_back(std::move(entry)); entry_values.push_back(id);
 }
 std::vector<std::vector<std::size_t>> outgoing(count);
 std::vector<bool> processed(count,false);
 std::vector<std::vector<std::size_t>> reachable_preds(count);
 for(std::size_t bi=0;bi<count;++bi) if(reachable[bi])
  for(auto pred:blocks[bi].predecessors) if(pred<count&&reachable[pred])reachable_preds[bi].push_back(pred);
 std::vector<std::vector<std::size_t>> phi_ids(count);
 auto add_definition=[&](std::size_t instruction,std::size_t block,const Instruction& ins,
                         const std::vector<std::size_t>& operands,SSAValueKind kind=SSAValueKind::Instruction){
  SSAValueDefinition d;d.id=next_id++;d.instruction=instruction;d.block=block;d.op=ins.op;d.kind=kind;
  d.integer=ins.integer;d.text=ins.operand;d.operands=operands;
  if(ins.op==OpCode::Load){auto it=load_versions.find(instruction);if(it!=load_versions.end())d.variable_version=it->second;}
  result.value_definitions.push_back(std::move(d));return next_id-1;
 };
 auto add_use=[&](std::size_t instruction,std::size_t value,std::size_t operand){result.value_uses.push_back({instruction,value,operand});};
 bool progress=true;
 while(progress){progress=false;
  for(std::size_t bi=0;bi<count;++bi){
   if(!reachable[bi]||processed[bi])continue;
   std::vector<std::size_t> stack;
   const auto& preds=reachable_preds[bi];
   if(bi==0){stack=entry_values;}
   else if(preds.empty()){fail("reachable stack-SSA block has no entry predecessor");return;}
   else if(preds.size()==1){if(!processed[preds.front()])continue;stack=outgoing[preds.front()];}
   else {
    const auto depth=static_cast<std::size_t>(std::max<std::int64_t>(0,in_depth[bi]));
    if(phi_ids[bi].empty()&&depth){phi_ids[bi].resize(depth);
     for(std::size_t slot=0;slot<depth;++slot){Instruction marker{OpCode::PushInt,{},0,1};
      const auto id=add_definition(static_cast<std::size_t>(-1),bi,marker,{},SSAValueKind::Phi);
      phi_ids[bi][slot]=id;result.stack_phis.push_back({bi,slot,id,{}});}}
    stack=phi_ids[bi];
   }
   auto pop=[&](std::size_t at,std::size_t operand)->std::size_t{
    if(stack.empty()){fail("operand stack underflow while constructing value SSA");return 0;}
    auto value=stack.back();stack.pop_back();add_use(at,value,operand);return value;
   };
   auto push_new=[&](std::size_t at,const Instruction& ins,std::vector<std::size_t> operands={}){
    const auto id=add_definition(at,bi,ins,operands);for(std::size_t k=0;k<operands.size();++k)add_use(at,operands[k],k);stack.push_back(id);
   };
   for(std::size_t i=blocks[bi].begin;i<blocks[bi].end;++i){const auto& ins=p.code[i];
    switch(ins.op){
     case OpCode::PushInt:case OpCode::PushString:case OpCode::Load:case OpCode::LoadCell:
     case OpCode::LoadFunction:case OpCode::NewObject: push_new(i,ins);break;
     case OpCode::Dup:{if(stack.empty()){fail("dup underflow in stack SSA");return;}add_use(i,stack.back(),0);stack.push_back(stack.back());break;}
     case OpCode::BoolNot:{if(stack.empty()){fail("bool_not underflow in stack SSA");return;}auto a=stack.back();add_use(i,a,0);const auto id=add_definition(i,bi,ins,{a});stack.back()=id;break;}
     case OpCode::Add:case OpCode::Sub:case OpCode::Mul:case OpCode::Div:
     case OpCode::Equal:case OpCode::NotEqual:case OpCode::Less:case OpCode::LessEqual:
     case OpCode::Greater:case OpCode::GreaterEqual:case OpCode::LogicalAnd:case OpCode::LogicalOr:{
      auto rhs=stack.back();stack.pop_back();auto lhs=stack.back();stack.pop_back();const auto id=add_definition(i,bi,ins,{lhs,rhs});stack.push_back(id);add_use(i,lhs,0);add_use(i,rhs,1);break;}
     case OpCode::ArrayGet:{auto index=stack.back();stack.pop_back();auto base=stack.back();stack.pop_back();const auto id=add_definition(i,bi,ins,{base,index});add_use(i,base,0);add_use(i,index,1);stack.push_back(id);break;}
     case OpCode::ArraySet:{(void)pop(i,2);(void)pop(i,1);(void)pop(i,0);if(!result.stack_ssa_valid)return;break;}
     case OpCode::ArrayLength:case OpCode::ArrayPop:case OpCode::ObjectGet:case OpCode::ObjectHas:{if(stack.empty()){fail("unary stack operation underflow");return;}auto base=stack.back();add_use(i,base,0);const auto id=add_definition(i,bi,ins,{base});stack.back()=id;break;}
     case OpCode::ArrayPush:{auto value=pop(i,1);if(!result.stack_ssa_valid||stack.empty()){fail("array_push underflow in stack SSA");return;}auto base=stack.back();add_use(i,base,0);const auto id=add_definition(i,bi,ins,{base,value});stack.back()=id;break;}
     case OpCode::ObjectSet:{(void)pop(i,1);if(!result.stack_ssa_valid||stack.empty()){fail("object_set underflow in stack SSA");return;}auto base=stack.back();add_use(i,base,0);break;}
     case OpCode::MakeArray:case OpCode::MakeClosure:{std::vector<std::size_t> operands;operands.reserve(static_cast<std::size_t>(ins.integer));
      for(std::int64_t k=0;k<ins.integer;++k){if(stack.empty()){fail("aggregate construction underflow");return;}operands.push_back(stack.back());stack.pop_back();}
      std::reverse(operands.begin(),operands.end());push_new(i,ins,std::move(operands));break;}
     case OpCode::Call:case OpCode::CallIndirect:{std::vector<std::size_t> operands;const auto n=ins.integer+(ins.op==OpCode::CallIndirect?1:0);
      for(std::int64_t k=0;k<n;++k){if(stack.empty()){fail("call operand stack underflow");return;}operands.push_back(stack.back());stack.pop_back();}
      std::reverse(operands.begin(),operands.end());push_new(i,ins,std::move(operands));break;}
     case OpCode::Store:case OpCode::Print:case OpCode::JumpIfZero:case OpCode::Return:
      (void)pop(i,0);if(!result.stack_ssa_valid)return;break;
     case OpCode::Jump:case OpCode::Function:break;
    }
   }
   outgoing[bi]=std::move(stack);processed[bi]=true;progress=true;
  }
 }
 for(std::size_t bi=0;bi<count;++bi)if(reachable[bi]&&!processed[bi]){fail("stack SSA could not resolve cyclic predecessor state");return;}
 // Fill stack Phi edges after every reachable predecessor has an outgoing state.
 for(auto& phi:result.stack_phis){
  for(auto pred:reachable_preds[phi.block]){
   if(phi.stack_slot>=outgoing[pred].size()){fail("stack Phi incoming slot is out of range");return;}
   phi.incoming.emplace_back(pred,outgoing[pred][phi.stack_slot]);
  }
  std::sort(phi.incoming.begin(),phi.incoming.end());
 }
 }
}

namespace {
struct MemoryEffectInfo { bool read{false}; bool write{false}; bool unknown{false}; };
MemoryEffectInfo memory_effect(const Instruction& ins) {
 switch (ins.op) {
  case OpCode::LoadCell: case OpCode::ArrayGet: case OpCode::ArrayLength:
  case OpCode::ObjectGet: case OpCode::ObjectHas: return {true,false,false};
  case OpCode::ArraySet: case OpCode::ArrayPush: case OpCode::ArrayPop:
  case OpCode::ObjectSet: return {true,true,false};
  case OpCode::NewObject: case OpCode::MakeArray: case OpCode::MakeClosure:
   return {false,true,false};
  case OpCode::Call: case OpCode::CallIndirect: return {true,true,true};
  default: return {};
 }
}
SSAMemoryEffect memory_effect_kind(const MemoryEffectInfo& e) {
 if (e.unknown) return SSAMemoryEffect::Unknown;
 if (e.read && e.write) return SSAMemoryEffect::ReadWrite;
 return e.write ? SSAMemoryEffect::Write : SSAMemoryEffect::Read;
}
constexpr std::uint8_t alias_heap_bit = 0x1;
constexpr std::uint8_t alias_cell_bit = 0x2;
constexpr std::uint8_t alias_unknown_bit = 0x4;
constexpr std::uint8_t alias_all_bits = alias_heap_bit | alias_cell_bit | alias_unknown_bit;

using IntegerBounds = std::pair<std::int64_t,std::int64_t>;
bool checked_add(std::int64_t a,std::int64_t b,std::int64_t& out) {
 if ((b>0 && a>std::numeric_limits<std::int64_t>::max()-b) ||
     (b<0 && a<std::numeric_limits<std::int64_t>::min()-b)) return false;
 out=a+b; return true;
}
bool checked_sub(std::int64_t a,std::int64_t b,std::int64_t& out) {
 if ((b<0 && a>std::numeric_limits<std::int64_t>::max()+b) ||
     (b>0 && a<std::numeric_limits<std::int64_t>::min()+b)) return false;
 out=a-b; return true;
}
bool checked_mul(std::int64_t a,std::int64_t b,std::int64_t& out) {
 if (a==0 || b==0) { out=0; return true; }
 const auto min=std::numeric_limits<std::int64_t>::min();
 const auto max=std::numeric_limits<std::int64_t>::max();
 if ((a==-1 && b==min) || (b==-1 && a==min)) return false;
 if (a>0) {
  if (b>0 ? a>max/b : b<min/a) return false;
 } else {
  if (b>0 ? a<min/b : a<max/b) return false;
 }
 out=a*b; return true;
}
std::optional<IntegerBounds> combine_integer_ranges(OpCode op, const IntegerBounds& a,
                                                      const IntegerBounds& b) {
 std::int64_t low{},high{};
 switch (op) {
  case OpCode::Add:
   if(!checked_add(a.first,b.first,low)||!checked_add(a.second,b.second,high)) return std::nullopt;
   return IntegerBounds{low,high};
  case OpCode::Sub:
   if(!checked_sub(a.first,b.second,low)||!checked_sub(a.second,b.first,high)) return std::nullopt;
   return IntegerBounds{low,high};
  case OpCode::Mul: {
   std::int64_t values[4]{};
   if(!checked_mul(a.first,b.first,values[0])||!checked_mul(a.first,b.second,values[1])||
      !checked_mul(a.second,b.first,values[2])||!checked_mul(a.second,b.second,values[3])) return std::nullopt;
   const auto bounds=std::minmax_element(std::begin(values),std::end(values));
   return IntegerBounds{*bounds.first,*bounds.second};
  }
  case OpCode::Div:
   // Division is currently kept exact-only: interval division across zero or
   // mixed signs is easy to get subtly wrong around truncation and INT64_MIN.
   if (a.first==a.second && b.first==b.second && b.first!=0 &&
       !(a.first==std::numeric_limits<std::int64_t>::min() && b.first==-1)) {
    const auto value=a.first/b.first; return IntegerBounds{value,value};
   }
   return std::nullopt;
  default:return std::nullopt;
 }
}

// Forward range propagation over value SSA and variable SSA. A variable load
// is resolved through its reaching Store or Phi versions; all incoming paths
// must have finite ranges before a result is published. Cyclic/unknown inputs
// therefore stay unknown and cannot be used to claim an array slot.
void build_integer_range_analysis(SSAProgram& result) {
 std::map<std::pair<std::string,std::size_t>,std::vector<std::size_t>> source_cache;
 std::set<std::pair<std::string,std::size_t>> resolving;
 std::function<std::vector<std::size_t>(const std::string&,std::size_t,std::size_t)> variable_sources =
  [&](const std::string& name,std::size_t version,std::size_t depth)->std::vector<std::size_t> {
   if (version==0 || depth>64) return {};
   const auto key=std::make_pair(name,version);
   if (auto cached=source_cache.find(key);cached!=source_cache.end()) return cached->second;
   if (!resolving.insert(key).second) return {};
   std::vector<std::size_t> values;
   auto def=std::find_if(result.definitions.begin(),result.definitions.end(),[&](const SSADef& item) {
    return item.variable==name && item.version==version;
   });
   if (def!=result.definitions.end()) {
    if (def->instruction!=none) {
     auto use=std::find_if(result.value_uses.begin(),result.value_uses.end(),[&](const SSAValueUse& item) {
      return item.instruction==def->instruction && item.operand_index==0;
     });
     if (use!=result.value_uses.end()) values.push_back(use->value);
    } else {
     for (const auto& block:result.blocks) for (const auto& phi:block.phis)
      if (phi.variable==name && phi.result_version==version)
       for (const auto& incoming:phi.incoming) {
        auto nested=variable_sources(name,incoming.second,depth+1);
        // A version-0 edge or a cycle is an unknown input. Never keep only
        // the known initial edge of a loop-carried Phi: that would understate
        // the true range after subsequent iterations.
        if (nested.empty()) { values.clear(); break; }
        values.insert(values.end(),nested.begin(),nested.end());
       }
    }
   }
   resolving.erase(key);
   std::sort(values.begin(),values.end());
   values.erase(std::unique(values.begin(),values.end()),values.end());
   source_cache.emplace(key,values);
   return values;
  };
 std::unordered_map<std::size_t,IntegerBounds> ranges;
 auto range_of=[&](std::size_t id)->std::optional<IntegerBounds> {
  auto found=ranges.find(id); if(found==ranges.end()) return std::nullopt; return found->second;
 };
 auto merge_sources=[&](const std::vector<std::size_t>& sources)->std::optional<IntegerBounds> {
  if(sources.empty()) return std::nullopt;
  auto first=range_of(sources.front()); if(!first) return std::nullopt;
  IntegerBounds merged=*first;
  for(std::size_t i=1;i<sources.size();++i) {
   auto next=range_of(sources[i]); if(!next) return std::nullopt;
   merged.first=std::min(merged.first,next->first);
   merged.second=std::max(merged.second,next->second);
  }
  return merged;
 };
 const std::size_t limit=std::max<std::size_t>(8,result.value_definitions.size()*3+4);
 bool changed=true;
 for(std::size_t round=0;changed && round<limit;++round) {
  changed=false;
  for(const auto& d:result.value_definitions) {
   if(ranges.contains(d.id)) continue;
   std::optional<IntegerBounds> value;
   if(d.kind==SSAValueKind::Instruction) {
    if(d.op==OpCode::PushInt) value=IntegerBounds{d.integer,d.integer};
    else if(d.op==OpCode::Load) value=merge_sources(variable_sources(d.text,d.variable_version,0));
    else if(d.op==OpCode::Add||d.op==OpCode::Sub||d.op==OpCode::Mul||d.op==OpCode::Div) {
     if(d.operands.size()==2) {
      auto a=range_of(d.operands[0]),b=range_of(d.operands[1]);
      if(a&&b) value=combine_integer_ranges(d.op,*a,*b);
     }
    }
   } else if(d.kind==SSAValueKind::Phi) {
    auto phi=std::find_if(result.stack_phis.begin(),result.stack_phis.end(),[&](const SSAValuePhi& item) {
     return item.result==d.id;
    });
    if(phi!=result.stack_phis.end()) {
     std::vector<std::size_t> incoming;
     for(const auto& edge:phi->incoming) incoming.push_back(edge.second);
     value=merge_sources(incoming);
    }
   }
   if(value) { ranges.emplace(d.id,*value); changed=true; }
  }
 }
 result.integer_ranges.clear();
 result.integer_ranges.reserve(ranges.size());
 for(const auto& item:ranges) result.integer_ranges.push_back({item.first,item.second.first,item.second.second});
 std::sort(result.integer_ranges.begin(),result.integer_ranges.end(),[](const SSAIntegerRange& a,const SSAIntegerRange& b) {
  return a.value<b.value;
 });
}
// A bounded, flow-insensitive points-to layer over value SSA. Allocation
// sites are instruction identities. Values loaded from variables/cells,
// memory reads and calls remain unknown unless preserved through a Phi.
void build_points_to_analysis(SSAProgram& result, const ProgramIR& program) {
 std::unordered_map<std::size_t,SSAPointsToSet> sets;
 std::size_t argument_index=0;
 for(const auto& d:result.value_definitions) {
  SSAPointsToSet set; set.value=d.id;
  if(d.kind==SSAValueKind::Entry) { set.parameter_indices.push_back(argument_index++); }
  else if(d.kind==SSAValueKind::Instruction) {
   if(d.op==OpCode::MakeArray || d.op==OpCode::NewObject || d.op==OpCode::MakeClosure) {
    SSAAllocationKind kind=d.op==OpCode::MakeArray?SSAAllocationKind::Array:
      (d.op==OpCode::MakeClosure?SSAAllocationKind::Closure:SSAAllocationKind::Object);
    result.allocation_sites.push_back({d.instruction,kind});
    set.allocation_sites.push_back(d.instruction);
   } else if(d.op==OpCode::LoadCell || d.op==OpCode::Call || d.op==OpCode::CallIndirect) set.unknown=true;
  }
  sets.emplace(d.id,std::move(set));
 }
 auto merge=[&](SSAPointsToSet& dst,const SSAPointsToSet& src) {
  bool changed=false;
  if(src.unknown&&!dst.unknown){dst.unknown=true;changed=true;}
  for(auto site:src.allocation_sites)
   if(std::find(dst.allocation_sites.begin(),dst.allocation_sites.end(),site)==dst.allocation_sites.end()) { dst.allocation_sites.push_back(site);changed=true; }
  for(auto param:src.parameter_indices)
   if(std::find(dst.parameter_indices.begin(),dst.parameter_indices.end(),param)==dst.parameter_indices.end()) { dst.parameter_indices.push_back(param);changed=true; }
  if(changed) { std::sort(dst.allocation_sites.begin(),dst.allocation_sites.end()); std::sort(dst.parameter_indices.begin(),dst.parameter_indices.end()); }
  return changed;
 };
 std::map<std::pair<std::size_t,std::string>,SSAPointsToSet> fields;
 std::map<std::pair<std::size_t,std::int64_t>,SSAPointsToSet> array_elements;
 std::set<std::size_t> unknown_array_sites;
 std::set<std::string> unknown_field_writes;
 using VariableVersion = std::pair<std::string,std::size_t>;
 std::map<VariableVersion,SSAPointsToSet> variable_sets;
 auto find_set=[&](std::size_t id)->SSAPointsToSet { auto it=sets.find(id); if(it!=sets.end()) return it->second; SSAPointsToSet u;u.unknown=true;return u; };
 auto find_variable_set=[&](const VariableVersion& key)->SSAPointsToSet { auto it=variable_sets.find(key); if(it!=variable_sets.end()) return it->second; SSAPointsToSet u;u.unknown=true;return u; };
 auto use_value=[&](std::size_t instruction,std::size_t operand)->std::size_t {
  auto it=std::find_if(result.value_uses.begin(),result.value_uses.end(),[&](const SSAValueUse& u){return u.instruction==instruction&&u.operand_index==operand;});
  return it==result.value_uses.end()?0:it->value;
 };
 // Resolve compile-time integer expressions for array selectors. Arithmetic
 // is evaluated with checked 128-bit intermediates; overflow/division by zero
 // becomes unknown rather than wrapping into an unsound slot identity.
 std::function<std::optional<std::int64_t>(std::size_t,std::size_t)> constant_value =
  [&](std::size_t id,std::size_t depth)->std::optional<std::int64_t> {
   if(depth>64) return std::nullopt;
   auto known_range=std::lower_bound(result.integer_ranges.begin(),result.integer_ranges.end(),id,
    [](const SSAIntegerRange& range,std::size_t value){return range.value<value;});
   if(known_range!=result.integer_ranges.end() && known_range->value==id &&
      known_range->minimum==known_range->maximum) return known_range->minimum;
   auto def=std::find_if(result.value_definitions.begin(),result.value_definitions.end(),
    [&](const SSAValueDefinition& d){return d.id==id;});
   if(def==result.value_definitions.end()||def->kind!=SSAValueKind::Instruction) return std::nullopt;
   if(def->op==OpCode::PushInt) return def->integer;
   if(def->operands.size()!=2) return std::nullopt;
   auto a=constant_value(def->operands[0],depth+1),b=constant_value(def->operands[1],depth+1);
   if(!a||!b) return std::nullopt;
   std::int64_t value{};
   switch(def->op) {
    case OpCode::Add:
     if((*b>0&&*a>std::numeric_limits<std::int64_t>::max()-*b)||(*b<0&&*a<std::numeric_limits<std::int64_t>::min()-*b)) return std::nullopt;
     value=*a+*b;break;
    case OpCode::Sub:
     if((*b<0&&*a>std::numeric_limits<std::int64_t>::max()+*b)||(*b>0&&*a<std::numeric_limits<std::int64_t>::min()+*b)) return std::nullopt;
     value=*a-*b;break;
    case OpCode::Mul:
     if(*a==0||*b==0) value=0;
     else if((*a==-1&&*b==std::numeric_limits<std::int64_t>::min())||(*b==-1&&*a==std::numeric_limits<std::int64_t>::min())) return std::nullopt;
     else if(*a>0 ? (*b>0 ? *a>std::numeric_limits<std::int64_t>::max()/ *b : *b<std::numeric_limits<std::int64_t>::min()/ *a)
                    : (*b>0 ? *a<std::numeric_limits<std::int64_t>::min()/ *b : *a<std::numeric_limits<std::int64_t>::max()/ *b)) return std::nullopt;
     else value=*a * *b;
     break;
    case OpCode::Div: if(*b==0||(*a==std::numeric_limits<std::int64_t>::min()&&*b==-1)) return std::nullopt; value=*a / *b;break;
    default:return std::nullopt;
   }
   return value;
  };
 auto allocation_size=[&](std::size_t site)->std::optional<std::int64_t> {
  if(site>=program.code.size()||program.code[site].op!=OpCode::MakeArray) return std::nullopt;
  return program.code[site].integer;
 };
 // Field-sensitive, flow-insensitive object property graph. A field is keyed
 // by (allocation-site, statically named property). Dynamic property writes
 // conservatively poison the affected abstract object/field relation.
 const std::size_t limit=std::max<std::size_t>(8,result.value_definitions.size()*4+4);
 bool changed=true;
 for(std::size_t round=0;changed&&round<limit;++round) {
  changed=false;
  for(const auto& phi:result.stack_phis) {
   auto dst=sets.find(phi.result); if(dst==sets.end()) continue;
   for(const auto& incoming:phi.incoming) changed=merge(dst->second,find_set(incoming.second))||changed;
  }
  // Carry allocation provenance through variable SSA as well as stack Phi
  // nodes. A Store transfers the points-to set of its consumed value into its
  // variable version; variable Phi nodes union predecessor versions; Load
  // definitions then inherit the version's set. Missing version-zero inputs
  // remain unknown, so this analysis never assumes an uninitialized/global
  // reference is disjoint from a known allocation.
  for(const auto& definition:result.definitions) {
   if(definition.instruction==static_cast<std::size_t>(-1) || definition.instruction>=program.code.size()) continue;
   if(program.code[definition.instruction].op!=OpCode::Store) continue;
   const auto source=use_value(definition.instruction,0);
   if(!source) continue;
   auto& dst=variable_sets[{definition.variable,definition.version}];
   changed=merge(dst,find_set(source))||changed;
  }
  for(const auto& block:result.blocks) for(const auto& phi:block.phis) {
   auto& dst=variable_sets[{phi.variable,phi.result_version}];
   for(const auto& incoming:phi.incoming)
    changed=merge(dst,find_variable_set({phi.variable,incoming.second}))||changed;
  }
  for(const auto& definition:result.value_definitions) {
   if(definition.kind!=SSAValueKind::Instruction || definition.op!=OpCode::Load) continue;
   auto dst=sets.find(definition.id); if(dst==sets.end()) continue;
   changed=merge(dst->second,find_variable_set({definition.text,definition.variable_version}))||changed;
  }
  for(std::size_t i=0;i<program.code.size();++i) {
   const auto& ins=program.code[i];
   if(ins.op!=OpCode::ObjectSet) continue;
   const auto base_id=use_value(i,0), value_id=use_value(i,1);
   if(!base_id) continue;
   const auto base=find_set(base_id), value=find_set(value_id);
   if(ins.operand.empty()) { unknown_field_writes.insert("*"); continue; }
   if(base.unknown || base.allocation_sites.empty()) { unknown_field_writes.insert(ins.operand); continue; }
   for(auto site:base.allocation_sites) {
    auto& slot=fields[{site,ins.operand}];
    changed=merge(slot,value)||changed;
   }
  }
  // Track the reference-valued contents of statically indexed array slots.
  // This lets an outer ArrayGet recover the allocation site of an inner array,
  // after which the ordinary per-allocation Memory SSA partitions apply.
  for(const auto& d:result.value_definitions) {
   if(d.kind!=SSAValueKind::Instruction || d.op!=OpCode::MakeArray) continue;
   for(std::size_t index=0;index<d.operands.size();++index) {
    auto& slot=array_elements[{d.instruction,static_cast<std::int64_t>(index)}];
    changed=merge(slot,find_set(d.operands[index]))||changed;
   }
  }
  for(std::size_t instruction=0;instruction<program.code.size();++instruction) {
   const auto& ins=program.code[instruction];
   if(ins.op==OpCode::ArraySet) {
    const auto base_id=use_value(instruction,0), index_id=use_value(instruction,1), value_id=use_value(instruction,2);
    const auto base=find_set(base_id); const auto index=constant_value(index_id,0);
    if(base.unknown||!base.parameter_indices.empty()||base.allocation_sites.empty()||!index||*index<0) {
     // An unresolved base may alias any known array; poison every array
     // allocation's element provenance rather than retaining stale nesting.
     for(const auto& allocation:result.allocation_sites) if(allocation.kind==SSAAllocationKind::Array)
      if(unknown_array_sites.insert(allocation.instruction).second) changed=true;
     continue;
    }
    for(auto site:base.allocation_sites) {
     const auto length=allocation_size(site);
     if(!length||*index>=*length) { if(unknown_array_sites.insert(site).second) changed=true; continue; }
     auto& slot=array_elements[{site,*index}]; changed=merge(slot,find_set(value_id))||changed;
    }
   } else if(ins.op==OpCode::ArrayPush||ins.op==OpCode::ArrayPop) {
    const auto base=find_set(use_value(instruction,0));
    if(base.unknown||!base.parameter_indices.empty()||base.allocation_sites.empty()) {
     for(const auto& allocation:result.allocation_sites) if(allocation.kind==SSAAllocationKind::Array)
      if(unknown_array_sites.insert(allocation.instruction).second) changed=true;
    } else for(auto site:base.allocation_sites) if(unknown_array_sites.insert(site).second) changed=true;
   } else if(ins.op==OpCode::Call||ins.op==OpCode::CallIndirect) {
    // Calls can mutate arrays passed through parameters or captured state.
    // Until a slot-specific interprocedural write summary exists, fail closed.
    for(const auto& allocation:result.allocation_sites) if(allocation.kind==SSAAllocationKind::Array)
     if(unknown_array_sites.insert(allocation.instruction).second) changed=true;
   }
  }
  for(const auto& d:result.value_definitions) {
   if(d.kind!=SSAValueKind::Instruction || d.op!=OpCode::ArrayGet || d.operands.size()<2) continue;
   auto dst=sets.find(d.id); if(dst==sets.end()) continue;
   const auto base=find_set(d.operands[0]); const auto index=constant_value(d.operands[1],0);
   if(base.unknown||!base.parameter_indices.empty()||base.allocation_sites.empty()||!index||*index<0) {
    if(!dst->second.unknown){dst->second.unknown=true;changed=true;}
    continue;
   }
   bool found_slot=false;
   for(auto site:base.allocation_sites) {
    const auto length=allocation_size(site);
    if(!length||*index>=*length||unknown_array_sites.count(site)) {
     if(!dst->second.unknown){dst->second.unknown=true;changed=true;}
     continue;
    }
    auto slot=array_elements.find({site,*index});
    if(slot!=array_elements.end()) { found_slot=true; changed=merge(dst->second,slot->second)||changed; }
   }
   if(!found_slot && !dst->second.unknown) { dst->second.unknown=true; changed=true; }
  }
  for(const auto& d:result.value_definitions) {
   if(d.kind!=SSAValueKind::Instruction || d.op!=OpCode::ObjectGet || d.operands.empty()) continue;
   auto dst=sets.find(d.id); if(dst==sets.end()) continue;
   const auto base=find_set(d.operands.front());
   if(base.unknown || base.allocation_sites.empty() || d.text.empty()) {
    if(!dst->second.unknown){dst->second.unknown=true;changed=true;}
    for(auto param:base.parameter_indices)
     if(std::find(dst->second.parameter_indices.begin(),dst->second.parameter_indices.end(),param)==dst->second.parameter_indices.end()){dst->second.parameter_indices.push_back(param);changed=true;}
    continue;
   }
   bool found_field=false;
   for(auto site:base.allocation_sites) {
    auto it=fields.find({site,d.text});
    if(it!=fields.end()) { found_field=true; changed=merge(dst->second,it->second)||changed; }
    else if(unknown_field_writes.count(d.text)||unknown_field_writes.count("*")) {
     if(!dst->second.unknown){dst->second.unknown=true;changed=true;}
    }
   }
   if(!found_field && !unknown_field_writes.count(d.text) && !unknown_field_writes.count("*") && !dst->second.unknown) {
    // No statically known store for this property: the object's contents may
    // have originated outside the analyzed region.
    dst->second.unknown=true; changed=true;
   }
   for(auto param:base.parameter_indices)
    if(std::find(dst->second.parameter_indices.begin(),dst->second.parameter_indices.end(),param)==dst->second.parameter_indices.end()){dst->second.parameter_indices.push_back(param);changed=true;}
  }
 }
 // Loads whose variable version had no reaching Store/Phi provenance are
 // unknown (e.g. globals or uninitialized values), not an empty no-alias set.
 for(const auto& d:result.value_definitions) {
  if(d.kind==SSAValueKind::Instruction && d.op==OpCode::Load &&
     !variable_sets.contains({d.text,d.variable_version})) {
   auto it=sets.find(d.id); if(it!=sets.end()) it->second.unknown=true;
  }
 }
 // Materialize deterministic public records.
 for(const auto& d:result.value_definitions) {
  auto it=sets.find(d.id); if(it!=sets.end()) {
   auto value=it->second; std::sort(value.allocation_sites.begin(),value.allocation_sites.end());
   std::sort(value.parameter_indices.begin(),value.parameter_indices.end());
   result.points_to_sets.push_back(std::move(value));
  }
 }
 for(const auto& entry:fields) {
  SSAFieldPointsTo field; field.allocation_site=entry.first.first; field.field=entry.first.second;
  field.allocation_sites=entry.second.allocation_sites; field.parameter_indices=entry.second.parameter_indices;
  field.unknown=entry.second.unknown; result.field_points_to.push_back(std::move(field));
 }
}
SSAPointsToSet points_to_for_instruction_base(const SSAProgram& result,std::size_t instruction) {
 SSAPointsToSet unknown; unknown.unknown=true;
 auto use=std::find_if(result.value_uses.begin(),result.value_uses.end(),[&](const SSAValueUse& u){
  return u.instruction==instruction && u.operand_index==0;
 });
 if(use==result.value_uses.end()) return unknown;
 auto found=std::find_if(result.points_to_sets.begin(),result.points_to_sets.end(),[&](const SSAPointsToSet& s){return s.value==use->value;});
 return found==result.points_to_sets.end()?unknown:*found;
}
std::optional<std::int64_t> constant_integer_value(const SSAProgram& result,std::size_t value) {
 std::function<std::optional<std::int64_t>(std::size_t,std::size_t)> resolve =
  [&](std::size_t id,std::size_t depth)->std::optional<std::int64_t> {
   if(depth>64) return std::nullopt;
   auto range=std::lower_bound(result.integer_ranges.begin(),result.integer_ranges.end(),id,
    [](const SSAIntegerRange& item,std::size_t candidate){return item.value<candidate;});
   if(range!=result.integer_ranges.end() && range->value==id && range->minimum==range->maximum)
    return range->minimum;
   auto def=std::find_if(result.value_definitions.begin(),result.value_definitions.end(),[&](const SSAValueDefinition& d){return d.id==id;});
   if(def==result.value_definitions.end()||def->kind!=SSAValueKind::Instruction) return std::nullopt;
   if(def->op==OpCode::PushInt) return def->integer;
   if(def->operands.size()!=2) return std::nullopt;
   auto a=resolve(def->operands[0],depth+1),b=resolve(def->operands[1],depth+1);
   if(!a||!b) return std::nullopt;
   std::int64_t v{};
   switch(def->op) {
    case OpCode::Add:
     if((*b>0&&*a>std::numeric_limits<std::int64_t>::max()-*b)||(*b<0&&*a<std::numeric_limits<std::int64_t>::min()-*b))return std::nullopt;
     v=*a+*b;break;
    case OpCode::Sub:
     if((*b<0&&*a>std::numeric_limits<std::int64_t>::max()+*b)||(*b>0&&*a<std::numeric_limits<std::int64_t>::min()+*b))return std::nullopt;
     v=*a-*b;break;
    case OpCode::Mul:
     if(*a==0||*b==0)v=0;
     else if((*a==-1&&*b==std::numeric_limits<std::int64_t>::min())||(*b==-1&&*a==std::numeric_limits<std::int64_t>::min()))return std::nullopt;
     else if(*a>0 ? (*b>0 ? *a>std::numeric_limits<std::int64_t>::max()/ *b : *b<std::numeric_limits<std::int64_t>::min()/ *a)
                    : (*b>0 ? *a<std::numeric_limits<std::int64_t>::min()/ *b : *a<std::numeric_limits<std::int64_t>::max()/ *b))return std::nullopt;
     else v=*a * *b;
     break;
    case OpCode::Div:if(*b==0||(*a==std::numeric_limits<std::int64_t>::min()&&*b==-1))return std::nullopt;v=*a / *b;break;
    default:return std::nullopt;
   }
   return v;
  };
 return resolve(value,0);
}
std::optional<std::int64_t> constant_array_index(const SSAProgram& result,std::size_t instruction) {
 auto use=std::find_if(result.value_uses.begin(),result.value_uses.end(),[&](const SSAValueUse& u){return u.instruction==instruction&&u.operand_index==1;});
 if(use==result.value_uses.end()) return std::nullopt;
 return constant_integer_value(result,use->value);
}
void build_alias_accesses(SSAProgram& result, const ProgramIR& p) {
 const auto count=result.blocks.size();
 if (!count) return;
 std::vector<bool> reachable(count,false); std::vector<std::size_t> work{0}; reachable[0]=true;
 for(std::size_t k=0;k<work.size();++k) for(auto succ:result.blocks[work[k]].successors)
  if(succ<count&&!reachable[succ]) { reachable[succ]=true; work.push_back(succ); }
 for(std::size_t b=0;b<count;++b) if(reachable[b])
  for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) {
   const auto& ins=p.code[i]; const auto effect=memory_effect(ins);
   if(!effect.read&&!effect.write) continue;
   SSAAliasAccess access; access.instruction=i; access.read=effect.read; access.write=effect.write;
   if(effect.unknown) { access.region=SSAAliasRegion::Unknown; access.may_alias_mask=alias_all_bits; }
   else if(ins.op==OpCode::LoadCell) {
    access.region=SSAAliasRegion::ClosureCell; access.may_alias_mask=alias_cell_bit;
   } else {
    access.region=SSAAliasRegion::HeapAggregate; access.may_alias_mask=alias_heap_bit;
   }
   if(ins.op==OpCode::NewObject || ins.op==OpCode::MakeArray || ins.op==OpCode::MakeClosure) {
    access.points_to_sites.push_back(i); access.points_to_unknown=false;
   } else if(ins.op!=OpCode::LoadCell && !effect.unknown) {
    const auto points=points_to_for_instruction_base(result,i);
    access.points_to_sites=points.allocation_sites;
    access.points_to_unknown=points.unknown;
   }
   access.must_alias_singleton=!access.points_to_unknown && access.points_to_sites.size()==1;
   result.alias_accesses.push_back(access);
  }
}
std::uint8_t memory_partition_bit(SSAAliasRegion region) {
 return region==SSAAliasRegion::ClosureCell ? alias_cell_bit : alias_heap_bit;
}
std::uint8_t memory_partition_mask(const SSAProgram& result, std::size_t instruction) {
 auto access=std::find_if(result.alias_accesses.begin(),result.alias_accesses.end(),
  [&](const SSAAliasAccess& item){return item.instruction==instruction;});
 // Missing alias metadata is never interpreted as no effect.
 if(access==result.alias_accesses.end()) return alias_heap_bit|alias_cell_bit;
 return static_cast<std::uint8_t>(access->may_alias_mask & (alias_heap_bit|alias_cell_bit));
}
void build_memory_ssa(SSAProgram& result, const ProgramIR& p) {
 const auto count=result.blocks.size();
 if (!count) return;
 const auto none=static_cast<std::size_t>(-1);
 std::vector<bool> reachable(count,false); std::vector<std::size_t> work{0}; reachable[0]=true;
 for(std::size_t k=0;k<work.size();++k) for(auto succ:result.blocks[work[k]].successors)
  if(succ<count&&!reachable[succ]) { reachable[succ]=true; work.push_back(succ); }
 const SSAAliasRegion partitions[] = {SSAAliasRegion::HeapAggregate, SSAAliasRegion::ClosureCell};
 std::size_t next=1;
 std::vector<std::vector<std::size_t>> phi_id(2,std::vector<std::size_t>(count,0));
 std::vector<std::vector<std::size_t>> write_id(2,std::vector<std::size_t>(p.code.size(),0));
 // Each alias region owns an independent version namespace. Unknown accesses
 // touch both concrete partitions; they do not create a third disjoint state.
 for(std::size_t part=0;part<2;++part) {
  const auto region=partitions[part]; const auto bit=memory_partition_bit(region);
  for(std::size_t b=0;b<count;++b) if(reachable[b]) {
   std::size_t pred_count=0; for(auto pred:result.blocks[b].predecessors) if(pred<count&&reachable[pred]) ++pred_count;
   if(pred_count>1 || (b==0&&pred_count>0)) {
    phi_id[part][b]=next++;
    result.memory_definitions.push_back({phi_id[part][b],none,b,SSAMemoryEffect::Write,true,region,{}});
    result.memory_phis.push_back({b,phi_id[part][b],{},region,{}});
   }
  }
  for(std::size_t b=0;b<count;++b) if(reachable[b]) for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) {
   const auto effect=memory_effect(p.code[i]);
   if(effect.write && (memory_partition_mask(result,i)&bit)) {
    write_id[part][i]=next++;
    result.memory_definitions.push_back({write_id[part][i],i,b,memory_effect_kind(effect),false,region,{}});
   }
  }
  std::vector<std::size_t> out(count,0), in(count,0);
  const std::size_t limit=std::max<std::size_t>(8,count*4+4);
  bool changed=true;
  for(std::size_t round=0;changed&&round<limit;++round) {
   changed=false;
   for(std::size_t b=0;b<count;++b) if(reachable[b]) {
    std::size_t incoming=0;
    if(phi_id[part][b]) incoming=phi_id[part][b];
    else {
     for(auto pred:result.blocks[b].predecessors) if(pred<count&&reachable[pred]) { incoming=out[pred]; break; }
    }
    std::size_t token=incoming;
    for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) if(write_id[part][i]) token=write_id[part][i];
    if(in[b]!=incoming||out[b]!=token) { in[b]=incoming;out[b]=token;changed=true; }
   }
  }
  if(changed) return; // fail closed for a CFG that does not reach a fixed point
  for(std::size_t b=0;b<count;++b) if(reachable[b]) {
   std::size_t token=in[b];
   for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) {
    const auto effect=memory_effect(p.code[i]);
    if((effect.read||effect.write) && (memory_partition_mask(result,i)&bit))
     result.memory_uses.push_back({i,token,memory_effect_kind(effect),region,{}});
    if(write_id[part][i]) token=write_id[part][i];
   }
  }
  for(auto& phi:result.memory_phis) if(phi.region==region && phi.partition_key.empty()) {
   for(auto pred:result.blocks[phi.block].predecessors)
    if(pred<count&&reachable[pred]) phi.incoming.emplace_back(pred,out[pred]);
   std::sort(phi.incoming.begin(),phi.incoming.end());
  }
 }

 // Field-sensitive object partitions supplement the coarse HeapAggregate token.
 // A known ObjectGet/ObjectHas/ObjectSet uses object:<site>:<field>. Unknown
 // heap writes (including unresolved calls and writes through unknown bases)
 // advance every discovered field token, so precision never weakens safety.
 struct FieldPartition {
  std::size_t site{};
  std::string field;
  std::string key;
  std::vector<bool> reads, writes;
 };
 std::map<std::pair<std::size_t,std::string>,FieldPartition> field_partitions;
 std::vector<bool> unknown_heap_write(p.code.size(),false);
 std::unordered_map<std::size_t,SSAAllocationKind> allocation_kinds;
 for(const auto& site:result.allocation_sites) allocation_kinds.emplace(site.instruction,site.kind);
 for(std::size_t b=0;b<count;++b) if(reachable[b])
  for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) {
   const auto& ins=p.code[i]; const auto effect=memory_effect(ins);
   if(!effect.write) continue;
   if(effect.unknown) unknown_heap_write[i]=true;
   if(ins.op!=OpCode::ObjectSet) continue;
   const auto base=points_to_for_instruction_base(result,i);
   if(ins.operand.empty() || base.unknown || !base.parameter_indices.empty() || base.allocation_sites.empty()) {
    unknown_heap_write[i]=true;
    continue;
   }
   for(auto site:base.allocation_sites) {
    auto kind=allocation_kinds.find(site);
    if(kind==allocation_kinds.end() || kind->second!=SSAAllocationKind::Object) continue;
    auto& part=field_partitions[{site,ins.operand}];
    part.site=site; part.field=ins.operand;
    part.key="object:"+std::to_string(site)+":"+ins.operand;
    part.reads.resize(p.code.size(),false); part.writes.resize(p.code.size(),false);
    part.writes[i]=true;
   }
  }
 for(std::size_t b=0;b<count;++b) if(reachable[b])
  for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) {
   const auto& ins=p.code[i];
   if(ins.op!=OpCode::ObjectGet && ins.op!=OpCode::ObjectHas) continue;
   if(ins.operand.empty()) continue;
   const auto base=points_to_for_instruction_base(result,i);
   if(base.unknown || !base.parameter_indices.empty() || base.allocation_sites.empty()) continue;
   for(auto site:base.allocation_sites) {
    auto kind=allocation_kinds.find(site);
    if(kind==allocation_kinds.end() || kind->second!=SSAAllocationKind::Object) continue;
    auto& part=field_partitions[{site,ins.operand}];
    part.site=site; part.field=ins.operand;
    part.key="object:"+std::to_string(site)+":"+ins.operand;
    part.reads.resize(p.code.size(),false); part.writes.resize(p.code.size(),false);
    part.reads[i]=true;
   }
  }
 for(auto& entry:field_partitions) {
  auto& part=entry.second;
  for(std::size_t i=0;i<p.code.size();++i) if(unknown_heap_write[i]) part.writes[i]=true;
  std::vector<std::size_t> field_phi(count,0), field_write(p.code.size(),0);
  for(std::size_t b=0;b<count;++b) if(reachable[b]) {
   std::size_t pred_count=0;
   for(auto pred:result.blocks[b].predecessors) if(pred<count&&reachable[pred]) ++pred_count;
   if(pred_count>1 || (b==0&&pred_count>0)) {
    field_phi[b]=next++;
    result.memory_definitions.push_back({field_phi[b],none,b,SSAMemoryEffect::Write,true,SSAAliasRegion::HeapAggregate,part.key});
    result.memory_phis.push_back({b,field_phi[b],{},SSAAliasRegion::HeapAggregate,part.key});
   }
  }
  for(std::size_t b=0;b<count;++b) if(reachable[b])
   for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) if(part.writes[i]) {
    field_write[i]=next++;
    result.memory_definitions.push_back({field_write[i],i,b,memory_effect_kind(memory_effect(p.code[i])),false,SSAAliasRegion::HeapAggregate,part.key});
   }
  std::vector<std::size_t> field_in(count,0),field_out(count,0);
  const std::size_t limit=std::max<std::size_t>(8,count*4+4); bool changed=true;
  for(std::size_t round=0;changed&&round<limit;++round) {
   changed=false;
   for(std::size_t b=0;b<count;++b) if(reachable[b]) {
    std::size_t incoming=field_phi[b];
    if(!incoming) for(auto pred:result.blocks[b].predecessors)
     if(pred<count&&reachable[pred]) { incoming=field_out[pred]; break; }
    std::size_t token=incoming;
    for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) if(field_write[i]) token=field_write[i];
    if(field_in[b]!=incoming||field_out[b]!=token) { field_in[b]=incoming;field_out[b]=token;changed=true; }
   }
  }
  if(changed) return;
  for(std::size_t b=0;b<count;++b) if(reachable[b]) {
   std::size_t token=field_in[b];
   for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) {
    if(part.reads[i]||part.writes[i]||unknown_heap_write[i])
     result.memory_uses.push_back({i,token,memory_effect_kind(memory_effect(p.code[i])),SSAAliasRegion::HeapAggregate,part.key});
    if(field_write[i]) token=field_write[i];
   }
  }
  for(auto& phi:result.memory_phis) if(phi.region==SSAAliasRegion::HeapAggregate && phi.partition_key==part.key) {
   for(auto pred:result.blocks[phi.block].predecessors)
    if(pred<count&&reachable[pred]) phi.incoming.emplace_back(pred,field_out[pred]);
   std::sort(phi.incoming.begin(),phi.incoming.end());
  }
 }

 // Constant-index array partitions supplement HeapAggregate. Only direct,
 // statically proven indices are split; dynamic writes and structural changes
 // conservatively advance every discovered array-slot token.
 struct ArrayPartition { std::size_t site{}; std::int64_t index{}; std::string key; std::vector<bool> reads,writes; };
 std::map<std::pair<std::size_t,std::int64_t>,ArrayPartition> array_partitions;
 std::vector<bool> unknown_array_write(p.code.size(),false);
 for(std::size_t b=0;b<count;++b) if(reachable[b])
  for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) {
   const auto& ins=p.code[i];
   if(ins.op==OpCode::ArrayPush || ins.op==OpCode::ArrayPop) { unknown_array_write[i]=true; continue; }
   if(ins.op==OpCode::ArraySet) {
    const auto index_value=std::find_if(result.value_uses.begin(),result.value_uses.end(),[&](const SSAValueUse& u){return u.instruction==i&&u.operand_index==1;});
    const auto resolved_index=index_value==result.value_uses.end()?std::optional<std::int64_t>{}:constant_integer_value(result,index_value->value);
    if(!resolved_index) { unknown_array_write[i]=true; continue; }
    const auto index=*resolved_index;
    const auto base=points_to_for_instruction_base(result,i);
    if(base.unknown || !base.parameter_indices.empty() || base.allocation_sites.size()!=1) {
     unknown_array_write[i]=true; continue;
    }
    const auto site=base.allocation_sites.front();
    auto allocation=std::find_if(result.allocation_sites.begin(),result.allocation_sites.end(),[&](const SSAAllocationSite& a){return a.instruction==site;});
    if(allocation==result.allocation_sites.end() || allocation->kind!=SSAAllocationKind::Array || site>=p.code.size() ||
       index<0 || index>=p.code[site].integer) { unknown_array_write[i]=true; continue; }
    auto& part=array_partitions[{site,index}]; part.site=site; part.index=index;
    part.key="array:"+std::to_string(site)+":"+std::to_string(index);
    part.reads.resize(p.code.size(),false); part.writes.resize(p.code.size(),false); part.writes[i]=true;
   } else if(ins.op==OpCode::ArrayGet) {
    const auto index=constant_array_index(result,i);
    const auto base=points_to_for_instruction_base(result,i);
    if(!index || *index<0 || base.unknown || !base.parameter_indices.empty() || base.allocation_sites.size()!=1) continue;
    const auto site=base.allocation_sites.front();
    auto allocation=std::find_if(result.allocation_sites.begin(),result.allocation_sites.end(),[&](const SSAAllocationSite& a){return a.instruction==site;});
    if(allocation==result.allocation_sites.end() || allocation->kind!=SSAAllocationKind::Array || site>=p.code.size() || *index>=p.code[site].integer) continue;
    auto& part=array_partitions[{site,*index}]; part.site=site; part.index=*index;
    part.key="array:"+std::to_string(site)+":"+std::to_string(*index);
    part.reads.resize(p.code.size(),false); part.writes.resize(p.code.size(),false); part.reads[i]=true;
   }
  }
 for(auto& entry:array_partitions) {
  auto& part=entry.second;
  for(std::size_t i=0;i<p.code.size();++i) if(unknown_heap_write[i]||unknown_array_write[i]) part.writes[i]=true;
  std::vector<std::size_t> array_phi(count,0),array_write(p.code.size(),0);
  for(std::size_t b=0;b<count;++b) if(reachable[b]) {
   std::size_t pred_count=0; for(auto pred:result.blocks[b].predecessors) if(pred<count&&reachable[pred]) ++pred_count;
   if(pred_count>1 || (b==0&&pred_count>0)) {
    array_phi[b]=next++;
    result.memory_definitions.push_back({array_phi[b],none,b,SSAMemoryEffect::Write,true,SSAAliasRegion::HeapAggregate,part.key});
    result.memory_phis.push_back({b,array_phi[b],{},SSAAliasRegion::HeapAggregate,part.key});
   }
  }
  for(std::size_t b=0;b<count;++b) if(reachable[b])
   for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) if(part.writes[i]) {
    array_write[i]=next++;
    result.memory_definitions.push_back({array_write[i],i,b,memory_effect_kind(memory_effect(p.code[i])),false,SSAAliasRegion::HeapAggregate,part.key});
   }
  std::vector<std::size_t> array_in(count,0),array_out(count,0);
  const std::size_t limit=std::max<std::size_t>(8,count*4+4); bool changed=true;
  for(std::size_t round=0;changed&&round<limit;++round) {
   changed=false;
   for(std::size_t b=0;b<count;++b) if(reachable[b]) {
    std::size_t incoming=array_phi[b];
    if(!incoming) for(auto pred:result.blocks[b].predecessors) if(pred<count&&reachable[pred]) {incoming=array_out[pred];break;}
    std::size_t token=incoming;
    for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) if(array_write[i]) token=array_write[i];
    if(array_in[b]!=incoming||array_out[b]!=token){array_in[b]=incoming;array_out[b]=token;changed=true;}
   }
  }
  if(changed) return;
  for(std::size_t b=0;b<count;++b) if(reachable[b]) {
   std::size_t token=array_in[b];
   for(std::size_t i=result.blocks[b].begin;i<result.blocks[b].end;++i) {
    if(part.reads[i]||part.writes[i]) result.memory_uses.push_back({i,token,memory_effect_kind(memory_effect(p.code[i])),SSAAliasRegion::HeapAggregate,part.key});
    if(array_write[i]) token=array_write[i];
   }
  }
  for(auto& phi:result.memory_phis) if(phi.region==SSAAliasRegion::HeapAggregate&&phi.partition_key==part.key) {
   for(auto pred:result.blocks[phi.block].predecessors) if(pred<count&&reachable[pred]) phi.incoming.emplace_back(pred,array_out[pred]);
   std::sort(phi.incoming.begin(),phi.incoming.end());
  }
 }
}

// Build a direct-effect summary for each function and then propagate callee
// effects to a fixed point. An unresolved or indirect call is always unknown.
void build_function_summaries(SSAProgram& root, const ProgramIR& p) {
 std::unordered_map<std::string,std::size_t> by_name;
 for(std::size_t i=0;i<root.functions.size();++i) by_name[root.functions[i].name]=i;
 for(auto& fn:root.functions) {
  for(std::size_t i=fn.begin;i<fn.end&&i<p.code.size();++i) {
   const auto& ins=p.code[i]; const auto effect=memory_effect(ins);
   if(ins.op==OpCode::Call) fn.callees.push_back(ins.operand);
   else if(ins.op==OpCode::CallIndirect) {
    fn.has_unknown_effects=true; fn.may_read_memory=true; fn.may_write_memory=true;
    fn.alias_read_mask|=alias_all_bits; fn.alias_write_mask|=alias_all_bits;
   } else {
    fn.may_read_memory=fn.may_read_memory||effect.read; fn.may_write_memory=fn.may_write_memory||effect.write;
    if(effect.read||effect.write) {
     const std::uint8_t mask = effect.unknown ? alias_all_bits :
       (ins.op==OpCode::LoadCell ? alias_cell_bit : alias_heap_bit);
     if(effect.read) fn.alias_read_mask|=mask;
     if(effect.write) fn.alias_write_mask|=mask;
    }
   }
  }
  std::sort(fn.callees.begin(),fn.callees.end());
  fn.callees.erase(std::unique(fn.callees.begin(),fn.callees.end()),fn.callees.end());
 }
 bool changed=true; const std::size_t limit=root.functions.size()*4+4;
 for(std::size_t round=0;changed&&round<limit;++round) {
  changed=false;
  for(auto& fn:root.functions) for(const auto& callee:fn.callees) {
   auto found=by_name.find(callee);
   bool read=true,write=true,unknown=true;
   std::uint8_t read_mask=alias_all_bits,write_mask=alias_all_bits;
   if(found!=by_name.end()) {
    const auto& target=root.functions[found->second];
    read=target.may_read_memory; write=target.may_write_memory; unknown=target.has_unknown_effects;
    read_mask=target.alias_read_mask; write_mask=target.alias_write_mask;
   }
   if(read&&!fn.may_read_memory){fn.may_read_memory=true;changed=true;}
   if(write&&!fn.may_write_memory){fn.may_write_memory=true;changed=true;}
   if(unknown&&!fn.has_unknown_effects){fn.has_unknown_effects=true;changed=true;}
   const auto old_read=fn.alias_read_mask, old_write=fn.alias_write_mask;
   fn.alias_read_mask|=read_mask; fn.alias_write_mask|=write_mask;
   if(old_read!=fn.alias_read_mask||old_write!=fn.alias_write_mask) changed=true;
  }
 }
 // Summarize function return provenance using symbolic entry-argument origins,
 // allocation sites local to the body, and conservative unknown state.
 for(auto& fn:root.functions) {
  if(!fn.analysis) { fn.return_unknown=true; continue; }
  const auto& local=*fn.analysis;
  for(const auto& use:local.value_uses) {
   if(use.operand_index!=0 || use.instruction>=fn.end-fn.begin) continue;
   if(use.instruction>=fn.end-fn.begin || p.code[fn.begin+use.instruction].op!=OpCode::Return) continue;
   auto points=std::find_if(local.points_to_sets.begin(),local.points_to_sets.end(),[&](const SSAPointsToSet& x){return x.value==use.value;});
   if(points==local.points_to_sets.end()) { fn.return_unknown=true; continue; }
   fn.return_unknown=fn.return_unknown||points->unknown;
   fn.return_parameter_indices.insert(fn.return_parameter_indices.end(),points->parameter_indices.begin(),points->parameter_indices.end());
   for(auto site:points->allocation_sites) fn.return_allocation_sites.push_back(site+fn.begin);
  }
  std::sort(fn.return_parameter_indices.begin(),fn.return_parameter_indices.end());
  fn.return_parameter_indices.erase(std::unique(fn.return_parameter_indices.begin(),fn.return_parameter_indices.end()),fn.return_parameter_indices.end());
  std::sort(fn.return_allocation_sites.begin(),fn.return_allocation_sites.end());
  fn.return_allocation_sites.erase(std::unique(fn.return_allocation_sites.begin(),fn.return_allocation_sites.end()),fn.return_allocation_sites.end());
 }
 // Compute parameter-level memory and escape effects. The local points-to
 // sets carry symbolic entry-argument origins; callers can therefore compose
 // summaries without pretending unknown values are disjoint.
 auto ensure_parameter=[&](SSAFunctionRegion& fn,std::size_t index)->SSAParameterEffect& {
  auto it=std::find_if(fn.parameter_effects.begin(),fn.parameter_effects.end(),[&](const SSAParameterEffect& e){return e.parameter_index==index;});
  if(it==fn.parameter_effects.end()) { fn.parameter_effects.push_back({index,false,false,false}); return fn.parameter_effects.back(); }
  return *it;
 };
 auto points_for_value=[](const SSAProgram& local,std::size_t value)->const SSAPointsToSet* {
  auto it=std::find_if(local.points_to_sets.begin(),local.points_to_sets.end(),[&](const SSAPointsToSet& x){return x.value==value;});
  return it==local.points_to_sets.end()?nullptr:&*it;
 };
 auto mark_origins=[&](SSAFunctionRegion& fn,const SSAPointsToSet* points,bool read,bool write,bool escape) {
  if(!points) return;
  for(auto index:points->parameter_indices) if(index<fn.arity) {
   auto& effect=ensure_parameter(fn,index);
   effect.may_read_memory=effect.may_read_memory||read;
   effect.may_write_memory=effect.may_write_memory||write;
   effect.may_escape=effect.may_escape||escape||points->unknown;
  }
 };
 for(auto& fn:root.functions) {
  if(!fn.analysis) continue;
  const auto& local=*fn.analysis;
  auto local_use=[&](std::size_t instruction,std::size_t operand)->const SSAPointsToSet* {
   auto use=std::find_if(local.value_uses.begin(),local.value_uses.end(),[&](const SSAValueUse& u){return u.instruction==instruction&&u.operand_index==operand;});
   return use==local.value_uses.end()?nullptr:points_for_value(local,use->value);
  };
  for(std::size_t i=0;i<fn.end-fn.begin&&i<p.code.size()-fn.begin;++i) {
   const auto& ins=p.code[fn.begin+i];
   const auto effect=memory_effect(ins);
   if((effect.read||effect.write) && ins.op!=OpCode::Call && ins.op!=OpCode::CallIndirect) {
    // Operand zero is the accessed aggregate for array/object operations.
    // Calls are handled below using their callee parameter summaries.
    // Cell loads are not associated with an explicit stack base.
    if(ins.op!=OpCode::LoadCell)
     mark_origins(fn,local_use(i,0),effect.read,effect.write,false);
   }
   // Values embedded into aggregates/closures can outlive the current frame.
   if(ins.op==OpCode::ObjectSet||ins.op==OpCode::ArrayPush)
    mark_origins(fn,local_use(i,1),false,false,true);
   else if(ins.op==OpCode::ArraySet)
    mark_origins(fn,local_use(i,2),false,false,true);
   else if(ins.op==OpCode::MakeArray||ins.op==OpCode::MakeClosure) {
    for(std::size_t operand=0;operand<static_cast<std::size_t>(std::max<std::int64_t>(0,ins.integer));++operand)
     mark_origins(fn,local_use(i,operand),false,false,true);
   }
  }
  // Returning a formal argument transfers its reference to the caller.
  for(auto index:fn.return_parameter_indices) {
   auto& effect=ensure_parameter(fn,index); effect.may_escape=true;
  }
  std::sort(fn.parameter_effects.begin(),fn.parameter_effects.end(),[](const auto& a,const auto& b){return a.parameter_index<b.parameter_index;});
 }
 // Propagate argument effects through direct calls to a bounded monotone fixed
 // point. Unresolved direct and all indirect calls conservatively escape actuals.
 bool parameter_changed=true; const std::size_t parameter_limit=root.functions.size()*8+8;
 for(std::size_t round=0;parameter_changed&&round<parameter_limit;++round) {
  parameter_changed=false;
  for(auto& caller:root.functions) {
   if(!caller.analysis) continue;
   const auto& local=*caller.analysis;
   for(const auto& call_def:local.value_definitions) {
    if(call_def.kind!=SSAValueKind::Instruction||!(call_def.op==OpCode::Call||call_def.op==OpCode::CallIndirect)||call_def.instruction>=caller.end-caller.begin) continue;
    const SSAFunctionRegion* callee=nullptr;
    if(call_def.op==OpCode::Call) {
     auto found=std::find_if(root.functions.begin(),root.functions.end(),[&](const SSAFunctionRegion& f){return f.name==call_def.text;});
     if(found!=root.functions.end()) callee=&*found;
    }
    for(std::size_t arg=0;arg<call_def.operands.size();++arg) {
     const auto* actual=points_for_value(local,call_def.operands[arg]);
     bool read=(callee==nullptr),write=(callee==nullptr),escape=(callee==nullptr);
     if(callee) {
      auto formal=std::find_if(callee->parameter_effects.begin(),callee->parameter_effects.end(),[&](const SSAParameterEffect& e){return e.parameter_index==arg;});
      if(formal!=callee->parameter_effects.end()) { read=formal->may_read_memory; write=formal->may_write_memory; escape=formal->may_escape; }
     }
     if(!actual) continue;
     for(auto index:actual->parameter_indices) if(index<caller.arity) {
      auto& dst=ensure_parameter(caller,index);
      const bool old_read=dst.may_read_memory,old_write=dst.may_write_memory,old_escape=dst.may_escape;
      dst.may_read_memory=dst.may_read_memory||read;
      dst.may_write_memory=dst.may_write_memory||write;
      dst.may_escape=dst.may_escape||escape||actual->unknown;
      if(old_read!=dst.may_read_memory||old_write!=dst.may_write_memory||old_escape!=dst.may_escape) parameter_changed=true;
     }
    }
   }
   std::sort(caller.parameter_effects.begin(),caller.parameter_effects.end(),[](const auto& a,const auto& b){return a.parameter_index<b.parameter_index;});
  }
 }
}
void apply_root_call_return_summaries(SSAProgram& root, const ProgramIR& p) {
 std::unordered_map<std::string,const SSAFunctionRegion*> by_name;
 for(const auto& fn:root.functions) by_name[fn.name]=&fn;
 for(const auto& d:root.value_definitions) {
  if(d.kind!=SSAValueKind::Instruction || d.op!=OpCode::Call || d.instruction>=p.code.size()) continue;
  auto fn=by_name.find(p.code[d.instruction].operand); if(fn==by_name.end()) continue;
  auto target=fn->second;
  for(auto site:target->return_allocation_sites) {
   if(site<p.code.size() && std::none_of(root.allocation_sites.begin(),root.allocation_sites.end(),[&](const SSAAllocationSite& a){return a.instruction==site;})) {
    const auto op=p.code[site].op;
    const auto kind=op==OpCode::MakeArray?SSAAllocationKind::Array:(op==OpCode::MakeClosure?SSAAllocationKind::Closure:SSAAllocationKind::Object);
    root.allocation_sites.push_back({site,kind});
   }
  }
  auto dst=std::find_if(root.points_to_sets.begin(),root.points_to_sets.end(),[&](const SSAPointsToSet& x){return x.value==d.id;});
  if(dst==root.points_to_sets.end()) continue;
  dst->unknown=target->return_unknown;
  dst->allocation_sites=target->return_allocation_sites;
  dst->parameter_indices.clear();
  for(auto index:target->return_parameter_indices) {
   if(index<d.operands.size()) {
    auto actual=std::find_if(root.points_to_sets.begin(),root.points_to_sets.end(),[&](const SSAPointsToSet& x){return x.value==d.operands[index];});
    if(actual==root.points_to_sets.end()) dst->unknown=true;
    else {
     dst->unknown=dst->unknown||actual->unknown;
     dst->allocation_sites.insert(dst->allocation_sites.end(),actual->allocation_sites.begin(),actual->allocation_sites.end());
     dst->parameter_indices.insert(dst->parameter_indices.end(),actual->parameter_indices.begin(),actual->parameter_indices.end());
    }
   } else dst->unknown=true;
  }
  std::sort(dst->allocation_sites.begin(),dst->allocation_sites.end());
  dst->allocation_sites.erase(std::unique(dst->allocation_sites.begin(),dst->allocation_sites.end()),dst->allocation_sites.end());
  std::sort(dst->parameter_indices.begin(),dst->parameter_indices.end());
  dst->parameter_indices.erase(std::unique(dst->parameter_indices.begin(),dst->parameter_indices.end()),dst->parameter_indices.end());
 }
}
ProgramIR slice_function_body(const ProgramIR& p,std::size_t begin,std::size_t end) {
 ProgramIR body; body.name=p.name; body.target=p.target;
 if(begin>end||end>p.code.size()) return body;
 body.code.assign(p.code.begin()+static_cast<std::ptrdiff_t>(begin),p.code.begin()+static_cast<std::ptrdiff_t>(end));
 for(auto& ins:body.code) if(ins.op==OpCode::Jump||ins.op==OpCode::JumpIfZero) {
  if(ins.integer>=static_cast<std::int64_t>(begin)&&ins.integer<static_cast<std::int64_t>(end)) ins.integer-=static_cast<std::int64_t>(begin);
  else if(ins.integer==static_cast<std::int64_t>(end)) ins.integer=static_cast<std::int64_t>(body.code.size());
  else ins.integer=-1; // a function branch may not escape its function region
 }
 return body;
}
}

static SSAProgram build_ssa_single(const ProgramIR& p,std::size_t initial_stack_depth=0){
 SSAProgram result; result.blocks=make_cfg(p); auto& b=result.blocks; const auto count=b.size(); if(!count)return result;
 std::vector<bool> reachable(count,false);std::vector<std::size_t> work{0};reachable[0]=true;
 for(std::size_t i=0;i<work.size();++i)for(auto s:b[work[i]].successors)if(!reachable[s]){reachable[s]=true;work.push_back(s);}
 // Classical iterative dominator sets over reachable CFG nodes.
 for(std::size_t i=0;i<count;++i)if(reachable[i]){if(i==0)b[i].dominators={0};else for(std::size_t j=0;j<count;++j)if(reachable[j])b[i].dominators.push_back(j);}
 bool changed=true;while(changed){changed=false;for(std::size_t i=1;i<count;++i)if(reachable[i]){
  std::vector<std::size_t> next;bool first=true;
  for(auto pred:b[i].predecessors)if(reachable[pred]){if(first){next=b[pred].dominators;first=false;}else{std::vector<std::size_t> intersection;std::set_intersection(next.begin(),next.end(),b[pred].dominators.begin(),b[pred].dominators.end(),std::back_inserter(intersection));next=std::move(intersection);}}
  if(first) continue;
  next.push_back(i); std::sort(next.begin(),next.end());
  if(next!=b[i].dominators){b[i].dominators=std::move(next);changed=true;}
 }}
 for(std::size_t i=1;i<count;++i)if(reachable[i]){
  std::size_t best=none;for(auto d:b[i].dominators)if(d!=i&&(best==none||b[d].dominators.size()>b[best].dominators.size()))best=d;
  b[i].immediate_dominator=best;if(best!=none)b[best].dominator_children.push_back(i);
 }
 // Dominance frontier using the standard predecessor runner algorithm.
 for(std::size_t i=0;i<count;++i)if(reachable[i]&&b[i].predecessors.size()>=2){
  for(auto pred:b[i].predecessors)if(reachable[pred]){auto runner=pred;while(runner!=none&&runner!=b[i].immediate_dominator){auto& df=b[runner].dominance_frontier;if(std::find(df.begin(),df.end(),i)==df.end())df.push_back(i);runner=b[runner].immediate_dominator;}}
 }
 for(auto& x:b){std::sort(x.dominators.begin(),x.dominators.end());std::sort(x.dominance_frontier.begin(),x.dominance_frontier.end());}
 std::map<std::string,std::set<std::size_t>> def_blocks;std::set<std::string> variables;
 for(const auto& x:p.code)if(x.op==OpCode::Load||x.op==OpCode::Store)variables.insert(x.operand);
 result.variable_count=variables.size();
 for(const auto& name:variables){std::set<std::size_t> defs;for(auto& block:b)if(reachable[block.id])for(std::size_t i=block.begin;i<block.end;++i)if(p.code[i].op==OpCode::Store&&p.code[i].operand==name)defs.insert(block.id);def_blocks[name]=std::move(defs);}
 // Cytron iterated dominance-frontier phi placement.
 for(const auto& name:variables){std::vector<std::size_t> queue(def_blocks[name].begin(),def_blocks[name].end());std::set<std::size_t> placed;
  for(std::size_t q=0;q<queue.size();++q)for(auto frontier:b[queue[q]].dominance_frontier)if(placed.insert(frontier).second){b[frontier].phis.push_back({name,0,{}});if(!def_blocks[name].contains(frontier))queue.push_back(frontier);}
 }
 for(auto& block:b)std::sort(block.phis.begin(),block.phis.end(),[](const auto& a,const auto& c){return a.variable<c.variable;});
 std::unordered_map<std::string,std::vector<std::size_t>> versions;std::unordered_map<std::string,std::size_t> next_version;std::vector<std::unordered_map<std::string,std::size_t>> block_out(count);
 for(const auto& name:variables){versions[name].push_back(0);next_version[name]=1;}
 auto define=[&](const std::string& name){auto v=next_version[name]++;versions[name].push_back(v);return v;};
 std::function<void(std::size_t)> rename=[&](std::size_t id){auto& block=b[id];std::vector<std::string> pushed;
  for(auto& phi:block.phis){phi.result_version=define(phi.variable);pushed.push_back(phi.variable);result.definitions.push_back({none,phi.variable,phi.result_version});}
  for(std::size_t i=block.begin;i<block.end;++i){const auto& ins=p.code[i];if(ins.op==OpCode::Load){auto& stack=versions[ins.operand];result.uses.push_back({i,ins.operand,stack.empty()?0:stack.back()});}
   else if(ins.op==OpCode::Store){auto v=define(ins.operand);result.definitions.push_back({i,ins.operand,v});pushed.push_back(ins.operand);}}
  for(const auto& name:variables){auto& stack=versions[name];block_out[id][name]=stack.empty()?0:stack.back();}
  for(auto child:block.dominator_children)rename(child);
  for(auto it=pushed.rbegin();it!=pushed.rend();++it)versions[*it].pop_back();
 };
 rename(0);for(auto& block:b)for(auto& phi:block.phis){for(auto pred:block.predecessors)if(reachable[pred]){auto it=block_out[pred].find(phi.variable);phi.incoming.emplace_back(pred,it==block_out[pred].end()?0:it->second);}std::sort(phi.incoming.begin(),phi.incoming.end());}
 result.phi_count=0;for(const auto& block:b)result.phi_count+=block.phis.size();build_stack_value_ssa(result,p,initial_stack_depth);build_integer_range_analysis(result);build_points_to_analysis(result,p);build_alias_accesses(result,p);build_memory_ssa(result,p);return result;
}


SSAProgram build_ssa(const ProgramIR& p) {
 SSAProgram root=build_ssa_single(p);
 for(std::size_t i=0;i<p.code.size();++i) {
  if(p.code[i].op!=OpCode::Function) continue;
  std::size_t end=i+1;
  while(end<p.code.size()&&p.code[end].op!=OpCode::Function) ++end;
  SSAFunctionRegion region;
  region.name=p.code[i].operand;
  region.begin=i+1;
  region.end=end;
  region.arity=p.code[i].integer<0?0:static_cast<std::size_t>(p.code[i].integer);
  auto body=slice_function_body(p,region.begin,region.end);
  region.analysis=std::make_shared<SSAProgram>(build_ssa_single(body,region.arity));
  root.functions.push_back(std::move(region));
  i=end==0?i:end-1;
 }
 build_function_summaries(root,p);
 apply_root_call_return_summaries(root,p);
 return root;
}

static SSAVerificationResult verify_ssa_single(const SSAProgram& ssa, const ProgramIR& program){
 SSAVerificationResult result;
 auto error=[&](const std::string& message){result.ok=false;result.errors.push_back(message);};
 const auto none=static_cast<std::size_t>(-1);
 if(program.code.empty()){
  if(!ssa.blocks.empty()) error("empty IR must not have SSA blocks");
  return result;
 }
 if(ssa.blocks.empty()){error("non-empty IR has no SSA entry block");return result;}
 std::vector<std::size_t> owner(program.code.size(),none);
 for(std::size_t bi=0;bi<ssa.blocks.size();++bi){
  const auto& b=ssa.blocks[bi];
  if(b.id!=bi) error("block IDs are not dense and ordered");
  if(b.begin>=b.end||b.end>program.code.size()) {error("block range is invalid");continue;}
  for(std::size_t i=b.begin;i<b.end;++i){if(owner[i]!=none)error("instruction belongs to multiple blocks");owner[i]=bi;}
 }
 for(auto b:owner)if(b==none)error("one or more IR instructions are not covered by blocks");
 for(std::size_t bi=0;bi<ssa.blocks.size();++bi){
  const auto& b=ssa.blocks[bi];
  for(auto succ:b.successors){
   if(succ>=ssa.blocks.size()){error("successor block index is out of range");continue;}
   const auto& preds=ssa.blocks[succ].predecessors;
   if(std::find(preds.begin(),preds.end(),bi)==preds.end())error("CFG successor/predecessor relation is asymmetric");
  }
  for(auto pred:b.predecessors){
   if(pred>=ssa.blocks.size()){error("predecessor block index is out of range");continue;}
   const auto& succs=ssa.blocks[pred].successors;
   if(std::find(succs.begin(),succs.end(),bi)==succs.end())error("CFG predecessor/successor relation is asymmetric");
  }
 }
 struct DefSite{std::string variable;std::size_t block;std::size_t instruction;};
 std::map<std::pair<std::string,std::size_t>,DefSite> defs;
 for(const auto& d:ssa.definitions){
  if(d.instruction==none)continue; // Phi definitions are validated against their block below.
  if(d.instruction>=program.code.size()){error("definition instruction index is invalid");continue;}
  if(owner[d.instruction]==none)continue;
  if(program.code[d.instruction].op!=OpCode::Store||program.code[d.instruction].operand!=d.variable)error("SSA definition does not correspond to its Store instruction");
  auto key=std::make_pair(d.variable,d.version);
  if(d.version==0||!defs.emplace(key,DefSite{d.variable,owner[d.instruction],d.instruction}).second)error("duplicate or reserved SSA definition version");
 }
 std::map<std::pair<std::string,std::size_t>,std::size_t> phi_defs;
 std::set<std::pair<std::string,std::size_t>> recorded_phi_defs;
 for(const auto& d:ssa.definitions)if(d.instruction==none)recorded_phi_defs.emplace(d.variable,d.version);
 for(std::size_t bi=0;bi<ssa.blocks.size();++bi){
  const auto& b=ssa.blocks[bi];
  for(const auto& phi:b.phis){
   auto key=std::make_pair(phi.variable,phi.result_version);
   if(phi.result_version==0||defs.count(key)||!phi_defs.emplace(key,bi).second)error("duplicate or reserved Phi result version");
   if(recorded_phi_defs.erase(key)!=1)error("Phi result is missing its SSA definition record");
   std::vector<std::size_t> expected;
   for(auto pred:b.predecessors)if(pred<ssa.blocks.size())expected.push_back(pred);
   std::vector<std::size_t> actual;
   for(const auto& incoming:phi.incoming){actual.push_back(incoming.first);if(incoming.first>=ssa.blocks.size())error("Phi incoming predecessor is out of range");}
   std::sort(expected.begin(),expected.end());std::sort(actual.begin(),actual.end());
   if(expected!=actual)error("Phi incoming edges do not match block predecessors");
  }
 }
 if(!recorded_phi_defs.empty())error("orphan Phi definition record");
 auto dominates=[&](std::size_t def_block,std::size_t use_block){
  if(use_block>=ssa.blocks.size())return false;
  const auto& dom=ssa.blocks[use_block].dominators;
  return std::find(dom.begin(),dom.end(),def_block)!=dom.end();
 };
 auto check_value=[&](const std::string& variable,std::size_t version,std::size_t use_block,std::size_t use_instruction,const char* context){
  if(version==0)return;
  auto key=std::make_pair(variable,version);
  auto dit=defs.find(key);
  if(dit!=defs.end()){
   const auto& d=dit->second;
   if(d.block==use_block){if(d.instruction>=use_instruction)error(std::string(context)+" uses a definition that occurs later in the same block");}
   else if(!dominates(d.block,use_block))error(std::string(context)+" uses a definition that does not dominate it");
   return;
  }
  auto pit=phi_defs.find(key);
  if(pit==phi_defs.end())error(std::string(context)+" references an undefined SSA version");
  else if(!dominates(pit->second,use_block))error(std::string(context)+" references a Phi that does not dominate it");
 };
 std::set<std::size_t> seen_loads;
 for(const auto& u:ssa.uses){
  if(u.instruction>=program.code.size()||owner[u.instruction]==none){error("SSA use instruction index is invalid");continue;}
  if(!seen_loads.insert(u.instruction).second)error("duplicate SSA use record");
  if(program.code[u.instruction].op!=OpCode::Load||program.code[u.instruction].operand!=u.variable)error("SSA use does not correspond to its Load instruction");
  check_value(u.variable,u.version,owner[u.instruction],u.instruction,"Load");
 }
 std::set<std::size_t> seen_stores;
 for(const auto& d:ssa.definitions)if(d.instruction!=none&&d.instruction<program.code.size()){
  if(!seen_stores.insert(d.instruction).second)error("duplicate SSA definition record for Store");
 }
 for(std::size_t i=0;i<program.code.size();++i){
  if(owner[i]>=ssa.blocks.size())continue;
  // Empty dominator sets identify blocks unreachable from the entry.
  if(ssa.blocks[owner[i]].dominators.empty())continue;
  if(program.code[i].op==OpCode::Load&&!seen_loads.count(i))error("reachable Load is missing its SSA use record");
  if(program.code[i].op==OpCode::Store&&!seen_stores.count(i))error("reachable Store is missing its SSA definition record");
 }
 for(std::size_t bi=0;bi<ssa.blocks.size();++bi)for(const auto& phi:ssa.blocks[bi].phis)for(const auto& incoming:phi.incoming){
  if(incoming.first>=ssa.blocks.size())continue;
  check_value(phi.variable,incoming.second,incoming.first,ssa.blocks[incoming.first].end,"Phi incoming edge");
 }
 if(!ssa.stack_ssa_valid)for(const auto& message:ssa.stack_ssa_errors)error("stack SSA: "+message);
 std::unordered_map<std::size_t,const SSAValueDefinition*> value_defs;
 for(const auto& d:ssa.value_definitions){
  if(d.id==0||!value_defs.emplace(d.id,&d).second)error("duplicate or reserved stack SSA value ID");
  if(d.block>=ssa.blocks.size())error("stack SSA value has an invalid defining block");
  if(d.kind==SSAValueKind::Instruction&&(d.instruction>=program.code.size()||owner[d.instruction]!=d.block))error("stack SSA value does not match its defining instruction/block");
  if(d.kind==SSAValueKind::Entry&&(d.instruction!=none||d.block!=0))error("stack SSA entry value must be defined at function entry");
 }
 for(const auto& u:ssa.value_uses){
  auto it=value_defs.find(u.value);
  if(u.instruction>=program.code.size()||owner[u.instruction]>=ssa.blocks.size()) {error("stack SSA use has an invalid instruction");continue;}
  if(it==value_defs.end()){error("stack SSA use references an undefined value");continue;}
  const auto& d=*it->second;const auto use_block=owner[u.instruction];
  if(d.block==use_block){if(d.kind==SSAValueKind::Instruction&&d.instruction>=u.instruction)error("stack SSA use precedes its definition");}
  else if(!dominates(d.block,use_block))error("stack SSA definition does not dominate its use");
 }
 for(const auto& d:ssa.value_definitions)if(d.kind==SSAValueKind::Instruction){
  for(std::size_t k=0;k<d.operands.size();++k){
   const auto found=std::count_if(ssa.value_uses.begin(),ssa.value_uses.end(),[&](const SSAValueUse& u){return u.instruction==d.instruction&&u.value==d.operands[k]&&u.operand_index==k;});
   if(found!=1)error("stack SSA operand is missing or has duplicate use records");
  }
 }
 for(const auto& phi:ssa.stack_phis){
  if(phi.block>=ssa.blocks.size()) {error("stack Phi has invalid block");continue;}
  auto def=value_defs.find(phi.result);
  if(def==value_defs.end()||def->second->kind!=SSAValueKind::Phi||def->second->block!=phi.block)error("stack Phi result has no matching definition");
  std::vector<std::size_t> expected,actual;
  for(auto pred:ssa.blocks[phi.block].predecessors)if(pred<ssa.blocks.size()&&!ssa.blocks[pred].dominators.empty())expected.push_back(pred);
  for(const auto& incoming:phi.incoming){actual.push_back(incoming.first);if(incoming.first>=ssa.blocks.size()){error("stack Phi predecessor is invalid");continue;}
   auto value=value_defs.find(incoming.second);if(value==value_defs.end()){error("stack Phi incoming value is undefined");continue;}
   const auto def_block=value->second->block;
   if(def_block!=incoming.first&&!dominates(def_block,incoming.first))error("stack Phi incoming value is not available on its predecessor edge");
  }
  std::sort(expected.begin(),expected.end());std::sort(actual.begin(),actual.end());
  if(expected!=actual)error("stack Phi incoming edges do not match reachable predecessors");
 }
 // Verify coarse region tokens and field-sensitive object-memory tokens.
 struct MemoryDefSite { std::size_t block; std::size_t instruction; bool phi; SSAAliasRegion region; std::string partition_key; };
 std::unordered_map<std::size_t,MemoryDefSite> memory_defs;
 auto valid_memory_region=[](SSAAliasRegion region) {
  return region==SSAAliasRegion::HeapAggregate || region==SSAAliasRegion::ClosureCell;
 };
 auto field_key_parts=[](const std::string& key, std::size_t& site, std::string& field) {
  constexpr const char* prefix="object:";
  if(key.rfind(prefix,0)!=0) return false;
  const auto split=key.find(':',7);
  if(split==std::string::npos || split+1>=key.size()) return false;
  try { site=static_cast<std::size_t>(std::stoull(key.substr(7,split-7))); }
  catch(...) { return false; }
  field=key.substr(split+1); return true;
 };
 auto field_access_matches=[&](std::size_t instruction,const std::string& key,bool write) {
  if(instruction>=program.code.size()) return false;
  const auto& ins=program.code[instruction];
  const auto effect=memory_effect(ins);
  if(effect.unknown && write) return true;
  if(write && ins.op==OpCode::ObjectSet) {
   auto base=points_to_for_instruction_base(ssa,instruction);
   std::size_t site{}; std::string field;
   if(!field_key_parts(key,site,field)) return false;
   if(ins.operand.empty() || base.unknown || !base.parameter_indices.empty() || base.allocation_sites.empty()) return true;
   return ins.operand==field && std::find(base.allocation_sites.begin(),base.allocation_sites.end(),site)!=base.allocation_sites.end();
  }
  if(!write && (ins.op==OpCode::ObjectGet || ins.op==OpCode::ObjectHas)) {
   auto base=points_to_for_instruction_base(ssa,instruction);
   std::size_t site{}; std::string field;
   return field_key_parts(key,site,field) && ins.operand==field && !base.unknown &&
    base.parameter_indices.empty() && std::find(base.allocation_sites.begin(),base.allocation_sites.end(),site)!=base.allocation_sites.end();
  }
  return false;
 };
 auto array_key_parts=[](const std::string& key,std::size_t& site,std::int64_t& index) {
  constexpr const char* prefix="array:";
  if(key.rfind(prefix,0)!=0) return false;
  const auto split=key.find(':',6); if(split==std::string::npos||split+1>=key.size()) return false;
  try { site=static_cast<std::size_t>(std::stoull(key.substr(6,split-6))); index=std::stoll(key.substr(split+1)); }
  catch(...) { return false; }
  return index>=0;
 };
 auto array_access_matches=[&](std::size_t instruction,const std::string& key,bool write) {
  if(instruction>=program.code.size()) return false;
  const auto& ins=program.code[instruction]; const auto effect=memory_effect(ins);
  if(write && (effect.unknown||ins.op==OpCode::ArrayPush||ins.op==OpCode::ArrayPop)) return true;
  std::size_t site{}; std::int64_t index{}; if(!array_key_parts(key,site,index)) return false;
  SSAPointsToSet base; std::optional<std::int64_t> actual_index;
  if(write && ins.op==OpCode::ArraySet) {
   base=points_to_for_instruction_base(ssa,instruction);
   auto use=std::find_if(ssa.value_uses.begin(),ssa.value_uses.end(),[&](const SSAValueUse& u){return u.instruction==instruction&&u.operand_index==1;});
   if(use!=ssa.value_uses.end()) actual_index=constant_integer_value(ssa,use->value);
   if(!actual_index) return true; // dynamic/unknown store aliases every known slot
  } else if(!write && ins.op==OpCode::ArrayGet) {
   base=points_to_for_instruction_base(ssa,instruction); actual_index=constant_array_index(ssa,instruction);
  } else return false;
  if(write && (base.unknown||!base.parameter_indices.empty()||base.allocation_sites.empty())) return true;
  return actual_index && *actual_index==index && !base.unknown && base.parameter_indices.empty() &&
   std::find(base.allocation_sites.begin(),base.allocation_sites.end(),site)!=base.allocation_sites.end();
 };
 auto partition_access_matches=[&](std::size_t instruction,const std::string& key,bool write) {
  return key.rfind("object:",0)==0 ? field_access_matches(instruction,key,write) :
         key.rfind("array:",0)==0 ? array_access_matches(instruction,key,write) : false;
 };
 for(const auto& d:ssa.memory_definitions) {
  if(d.id==0||!memory_defs.emplace(d.id,MemoryDefSite{d.block,d.instruction,d.phi,d.region,d.partition_key}).second)
   error("duplicate or reserved Memory SSA definition ID");
  if(d.block>=ssa.blocks.size()) error("Memory SSA definition has an invalid block");
  if(!valid_memory_region(d.region)) error("Memory SSA definition must belong to a concrete alias partition");
  if(!d.partition_key.empty() && (d.region!=SSAAliasRegion::HeapAggregate ||
     (d.partition_key.rfind("object:",0)!=0 && d.partition_key.rfind("array:",0)!=0)))
   error("fine-grained Memory SSA key must identify a concrete object field or array slot");
  if(d.phi) {
   if(d.instruction!=none) error("Memory Phi must not reference an instruction");
  } else {
   if(d.instruction>=program.code.size()||d.block>=ssa.blocks.size()||owner[d.instruction]!=d.block)
    error("Memory SSA definition does not match its instruction/block");
   else {
    const auto effect=memory_effect(program.code[d.instruction]);
    if(!effect.write) error("Memory SSA definition is attached to a non-writing instruction");
    if(d.partition_key.empty()) {
     if(!(memory_partition_mask(ssa,d.instruction)&memory_partition_bit(d.region)))
      error("Memory SSA definition is attached to an unrelated alias partition");
    } else if(!partition_access_matches(d.instruction,d.partition_key,true))
     error("fine-grained Memory SSA definition is attached to an unrelated object field or array slot");
   }
  }
 }
 using MemoryPhiKey=std::tuple<std::size_t,int,std::string>;
 auto region_key=[](SSAAliasRegion region){return static_cast<int>(region);};
 std::set<MemoryPhiKey> seen_memory_phi;
 for(const auto& phi:ssa.memory_phis) {
  if(phi.block>=ssa.blocks.size()) {error("Memory Phi has invalid block");continue;}
  if(!valid_memory_region(phi.region)) error("Memory Phi must belong to a concrete alias partition");
  if(!phi.partition_key.empty() && (phi.region!=SSAAliasRegion::HeapAggregate ||
     (phi.partition_key.rfind("object:",0)!=0 && phi.partition_key.rfind("array:",0)!=0)))
   error("fine-grained Memory Phi has an invalid partition key");
  if(!seen_memory_phi.insert({phi.block,region_key(phi.region),phi.partition_key}).second)
   error("duplicate Memory Phi for a block/partition pair");
  auto def=memory_defs.find(phi.result);
  if(def==memory_defs.end()||!def->second.phi||def->second.block!=phi.block||def->second.region!=phi.region||def->second.partition_key!=phi.partition_key)
   error("Memory Phi result has no matching partition definition");
  std::vector<std::size_t> expected,actual;
  for(auto pred:ssa.blocks[phi.block].predecessors)
   if(pred<ssa.blocks.size()&&!ssa.blocks[pred].dominators.empty()) expected.push_back(pred);
  for(const auto& edge:phi.incoming) {
   actual.push_back(edge.first);
   if(edge.first>=ssa.blocks.size()) {error("Memory Phi predecessor is invalid");continue;}
   if(edge.second!=0) {
    auto incoming=memory_defs.find(edge.second);
    if(incoming==memory_defs.end()) error("Memory Phi incoming version is undefined");
    else {
     if(incoming->second.region!=phi.region || incoming->second.partition_key!=phi.partition_key)
      error("Memory Phi incoming version belongs to another partition");
     if(incoming->second.block!=edge.first &&
        std::find(ssa.blocks[edge.first].dominators.begin(),ssa.blocks[edge.first].dominators.end(),incoming->second.block)==ssa.blocks[edge.first].dominators.end())
      error("Memory Phi incoming version is unavailable on predecessor edge");
    }
   }
  }
  std::sort(expected.begin(),expected.end());std::sort(actual.begin(),actual.end());
  if(expected!=actual) error("Memory Phi incoming edges do not match reachable predecessors");
 }
 for(const auto& d:ssa.memory_definitions) if(d.phi && !seen_memory_phi.contains({d.block,region_key(d.region),d.partition_key}))
  error("orphan Memory Phi definition");
 using MemoryUseKey=std::tuple<std::size_t,int,std::string>;
 std::set<MemoryUseKey> seen_memory_uses;
 for(const auto& u:ssa.memory_uses) {
  if(u.instruction>=program.code.size()||owner[u.instruction]>=ssa.blocks.size()) {error("Memory SSA use has invalid instruction");continue;}
  if(!valid_memory_region(u.region)) error("Memory SSA use must belong to a concrete alias partition");
  if(!u.partition_key.empty() && (u.region!=SSAAliasRegion::HeapAggregate ||
     (u.partition_key.rfind("object:",0)!=0 && u.partition_key.rfind("array:",0)!=0)))
   error("fine-grained Memory SSA use has an invalid partition key");
  if(!seen_memory_uses.insert({u.instruction,region_key(u.region),u.partition_key}).second)
   error("duplicate Memory SSA use for instruction/partition pair");
  const auto effect=memory_effect(program.code[u.instruction]);
  if(!effect.read&&!effect.write) error("Memory SSA use is attached to a non-memory instruction");
  if(u.partition_key.empty()) {
   if(!(memory_partition_mask(ssa,u.instruction)&memory_partition_bit(u.region)))
    error("Memory SSA use is attached to an unrelated alias partition");
  } else if(!partition_access_matches(u.instruction,u.partition_key,false) &&
            !partition_access_matches(u.instruction,u.partition_key,true))
   error("fine-grained Memory SSA use is attached to an unrelated object field or array slot");
  if(u.version!=0) {
   auto def=memory_defs.find(u.version);
   if(def==memory_defs.end()) error("Memory SSA use references an undefined version");
   else {
    if(def->second.region!=u.region || def->second.partition_key!=u.partition_key)
     error("Memory SSA use references a version from another partition");
    if(def->second.block==owner[u.instruction]) {
     if(!def->second.phi&&def->second.instruction>=u.instruction) error("Memory SSA use precedes its definition");
    } else if(std::find(ssa.blocks[owner[u.instruction]].dominators.begin(),ssa.blocks[owner[u.instruction]].dominators.end(),def->second.block)==ssa.blocks[owner[u.instruction]].dominators.end())
     error("Memory SSA definition does not dominate its use");
   }
  }
 }
 for(std::size_t i=0;i<program.code.size();++i) if(owner[i]<ssa.blocks.size()&&!ssa.blocks[owner[i]].dominators.empty()) {
  const auto effect=memory_effect(program.code[i]);
  if(!effect.read&&!effect.write) continue;
  const auto mask=memory_partition_mask(ssa,i);
  for(const auto region:{SSAAliasRegion::HeapAggregate,SSAAliasRegion::ClosureCell}) {
   if(!(mask&memory_partition_bit(region))) continue;
   if(!seen_memory_uses.contains({i,region_key(region),std::string{}})) error("reachable memory operation is missing a partitioned Memory SSA use");
   if(effect.write) {
    const auto defs=std::count_if(ssa.memory_definitions.begin(),ssa.memory_definitions.end(),[&](const SSAMemoryDefinition& d){return !d.phi&&d.instruction==i&&d.region==region&&d.partition_key.empty();});
    if(defs!=1) error("reachable memory write is missing its unique partitioned Memory SSA definition");
   }
  }
 }
 std::unordered_set<std::size_t> range_values;
 std::size_t previous_range_value=0; bool first_range=true;
 std::unordered_set<std::size_t> defined_value_ids;
 for(const auto& definition:ssa.value_definitions) defined_value_ids.insert(definition.id);
 for(const auto& range:ssa.integer_ranges) {
  if(!defined_value_ids.contains(range.value)) error("integer range references an undefined SSA value");
  if(range.minimum>range.maximum) error("integer range minimum exceeds maximum");
  if(!range_values.insert(range.value).second) error("duplicate integer range for an SSA value");
  if(!first_range && range.value<=previous_range_value) error("integer ranges must be sorted by SSA value id");
  first_range=false; previous_range_value=range.value;
  auto definition=std::find_if(ssa.value_definitions.begin(),ssa.value_definitions.end(),[&](const SSAValueDefinition& item){return item.id==range.value;});
  if(definition!=ssa.value_definitions.end() && definition->kind==SSAValueKind::Instruction && definition->op==OpCode::PushInt &&
     (range.minimum!=definition->integer || range.maximum!=definition->integer))
   error("integer range for an integer literal must be its exact literal value");
 }
 std::unordered_map<std::size_t,const SSAPointsToSet*> points_by_value;
 for(const auto& points:ssa.points_to_sets) {
  if(!points_by_value.emplace(points.value,&points).second) error("duplicate points-to value set");
  if(!std::is_sorted(points.allocation_sites.begin(),points.allocation_sites.end()) ||
     std::adjacent_find(points.allocation_sites.begin(),points.allocation_sites.end())!=points.allocation_sites.end())
   error("points-to sites must be sorted and unique");
  for(auto site:points.allocation_sites) {
   const auto found=std::find_if(ssa.allocation_sites.begin(),ssa.allocation_sites.end(),[&](const SSAAllocationSite& a){return a.instruction==site;});
   if(found==ssa.allocation_sites.end()) error("points-to set references an unknown allocation site");
  }
 }
 std::unordered_set<std::size_t> allocation_ids;
 for(const auto& site:ssa.allocation_sites) {
  if(site.instruction>=program.code.size() || !allocation_ids.insert(site.instruction).second) error("invalid or duplicate allocation site");
  else { const auto op=program.code[site.instruction].op;
   if(!((site.kind==SSAAllocationKind::Array&&op==OpCode::MakeArray) ||
        (site.kind==SSAAllocationKind::Object&&op==OpCode::NewObject) ||
        (site.kind==SSAAllocationKind::Closure&&op==OpCode::MakeClosure))) error("allocation site kind does not match instruction");
  }
 }
 for(const auto& points:ssa.points_to_sets) {
  if(!std::is_sorted(points.parameter_indices.begin(),points.parameter_indices.end()) ||
     std::adjacent_find(points.parameter_indices.begin(),points.parameter_indices.end())!=points.parameter_indices.end())
   error("points-to parameter origins must be sorted and unique");
 }
 std::set<std::pair<std::size_t,std::string>> unique_field_slots;
 for(const auto& field:ssa.field_points_to) {
  if(!unique_field_slots.emplace(field.allocation_site,field.field).second) error("duplicate field points-to slot");
  if(field.field.empty()) error("field points-to entry has an empty field name");
  if(!std::is_sorted(field.allocation_sites.begin(),field.allocation_sites.end()) || std::adjacent_find(field.allocation_sites.begin(),field.allocation_sites.end())!=field.allocation_sites.end()) error("field points-to sites must be sorted and unique");
  if(!std::is_sorted(field.parameter_indices.begin(),field.parameter_indices.end()) || std::adjacent_find(field.parameter_indices.begin(),field.parameter_indices.end())!=field.parameter_indices.end()) error("field points-to parameter origins must be sorted and unique");
  if(!allocation_ids.contains(field.allocation_site)) error("field points-to entry references an unknown base allocation site");
  for(auto site:field.allocation_sites) if(!allocation_ids.contains(site)) error("field points-to entry references an unknown value allocation site");
 }
 for(const auto& d:ssa.value_definitions) if(!points_by_value.contains(d.id)) error("value SSA definition is missing its points-to set");
 std::map<std::size_t,SSAAliasAccess> alias_by_instruction;
 for(const auto& access:ssa.alias_accesses) {
  if(access.instruction>=program.code.size()||owner[access.instruction]>=ssa.blocks.size()) { error("alias access has invalid instruction"); continue; }
  if(!alias_by_instruction.emplace(access.instruction,access).second) error("duplicate alias access for an instruction");
  const auto effect=memory_effect(program.code[access.instruction]);
  const auto expected_region=effect.unknown?SSAAliasRegion::Unknown:
   (program.code[access.instruction].op==OpCode::LoadCell?SSAAliasRegion::ClosureCell:SSAAliasRegion::HeapAggregate);
  const std::uint8_t expected_mask=effect.unknown?alias_all_bits:(expected_region==SSAAliasRegion::ClosureCell?alias_cell_bit:alias_heap_bit);
  if(!(effect.read||effect.write)||access.region!=expected_region||access.read!=effect.read||access.write!=effect.write||access.may_alias_mask!=expected_mask)
   error("alias access classification does not match instruction effects");
  if(!std::is_sorted(access.points_to_sites.begin(),access.points_to_sites.end()) ||
     std::adjacent_find(access.points_to_sites.begin(),access.points_to_sites.end())!=access.points_to_sites.end())
   error("points-to allocation sites must be sorted and unique");
  for(auto site:access.points_to_sites) {
   const auto found=std::find_if(ssa.allocation_sites.begin(),ssa.allocation_sites.end(),[&](const SSAAllocationSite& a){return a.instruction==site;});
   if(found==ssa.allocation_sites.end()) error("alias access references an unknown allocation site");
  }
  if(access.must_alias_singleton!=( !access.points_to_unknown && access.points_to_sites.size()==1))
   error("must-alias singleton flag is inconsistent with points-to set");
 }
 for(std::size_t i=0;i<program.code.size();++i) if(owner[i]<ssa.blocks.size()&&!ssa.blocks[owner[i]].dominators.empty()) {
  const auto e=memory_effect(program.code[i]);
  if((e.read||e.write)&&!alias_by_instruction.contains(i)) error("reachable memory operation is missing alias analysis metadata");
 }
 return result;
}

SSAVerificationResult verify_ssa(const SSAProgram& ssa,const ProgramIR& program) {
 auto result=verify_ssa_single(ssa,program);
 auto error=[&](const std::string& message){result.ok=false;result.errors.push_back(message);};
 std::unordered_set<std::string> names;
 for(const auto& fn:ssa.functions) {
  if(fn.name.empty()||!names.insert(fn.name).second) error("function SSA region has an empty or duplicate name");
  if(fn.begin==0||fn.begin>fn.end||fn.end>program.code.size()) {error("function SSA region has invalid instruction bounds");continue;}
  const auto& marker=program.code[fn.begin-1];
  if(marker.op!=OpCode::Function||marker.operand!=fn.name) error("function SSA region does not match its Function marker");
  if(marker.integer<0||static_cast<std::size_t>(marker.integer)!=fn.arity) error("function SSA arity does not match its Function marker");
  if(!fn.analysis) {error("function SSA region has no analysis payload");continue;}
  const auto body=slice_function_body(program,fn.begin,fn.end);
  const auto checked=verify_ssa_single(*fn.analysis,body);
  for(const auto& message:checked.errors) error("function "+fn.name+": "+message);
  if(!std::is_sorted(fn.return_parameter_indices.begin(),fn.return_parameter_indices.end()) ||
     std::adjacent_find(fn.return_parameter_indices.begin(),fn.return_parameter_indices.end())!=fn.return_parameter_indices.end())
   error("function return parameter summary must be sorted and unique");
  for(auto parameter:fn.return_parameter_indices) if(parameter>=fn.arity) error("function return summary references an argument outside its arity");
  if(!std::is_sorted(fn.return_allocation_sites.begin(),fn.return_allocation_sites.end()) ||
     std::adjacent_find(fn.return_allocation_sites.begin(),fn.return_allocation_sites.end())!=fn.return_allocation_sites.end())
   error("function return allocation summary must be sorted and unique");
  for(auto site:fn.return_allocation_sites) if(site>=program.code.size() ||
     !(program.code[site].op==OpCode::MakeArray || program.code[site].op==OpCode::NewObject || program.code[site].op==OpCode::MakeClosure))
   error("function return summary references an invalid allocation site");
  std::size_t previous_parameter=none;
  for(const auto& effect:fn.parameter_effects) {
   if(effect.parameter_index>=fn.arity) error("function parameter effect references an argument outside its arity");
   if(previous_parameter!=none&&effect.parameter_index<=previous_parameter) error("function parameter effects must be sorted and unique");
   previous_parameter=effect.parameter_index;
  }
 }
 return result;
}

static std::string dump_ssa_single(const SSAProgram& p){std::ostringstream out;out<<"SSA blocks="<<p.blocks.size()<<" variables="<<p.variable_count<<" phis="<<p.phi_count<<'\n';
 for(const auto& b:p.blocks){out<<"B"<<b.id<<" idom=";if(b.immediate_dominator==none)out<<"-";else out<<'B'<<b.immediate_dominator;out<<" preds=";for(auto x:b.predecessors)out<<'B'<<x<<' ';out<<" DF=";for(auto x:b.dominance_frontier)out<<'B'<<x<<' ';out<<'\n';
  for(const auto& phi:b.phis){out<<"  "<<phi.variable<<'.'<<phi.result_version<<" = phi(";for(std::size_t i=0;i<phi.incoming.size();++i){if(i)out<<", ";out<<"B"<<phi.incoming[i].first<<":"<<phi.variable<<'.'<<phi.incoming[i].second;}out<<")\n";}}
 for(const auto& d:p.definitions)if(d.instruction!=none)out<<"  i"<<d.instruction<<": "<<d.variable<<'.'<<d.version<<" = store\n";
 for(const auto& u:p.uses) out<<"  i"<<u.instruction<<": load "<<u.variable<<'.'<<u.version<<'\n';
 out<<"Value SSA: "<<(p.stack_ssa_valid?"valid":"invalid")<<" defs="<<p.value_definitions.size()<<" uses="<<p.value_uses.size()<<" stack_phis="<<p.stack_phis.size()<<'\n';
 for(const auto& phi:p.stack_phis){out<<"  v"<<phi.result<<" = stack_phi[B"<<phi.block<<", slot "<<phi.stack_slot<<"](";for(std::size_t i=0;i<phi.incoming.size();++i){if(i)out<<", ";out<<"B"<<phi.incoming[i].first<<":v"<<phi.incoming[i].second;}out<<")\n";}
 for(const auto& d:p.value_definitions)if(d.kind==SSAValueKind::Instruction){
  const char* label="value";
  switch(d.op){
   case OpCode::PushInt:label="push_i64";break;case OpCode::PushString:label="push_string";break;
   case OpCode::Load:label="load";break;case OpCode::LoadCell:label="load_cell";break;
   case OpCode::Add:label="add";break;case OpCode::Sub:label="sub";break;case OpCode::Mul:label="mul";break;case OpCode::Div:label="div";break;
   case OpCode::BoolNot:label="bool_not";break;case OpCode::Equal:label="equal";break;case OpCode::NotEqual:label="not_equal";break;
   case OpCode::Less:label="less";break;case OpCode::LessEqual:label="less_equal";break;case OpCode::Greater:label="greater";break;case OpCode::GreaterEqual:label="greater_equal";break;
   case OpCode::LogicalAnd:label="logical_and";break;case OpCode::LogicalOr:label="logical_or";break;
   case OpCode::ArrayGet:label="array_get";break;case OpCode::ArrayLength:label="array_length";break;case OpCode::ArrayPop:label="array_pop";break;case OpCode::ArrayPush:label="array_push";break;
   case OpCode::ObjectGet:label="object_get";break;case OpCode::ObjectHas:label="object_has";break;case OpCode::Call:label="call_result";break;case OpCode::CallIndirect:label="indirect_call_result";break;
   case OpCode::MakeArray:label="make_array";break;case OpCode::MakeClosure:label="make_closure";break;case OpCode::NewObject:label="new_object";break;case OpCode::LoadFunction:label="load_function";break;
   default:break;
  }
  out<<"  v"<<d.id<<" = "<<label<<" @i"<<d.instruction;
  if(d.op==OpCode::PushInt)out<<" ("<<d.integer<<")";
  if(!d.text.empty())out<<" ["<<d.text<<"]";
  if(!d.operands.empty()){out<<" <-";for(auto operand:d.operands)out<<" v"<<operand;}
  out<<'\n';
 }
 out<<"Integer range analysis: "<<p.integer_ranges.size()<<" proven finite ranges\n";
 for(const auto& range:p.integer_ranges) out<<"  v"<<range.value<<" in ["<<range.minimum<<", "<<range.maximum<<"]\n";
 out<<"Memory SSA partitions: heap_aggregate + closure_cell + field-sensitive object tokens + nested constant-index array slots (unknown effects touch all discovered partitions)\n";
 for(const auto& phi:p.memory_phis) {
  out<<"  m"<<phi.result<<"["<<to_string(phi.region);
  if(!phi.partition_key.empty()) out<<":"<<phi.partition_key;
  out<<"] = memory_phi[B"<<phi.block<<"](";
  for(std::size_t i=0;i<phi.incoming.size();++i){if(i)out<<", ";out<<"B"<<phi.incoming[i].first<<":m"<<phi.incoming[i].second;}
  out<<")\n";
 }
 for(const auto& d:p.memory_definitions) if(!d.phi) {
  out<<"  m"<<d.id<<"["<<to_string(d.region);
  if(!d.partition_key.empty()) out<<":"<<d.partition_key;
  out<<"] = memory_"<<to_string(d.effect)<<" @i"<<d.instruction<<"\n";
 }
 for(const auto& u:p.memory_uses) {
  out<<"  i"<<u.instruction<<": memory_"<<to_string(u.effect)<<"["<<to_string(u.region);
  if(!u.partition_key.empty()) out<<":"<<u.partition_key;
  out<<"] m"<<u.version<<"\n";
 }
 out<<"Points-to: allocation_sites="<<p.allocation_sites.size()<<" value_sets="<<p.points_to_sets.size()<<"\n";
 for(const auto& site:p.allocation_sites) out<<"  allocation @i"<<site.instruction<<" kind="<<to_string(site.kind)<<"\n";
 for(const auto& points:p.points_to_sets) if(!points.allocation_sites.empty()||points.unknown) {
  out<<"  v"<<points.value<<" points_to={";
  for(std::size_t i=0;i<points.allocation_sites.size();++i){if(i)out<<",";out<<"@i"<<points.allocation_sites[i];}
  out<<"} unknown="<<(points.unknown?"yes":"no")<<"\n";
 }
 out<<"Field-sensitive points-to: "<<p.field_points_to.size()<<" field slots\n";
 for(const auto& field:p.field_points_to) {
  out<<"  @i"<<field.allocation_site<<"."<<field.field<<" -> {";
  for(std::size_t i=0;i<field.allocation_sites.size();++i){if(i)out<<",";out<<"@i"<<field.allocation_sites[i];}
  out<<"} params={";for(std::size_t i=0;i<field.parameter_indices.size();++i){if(i)out<<",";out<<"arg"<<field.parameter_indices[i];}
  out<<"} unknown="<<(field.unknown?"yes":"no")<<"\n";
 }
 out<<"Alias accesses: "<<p.alias_accesses.size()<<"\n";
 for(const auto& a:p.alias_accesses) {
  out<<"  i"<<a.instruction<<": "<<to_string(a.region)
   <<" read="<<(a.read?"yes":"no")<<" write="<<(a.write?"yes":"no")
   <<" may_alias_mask=0x"<<std::hex<<static_cast<unsigned>(a.may_alias_mask)<<std::dec
   <<" points_to={";
  for(std::size_t i=0;i<a.points_to_sites.size();++i){if(i)out<<",";out<<"@i"<<a.points_to_sites[i];}
  out<<"} points_to_unknown="<<(a.points_to_unknown?"yes":"no")
     <<" must_alias_singleton="<<(a.must_alias_singleton?"yes":"no")<<"\n";
 }
 return out.str();}

const char* to_string(SSAMemoryEffect effect) {
 switch(effect) {
  case SSAMemoryEffect::Read:return "read";
  case SSAMemoryEffect::Write:return "write";
  case SSAMemoryEffect::ReadWrite:return "read_write";
  case SSAMemoryEffect::Unknown:return "unknown";
 }
 return "unknown";
}
const char* to_string(SSAAliasRegion region) {
 switch(region) {
  case SSAAliasRegion::HeapAggregate:return "heap_aggregate";
  case SSAAliasRegion::ClosureCell:return "closure_cell";
  case SSAAliasRegion::Unknown:return "unknown";
 }
 return "unknown";
}
bool alias_regions_may_alias(SSAAliasRegion a, SSAAliasRegion b) {
 return a==SSAAliasRegion::Unknown || b==SSAAliasRegion::Unknown || a==b;
}
bool points_to_sets_may_alias(const SSAPointsToSet& a,const SSAPointsToSet& b) {
 if(a.unknown || b.unknown) return true;
 // A symbolic formal parameter may designate any caller-visible allocation;
 // parameter provenance is therefore not evidence of disjointness.
 if(!a.parameter_indices.empty() || !b.parameter_indices.empty()) return true;
 for(auto site:a.allocation_sites)
  if(std::find(b.allocation_sites.begin(),b.allocation_sites.end(),site)!=b.allocation_sites.end()) return true;
 return false;
}
const char* to_string(SSAAllocationKind kind) {
 switch(kind) { case SSAAllocationKind::Array:return "array"; case SSAAllocationKind::Object:return "object"; case SSAAllocationKind::Closure:return "closure"; }
 return "object";
}
std::string dump_ssa(const SSAProgram& p) {
 std::ostringstream out; out<<dump_ssa_single(p);
 out<<"Functions analyzed: "<<p.functions.size()<<'\n';
 for(const auto& fn:p.functions) {
  out<<"Function "<<fn.name<<" ["<<fn.begin<<","<<fn.end<<") arity="<<fn.arity
     <<" reads_memory="<<(fn.may_read_memory?"yes":"no")
     <<" writes_memory="<<(fn.may_write_memory?"yes":"no")
     <<" unknown_effects="<<(fn.has_unknown_effects?"yes":"no")
     <<" alias_read_mask=0x"<<std::hex<<static_cast<unsigned>(fn.alias_read_mask)
     <<" alias_write_mask=0x"<<static_cast<unsigned>(fn.alias_write_mask)<<std::dec
     <<" return_params={";
  for(std::size_t i=0;i<fn.return_parameter_indices.size();++i){if(i)out<<",";out<<"arg"<<fn.return_parameter_indices[i];}
  out<<"} return_sites={";for(std::size_t i=0;i<fn.return_allocation_sites.size();++i){if(i)out<<",";out<<"@i"<<fn.return_allocation_sites[i];}
  out<<"} return_unknown="<<(fn.return_unknown?"yes":"no")<<'\n';
  out<<"  parameter_effects="<<fn.parameter_effects.size()<<'\n';
  for(const auto& effect:fn.parameter_effects)
   out<<"    arg"<<effect.parameter_index<<": read="<<(effect.may_read_memory?"yes":"no")
      <<" write="<<(effect.may_write_memory?"yes":"no")
      <<" escape="<<(effect.may_escape?"yes":"no")<<'\n';
  if(fn.analysis) out<<dump_ssa_single(*fn.analysis);
 }
 return out.str();
}
}
