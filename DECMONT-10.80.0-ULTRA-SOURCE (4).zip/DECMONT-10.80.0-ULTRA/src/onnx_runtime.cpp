#include "docmont/onnx_runtime.hpp"
#include <algorithm>
#include <cmath>
#include <cstring>
#include <fstream>
#include <limits>
#include <set>

namespace docmont::neural {
namespace {
struct Field { std::uint32_t number{}, wire{}; std::uint64_t varint{}; std::vector<std::uint8_t> bytes; std::uint32_t fixed32{}; };
class Reader {
public:
    explicit Reader(const std::vector<std::uint8_t>& b):b_(b){}
    bool next(Field& f){
        if(pos_>=b_.size())return false;
        std::uint64_t tag=0;if(!varint(tag)||tag==0)return fail("invalid protobuf tag");
        f={};f.number=static_cast<std::uint32_t>(tag>>3);f.wire=static_cast<std::uint32_t>(tag&7);
        if(f.number==0)return fail("protobuf field number zero");
        if(f.wire==0)return varint(f.varint);
        if(f.wire==1){if(pos_+8>b_.size())return fail("truncated fixed64");pos_+=8;return true;}
        if(f.wire==2){std::uint64_t n=0;if(!varint(n)||n>b_.size()-pos_)return fail("invalid length-delimited field");f.bytes.assign(b_.begin()+static_cast<std::ptrdiff_t>(pos_),b_.begin()+static_cast<std::ptrdiff_t>(pos_+n));pos_+=static_cast<std::size_t>(n);return true;}
        if(f.wire==5){if(pos_+4>b_.size())return fail("truncated fixed32");std::memcpy(&f.fixed32,b_.data()+pos_,4);pos_+=4;return true;}
        return fail("unsupported protobuf wire type");
    }
    const std::string& error()const{return error_;}
private:
    bool varint(std::uint64_t& v){v=0;for(unsigned i=0;i<10;++i){if(pos_>=b_.size())return fail("truncated protobuf varint");auto c=b_[pos_++];if(i==9&&(c&0xfe))return fail("protobuf varint overflow");v|=std::uint64_t(c&0x7f)<<(7*i);if(!(c&0x80))return true;}return fail("overlong protobuf varint");}
    bool fail(const char* s){error_=s;return false;}
    const std::vector<std::uint8_t>& b_;std::size_t pos_{};std::string error_;
};
std::string str(const Field& f){return std::string(f.bytes.begin(),f.bytes.end());}
std::size_t element_count(const std::vector<std::int64_t>& shape);
bool parse_packed_varints(const std::vector<std::uint8_t>& b,std::vector<std::int64_t>& out){std::size_t p=0;while(p<b.size()){std::uint64_t v=0;unsigned shift=0;bool done=false;for(unsigned i=0;i<10&&p<b.size();++i){auto c=b[p++];if(i==9&&(c&0xfe))return false;v|=std::uint64_t(c&0x7f)<<shift;if(!(c&0x80)){done=true;break;}shift+=7;}if(!done)return false;out.push_back(static_cast<std::int64_t>(v));}return true;}
bool parse_tensor(const std::vector<std::uint8_t>& b,std::string& name,Tensor& t,std::string& error){
    Reader r(b);Field f;std::vector<std::int64_t> dims;std::vector<float> fdata;std::vector<std::uint8_t> raw;std::int64_t dtype=0;
    while(r.next(f)){switch(f.number){case 1:if(f.wire==2){if(!parse_packed_varints(f.bytes,dims)){error="invalid ONNX tensor dimensions";return false;}}else if(f.wire==0)dims.push_back(static_cast<std::int64_t>(f.varint));break;case 2:if(f.wire==0)dtype=static_cast<std::int64_t>(f.varint);break;case 4:if(f.wire==2){if(f.bytes.size()%4){error="invalid ONNX float_data size";return false;}for(std::size_t i=0;i<f.bytes.size();i+=4){float x;std::memcpy(&x,f.bytes.data()+i,4);fdata.push_back(x);}}else if(f.wire==5){float x;std::memcpy(&x,&f.fixed32,4);fdata.push_back(x);}break;case 8:name=str(f);break;case 9:raw=f.bytes;break;default:break;}}
    if(!r.error().empty()){error=r.error();return false;}if(dtype!=1){error="DOCMONT ONNX runtime currently supports FLOAT tensors only";return false;}t.shape=dims;const auto expected=element_count(t.shape);if(expected==0||expected>16u*1024u*1024u){error="invalid or oversized ONNX tensor shape";return false;}
    if(!raw.empty()){if(raw.size()%4){error="ONNX raw_data is not float32-aligned";return false;}if(raw.size()/4!=expected){error="ONNX raw_data length does not match tensor shape";return false;}t.values.resize(expected);std::memcpy(t.values.data(),raw.data(),raw.size());}
    else t.values=std::move(fdata);
    if(t.values.size()!=element_count(t.shape)){error="ONNX initializer element count does not match shape";return false;}
    for(float x:t.values)if(!std::isfinite(x)){error="ONNX initializer contains non-finite value";return false;}
    return !name.empty();
}
std::size_t element_count(const std::vector<std::int64_t>& shape){std::size_t n=1;for(auto d:shape){if(d<=0||static_cast<std::uint64_t>(d)>std::numeric_limits<std::size_t>::max()/n)return 0;n*=static_cast<std::size_t>(d);}return n;}
bool parse_value_info(const std::vector<std::uint8_t>& b,std::string& name){Reader r(b);Field f;while(r.next(f))if(f.number==1&&f.wire==2){name=str(f);break;}return !name.empty();}
bool parse_node(const std::vector<std::uint8_t>& b,OnnxModel::Node& node,std::string& error){
    Reader r(b);Field f;while(r.next(f)){if(f.wire!=2)continue;switch(f.number){case 1:node.info.inputs.push_back(str(f));break;case 2:node.info.outputs.push_back(str(f));break;case 3:break;case 4:node.info.op_type=str(f);break;case 5:{Reader ar(f.bytes);Field a;OnnxModel::Attribute attr;while(ar.next(a)){if(a.number==1&&a.wire==2)attr.name=str(a);else if(a.number==2&&a.wire==5)std::memcpy(&attr.real,&a.fixed32,4);else if(a.number==3&&a.wire==0)attr.integer=static_cast<std::int64_t>(a.varint);else if(a.number==8&&a.wire==2){if(!parse_packed_varints(a.bytes,attr.integers)){error="invalid packed ONNX integer attribute";return false;}}else if(a.number==8&&a.wire==0)attr.integers.push_back(static_cast<std::int64_t>(a.varint));}if(!ar.error().empty()){error=ar.error();return false;}node.attributes.push_back(std::move(attr));break;}default:break;}}
    if(!r.error().empty()){error=r.error();return false;}if(node.info.op_type.empty()||node.info.outputs.empty()){error="ONNX node requires op_type and output";return false;}return true;
}
bool parse_graph(const std::vector<std::uint8_t>& b,ModelInfo& info,std::vector<OnnxModel::Node>& nodes,std::map<std::string,Tensor>& initializers,std::string& error){
    Reader r(b);Field f;while(r.next(f)){if(f.wire!=2)continue;if(f.number==1){OnnxModel::Node n;if(!parse_node(f.bytes,n,error))return false;info.nodes.push_back(n.info);nodes.push_back(std::move(n));}
        else if(f.number==2)info.graph_name=str(f);
        else if(f.number==5){std::string name;Tensor t;if(!parse_tensor(f.bytes,name,t,error))return false;info.initializer_bytes+=t.values.size()*sizeof(float);if(!initializers.emplace(name,std::move(t)).second){error="duplicate ONNX initializer name";return false;}}
        else if(f.number==11){std::string n;if(!parse_value_info(f.bytes,n)){error="invalid ONNX graph input";return false;}info.inputs.push_back(std::move(n));}
        else if(f.number==12){std::string n;if(!parse_value_info(f.bytes,n)){error="invalid ONNX graph output";return false;}info.outputs.push_back(std::move(n));}}
    if(!r.error().empty()){error=r.error();return false;}return true;
}
const OnnxModel::Attribute* attr(const OnnxModel::Node& n,const std::string& key){for(const auto& a:n.attributes)if(a.name==key)return &a;return nullptr;}
std::optional<Tensor> binary_broadcast(const Tensor& a,const Tensor& b,const std::string& op,std::string& error){
    std::vector<std::int64_t> shape(std::max(a.shape.size(),b.shape.size()),1);
    for(std::size_t k=0;k<shape.size();++k){const auto ai=k<a.shape.size()?a.shape[a.shape.size()-1-k]:1;const auto bi=k<b.shape.size()?b.shape[b.shape.size()-1-k]:1;if(ai!=bi&&ai!=1&&bi!=1){error="ONNX Add/Mul broadcast dimensions are incompatible";return std::nullopt;}shape[shape.size()-1-k]=std::max(ai,bi);}
    Tensor out;out.shape=shape;const auto total=element_count(shape);if(!total||total>16u*1024u*1024u){error="ONNX output tensor exceeds element limit";return std::nullopt;}out.values.resize(total);
    std::vector<std::size_t> strides(shape.size(),1),as(a.shape.size(),1),bs(b.shape.size(),1);for(std::size_t i=shape.size();i-->1;)strides[i-1]=strides[i]*static_cast<std::size_t>(shape[i]);
    for (std::size_t i = a.shape.size(); i-- > 1;) {
        as[i - 1] = as[i] * static_cast<std::size_t>(a.shape[i]);
    }
    for (std::size_t i = b.shape.size(); i-- > 1;) {
        bs[i - 1] = bs[i] * static_cast<std::size_t>(b.shape[i]);
    }
    for(std::size_t linear=0;linear<total;++linear){std::size_t ai=0,bi=0;for(std::size_t d=0;d<shape.size();++d){const auto coord=(linear/strides[d])%static_cast<std::size_t>(shape[d]);const auto ad=d+ a.shape.size()>=shape.size()?d-(shape.size()-a.shape.size()):shape.size();const auto bd=d+ b.shape.size()>=shape.size()?d-(shape.size()-b.shape.size()):shape.size();if(ad<a.shape.size()&&a.shape[ad]!=1)ai+=coord*as[ad];if(bd<b.shape.size()&&b.shape[bd]!=1)bi+=coord*bs[bd];}
        const float av=a.values[ai],bv=b.values[bi];
        if(op=="Add")out.values[linear]=av+bv;
        else if(op=="Sub")out.values[linear]=av-bv;
        else if(op=="Mul")out.values[linear]=av*bv;
        else if(op=="Div"){if(bv==0.0f){error="ONNX Div encountered division by zero";return std::nullopt;}out.values[linear]=av/bv;}
        else if(op=="Pow")out.values[linear]=std::pow(av,bv);
        else if(op=="Max")out.values[linear]=std::max(av,bv);
        else if(op=="Min")out.values[linear]=std::min(av,bv);
        else {error="unsupported broadcast operator: "+op;return std::nullopt;}}
    return out;
}
std::optional<Tensor> execute_node(const OnnxModel::Node& n,const std::map<std::string,Tensor>& values,std::string& error){
    std::vector<const Tensor*> in;for(const auto& name:n.info.inputs){if(name.empty())continue;auto it=values.find(name);if(it==values.end()){error="ONNX node input not found: "+name;return std::nullopt;}in.push_back(&it->second);}const auto& op=n.info.op_type;
    if(op=="Identity"){if(in.size()!=1){error="Identity expects one input";return std::nullopt;}return *in[0];}
    if(op=="Add"||op=="Sub"||op=="Mul"||op=="Div"||op=="Pow"||op=="Max"||op=="Min"){if(in.size()!=2){error=op+" expects two inputs";return std::nullopt;}return binary_broadcast(*in[0],*in[1],op,error);}
    if(op=="Relu"||op=="Sigmoid"||op=="Tanh"||op=="LeakyRelu"||op=="Elu"||op=="Softplus"||op=="HardSigmoid"){if(in.size()!=1){error=op+" expects one input";return std::nullopt;}Tensor out=*in[0];const float alpha=attr(n,"alpha")?attr(n,"alpha")->real:(op=="HardSigmoid"?0.2f:0.01f);const float beta=attr(n,"beta")?attr(n,"beta")->real:(op=="HardSigmoid"?0.5f:0.0f);for(auto& x:out.values){if(op=="Relu")x=std::max(0.0f,x);else if(op=="Sigmoid")x=1.0f/(1.0f+std::exp(-x));else if(op=="Tanh")x=std::tanh(x);else if(op=="LeakyRelu")x=x>=0?x:alpha*x;else if(op=="Elu")x=x>=0?x:alpha*(std::exp(x)-1.0f);else if(op=="Softplus")x=std::max(x,0.0f)+std::log1p(std::exp(-std::abs(x)));else x=std::clamp(alpha*x+beta,0.0f,1.0f);}return out;}
    if(op=="Flatten"){
        if(in.size()!=1){error="Flatten expects one input";return std::nullopt;}const auto& a=*in[0];std::int64_t axis=attr(n,"axis")?attr(n,"axis")->integer:1;const auto rank=static_cast<std::int64_t>(a.shape.size());if(axis<0)axis+=rank;if(axis<0||axis>rank){error="Flatten axis out of range";return std::nullopt;}std::int64_t left=1,right=1;for(std::int64_t i=0;i<axis;++i)left*=a.shape[static_cast<std::size_t>(i)];for(std::int64_t i=axis;i<rank;++i)right*=a.shape[static_cast<std::size_t>(i)];Tensor out=a;out.shape={left,right};return out;
    }
    if(op=="Transpose"){
        if(in.size()!=1){error="Transpose expects one input";return std::nullopt;}const auto& a=*in[0];std::vector<std::int64_t> perm;if(auto at=attr(n,"perm"))perm=at->integers;if(perm.empty()){for(std::size_t i=a.shape.size();i-->0;)perm.push_back(static_cast<std::int64_t>(i));}if(perm.size()!=a.shape.size()){error="Transpose permutation rank mismatch";return std::nullopt;}std::vector<bool> seen(perm.size());Tensor out;out.shape.resize(perm.size());for(std::size_t i=0;i<perm.size();++i){if(perm[i]<0||static_cast<std::size_t>(perm[i])>=perm.size()||seen[static_cast<std::size_t>(perm[i])]){error="Transpose permutation is invalid";return std::nullopt;}seen[static_cast<std::size_t>(perm[i])]=true;out.shape[i]=a.shape[static_cast<std::size_t>(perm[i])];}out.values.resize(a.values.size());std::vector<std::size_t> in_stride(a.shape.size(),1),out_stride(out.shape.size(),1);for(std::size_t i=a.shape.size();i-->1;)in_stride[i-1]=in_stride[i]*static_cast<std::size_t>(a.shape[i]);for(std::size_t i=out.shape.size();i-->1;)out_stride[i-1]=out_stride[i]*static_cast<std::size_t>(out.shape[i]);for(std::size_t linear=0;linear<out.values.size();++linear){std::size_t src=0;for(std::size_t d=0;d<perm.size();++d){const auto coord=(linear/out_stride[d])%static_cast<std::size_t>(out.shape[d]);src+=coord*in_stride[static_cast<std::size_t>(perm[d])];}out.values[linear]=a.values[src];}return out;
    }
    if(op=="ReduceMean"){
        if(in.size()!=1){error="ReduceMean expects one input";return std::nullopt;}const auto& a=*in[0];std::vector<std::int64_t> axes;if(auto at=attr(n,"axes"))axes=at->integers;if(axes.empty()){for(std::size_t i=0;i<a.shape.size();++i)axes.push_back(static_cast<std::int64_t>(i));}std::vector<bool> reduce(a.shape.size());for(auto axis:axes){if(axis<0)axis+=static_cast<std::int64_t>(a.shape.size());if(axis<0||static_cast<std::size_t>(axis)>=a.shape.size()||reduce[static_cast<std::size_t>(axis)]){error="ReduceMean axes are invalid";return std::nullopt;}reduce[static_cast<std::size_t>(axis)]=true;}const bool keep=attr(n,"keepdims")?attr(n,"keepdims")->integer!=0:true;Tensor out;for(std::size_t i=0;i<a.shape.size();++i)if(!reduce[i])out.shape.push_back(a.shape[i]);else if(keep)out.shape.push_back(1);if(out.shape.empty()&&!keep)out.shape={1};const auto out_count=element_count(out.shape);if(!out_count){error="ReduceMean output shape invalid";return std::nullopt;}out.values.assign(out_count,0.0f);std::vector<std::size_t> in_stride(a.shape.size(),1),out_stride(out.shape.size(),1);for(std::size_t i=a.shape.size();i-->1;)in_stride[i-1]=in_stride[i]*static_cast<std::size_t>(a.shape[i]);for(std::size_t i=out.shape.size();i-->1;)out_stride[i-1]=out_stride[i]*static_cast<std::size_t>(out.shape[i]);std::size_t divisor=1;for(std::size_t i=0;i<a.shape.size();++i)if(reduce[i])divisor*=static_cast<std::size_t>(a.shape[i]);for(std::size_t linear=0;linear<a.values.size();++linear){std::size_t oi=0,od=0;for(std::size_t d=0;d<a.shape.size();++d){const auto coord=(linear/in_stride[d])%static_cast<std::size_t>(a.shape[d]);if(!reduce[d]){oi+=coord*out_stride[od++];}else if(keep){++od;}}out.values[oi]+=a.values[linear];}for(auto& x:out.values)x/=static_cast<float>(divisor);return out;
    }
    if(op=="Concat"){
        if(in.empty()){error="Concat expects one or more inputs";return std::nullopt;}const auto rank=in.front()->shape.size();std::int64_t axis=attr(n,"axis")?attr(n,"axis")->integer:0;if(axis<0)axis+=static_cast<std::int64_t>(rank);if(axis<0||static_cast<std::size_t>(axis)>=rank){error="Concat axis out of range";return std::nullopt;}Tensor out;out.shape=in.front()->shape;out.shape[static_cast<std::size_t>(axis)]=0;std::size_t outer=1,inner=1;for(std::size_t i=0;i<static_cast<std::size_t>(axis);++i)outer*=static_cast<std::size_t>(out.shape[i]);for(std::size_t i=static_cast<std::size_t>(axis)+1;i<rank;++i)inner*=static_cast<std::size_t>(out.shape[i]);std::vector<std::size_t> axis_dims;for(const auto* t:in){if(t->shape.size()!=rank){error="Concat input ranks differ";return std::nullopt;}for(std::size_t d=0;d<rank;++d)if(d!=static_cast<std::size_t>(axis)&&t->shape[d]!=out.shape[d]){error="Concat non-axis dimensions differ";return std::nullopt;}const auto ad=static_cast<std::size_t>(t->shape[static_cast<std::size_t>(axis)]);axis_dims.push_back(ad);out.shape[static_cast<std::size_t>(axis)]+=static_cast<std::int64_t>(ad);}const auto total=element_count(out.shape);if(!total||total>16u*1024u*1024u){error="Concat output exceeds tensor limit";return std::nullopt;}out.values.resize(total);const auto out_axis=static_cast<std::size_t>(out.shape[static_cast<std::size_t>(axis)]);for(std::size_t o=0;o<outer;++o){std::size_t dst=(o*out_axis)*inner;for(std::size_t j=0;j<in.size();++j){const auto chunk=axis_dims[j]*inner;const auto src=(o*axis_dims[j])*inner;std::copy_n(in[j]->values.begin()+static_cast<std::ptrdiff_t>(src),chunk,out.values.begin()+static_cast<std::ptrdiff_t>(dst));dst+=chunk;}}return out;
    }
    if(op=="Clip"){
        if(in.empty()||in.size()>3){error="Clip expects one to three inputs";return std::nullopt;}float lo=attr(n,"min")?attr(n,"min")->real:-std::numeric_limits<float>::infinity(),hi=attr(n,"max")?attr(n,"max")->real:std::numeric_limits<float>::infinity();if(in.size()>1&&!in[1]->values.empty())lo=in[1]->values.front();if(in.size()>2&&!in[2]->values.empty())hi=in[2]->values.front();if(lo>hi){error="Clip min exceeds max";return std::nullopt;}Tensor out=*in[0];for(auto& x:out.values)x=std::clamp(x,lo,hi);return out;
    }
    if(op=="MatMul"||op=="Gemm"){
        if(in.size()<2||in.size()>3||in[0]->shape.size()!=2||in[1]->shape.size()!=2){error=op+" currently supports 2-D float matrices";return std::nullopt;}
        const bool ta=op=="Gemm"&&attr(n,"transA")&&attr(n,"transA")->integer!=0;const bool tb=op=="Gemm"&&attr(n,"transB")&&attr(n,"transB")->integer!=0;
        const auto am=static_cast<std::size_t>(in[0]->shape[ta?1:0]),ak=static_cast<std::size_t>(in[0]->shape[ta?0:1]);const auto bk=static_cast<std::size_t>(in[1]->shape[tb?1:0]),bn=static_cast<std::size_t>(in[1]->shape[tb?0:1]);
        if(ak!=bk){error=op+" inner matrix dimensions do not match";return std::nullopt;}Tensor out;out.shape={static_cast<std::int64_t>(am),static_cast<std::int64_t>(bn)};out.values.assign(am*bn,0.0f);
        auto A=[&](std::size_t i,std::size_t j){return ta?in[0]->values[j*static_cast<std::size_t>(in[0]->shape[1])+i]:in[0]->values[i*ak+j];};auto B=[&](std::size_t i,std::size_t j){return tb?in[1]->values[j*static_cast<std::size_t>(in[1]->shape[1])+i]:in[1]->values[i*bn+j];};
        const float alpha=op=="Gemm"&&attr(n,"alpha")?attr(n,"alpha")->real:1.0f;const float beta=op=="Gemm"&&attr(n,"beta")?attr(n,"beta")->real:1.0f;
        for(std::size_t i=0;i<am;++i)for(std::size_t j=0;j<bn;++j){float sum=0;for(std::size_t k=0;k<ak;++k)sum+=A(i,k)*B(k,j);out.values[i*bn+j]=alpha*sum;}
        if(in.size()==3){const auto& bias=*in[2];if(bias.values.size()!=bn&&bias.values.size()!=out.values.size()){error="Gemm bias shape is unsupported";return std::nullopt;}for(std::size_t i=0;i<out.values.size();++i)out.values[i]+=beta*bias.values[bias.values.size()==bn?i%bn:i];}
        return out;
    }
    if(op=="Softmax"){
        if(in.size()!=1){error="Softmax expects one input";return std::nullopt;}Tensor out=*in[0];if(out.shape.empty()){error="Softmax requires a non-scalar tensor";return std::nullopt;}std::int64_t axis=attr(n,"axis")?attr(n,"axis")->integer:-1;if(axis<0)axis+=static_cast<std::int64_t>(out.shape.size());if(axis<0||axis>=static_cast<std::int64_t>(out.shape.size())){error="Softmax axis out of range";return std::nullopt;}
        std::size_t inner=1,outer=1,dim=static_cast<std::size_t>(out.shape[axis]);for(std::size_t i=axis+1;i<out.shape.size();++i)inner*=static_cast<std::size_t>(out.shape[i]);for(std::size_t i=0;i<static_cast<std::size_t>(axis);++i)outer*=static_cast<std::size_t>(out.shape[i]);
        for(std::size_t o=0;o<outer;++o)for(std::size_t j=0;j<inner;++j){float mx=-std::numeric_limits<float>::infinity();for(std::size_t k=0;k<dim;++k)mx=std::max(mx,out.values[o*dim*inner+k*inner+j]);float sum=0;for(std::size_t k=0;k<dim;++k){auto& x=out.values[o*dim*inner+k*inner+j];x=std::exp(x-mx);sum+=x;}for(std::size_t k=0;k<dim;++k)out.values[o*dim*inner+k*inner+j]/=sum;}
        return out;
    }
    error="unsupported ONNX operator: "+op;return std::nullopt;
}
}

bool Tensor::valid(std::size_t max) const noexcept {const auto n=element_count(shape);if(!n||n!=values.size()||n>max)return false;for(float x:values)if(!std::isfinite(x))return false;return true;}
bool OnnxModel::load(const std::string& path,std::string* error,std::size_t max_bytes){std::ifstream f(path,std::ios::binary);if(!f){if(error)*error="cannot open ONNX model: "+path;return false;}f.seekg(0,std::ios::end);const auto n=f.tellg();if(n<0||static_cast<std::uint64_t>(n)>max_bytes){if(error)*error="ONNX model exceeds configured size limit";return false;}f.seekg(0);std::vector<std::uint8_t>b(static_cast<std::size_t>(n));if(!b.empty())f.read(reinterpret_cast<char*>(b.data()),static_cast<std::streamsize>(b.size()));if(!f&&!b.empty()){if(error)*error="failed to read ONNX model";return false;}return load_bytes(b,error);}
bool OnnxModel::load_bytes(const std::vector<std::uint8_t>& b,std::string* error){loaded_=false;info_={};nodes_.clear();initializers_.clear();if(b.empty()||b.size()>256u*1024u*1024u){if(error)*error="ONNX model is empty or exceeds 256 MiB";return false;}Reader r(b);Field f;bool graph=false;std::string why;while(r.next(f)){if(f.number==7&&f.wire==2){if(graph){why="ONNX ModelProto contains multiple graph fields";break;}graph=true;if(!parse_graph(f.bytes,info_,nodes_,initializers_,why))break;}}if(why.empty()&&!r.error().empty())why=r.error();if(why.empty()&&!graph)why="ONNX ModelProto has no graph";if(why.empty()&&info_.nodes.empty())why="ONNX graph contains no nodes";
    if(why.empty()){const auto supported=supported_operators();for(const auto& n:nodes_)if(std::find(supported.begin(),supported.end(),n.info.op_type)==supported.end())info_.unsupported_operators.push_back(n.info.op_type);std::set<std::string> available;for(const auto& kv:initializers_)available.insert(kv.first);for(const auto& name:info_.inputs)if(!initializers_.count(name))available.insert(name);
        for(const auto& n:nodes_){for(const auto& i:n.info.inputs)if(!i.empty()&&!available.count(i)){why="ONNX graph has unresolved or out-of-order input: "+i;break;}if(!why.empty())break;for(const auto& o:n.info.outputs)if(!available.insert(o).second){why="ONNX graph has duplicate value definition: "+o;break;}if(!why.empty())break;}
        if(why.empty())for(const auto& o:info_.outputs)if(!available.count(o)){why="ONNX graph output is not produced: "+o;break;}}
    if(!why.empty()){if(error)*error=why;nodes_.clear();initializers_.clear();return false;}loaded_=true;return true;}
InferenceResult OnnxModel::run(const std::map<std::string,Tensor>& inputs,std::size_t max_elements)const{InferenceResult r;if(!loaded_){r.error="ONNX model is not loaded";return r;}std::map<std::string,Tensor> values=initializers_;for(const auto& name:info_.inputs){auto it=inputs.find(name);if(it==inputs.end()&&!initializers_.count(name)){r.error="missing ONNX model input: "+name;return r;}if(it!=inputs.end()){if(!it->second.valid(max_elements)){r.error="input tensor is invalid or exceeds element limit: "+name;return r;}values[name]=it->second;}}
    for(const auto& n:nodes_){auto out=execute_node(n,values,r.error);if(!out)return r;if(!out->valid(max_elements)){r.error="operator produced invalid or oversized tensor: "+n.info.op_type;return r;}values[n.info.outputs.front()]=std::move(*out);}
    for(const auto& name:info_.outputs){auto it=values.find(name);if(it==values.end()){r.error="missing ONNX graph output: "+name;return r;}r.outputs.emplace(name,it->second);}r.ok=true;return r;}
std::vector<std::string> supported_operators(){return {"Add","Sub","Div","Mul","Pow","Max","Min","Gemm","Identity","MatMul","Relu","LeakyRelu","Elu","Softplus","HardSigmoid","Sigmoid","Softmax","Tanh","Flatten","Transpose","ReduceMean","Concat","Clip"};}
} // namespace docmont::neural
