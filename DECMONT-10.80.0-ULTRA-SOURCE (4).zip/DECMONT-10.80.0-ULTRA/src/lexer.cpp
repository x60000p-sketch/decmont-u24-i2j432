#include "docmont/lexer.hpp"
#include <cctype>
#include <utility>

namespace docmont {
Lexer::Lexer(std::string s) : source_(std::move(s)) {}

char Lexer::peek() const {
    return pos_ < source_.size() ? source_[pos_] : '\0';
}

char Lexer::advance() {
    char c = peek();
    if (c == '\0') return c;
    ++pos_;
    if (c == '\n') { ++line_; column_ = 1; }
    else { ++column_; }
    return c;
}

void Lexer::skip_spaces() {
    while (peek() == ' ' || peek() == '\t' || peek() == '\r') advance();
}

LexResult Lexer::scan() {
    LexResult result;
    auto emit = [&](TokenKind kind, std::string text, int line, int column) {
        result.tokens.push_back({kind, std::move(text), line, column});
    };

    while (peek() != '\0') {
        skip_spaces();
        const char c = peek();
        if (c == '\0') break;
        const int line = line_;
        const int column = column_;

        if (c == '\n') {
            advance();
            emit(TokenKind::Newline, "\\n", line, column);
            continue;
        }

        if (std::isalpha(static_cast<unsigned char>(c)) || c == '_' || (c == '!' && source_.compare(pos_, 8, "!docmont") == 0)) {
            std::string text;
            while (std::isalnum(static_cast<unsigned char>(peek())) || peek() == '_' || peek() == '!')
                text += advance();
            emit(TokenKind::Identifier, text, line, column);
            continue;
        }

        if (std::isdigit(static_cast<unsigned char>(c))) {
            std::string text;
            while (std::isdigit(static_cast<unsigned char>(peek()))) text += advance();
            emit(TokenKind::Number, text, line, column);
            continue;
        }

        if (c == '"' || c == '\'') {
            const char quote = advance();
            std::string text;
            bool closed = false;
            while (peek() != '\0' && peek() != '\n') {
                const char x = advance();
                if (x == quote) { closed = true; break; }
                if (x == '\\' && peek() != '\0') text += advance();
                else text += x;
            }
            if (!closed)
                result.diagnostics.push_back({Severity::Error, line, column, "Unterminated string literal"});
            emit(closed ? TokenKind::String : TokenKind::Invalid, text, line, column);
            continue;
        }

        advance();
        if ((c == '<' || c == '>' || c == '=' || c == '!') && peek() == '=') {
            advance();
            TokenKind kind = c == '<' ? TokenKind::LessEqual : c == '>' ? TokenKind::GreaterEqual : c == '=' ? TokenKind::EqualEqual : TokenKind::BangEqual;
            emit(kind, std::string(1,c) + "=", line, column);
            continue;
        }
        if ((c == '&' && peek() == '&') || (c == '|' && peek() == '|')) { char second=advance(); emit(c == '&' ? TokenKind::AndAnd : TokenKind::OrOr, std::string(1,c)+second, line, column); continue; }
        if (c == ':' && peek() == ':') { advance(); emit(TokenKind::DoubleColon, "::", line, column); continue; }
        if (c == '=' && peek() == '>') { advance(); emit(TokenKind::Arrow, "=>", line, column); continue; }
        if (c == '!') { emit(TokenKind::Bang, "!", line, column); continue; }
        if (c == '>') { emit(TokenKind::Greater, ">", line, column); continue; }
        switch (c) {
            case '{': emit(TokenKind::LBrace, "{", line, column); break;
            case '}': emit(TokenKind::RBrace, "}", line, column); break;
            case '[': emit(TokenKind::LBracket, "[", line, column); break;
            case ']': emit(TokenKind::RBracket, "]", line, column); break;
            case '(': emit(TokenKind::LParen, "(", line, column); break;
            case ')': emit(TokenKind::RParen, ")", line, column); break;
            case '=': emit(TokenKind::Equal, "=", line, column); break;
            case ':': emit(TokenKind::Colon, ":", line, column); break;
            case '?': emit(TokenKind::Question, "?", line, column); break;
            case '&': emit(TokenKind::Ampersand, "&", line, column); break;
            case ',': emit(TokenKind::Comma, ",", line, column); break;
            case '.': emit(TokenKind::Dot, ".", line, column); break;
            case '+': emit(TokenKind::Plus, "+", line, column); break;
            case '-': emit(TokenKind::Minus, "-", line, column); break;
            case '*': emit(TokenKind::Star, "*", line, column); break;
            case '/': emit(TokenKind::Slash, "/", line, column); break;
            case '<': emit(TokenKind::Less, "<", line, column); break;
            default:
                emit(TokenKind::Invalid, std::string(1, c), line, column);
                result.diagnostics.push_back({Severity::Error, line, column,
                    std::string("Unexpected character: ") + c});
                break;
        }
    }

    emit(TokenKind::End, "", line_, column_);
    return result;
}
}
