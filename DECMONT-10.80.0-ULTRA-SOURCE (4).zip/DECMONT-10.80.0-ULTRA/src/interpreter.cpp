#include "docmont/runtime.hpp"
#include "docmont/ast.hpp"
#include <iostream>
#include <limits>
#include <map>
#include <memory>
#include <unordered_map>
#include <optional>
#include <variant>

namespace docmont {
namespace {
struct Value;
struct Callable;
using Array = std::vector<Value>;
using Object = std::map<std::string, Value, std::less<>>;
struct Value { std::variant<std::int64_t, bool, std::string, std::shared_ptr<Array>, std::shared_ptr<Object>, std::shared_ptr<Callable>> data{std::int64_t{0}}; };
using Cell = std::shared_ptr<Value>;
using Env = std::unordered_map<std::string, Cell>;
struct Callable { std::vector<Parameter> parameters; std::vector<Statement> body; Env captured; };
struct Flow { enum class Signal { None, Return, Break, Continue } signal{Signal::None}; Value value; };
std::string show(const Value& v) {
 if (auto n=std::get_if<std::int64_t>(&v.data)) return std::to_string(*n);
 if (auto b=std::get_if<bool>(&v.data)) return *b ? "true" : "false";
 if (auto s=std::get_if<std::string>(&v.data)) return *s;
 if(auto a=std::get_if<std::shared_ptr<Array>>(&v.data)){std::string out="["; for(std::size_t i=0;i<(*a)->size();++i){if(i)out+=", ";out+=show((**a)[i]);} return out+"]";}
 if (std::holds_alternative<std::shared_ptr<Callable>>(v.data)) return "<function>";
 const auto& o=*std::get<std::shared_ptr<Object>>(v.data); std::string out="{"; bool first=true; for(const auto& [k,x]:o){if(!first)out+=", ";first=false;out+=k+": "+show(x);} return out+"}";
}
class Interpreter {
 const Application& app; std::unordered_map<std::string,const FunctionDecl*> functions;
 std::size_t steps{0}; int depth{0}; std::string error; std::optional<Value> pending_propagation;
 bool tick(int line){if(++steps>1000000){error="execution step limit exceeded";return false;} if(depth>128){error="maximum function recursion depth exceeded";return false;} (void)line;return true;}
 bool truth(const Value& v, bool& result){ if(auto b=std::get_if<bool>(&v.data)){result=*b;return true;} if(auto n=std::get_if<std::int64_t>(&v.data)){result=*n!=0;return true;} error="condition requires a boolean value";return false;}
 bool eval(const std::shared_ptr<Expr>& e, Env& env, Value& out){
  if (pending_propagation) return true;
  if(!e){out.data=std::int64_t{0};return true;} if(!tick(e->line))return false;
  switch(e->kind){
   case ExprKind::Integer: try{out.data=static_cast<std::int64_t>(std::stoll(e->text));return true;}catch(...){error="integer literal out of range";return false;}
   case ExprKind::Boolean: out.data=(e->text=="true");return true;
   case ExprKind::String: out.data=e->text;return true;
   case ExprKind::Identifier:{
    auto i=env.find(e->text);
    if(i!=env.end()){out=*i->second;return true;}
    auto function=functions.find(e->text);
    if(function!=functions.end()){
      auto callable=std::make_shared<Callable>();
      callable->parameters=function->second->parameters;
      callable->body=function->second->body;
      out.data=std::move(callable);
      return true;
    }
    error="undefined variable '"+e->text+"'";return false;
   }
   case ExprKind::Lambda:{if(!e->lambda_function){error="invalid lambda expression";return false;}auto fn=std::make_shared<Callable>();fn->parameters=e->lambda_function->parameters;fn->body=e->lambda_function->body;fn->captured=env;out.data=fn;return true;}
   case ExprKind::ObjectLiteral:{auto o=std::make_shared<Object>(); for(const auto& property:e->properties){Value v;if(!eval(property.second,env,v))return false;o->insert_or_assign(property.first,std::move(v));} out.data=o; return true;}
   case ExprKind::Member:{Value base;if(!eval(e->left,env,base))return false;auto o=std::get_if<std::shared_ptr<Object>>(&base.data);if(!o||!*o){error="property access requires an object";return false;}auto it=(*o)->find(e->text);if(it==(*o)->end()){error="object has no property '"+e->text+"'";return false;}out=it->second;return true;}
   case ExprKind::ArrayLiteral:{auto a=std::make_shared<Array>();for(const auto& x:e->elements){Value v;if(!eval(x,env,v))return false;a->push_back(std::move(v));}out.data=a;return true;}
   case ExprKind::Call:{
    if (e->callee.find("::") != std::string::npos) {
      const auto split=e->callee.find("::");
      auto object=std::make_shared<Object>();
      object->emplace("__enum",Value{e->callee.substr(0,split)});
      object->emplace("__variant",Value{e->callee.substr(split+2)});
      if (e->elements.empty()) object->emplace("__payload",Value{std::int64_t{0}});
      else if(e->elements.size()==1) { Value payload; if(!eval(e->elements.front(),env,payload))return false; if(pending_propagation)return true; object->emplace("__payload",std::move(payload)); }
      else { auto tuple=std::make_shared<Array>(); for(const auto& argument:e->elements){Value payload;if(!eval(argument,env,payload))return false;if(pending_propagation)return true;tuple->push_back(std::move(payload));} object->emplace("__payload",Value{std::move(tuple)}); }
      out.data=std::move(object); return true;
    }
    if(e->callee=="print"){for(std::size_t i=0;i<e->elements.size();++i){Value v;if(!eval(e->elements[i],env,v))return false;if(i)std::cout<<" ";std::cout<<show(v);}std::cout<<"\n";out.data=std::int64_t{0};return true;}
    if(e->callee=="push") {
      if(e->elements.size()!=2){error="push() expects 2 argument(s)";return false;}
      Value array_value,item;if(!eval(e->elements[0],env,array_value)||!eval(e->elements[1],env,item))return false;
      auto array=std::get_if<std::shared_ptr<Array>>(&array_value.data);
      if(!array||!*array){error="push() requires an array as its first argument";return false;}
      if((*array)->size()>=1000000){error="array element limit exceeded";return false;}
      (*array)->push_back(std::move(item));out.data=static_cast<std::int64_t>((*array)->size());return true;
    }
    if(e->callee=="pop") {
      if(e->elements.size()!=1){error="pop() expects 1 argument(s)";return false;}
      Value array_value;if(!eval(e->elements[0],env,array_value))return false;
      auto array=std::get_if<std::shared_ptr<Array>>(&array_value.data);
      if(!array||!*array){error="pop() requires an array";return false;}
      if((*array)->empty()){error="cannot pop from an empty array";return false;}
      out=std::move((*array)->back());(*array)->pop_back();return true;
    }
    if(e->callee=="len" || e->callee=="length" || e->callee=="type" || e->callee=="keys" || e->callee=="has") {
      const std::size_t expected=e->callee=="has"?2:1;
      if(e->elements.size()!=expected){error=e->callee+"() expects "+std::to_string(expected)+" argument(s)";return false;}
      Value v;if(!eval(e->elements[0],env,v))return false;
      if(e->callee=="type") { const char* name=std::holds_alternative<std::int64_t>(v.data)?"integer":std::holds_alternative<bool>(v.data)?"boolean":std::holds_alternative<std::string>(v.data)?"string":std::holds_alternative<std::shared_ptr<Array>>(v.data)?"array":std::holds_alternative<std::shared_ptr<Callable>>(v.data)?"function":"object"; out.data=std::string(name); return true; }
      if(e->callee=="len" || e->callee=="length") { if(auto a=std::get_if<std::shared_ptr<Array>>(&v.data))out.data=static_cast<std::int64_t>((*a)->size()); else if(auto x=std::get_if<std::string>(&v.data))out.data=static_cast<std::int64_t>(x->size()); else if(auto o=std::get_if<std::shared_ptr<Object>>(&v.data))out.data=static_cast<std::int64_t>((*o)->size()); else {error=e->callee+"() requires an array, object or string";return false;} return true; }
      if(e->callee=="keys") { auto o=std::get_if<std::shared_ptr<Object>>(&v.data); if(!o){error="keys() requires an object";return false;} auto a=std::make_shared<Array>(); for(const auto& item:**o){Value k;k.data=item.first;a->push_back(std::move(k));}out.data=a;return true; }
      Value k;if(!eval(e->elements[1],env,k))return false; auto o=std::get_if<std::shared_ptr<Object>>(&v.data);auto name=std::get_if<std::string>(&k.data);if(!o||!name){error="has() requires an object and string property name";return false;}out.data=(*o)->contains(*name);return true;
    }
    std::vector<Value> arguments; arguments.reserve(e->elements.size());
    for(const auto& arg:e->elements){Value value;if(!eval(arg,env,value))return false;arguments.push_back(std::move(value));}
    auto variable=env.find(e->callee);
    if(variable!=env.end()) {
      auto callable=std::get_if<std::shared_ptr<Callable>>(&variable->second->data);
      if(!callable||!*callable){error="value '"+e->callee+"' is not callable";return false;}
      const auto& fn=**callable;std::size_t required=fn.parameters.size();while(required>0&&fn.parameters[required-1].default_value)--required;
      if(arguments.size()<required||arguments.size()>fn.parameters.size()){error="lambda expects "+std::to_string(required)+".."+std::to_string(fn.parameters.size())+" arguments";return false;}
      Env local=fn.captured;
      for(std::size_t i=0;i<fn.parameters.size();++i){Value value;if(i<arguments.size())value=arguments[i];else if(!eval(fn.parameters[i].default_value,local,value))return false;local.insert_or_assign(fn.parameters[i].name,std::make_shared<Value>(std::move(value)));}
      ++depth;Flow flow;bool ok=exec(fn.body,local,flow);--depth;if(!ok)return false;out=flow.value;return true;
    }
    auto f=functions.find(e->callee);if(f==functions.end()){error="unknown function '"+e->callee+"'";return false;}const auto& fn=*f->second;
    std::size_t required=fn.parameters.size();while(required>0&&fn.parameters[required-1].default_value)--required;
    if(arguments.size()<required||arguments.size()>fn.parameters.size()){error="function '"+e->callee+"' expects "+std::to_string(required)+".."+std::to_string(fn.parameters.size())+" arguments";return false;}
    Env local;for(std::size_t i=0;i<fn.parameters.size();++i){Value value;if(i<arguments.size())value=arguments[i];else if(!eval(fn.parameters[i].default_value,local,value))return false;local.emplace(fn.parameters[i].name,std::make_shared<Value>(std::move(value)));}
    ++depth;Flow flow;bool ok=exec(fn.body,local,flow);--depth;if(!ok)return false;out=flow.value;return true;}
   case ExprKind::Try: {
    Value wrapped; if(!eval(e->left,env,wrapped))return false; if(pending_propagation)return true;
    auto object=std::get_if<std::shared_ptr<Object>>(&wrapped.data);
    if(!object||!*object){error="postfix '?' requires an Option or Result value";return false;}
    auto type=(*object)->find("__enum"), variant=(*object)->find("__variant"), payload=(*object)->find("__payload");
    if(type==(*object)->end()||variant==(*object)->end()||payload==(*object)->end()){error="postfix '?' requires a tagged Option or Result value";return false;}
    auto type_name=std::get_if<std::string>(&type->second.data); auto variant_name=std::get_if<std::string>(&variant->second.data);
    if(!type_name||!variant_name||(*type_name!="Option"&&*type_name!="Result")){error="postfix '?' requires Option or Result";return false;}
    const bool success=(*type_name=="Option"&&*variant_name=="Some")||(*type_name=="Result"&&*variant_name=="Ok");
    if(success) out=payload->second;
    else { pending_propagation=wrapped; out.data=std::int64_t{0}; }
    return true;
   }
   case ExprKind::Index:{Value base,index;if(!eval(e->left,env,base)||!eval(e->right,env,index))return false;auto a=std::get_if<std::shared_ptr<Array>>(&base.data);auto i=std::get_if<std::int64_t>(&index.data);if(!a||!i){error="array index requires an array and integer index";return false;}if(*i<0||static_cast<std::uint64_t>(*i)>=(*a)->size()){error="array index out of bounds";return false;}out=(**a)[static_cast<std::size_t>(*i)];return true;}
   case ExprKind::Unary:{Value a;if(!eval(e->left,env,a))return false;if(pending_propagation)return true;if(e->op=="&"||e->op=="&mut"||e->op=="move"){out=std::move(a);return true;}if(e->op=="!"){bool b;if(!truth(a,b))return false;out.data=!b;return true;}auto n=std::get_if<std::int64_t>(&a.data);if(!n){error="unary '-' requires an integer operand";return false;}if(*n==INT64_MIN){error="integer overflow";return false;}out.data=-*n;return true;}
   case ExprKind::Binary:{Value a,b;if(!eval(e->left,env,a))return false;
    if(e->op=="&&"||e->op=="||"){bool av;if(!truth(a,av))return false;if(e->op=="&&"&&!av){out.data=false;return true;}if(e->op=="||"&&av){out.data=true;return true;}if(!eval(e->right,env,b))return false;bool bv;if(!truth(b,bv))return false;out.data=bv;return true;}
    if(!eval(e->right,env,b))return false;
    if(e->op=="=="||e->op=="!="){bool equal=false;if(a.data.index()!=b.data.index()){equal=false;}else if(auto x=std::get_if<std::int64_t>(&a.data)){equal=*x==std::get<std::int64_t>(b.data);}else if(auto x=std::get_if<bool>(&a.data)){equal=*x==std::get<bool>(b.data);}else if(auto x=std::get_if<std::string>(&a.data)){equal=*x==std::get<std::string>(b.data);}else if(auto aa=std::get_if<std::shared_ptr<Array>>(&a.data)){equal=*aa==std::get<std::shared_ptr<Array>>(b.data);}else{equal=std::get<std::shared_ptr<Object>>(a.data)==std::get<std::shared_ptr<Object>>(b.data);}out.data=(e->op=="==")?equal:!equal;return true;}
    if(e->op=="+") { auto left=std::get_if<std::string>(&a.data); auto right=std::get_if<std::string>(&b.data); if(left&&right){out.data=*left+*right;return true;} }
    auto x=std::get_if<std::int64_t>(&a.data);auto y=std::get_if<std::int64_t>(&b.data);if(!x||!y){error="arithmetic and ordering comparisons require integer operands (string '+' string is also supported)";return false;}std::int64_t z=0;
    if(e->op=="+"){if((*y>0&&*x>INT64_MAX-*y)||(*y<0&&*x<INT64_MIN-*y)){error="integer overflow";return false;}z=*x+*y;}
    else if(e->op=="-"){if((*y<0&&*x>INT64_MAX+*y)||(*y>0&&*x<INT64_MIN+*y)){error="integer overflow";return false;}z=*x-*y;}
    else if(e->op=="*"){if(*x!=0&&(*x== -1?*y==INT64_MIN:(*y!=0&&(*x>0?(*y>0?*x>INT64_MAX/ *y:*y<INT64_MIN/ *x):(*y>0?*x<INT64_MIN/ *y:*x<INT64_MAX/ *y))))){error="integer overflow";return false;}z=*x**y;}
    else if(e->op=="<"){out.data=(*x<*y);return true;}
    else if(e->op=="<="){out.data=(*x<=*y);return true;}
    else if(e->op==">"){out.data=(*x>*y);return true;}
    else if(e->op==">="){out.data=(*x>=*y);return true;}
    else {if(*y==0){error="division by zero";return false;}if(*x==INT64_MIN&&*y==-1){error="integer overflow";return false;}z=*x/ *y;}out.data=z;return true;}
  }return false;
 }
 bool exec(const std::vector<Statement>& body,Env& env,Flow& flow){
  auto eval_statement = [&](const std::shared_ptr<Expr>& expr, Value& value) {
    if (!eval(expr,env,value)) return false;
    if (pending_propagation) { flow.signal=Flow::Signal::Return; flow.value=std::move(*pending_propagation); pending_propagation.reset(); }
    return true;
  };
  for(const auto& s:body){
   if(!tick(s.line))return false;
   Value v;
   if(s.kind==Statement::Kind::Let){if(!eval_statement(s.expression,v))return false;if(flow.signal!=Flow::Signal::None)return true;env[s.name]=std::make_shared<Value>(std::move(v));}
   else if(s.kind==Statement::Kind::Assign){
    if(!eval_statement(s.expression,v))return false;
    if(flow.signal!=Flow::Signal::None)return true;
    if(s.target_member){
     const auto& target=s.target_member;
     if(target->kind!=ExprKind::Member || !target->left){error="invalid object property assignment target";return false;}
     Value parent;if(!eval(target->left,env,parent))return false;
     auto object=std::get_if<std::shared_ptr<Object>>(&parent.data);
     if(!object||!*object){error="property assignment requires an object";return false;}
     (*object)->insert_or_assign(target->text,std::move(v));
    }else {
     auto found=env.find(s.name);
     if(found==env.end()){error="assignment to undefined variable '"+s.name+"'";return false;}
     if(s.target_index){
     Value parent,idx;
     if(s.target_index->kind==ExprKind::Index && s.target_index->left && s.target_index->right){
      if(!eval(s.target_index->left,env,parent)||!eval(s.target_index->right,env,idx))return false;
     } else { parent=*found->second; if(!eval(s.target_index,env,idx))return false; }
     auto arr=std::get_if<std::shared_ptr<Array>>(&parent.data);auto n=std::get_if<std::int64_t>(&idx.data);
     if(!arr||!n){error="indexed assignment requires an array and integer index";return false;}
     if(*n<0||static_cast<std::uint64_t>(*n)>=(*arr)->size()){error="array index out of bounds";return false;}
     (**arr)[static_cast<std::size_t>(*n)]=std::move(v);
     }else *found->second=std::move(v);
    }
   }
   else if(s.kind==Statement::Kind::ForEach){
    if(!eval_statement(s.expression,v))return false;
    if(flow.signal!=Flow::Signal::None) return true;
    auto arr=std::get_if<std::shared_ptr<Array>>(&v.data);
    if(!arr){error="for-in requires an array";return false;}
    for(const auto& item:**arr){if(!tick(s.line))return false;Env iteration=env;iteration[s.name]=std::make_shared<Value>(item);Flow nested;if(!exec(s.body,iteration,nested))return false;for(const auto& pair:iteration){if(pair.first!=s.name&&env.contains(pair.first))env[pair.first]=pair.second;}
     if(nested.signal==Flow::Signal::Return){flow=std::move(nested);return true;}if(nested.signal==Flow::Signal::Break)break;
    }
   }
   else if(s.kind==Statement::Kind::While){
    std::size_t iterations=0;
    for(;;){if(++iterations>1000000){error="while iteration limit exceeded";return false;}if(!eval_statement(s.expression,v))return false;if(flow.signal!=Flow::Signal::None)return true;bool condition;if(!truth(v,condition))return false;if(!condition)break;Flow nested;if(!exec(s.body,env,nested))return false;if(nested.signal==Flow::Signal::Return){flow=std::move(nested);return true;}if(nested.signal==Flow::Signal::Break)break;
    }
   }
   else if(s.kind==Statement::Kind::Break){flow.signal=Flow::Signal::Break;return true;}
   else if(s.kind==Statement::Kind::Continue){flow.signal=Flow::Signal::Continue;return true;}
   else if(s.kind==Statement::Kind::Output){if(!eval_statement(s.expression,v))return false;if(flow.signal!=Flow::Signal::None)return true;std::cout<<show(v)<<"\n";}
   else if(s.kind==Statement::Kind::If){if(!eval_statement(s.expression,v))return false;if(flow.signal!=Flow::Signal::None)return true;bool condition;if(!truth(v,condition))return false;Flow nested;if(!exec(condition?s.body:s.else_body,env,nested))return false;if(nested.signal!=Flow::Signal::None){flow=std::move(nested);return true;}}
   else if(s.kind==Statement::Kind::Match){
    if(!eval_statement(s.expression,v))return false;
    if(flow.signal!=Flow::Signal::None)return true;
    auto object=std::get_if<std::shared_ptr<Object>>(&v.data);if(!object||!*object){error="match requires a tagged enum value";return false;}
    auto en=(*object)->find("__enum"),var=(*object)->find("__variant"),payload=(*object)->find("__payload");
    if(en==(*object)->end()||var==(*object)->end()){error="match value is not a tagged enum";return false;}
    const auto enum_name=std::get_if<std::string>(&en->second.data);const auto variant_name=std::get_if<std::string>(&var->second.data);
    if(!enum_name||!variant_name){error="invalid enum tag representation";return false;}
    bool matched=false;
    for(const auto& arm:s.match_arms){if(!arm)continue;if(!arm->wildcard&&arm->variant!=*variant_name)continue;if(!arm->wildcard&&!arm->enum_name.empty()&&arm->enum_name!=*enum_name)continue;
      Env arm_env=env;if(!arm->binding.empty()){if(payload==(*object)->end()){error="matched enum variant has no payload";return false;}arm_env[arm->binding]=std::make_shared<Value>(payload->second);}
      Flow nested;if(!exec(arm->body,arm_env,nested))return false;for(const auto& pair:arm_env)if(pair.first!=arm->binding&&env.contains(pair.first))env[pair.first]=pair.second;
      if(nested.signal!=Flow::Signal::None){flow=std::move(nested);return true;}matched=true;break;
    }
    if(!matched){error="non-exhaustive match reached at runtime";return false;}
   }
   else if(s.kind==Statement::Kind::Return){if(!eval_statement(s.expression,v))return false;if(flow.signal!=Flow::Signal::None)return true;flow.signal=Flow::Signal::Return;flow.value=std::move(v);return true;}
   else if(s.kind==Statement::Kind::Expression){if(!eval_statement(s.expression,v))return false;if(flow.signal!=Flow::Signal::None)return true;}
  }
  return true;
 }
public: explicit Interpreter(const Application& a):app(a){for(const auto& f:a.functions){if(functions.contains(f.name))error="duplicate function '"+f.name+"'";else functions[f.name]=&f;}}
 int run(){if(!error.empty()){std::cerr<<"runtime error: "<<error<<"\n";return 1;}Env globals;Flow flow;const FunctionDecl* main=nullptr;for(const auto& f:app.functions)if(f.name=="main")main=&f;if(main){if(!main->parameters.empty()){std::cerr<<"runtime error: main must not take parameters\n";return 1;}++depth;bool ok=exec(main->body,globals,flow);--depth;if(!ok){std::cerr<<"runtime error: "<<error<<"\n";return 1;}return 0;}if(!exec(app.statements,globals,flow)){std::cerr<<"runtime error: "<<error<<"\n";return 1;}return 0;}
};
}
int execute_application(const Application& app){return Interpreter(app).run();}
}
