#include "docmont/vlot.hpp"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <limits>
#include <sstream>
#include <unordered_map>
#include <unordered_set>

namespace docmont::vlot {
namespace {
std::string trim(std::string s) {
    const auto first = s.find_first_not_of(" \t\r\n");
    if (first == std::string::npos) return {};
    const auto last = s.find_last_not_of(" \t\r\n");
    return s.substr(first, last - first + 1);
}
std::string unquote(std::string s) {
    s = trim(std::move(s));
    if (s.size() >= 2 && s.front() == '"' && s.back() == '"') return s.substr(1, s.size()-2);
    return s;
}
bool safe_relative_path(const std::string& path) {
    if (path.empty() || path.front() == '/' || path.front() == '\\') return false;
    if (path.find(':') != std::string::npos || path.find('\\') != std::string::npos) return false;
    std::stringstream ss(path); std::string part;
    while (std::getline(ss, part, '/')) if (part == ".." || part == "." || part.empty()) return false;
    return true;
}
float edge(const Vertex& a, const Vertex& b, float x, float y) {
    return (x-a.x)*(b.y-a.y) - (y-a.y)*(b.x-a.x);
}
std::uint8_t channel(float a, float b, float c, float wa, float wb, float wc) {
    const float value = a*wa + b*wb + c*wc;
    return static_cast<std::uint8_t>(std::clamp(value, 0.0f, 255.0f));
}
} // namespace

std::string to_string(Platform p) {
    switch (p) { case Platform::PC: return "PC"; case Platform::Android: return "ANDROID"; case Platform::PS5: return "PS5"; }
    return "UNKNOWN";
}
std::string to_string(BuildState s) {
    switch (s) { case BuildState::Ready: return "READY"; case BuildState::Planned: return "PLANNED"; case BuildState::RequiresToolchain: return "REQUIRES_TOOLCHAIN"; case BuildState::Blocked: return "BLOCKED"; }
    return "UNKNOWN";
}

Result load_project(const std::string& path, ProjectConfig& out) {
    std::ifstream in(path);
    if (!in) return {false, "cannot open VLOT project: " + path};
    ProjectConfig candidate;
    std::string line; std::size_t line_no = 0; bool header = false; std::unordered_set<std::string> keys;
    while (std::getline(in, line)) {
        ++line_no; line = trim(line);
        if (line.empty() || line[0] == '#') continue;
        if (!header) {
            if (line != "VLOT 1") return {false, "line  " + std::to_string(line_no) + ": expected VLOT 1 header"};
            header = true; continue;
        }
        const auto eq = line.find('=');
        if (eq == std::string::npos) return {false, "line " + std::to_string(line_no) + ": expected key = value"};
        const auto key = trim(line.substr(0, eq));
        const auto value = unquote(line.substr(eq+1));
        if (!keys.insert(key).second) return {false, "line " + std::to_string(line_no) + ": duplicate key '" + key + "'"};
        if (key == "name") candidate.name = value;
        else if (key == "targets") {
            std::stringstream values(value); std::string target;
            while (std::getline(values, target, ',')) {
                target = trim(target);
                if (target == "pc") candidate.targets.push_back(Platform::PC);
                else if (target == "android") candidate.targets.push_back(Platform::Android);
                else if (target == "ps5") candidate.targets.push_back(Platform::PS5);
                else return {false, "line " + std::to_string(line_no) + ": unknown target '" + target + "'"};
            }
        } else if (key == "renderer") {
            if (value == "auto") candidate.renderer = Renderer::Auto;
            else if (value == "software") candidate.renderer = Renderer::Software;
            else if (value == "vulkan") candidate.renderer = Renderer::Vulkan;
            else if (value == "directx12") candidate.renderer = Renderer::DirectX12;
            else if (value == "opengles") candidate.renderer = Renderer::OpenGLES;
            else if (value == "console_sdk") candidate.renderer = Renderer::ConsoleSDK;
            else return {false, "line " + std::to_string(line_no) + ": unknown renderer"};
        } else if (key == "quality") candidate.quality = value;
        else if (key == "assets") candidate.asset_root = value;
        else return {false, "line " + std::to_string(line_no) + ": unknown key '" + key + "'"};
    }
    if (!header) return {false, "empty VLOT project file"};
    auto checked = validate_project(candidate);
    if (!checked.ok) return checked;
    out = std::move(candidate);
    return {true, "VLOT project loaded"};
}

Result validate_project(const ProjectConfig& p) {
    if (p.name.empty()) return {false, "project name is required"};
    if (p.name.size() > 96) return {false, "project name exceeds 96 characters"};
    if (p.targets.empty()) return {false, "at least one target is required"};
    std::unordered_set<int> seen;
    for (auto t : p.targets) if (!seen.insert(static_cast<int>(t)).second) return {false, "duplicate platform target: " + to_string(t)};
    if (p.quality != "low" && p.quality != "medium" && p.quality != "high" && p.quality != "ultra") return {false, "quality must be low, medium, high, or ultra"};
    if (!safe_relative_path(p.asset_root)) return {false, "asset root must be a safe relative path without traversal"};
    if (p.renderer == Renderer::DirectX12 && std::find(p.targets.begin(),p.targets.end(),Platform::Android)!=p.targets.end()) return {false, "DirectX 12 is not a valid shared renderer for an Android target"};
    return {true, "VLOT project valid"};
}

DeviceProfile device_profile(Platform p) {
    switch (p) {
        case Platform::PC: return {p,"Desktop PC",{"Vulkan","DirectX 12","OpenGL"},"native executable",false};
        case Platform::Android: return {p,"Android device",{"Vulkan","OpenGL ES"},"APK / AAB",false};
        case Platform::PS5: return {p,"PlayStation 5",{"official PlayStation graphics APIs"},"official console package",true};
    }
    return {p,"Unknown",{},"unknown",true};
}

BuildPlan create_build_plan(const ProjectConfig& p, const ToolchainAvailability& tools) {
    BuildPlan plan; plan.project_name = p.name;
    for (const auto target : p.targets) {
        BuildTargetPlan item; item.platform = target;
        if (target == Platform::PC) {
            item.backend = "VLOT VPAK portable content packager"; item.artifact = p.name + ".vpak";
            item.state = BuildState::Ready;
            item.reason = "project manifest and bounded asset payloads can be packaged and integrity-verified; this is a content bundle, not a native executable";
        } else if (target == Platform::Android) {
            item.backend = "Android Gradle + NDK + JNI"; item.artifact = p.name + ".apk / .aab";
            item.state = (tools.android_sdk && tools.android_ndk) ? BuildState::Planned : BuildState::RequiresToolchain;
            item.reason = (tools.android_sdk && tools.android_ndk) ? "Android SDK and NDK detected; VLOT APK build orchestration and device validation remain pending" : "requires Android SDK and NDK; project scaffold is present but APK/device validation is not implied";
        } else {
            item.backend = "official PlayStation SDK integration"; item.artifact = "official PS5 package";
            item.state = tools.playstation_sdk ? BuildState::Planned : BuildState::Blocked;
            item.reason = tools.playstation_sdk ? "SDK path detected; official platform adapter, signing workflow and hardware validation are still required" : "requires authorized Sony developer access, official SDK, signing and target hardware; no generic PS5 build is claimed";
        }
        plan.targets.push_back(std::move(item));
    }
    return plan;
}

std::string format_build_plan(const BuildPlan& plan) {
    std::ostringstream out;
    out << "VLOT build plan: " << plan.project_name << '\n';
    for (const auto& t : plan.targets) {
        out << "- " << to_string(t.platform) << " | " << to_string(t.state) << " | " << t.backend << " | " << t.artifact << '\n'
            << "  " << t.reason << '\n';
    }
    return out.str();
}

Result validate_scene(const Scene& scene) {
    std::unordered_map<std::string,const SceneNode*> nodes;
    for (const auto& n : scene.nodes) {
        if (n.id.empty()) return {false,"scene node id cannot be empty"};
        if (!nodes.emplace(n.id,&n).second) return {false,"duplicate scene node id: " + n.id};
        if (!std::isfinite(n.position.x)||!std::isfinite(n.position.y)||!std::isfinite(n.position.z)||!std::isfinite(n.scale.x)||!std::isfinite(n.scale.y)||!std::isfinite(n.scale.z)||!std::isfinite(n.width)||!std::isfinite(n.height)) return {false,"scene node contains non-finite transform values: " + n.id};
        if (n.scale.x <= 0 || n.scale.y <= 0 || n.scale.z <= 0 || n.width < 0 || n.height < 0) return {false,"scene node has invalid scale or dimensions: " + n.id};
    }
    for (const auto& n : scene.nodes) if (!n.parent.empty() && nodes.find(n.parent)==nodes.end()) return {false,"missing parent '"+n.parent+"' for node '"+n.id+"'"};
    for (const auto& n : scene.nodes) {
        std::unordered_set<std::string> chain; const SceneNode* cur=&n;
        while (cur && !cur->parent.empty()) {
            if (!chain.insert(cur->id).second) return {false,"scene graph cycle detected at node: "+cur->id};
            const auto it=nodes.find(cur->parent); cur=it==nodes.end()?nullptr:it->second;
        }
    }
    return {true,"scene graph valid"};
}

Result validate_asset(const Asset& a) {
    if (a.logical_name.empty()) return {false,"asset logical name is required"};
    if (!safe_relative_path(a.relative_path)) return {false,"asset path must remain relative to the project root"};
    static const std::unordered_set<std::string> kinds{"texture","model","audio","shader","font","data"};
    if (kinds.find(a.kind)==kinds.end()) return {false,"unsupported asset kind: "+a.kind};
    return {true,"asset descriptor valid"};
}

SoftwareRenderer::SoftwareRenderer(int w,int h,Color clear_color)
    : canvas_(w,h,clear_color), depth_(canvas_.pixels().size(),std::numeric_limits<float>::infinity()) {}
void SoftwareRenderer::clear(Color color) {
    canvas_=Canvas(canvas_.width(),canvas_.height(),color);
    std::fill(depth_.begin(),depth_.end(),std::numeric_limits<float>::infinity());
}
void SoftwareRenderer::triangle(const Vertex& a,const Vertex& b,const Vertex& c) {
    if(canvas_.width()<=0||canvas_.height()<=0) return;
    const auto finite_vertex=[](const Vertex& v) { return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.depth); };
    if(!finite_vertex(a)||!finite_vertex(b)||!finite_vertex(c)) return;
    const float area=edge(a,b,c.x,c.y); if(std::abs(area)<1e-6f) return;
    const float min_fx=std::max(0.0f,std::floor(std::min({a.x,b.x,c.x})));
    const float max_fx=std::min(static_cast<float>(canvas_.width()-1),std::ceil(std::max({a.x,b.x,c.x})));
    const float min_fy=std::max(0.0f,std::floor(std::min({a.y,b.y,c.y})));
    const float max_fy=std::min(static_cast<float>(canvas_.height()-1),std::ceil(std::max({a.y,b.y,c.y})));
    if(min_fx>max_fx||min_fy>max_fy) return;
    const int min_x=static_cast<int>(min_fx), max_x=static_cast<int>(max_fx);
    const int min_y=static_cast<int>(min_fy), max_y=static_cast<int>(max_fy);
    for(int y=min_y;y<=max_y;++y) for(int x=min_x;x<=max_x;++x) {
        const float px=static_cast<float>(x)+0.5f, py=static_cast<float>(y)+0.5f;
        const float wa=edge(b,c,px,py)/area, wb=edge(c,a,px,py)/area, wc=edge(a,b,px,py)/area;
        if(wa < -1e-5f || wb < -1e-5f || wc < -1e-5f) continue;
        const float z=a.depth*wa+b.depth*wb+c.depth*wc;
        const auto index=static_cast<std::size_t>(y)*static_cast<std::size_t>(canvas_.width())+static_cast<std::size_t>(x);
        if(z>=depth_[index]) continue;
        depth_[index]=z;
        canvas_.pixel(x,y,{channel(a.color.r,b.color.r,c.color.r,wa,wb,wc),channel(a.color.g,b.color.g,c.color.g,wa,wb,wc),channel(a.color.b,b.color.b,c.color.b,wa,wb,wc)});
    }
}
void SoftwareRenderer::rectangle(float x,float y,float w,float h,float z,Color color) {
    if(w<=0||h<=0) return;
    const Vertex a{x,y,z,color},b{x+w,y,z,color},c{x+w,y+h,z,color},d{x,y+h,z,color};
    triangle(a,b,c); triangle(a,c,d);
}
bool SoftwareRenderer::write_ppm(const std::string& path) const { return canvas_.write_ppm(path); }

} // namespace docmont::vlot
