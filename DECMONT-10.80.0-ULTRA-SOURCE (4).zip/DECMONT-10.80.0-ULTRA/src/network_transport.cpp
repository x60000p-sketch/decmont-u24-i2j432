#include "docmont/network_transport.hpp"
#include <algorithm>
#include <array>
#include <cerrno>
#include <fcntl.h>
#include <cstring>
#include <limits>
#include <string>
#if defined(_WIN32)
#error "DOCMONT 9.00.0 socket transport currently requires the POSIX sockets adapter; use the platform socket adapter on Windows."
#endif
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netdb.h>
#include <poll.h>
#include <sys/socket.h>
#include <unistd.h>

namespace docmont::network {
namespace {
std::string sys_error(const char* prefix){return std::string(prefix)+": "+std::strerror(errno);}
bool wait_fd(int fd,short events,std::chrono::milliseconds timeout,std::string* error){
    if(timeout.count()<0){if(error)*error="timeout cannot be negative";return false;}
    pollfd p{fd,events,0};
    const auto n=::poll(&p,1,static_cast<int>(std::min<std::int64_t>(timeout.count(),std::numeric_limits<int>::max())));
    if(n==0){if(error)*error="socket operation timed out";return false;}
    if(n<0){if(errno==EINTR)return wait_fd(fd,events,timeout,error);if(error)*error=sys_error("poll failed");return false;}
    if(p.revents&(POLLERR|POLLNVAL)){if(error)*error="socket poll reported an error";return false;}
    if(!(p.revents&(events|POLLHUP))){if(error)*error="socket became unavailable";return false;}
    return true;
}
bool send_all(int fd,const std::uint8_t* data,std::size_t n,std::string* error){
    std::size_t off=0;while(off<n){const auto k=::send(fd,data+off,n-off,MSG_NOSIGNAL);if(k<0){if(errno==EINTR)continue;if(error)*error=sys_error("send failed");return false;}if(k==0){if(error)*error="socket closed during send";return false;}off+=static_cast<std::size_t>(k);}return true;
}
bool recv_all(int fd,std::uint8_t* data,std::size_t n,std::chrono::milliseconds timeout,std::string* error){
    std::size_t off=0;while(off<n){if(!wait_fd(fd,POLLIN,timeout,error))return false;const auto k=::recv(fd,data+off,n-off,0);if(k<0){if(errno==EINTR)continue;if(error)*error=sys_error("recv failed");return false;}if(k==0){if(error)*error="peer closed connection";return false;}off+=static_cast<std::size_t>(k);}return true;
}
void put16(std::uint8_t* p,std::uint16_t v){p[0]=static_cast<std::uint8_t>(v>>8);p[1]=static_cast<std::uint8_t>(v);}
void put32(std::uint8_t* p,std::uint32_t v){p[0]=static_cast<std::uint8_t>(v>>24);p[1]=static_cast<std::uint8_t>(v>>16);p[2]=static_cast<std::uint8_t>(v>>8);p[3]=static_cast<std::uint8_t>(v);}
std::uint16_t get16(const std::uint8_t* p){return static_cast<std::uint16_t>((p[0]<<8)|p[1]);}
std::uint32_t get32(const std::uint8_t* p){return (std::uint32_t(p[0])<<24)|(std::uint32_t(p[1])<<16)|(std::uint32_t(p[2])<<8)|p[3];}
}
std::uint32_t crc32(std::span<const std::uint8_t> b) noexcept {std::uint32_t c=0xffffffffu;for(auto x:b){c^=x;for(int i=0;i<8;++i)c=(c>>1)^(0xedb88320u&static_cast<std::uint32_t>(-static_cast<std::int32_t>(c&1)));}return ~c;}
TcpConnection::~TcpConnection(){close();}
TcpConnection::TcpConnection(TcpConnection&& o) noexcept:handle_(o.handle_){o.handle_=-1;}
TcpConnection& TcpConnection::operator=(TcpConnection&& o) noexcept{if(this!=&o){close();handle_=o.handle_;o.handle_=-1;}return *this;}
void TcpConnection::close() noexcept{if(handle_>=0){::shutdown(handle_,SHUT_RDWR);::close(handle_);handle_=-1;}}
bool TcpConnection::send_frame(std::span<const std::uint8_t> payload,std::string* e){
    if(!valid()){if(e)*e="TCP connection is closed";return false;}
    if(payload.size()>16u*1024u*1024u){if(e)*e="TCP frame exceeds 16 MiB";return false;}
    std::array<std::uint8_t,12> h{'D','M','T','1'};put32(h.data()+4,static_cast<std::uint32_t>(payload.size()));put32(h.data()+8,crc32(payload));
    return send_all(handle_,h.data(),h.size(),e)&&send_all(handle_,payload.data(),payload.size(),e);
}
FrameResult TcpConnection::receive_frame(std::chrono::milliseconds timeout,std::size_t max_bytes){
    FrameResult r;if(!valid()){r.error="TCP connection is closed";return r;}
    std::array<std::uint8_t,12> h{};if(!recv_all(handle_,h.data(),h.size(),timeout,&r.error))return r;
    if(std::memcmp(h.data(),"DMT1",4)!=0){r.error="invalid TCP frame magic";return r;}
    const auto n=get32(h.data()+4);if(n>max_bytes){r.error="TCP frame exceeds configured size limit";return r;}
    r.payload.resize(n);if(n&&!recv_all(handle_,r.payload.data(),n,timeout,&r.error)){r.payload.clear();return r;}
    if(crc32(r.payload)!=get32(h.data()+8)){r.payload.clear();r.error="TCP frame checksum mismatch";return r;}r.ok=true;return r;
}
std::optional<TcpConnection> TcpConnection::connect(const Endpoint& ep,std::chrono::milliseconds timeout,std::string* e){
    if(ep.host.empty()||ep.port==0){if(e)*e="TCP endpoint requires host and non-zero port";return std::nullopt;}
    addrinfo hints{};hints.ai_family=AF_UNSPEC;hints.ai_socktype=SOCK_STREAM;addrinfo* result=nullptr;const auto service=std::to_string(ep.port);
    const int gr=getaddrinfo(ep.host.c_str(),service.c_str(),&hints,&result);if(gr!=0){if(e)*e=gai_strerror(gr);return std::nullopt;}
    int fd=-1;std::string last="unable to connect";
    for(auto* p=result;p;p=p->ai_next){fd=::socket(p->ai_family,p->ai_socktype,p->ai_protocol);if(fd<0){last=sys_error("socket failed");continue;}
        const int old=fcntl(fd,F_GETFL,0);fcntl(fd,F_SETFL,old|O_NONBLOCK);const int rc=::connect(fd,p->ai_addr,p->ai_addrlen);
        if(rc<0&&errno!=EINPROGRESS){last=sys_error("connect failed");::close(fd);fd=-1;continue;}
        if(rc<0){if(!wait_fd(fd,POLLOUT,timeout,&last)){::close(fd);fd=-1;continue;}int so=0;socklen_t sl=sizeof(so);getsockopt(fd,SOL_SOCKET,SO_ERROR,&so,&sl);if(so){errno=so;last=sys_error("connect failed");::close(fd);fd=-1;continue;}}
        fcntl(fd,F_SETFL,old);break;
    }
    freeaddrinfo(result);if(fd<0){if(e)*e=last;return std::nullopt;}return TcpConnection(fd);
}
TcpListener::~TcpListener(){close();}
TcpListener::TcpListener(TcpListener&& o) noexcept:handle_(o.handle_),port_(o.port_){o.handle_=-1;o.port_=0;}
TcpListener& TcpListener::operator=(TcpListener&& o) noexcept{if(this!=&o){close();handle_=o.handle_;port_=o.port_;o.handle_=-1;o.port_=0;}return *this;}
void TcpListener::close() noexcept{if(handle_>=0){::close(handle_);handle_=-1;port_=0;}}
std::optional<TcpListener> TcpListener::bind(const Endpoint& ep,std::string* e){
    if(ep.port==0 && ep.host.empty()) { /* port zero is valid for ephemeral listeners */ }
    const std::string host=ep.host.empty()?"0.0.0.0":ep.host;
    addrinfo hints{};hints.ai_family=AF_INET;hints.ai_socktype=SOCK_STREAM;hints.ai_flags=AI_PASSIVE;
    addrinfo* result=nullptr;const auto service=std::to_string(ep.port);
    const int gr=getaddrinfo(host.c_str(),service.c_str(),&hints,&result);
    if(gr!=0){if(e)*e=gai_strerror(gr);return std::nullopt;}
    int fd=-1;std::string last="unable to bind TCP listener";
    for(auto* p=result;p;p=p->ai_next){fd=::socket(p->ai_family,p->ai_socktype,p->ai_protocol);if(fd<0){last=sys_error("TCP socket failed");continue;}
        int one=1;setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&one,sizeof(one));
        if(::bind(fd,p->ai_addr,p->ai_addrlen)<0||::listen(fd,32)<0){last=sys_error("TCP bind/listen failed");::close(fd);fd=-1;continue;}break;}
    freeaddrinfo(result);if(fd<0){if(e)*e=last;return std::nullopt;}
    sockaddr_in a{};socklen_t n=sizeof(a);if(getsockname(fd,reinterpret_cast<sockaddr*>(&a),&n)<0){if(e)*e=sys_error("getsockname failed");::close(fd);return std::nullopt;}
    TcpListener listener;listener.handle_=fd;listener.port_=ntohs(a.sin_port);return listener;
}
std::optional<TcpListener> TcpListener::bind_any(std::uint16_t port,std::string* e){return bind({"0.0.0.0",port},e);}
std::optional<TcpListener> TcpListener::bind_loopback(std::uint16_t port,std::string* e){return bind({"127.0.0.1",port},e);}
std::optional<TcpConnection> TcpListener::accept(std::chrono::milliseconds timeout,std::string* e){
    if(!valid()){if(e)*e="TCP listener is closed";return std::nullopt;}if(!wait_fd(handle_,POLLIN,timeout,e))return std::nullopt;
    int fd=::accept(handle_,nullptr,nullptr);if(fd<0){if(e)*e=sys_error("accept failed");return std::nullopt;}return TcpConnection(fd);
}
UdpSocket::~UdpSocket(){close();}
UdpSocket::UdpSocket(UdpSocket&& o) noexcept:handle_(o.handle_),port_(o.port_){o.handle_=-1;o.port_=0;}
UdpSocket& UdpSocket::operator=(UdpSocket&& o) noexcept{if(this!=&o){close();handle_=o.handle_;port_=o.port_;o.handle_=-1;o.port_=0;}return *this;}
void UdpSocket::close() noexcept{if(handle_>=0){::close(handle_);handle_=-1;port_=0;}}
std::optional<UdpSocket> UdpSocket::bind(const Endpoint& ep,std::string* e){
    const std::string host=ep.host.empty()?"0.0.0.0":ep.host;
    addrinfo hints{};hints.ai_family=AF_INET;hints.ai_socktype=SOCK_DGRAM;hints.ai_flags=AI_PASSIVE;
    addrinfo* result=nullptr;const auto service=std::to_string(ep.port);
    const int gr=getaddrinfo(host.c_str(),service.c_str(),&hints,&result);
    if(gr!=0){if(e)*e=gai_strerror(gr);return std::nullopt;}
    int fd=-1;std::string last="unable to bind UDP socket";
    for(auto* p=result;p;p=p->ai_next){fd=::socket(p->ai_family,p->ai_socktype,p->ai_protocol);if(fd<0){last=sys_error("UDP socket failed");continue;}
        if(::bind(fd,p->ai_addr,p->ai_addrlen)<0){last=sys_error("UDP bind failed");::close(fd);fd=-1;continue;}break;}
    freeaddrinfo(result);if(fd<0){if(e)*e=last;return std::nullopt;}
    sockaddr_in a{};socklen_t n=sizeof(a);if(getsockname(fd,reinterpret_cast<sockaddr*>(&a),&n)<0){if(e)*e=sys_error("UDP getsockname failed");::close(fd);return std::nullopt;}
    UdpSocket socket;socket.handle_=fd;socket.port_=ntohs(a.sin_port);return socket;
}
std::optional<UdpSocket> UdpSocket::bind_any(std::uint16_t port,std::string* e){return bind({"0.0.0.0",port},e);}
std::optional<UdpSocket> UdpSocket::bind_loopback(std::uint16_t port,std::string* e){return bind({"127.0.0.1",port},e);}
bool UdpSocket::send_to(const Endpoint& ep,std::uint32_t seq,std::span<const std::uint8_t> p,std::string* e){
    if(!valid()){if(e)*e="UDP socket is closed";return false;}if(p.size()>60u*1024u){if(e)*e="UDP payload exceeds 60 KiB";return false;}
    if(ep.host.empty()||ep.port==0){if(e)*e="UDP endpoint requires host and non-zero port";return false;}
    addrinfo hints{};hints.ai_family=AF_INET;hints.ai_socktype=SOCK_DGRAM;addrinfo* result=nullptr;const auto service=std::to_string(ep.port);
    const int gr=getaddrinfo(ep.host.c_str(),service.c_str(),&hints,&result);if(gr!=0){if(e)*e=gai_strerror(gr);return false;}
    std::vector<std::uint8_t> d(14+p.size());std::memcpy(d.data(),"DNU1",4);put32(d.data()+4,seq);put16(d.data()+8,static_cast<std::uint16_t>(p.size()));if(!p.empty())std::memcpy(d.data()+14,p.data(),p.size());put32(d.data()+10,crc32(p));
    bool sent=false;for(auto* a=result;a;a=a->ai_next){const auto n=::sendto(handle_,d.data(),d.size(),0,a->ai_addr,a->ai_addrlen);if(n>=0&&static_cast<std::size_t>(n)==d.size()){sent=true;break;}}
    freeaddrinfo(result);if(!sent){if(e)*e=sys_error("UDP sendto failed");return false;}return true;
}
DatagramResult UdpSocket::receive(std::chrono::milliseconds timeout,std::size_t max_bytes){
    DatagramResult r;if(!valid()){r.error="UDP socket is closed";return r;}std::string why;if(!wait_fd(handle_,POLLIN,timeout,&why)){r.error=why;return r;}
    std::vector<std::uint8_t> b(std::min<std::size_t>(max_bytes+14,65507));sockaddr_in from{};socklen_t fl=sizeof(from);const auto n=::recvfrom(handle_,b.data(),b.size(),0,reinterpret_cast<sockaddr*>(&from),&fl);if(n<0){r.error=sys_error("UDP recvfrom failed");return r;}b.resize(static_cast<std::size_t>(n));
    if(b.size()<14||std::memcmp(b.data(),"DNU1",4)!=0){r.error="invalid UDP datagram header";return r;}const auto len=get16(b.data()+8);if(len>max_bytes||b.size()!=14u+len){r.error="invalid UDP datagram length";return r;}
    r.sequence=get32(b.data()+4);r.payload.assign(b.begin()+14,b.end());if(crc32(r.payload)!=get32(b.data()+10)){r.payload.clear();r.error="UDP datagram checksum mismatch";return r;}
    char ip[INET_ADDRSTRLEN]{};inet_ntop(AF_INET,&from.sin_addr,ip,sizeof(ip));r.from={ip,ntohs(from.sin_port)};r.ok=true;return r;
}
} // namespace docmont::network
