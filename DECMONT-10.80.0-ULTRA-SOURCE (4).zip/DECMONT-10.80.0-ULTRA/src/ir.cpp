#include "docmont/ir.hpp"
#include <sstream>
#include <algorithm>
#include <cstddef>
#include <unordered_set>
#include <unordered_map>
#include <set>
#include <cstdint>
namespace docmont {
namespace {
std::unordered_set<std::string> dvm_function_names;
std::unordered_map<std::string, const FunctionDecl*> dvm_function_declarations;
std::unordered_map<std::string, std::string> dvm_function_aliases;
std::unordered_map<std::string, std::string> dvm_identifier_substitutions;
std::uint64_t dvm_default_temp_counter = 0;
std::vector<std::pair<std::string, FunctionDecl>> dvm_lambdas;
std::unordered_map<const Expr*, std::string> dvm_lambda_names;
std::size_t dvm_lambda_counter = 0;
std::uint64_t dvm_control_temp_counter = 0;

void collect_expr_identifiers(const std::shared_ptr<Expr>& e, std::set<std::string>& names) {
    if (!e) return;
    if (e->kind == ExprKind::Identifier) names.insert(e->text);
    if (e->kind == ExprKind::Call && !e->callee.empty()) names.insert(e->callee);
    collect_expr_identifiers(e->left, names); collect_expr_identifiers(e->right, names);
    for (const auto& item : e->elements) collect_expr_identifiers(item, names);
    for (const auto& item : e->properties) collect_expr_identifiers(item.second, names);
}
void collect_stmt_identifiers(const std::vector<Statement>& statements, std::set<std::string>& names) {
    for (const auto& st : statements) { if (st.kind == Statement::Kind::Assign) names.insert(st.name); collect_expr_identifiers(st.expression, names); collect_expr_identifiers(st.target_index, names); collect_expr_identifiers(st.target_member, names); collect_stmt_identifiers(st.body, names); collect_stmt_identifiers(st.else_body, names); }
}
std::vector<std::string> lambda_captures(const FunctionDecl& fn) {
    std::set<std::string> names, excluded; collect_stmt_identifiers(fn.body, names);
    for (const auto& p : fn.parameters) excluded.insert(p.name);
    for (const auto& st : fn.body) if (st.kind == Statement::Kind::Let) excluded.insert(st.name);
    for (const auto& name : dvm_function_names) excluded.insert(name);
    for (const auto& builtin : {std::string("length"), std::string("push"), std::string("pop")}) excluded.insert(builtin);
    std::vector<std::string> result; for (const auto& name : names) if (!excluded.contains(name)) result.push_back(name); return result;
}
void lower_expr(const std::shared_ptr<Expr>& e, std::vector<Instruction>& out) {
    if (!e) return;
    switch (e->kind) {
    case ExprKind::Integer: out.push_back({OpCode::PushInt, {}, std::stoll(e->text), e->line}); break;
    case ExprKind::String: out.push_back({OpCode::PushString, e->text, 0, e->line}); break;
    case ExprKind::Boolean: out.push_back({OpCode::PushInt, {}, e->text=="true"?1:0, e->line}); break;
    case ExprKind::Unary:
        lower_expr(e->left,out);
        if(e->op=="!") out.push_back({OpCode::BoolNot,{},0,e->line});
        else if(e->op=="-" ) { out.push_back({OpCode::PushInt,{},-1,e->line}); out.push_back({OpCode::Mul,{},0,e->line}); }
        // Borrow and move are compile-time ownership operators; they have no DVM opcode.
        break;
    case ExprKind::Identifier: {
        const auto substitution = dvm_identifier_substitutions.find(e->text);
        if (substitution != dvm_identifier_substitutions.end())
            out.push_back({OpCode::Load, substitution->second, 0, e->line});
        else
            out.push_back({dvm_function_names.contains(e->text) ? OpCode::LoadFunction : OpCode::Load, e->text, 0, e->line});
        break;
    }
    case ExprKind::Lambda: {
        auto found = dvm_lambda_names.find(e.get());
        if (found == dvm_lambda_names.end()) {
            const auto name = "__docmont_lambda_" + std::to_string(++dvm_lambda_counter);
            dvm_lambda_names.emplace(e.get(), name);
            dvm_function_names.insert(name);
            if (e->lambda_function) {
                const auto captures = lambda_captures(*e->lambda_function);
                for (const auto& capture : captures) out.push_back({OpCode::LoadCell, capture, 0, e->line});
                dvm_lambdas.emplace_back(name, *e->lambda_function);
                std::string metadata = name; for (const auto& capture : captures) metadata += "|" + capture;
                out.push_back({OpCode::MakeClosure, metadata, static_cast<std::int64_t>(captures.size()), e->line});
            } else out.push_back({OpCode::LoadFunction, name, 0, e->line});
        } else out.push_back({OpCode::LoadFunction, found->second, 0, e->line});
        break;
    }
    case ExprKind::ObjectLiteral:
        out.push_back({OpCode::NewObject, {}, 0, e->line});
        for (const auto& property : e->properties) {
            lower_expr(property.second, out);
            // ObjectSet mutates the object already on top of the VM stack and
            // deliberately leaves it there as the literal expression result.
            // A duplicate here would leak one reference per property.
            out.push_back({OpCode::ObjectSet, property.first, 0, e->line});
        }
        break;
    case ExprKind::Member:
        lower_expr(e->left, out); out.push_back({OpCode::ObjectGet, e->text, 0, e->line}); break;
    case ExprKind::ArrayLiteral:
        for (const auto& element : e->elements) lower_expr(element, out);
        out.push_back({OpCode::MakeArray, {}, static_cast<std::int64_t>(e->elements.size()), e->line});
        break;
    case ExprKind::Index:
        lower_expr(e->left, out); lower_expr(e->right, out);
        out.push_back({OpCode::ArrayGet, {}, 0, e->line});
        break;
    case ExprKind::Call:
        if (e->callee.find("::") != std::string::npos) {
            const auto split=e->callee.find("::");
            out.push_back({OpCode::NewObject,{},0,e->line});
            out.push_back({OpCode::PushString,e->callee.substr(0,split),0,e->line}); out.push_back({OpCode::ObjectSet,"__enum",0,e->line});
            out.push_back({OpCode::PushString,e->callee.substr(split+2),0,e->line}); out.push_back({OpCode::ObjectSet,"__variant",0,e->line});
            if (e->elements.size()==1) lower_expr(e->elements.front(),out);
            else if (!e->elements.empty()) { for(const auto& arg:e->elements) lower_expr(arg,out); out.push_back({OpCode::MakeArray,{},static_cast<std::int64_t>(e->elements.size()),e->line}); }
            else out.push_back({OpCode::PushInt,{},0,e->line});
            out.push_back({OpCode::ObjectSet,"__payload",0,e->line});
        }
        else if ((e->callee == "length" || e->callee == "len") && e->elements.size() == 1) { lower_expr(e->elements[0], out); out.push_back({OpCode::ArrayLength,{},0,e->line}); }
        else if (e->callee == "push" && e->elements.size() == 2) { lower_expr(e->elements[0],out); lower_expr(e->elements[1],out); out.push_back({OpCode::ArrayPush,{},0,e->line}); }
        else if (e->callee == "pop" && e->elements.size() == 1) { lower_expr(e->elements[0],out); out.push_back({OpCode::ArrayPop,{},0,e->line}); }
        else {
            std::string resolved_function = e->callee;
            if (!dvm_function_declarations.contains(resolved_function)) {
                const auto alias = dvm_function_aliases.find(resolved_function);
                if (alias != dvm_function_aliases.end()) resolved_function = alias->second;
            }
            const auto declaration = dvm_function_declarations.find(resolved_function);
            if (declaration != dvm_function_declarations.end()) {
                const auto& function = *declaration->second;
                std::size_t required = function.parameters.size();
                while (required > 0 && function.parameters[required - 1].default_value) --required;
                if (e->elements.size() >= required && e->elements.size() <= function.parameters.size() &&
                    e->elements.size() < function.parameters.size()) {
                    // Materialize each argument exactly once. Defaults are evaluated
                    // in parameter order and can reference earlier parameters.
                    const auto previous_substitutions = dvm_identifier_substitutions;
                    std::unordered_map<std::string, std::string> parameter_substitutions = previous_substitutions;
                    std::vector<std::string> temporaries;
                    temporaries.reserve(function.parameters.size());
                    for (std::size_t i = 0; i < function.parameters.size(); ++i) {
                        dvm_identifier_substitutions = parameter_substitutions;
                        if (i < e->elements.size()) {
                            lower_expr(e->elements[i], out);
                        } else if (function.parameters[i].default_value) {
                            lower_expr(function.parameters[i].default_value, out);
                        } else {
                            // Semantic validation rejects this path; retain a safe
                            // placeholder so malformed ASTs do not corrupt the stack.
                            out.push_back({OpCode::PushInt, {}, 0, e->line});
                        }
                        const auto temporary = "__docmont_default_arg_" + std::to_string(++dvm_default_temp_counter);
                        out.push_back({OpCode::Store, temporary, 0, e->line});
                        temporaries.push_back(temporary);
                        parameter_substitutions[function.parameters[i].name] = temporary;
                    }
                    dvm_identifier_substitutions = previous_substitutions;
                    for (const auto& temporary : temporaries)
                        out.push_back({OpCode::Load, temporary, 0, e->line});
                    out.push_back({OpCode::Call, resolved_function, static_cast<std::int64_t>(function.parameters.size()), e->line});
                } else {
                    for (const auto& arg : e->elements) lower_expr(arg, out);
                    out.push_back({OpCode::Call, resolved_function, static_cast<std::int64_t>(e->elements.size()), e->line});
                }
            } else {
                out.push_back({OpCode::Load, e->callee, 0, e->line});
                for (const auto& arg : e->elements) lower_expr(arg, out);
                out.push_back({OpCode::CallIndirect, {}, static_cast<std::int64_t>(e->elements.size()), e->line});
            }
        }
        break;
    case ExprKind::Binary: {
        // Logical operators use control flow, not eager binary instructions.
        // This guarantees short-circuit semantics in the DVM.
        if (e->op == "&&") {
            lower_expr(e->left, out);
            const auto false_branch = out.size(); out.push_back({OpCode::JumpIfZero, {}, 0, e->line});
            lower_expr(e->right, out); out.push_back({OpCode::BoolNot,{},0,e->line}); out.push_back({OpCode::BoolNot,{},0,e->line});
            const auto end_jump = out.size(); out.push_back({OpCode::Jump,{},0,e->line});
            out[false_branch].integer = static_cast<std::int64_t>(out.size());
            out.push_back({OpCode::PushInt,{},0,e->line});
            out[end_jump].integer = static_cast<std::int64_t>(out.size());
            break;
        }
        if (e->op == "||") {
            lower_expr(e->left, out);
            const auto rhs_branch = out.size(); out.push_back({OpCode::JumpIfZero, {}, 0, e->line});
            out.push_back({OpCode::PushInt,{},1,e->line});
            const auto end_jump = out.size(); out.push_back({OpCode::Jump,{},0,e->line});
            out[rhs_branch].integer = static_cast<std::int64_t>(out.size());
            lower_expr(e->right, out); out.push_back({OpCode::BoolNot,{},0,e->line}); out.push_back({OpCode::BoolNot,{},0,e->line});
            out[end_jump].integer = static_cast<std::int64_t>(out.size());
            break;
        }
        lower_expr(e->left, out); lower_expr(e->right, out);
        OpCode op=OpCode::Div;
        if(e->op=="+")op=OpCode::Add; else if(e->op=="-")op=OpCode::Sub; else if(e->op=="*")op=OpCode::Mul;
        else if(e->op=="==")op=OpCode::Equal; else if(e->op=="!=")op=OpCode::NotEqual;
        else if(e->op=="<")op=OpCode::Less; else if(e->op=="<=")op=OpCode::LessEqual;
        else if(e->op==">")op=OpCode::Greater; else if(e->op==">=")op=OpCode::GreaterEqual;
        out.push_back({op, {}, 0, e->line});
        break;
    }
    case ExprKind::Try: {
        const auto temp = "__docmont_try_" + std::to_string(++dvm_control_temp_counter);
        lower_expr(e->left,out); out.push_back({OpCode::Store,temp,0,e->line});
        // Result::Ok and Option::Some unwrap to payload. Err/None return the
        // original tagged value from the enclosing function.
        out.push_back({OpCode::Load,temp,0,e->line}); out.push_back({OpCode::ObjectGet,"__variant",0,e->line});
        out.push_back({OpCode::PushString,"Ok",0,e->line}); out.push_back({OpCode::Equal,{},0,e->line});
        const auto check_some=out.size(); out.push_back({OpCode::JumpIfZero,{},0,e->line});
        out.push_back({OpCode::Load,temp,0,e->line}); out.push_back({OpCode::ObjectGet,"__payload",0,e->line});
        const auto done_ok=out.size(); out.push_back({OpCode::Jump,{},0,e->line});
        out[check_some].integer=static_cast<std::int64_t>(out.size());
        out.push_back({OpCode::Load,temp,0,e->line}); out.push_back({OpCode::ObjectGet,"__variant",0,e->line});
        out.push_back({OpCode::PushString,"Some",0,e->line}); out.push_back({OpCode::Equal,{},0,e->line});
        const auto propagate=out.size(); out.push_back({OpCode::JumpIfZero,{},0,e->line});
        out.push_back({OpCode::Load,temp,0,e->line}); out.push_back({OpCode::ObjectGet,"__payload",0,e->line});
        const auto done_some=out.size(); out.push_back({OpCode::Jump,{},0,e->line});
        out[propagate].integer=static_cast<std::int64_t>(out.size());
        out.push_back({OpCode::Load,temp,0,e->line}); out.push_back({OpCode::Return,{},0,e->line});
        const auto end=out.size(); out[done_ok].integer=static_cast<std::int64_t>(end); out[done_some].integer=static_cast<std::int64_t>(end);
        break;
    }
    default: break;
    }
}
struct LoopPatch { std::size_t continue_target; std::vector<std::size_t> breaks; std::vector<std::size_t> continues; };
void lower_statements(const std::vector<Statement>& statements, std::vector<Instruction>& out, std::vector<LoopPatch>& loops) {
    for (const auto& st : statements) {
        if (st.kind == Statement::Kind::Let || st.kind == Statement::Kind::Assign) {
            if (st.kind == Statement::Kind::Assign && st.target_index) {
                // The parser stores the complete indexed l-value as an Index chain.
                // Lower its parent expression first, then write the final element.
                const auto& target = st.target_index;
                if (target->kind == ExprKind::Index && target->left && target->right) {
                    lower_expr(target->left, out);
                    lower_expr(target->right, out);
                    lower_expr(st.expression, out);
                    out.push_back({OpCode::ArraySet, {}, 0, st.line});
                } else {
                    out.push_back({OpCode::Load, st.name, 0, st.line});
                    lower_expr(target, out); lower_expr(st.expression, out);
                    out.push_back({OpCode::ArraySet, {}, 0, st.line});
                }
            } else {
                lower_expr(st.expression, out); out.push_back({OpCode::Store, st.name, 0, st.line});
            }
        } else if (st.kind == Statement::Kind::Output) {
            lower_expr(st.expression, out); out.push_back({OpCode::Print, {}, 0, st.line});
        } else if (st.kind == Statement::Kind::Return) {
            if (st.expression) lower_expr(st.expression, out); else out.push_back({OpCode::PushInt,{},0,st.line});
            out.push_back({OpCode::Return,{},0,st.line});
        } else if (st.kind == Statement::Kind::Break) {
            if (!loops.empty()) { loops.back().breaks.push_back(out.size()); out.push_back({OpCode::Jump,{},0,st.line}); }
        } else if (st.kind == Statement::Kind::Continue) {
            if (!loops.empty()) { if (loops.back().continue_target == static_cast<std::size_t>(-1)) { loops.back().continues.push_back(out.size()); out.push_back({OpCode::Jump,{},0,st.line}); } else out.push_back({OpCode::Jump,{},static_cast<std::int64_t>(loops.back().continue_target),st.line}); }
        } else if (st.kind == Statement::Kind::ForEach) {
            const std::string array_name = "__docmont_foreach_array_" + std::to_string(st.line) + "_" + std::to_string(out.size());
            const std::string index_name = "__docmont_foreach_index_" + std::to_string(st.line) + "_" + std::to_string(out.size());
            lower_expr(st.expression,out); out.push_back({OpCode::Store,array_name,0,st.line});
            out.push_back({OpCode::PushInt,{},0,st.line}); out.push_back({OpCode::Store,index_name,0,st.line});
            const auto start=out.size();
            out.push_back({OpCode::Load,index_name,0,st.line}); out.push_back({OpCode::Load,array_name,0,st.line}); out.push_back({OpCode::ArrayLength,{},0,st.line}); out.push_back({OpCode::Less,{},0,st.line});
            const auto exit=out.size(); out.push_back({OpCode::JumpIfZero,{},0,st.line});
            out.push_back({OpCode::Load,array_name,0,st.line}); out.push_back({OpCode::Load,index_name,0,st.line}); out.push_back({OpCode::ArrayGet,{},0,st.line}); out.push_back({OpCode::Store,st.name,0,st.line});
            loops.push_back({static_cast<std::size_t>(-1),{}, {}});
            lower_statements(st.body,out,loops);
            const auto continue_target=out.size();
            // Continue statements target the increment sequence, patched after body emission.
            for (const auto patch : loops.back().continues) out[patch].integer=static_cast<std::int64_t>(continue_target);
            out.push_back({OpCode::Load,index_name,0,st.line}); out.push_back({OpCode::PushInt,{},1,st.line}); out.push_back({OpCode::Add,{},0,st.line}); out.push_back({OpCode::Store,index_name,0,st.line});
            out.push_back({OpCode::Jump,{},static_cast<std::int64_t>(start),st.line});
            const auto end=out.size(); out[exit].integer=static_cast<std::int64_t>(end);
            for (const auto patch : loops.back().breaks) out[patch].integer=static_cast<std::int64_t>(end);
            loops.pop_back();
        } else if (st.kind == Statement::Kind::While) {
            const auto start=out.size(); lower_expr(st.expression,out);
            const auto exit=out.size(); out.push_back({OpCode::JumpIfZero,{},0,st.line});
            loops.push_back({start,{},{}});
            lower_statements(st.body,out,loops);
            out.push_back({OpCode::Jump,{},static_cast<std::int64_t>(start),st.line});
            const auto loop_end=out.size(); out[exit].integer=static_cast<std::int64_t>(loop_end);
            for (const auto patch : loops.back().breaks) out[patch].integer=static_cast<std::int64_t>(loop_end);
            loops.pop_back();
        } else if (st.kind == Statement::Kind::Match) {
            const auto temp="__docmont_match_"+std::to_string(++dvm_control_temp_counter);
            lower_expr(st.expression,out); out.push_back({OpCode::Store,temp,0,st.line});
            std::vector<std::size_t> end_jumps;
            for (const auto& arm_ptr : st.match_arms) {
                if (!arm_ptr) continue;
                if (!arm_ptr->wildcard) {
                    out.push_back({OpCode::Load,temp,0,arm_ptr->line}); out.push_back({OpCode::ObjectGet,"__variant",0,arm_ptr->line});
                    out.push_back({OpCode::PushString,arm_ptr->variant,0,arm_ptr->line}); out.push_back({OpCode::Equal,{},0,arm_ptr->line});
                    const auto next=out.size(); out.push_back({OpCode::JumpIfZero,{},0,arm_ptr->line});
                    if (!arm_ptr->binding.empty()) { out.push_back({OpCode::Load,temp,0,arm_ptr->line}); out.push_back({OpCode::ObjectGet,"__payload",0,arm_ptr->line}); out.push_back({OpCode::Store,arm_ptr->binding,0,arm_ptr->line}); }
                    lower_statements(arm_ptr->body,out,loops);
                    end_jumps.push_back(out.size()); out.push_back({OpCode::Jump,{},0,arm_ptr->line});
                    out[next].integer=static_cast<std::int64_t>(out.size());
                } else {
                    if (!arm_ptr->binding.empty()) { out.push_back({OpCode::Load,temp,0,arm_ptr->line}); out.push_back({OpCode::ObjectGet,"__payload",0,arm_ptr->line}); out.push_back({OpCode::Store,arm_ptr->binding,0,arm_ptr->line}); }
                    lower_statements(arm_ptr->body,out,loops);
                    end_jumps.push_back(out.size()); out.push_back({OpCode::Jump,{},0,arm_ptr->line});
                    break;
                }
            }
            const auto end=out.size(); for(auto patch:end_jumps) out[patch].integer=static_cast<std::int64_t>(end);
        } else {
            lower_expr(st.expression, out);
            const auto branch = out.size(); out.push_back({OpCode::JumpIfZero, {}, 0, st.line});
            lower_statements(st.body, out, loops);
            if (st.else_body.empty()) out[branch].integer = static_cast<std::int64_t>(out.size());
            else {
                const auto jump = out.size(); out.push_back({OpCode::Jump, {}, 0, st.line});
                out[branch].integer = static_cast<std::int64_t>(out.size());
                lower_statements(st.else_body, out, loops);
                out[jump].integer = static_cast<std::int64_t>(out.size());
            }
        }
    }
}
const char* opname(OpCode op) {
    switch(op) {
    case OpCode::PushInt:return "push_i64"; case OpCode::PushString:return "push_string";
    case OpCode::Load:return "load"; case OpCode::Store:return "store";
    case OpCode::Add:return "add"; case OpCode::Sub:return "sub";
    case OpCode::Mul:return "mul"; case OpCode::Div:return "div";
    case OpCode::Print:return "print"; case OpCode::Jump:return "jump";
    case OpCode::JumpIfZero:return "jump_if_zero";
    case OpCode::BoolNot:return "bool_not"; case OpCode::Equal:return "equal"; case OpCode::NotEqual:return "not_equal";
    case OpCode::Less:return "less"; case OpCode::LessEqual:return "less_equal"; case OpCode::Greater:return "greater"; case OpCode::GreaterEqual:return "greater_equal";
    case OpCode::LogicalAnd:return "logical_and"; case OpCode::LogicalOr:return "logical_or";
    case OpCode::MakeArray:return "make_array"; case OpCode::ArrayGet:return "array_get"; case OpCode::ArraySet:return "array_set"; case OpCode::ArrayLength:return "array_length"; case OpCode::ArrayPush:return "array_push"; case OpCode::ArrayPop:return "array_pop";
    case OpCode::Function:return "function"; case OpCode::Call:return "call"; case OpCode::Return:return "return";
    case OpCode::LoadFunction:return "load_function"; case OpCode::CallIndirect:return "call_indirect"; case OpCode::MakeClosure:return "make_closure"; case OpCode::LoadCell:return "load_cell";
    case OpCode::Dup:return "dup"; case OpCode::NewObject:return "new_object"; case OpCode::ObjectGet:return "object_get"; case OpCode::ObjectSet:return "object_set"; case OpCode::ObjectHas:return "object_has";
    }
    return "?";
}
}
ProgramIR lower_to_ir(const Application& app) {
    ProgramIR ir; ir.name=app.name; ir.target=app.architecture;
    dvm_function_names.clear(); dvm_function_declarations.clear(); dvm_function_aliases.clear();
    dvm_identifier_substitutions.clear(); dvm_default_temp_counter = 0;
    dvm_lambdas.clear(); dvm_lambda_names.clear(); dvm_lambda_counter = 0; dvm_control_temp_counter = 0;
    for (const auto& fn : app.functions) {
        dvm_function_names.insert(fn.name);
        dvm_function_declarations.emplace(fn.name, &fn);
    }
    auto collect_aliases = [&](const auto& self, const std::vector<Statement>& statements) -> void {
        for (const auto& statement : statements) {
            if (statement.kind == Statement::Kind::Let && statement.expression &&
                statement.expression->kind == ExprKind::Identifier &&
                dvm_function_declarations.contains(statement.expression->text))
                dvm_function_aliases[statement.name] = statement.expression->text;
            self(self, statement.body);
            self(self, statement.else_body);
        }
    };
    collect_aliases(collect_aliases, app.statements);
    for (const auto& fn : app.functions) collect_aliases(collect_aliases, fn.body);
    std::vector<LoopPatch> loops;
    const auto main_fn = std::find_if(app.functions.begin(), app.functions.end(), [](const FunctionDecl& fn) { return fn.name == "main"; });
    if (!app.statements.empty()) lower_statements(app.statements, ir.code, loops);
    else if (main_fn != app.functions.end()) lower_statements(main_fn->body, ir.code, loops);
    else for (const auto& s : app.outputs) { ir.code.push_back({OpCode::PushString,s}); ir.code.push_back({OpCode::Print,{}}); }
    if (!app.functions.empty() || !dvm_lambdas.empty()) {
        const auto skip_functions = ir.code.size();
        ir.code.push_back({OpCode::Jump,{},0,1});
        std::size_t emitted_lambda_count = 0;
        auto emit_function = [&](const std::string& name, const FunctionDecl& fn) {
            ir.code.push_back({OpCode::Function,name,static_cast<std::int64_t>(fn.parameters.size()),fn.line});
            for (auto it=fn.parameters.rbegin(); it!=fn.parameters.rend(); ++it)
                ir.code.push_back({OpCode::Store,it->name,0,it->line});
            loops.clear(); lower_statements(fn.body,ir.code,loops);
            ir.code.push_back({OpCode::PushInt,{},0,fn.line});
            ir.code.push_back({OpCode::Return,{},0,fn.line});
        };
        for (const auto& fn : app.functions) {
            if (fn.name == "main") continue;
            emit_function(fn.name, fn);
        }
        // Lambda bodies discovered while lowering are appended as ordinary DVM
        // functions. Closure environments are supplied by MakeClosure/LoadCell.
        while (emitted_lambda_count < dvm_lambdas.size()) {
            auto item = dvm_lambdas[emitted_lambda_count++];
            emit_function(item.first, item.second);
        }
        ir.code[skip_functions].integer=static_cast<std::int64_t>(ir.code.size());
    }
    return ir;
}

std::string dump_ir(const ProgramIR& ir) {
    std::ostringstream o; o << "DOCMONT-IR v3\nmodule " << ir.name << "\ntarget " << ir.target << "\n";
    for (std::size_t pc=0; pc<ir.code.size(); ++pc) {
        const auto& i=ir.code[pc]; o << "  " << pc << ": " << opname(i.op);
        if (i.op==OpCode::PushInt || i.op==OpCode::Jump || i.op==OpCode::JumpIfZero || i.op==OpCode::Call || i.op==OpCode::Function) o << ' ' << i.integer;
        else if (i.op==OpCode::PushString) o << " \"" << i.operand << "\"";
        else if (i.op==OpCode::Load || i.op==OpCode::Store || i.op==OpCode::ObjectGet || i.op==OpCode::ObjectSet || i.op==OpCode::ObjectHas) o << ' ' << i.operand;
        o << '\n';
    }
    return o.str();
}
}
