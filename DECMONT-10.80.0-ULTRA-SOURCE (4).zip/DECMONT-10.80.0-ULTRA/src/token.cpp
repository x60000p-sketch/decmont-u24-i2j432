#include "docmont/token.hpp"
namespace docmont {
const char* token_name(TokenKind k) {
 switch(k) {
 case TokenKind::Identifier:return "identifier"; case TokenKind::String:return "string";
 case TokenKind::Number:return "number"; case TokenKind::LBrace:return "{";
 case TokenKind::RBrace:return "}"; case TokenKind::LBracket:return "[";
 case TokenKind::RBracket:return "]"; case TokenKind::LParen:return "(";
 case TokenKind::RParen:return ")"; case TokenKind::Equal:return "=";
 case TokenKind::Colon:return ":"; case TokenKind::Comma:return ","; case TokenKind::Dot:return ".";
 case TokenKind::Plus:return "+"; case TokenKind::Minus:return "-";
 case TokenKind::Star:return "*"; case TokenKind::Slash:return "/"; case TokenKind::Less:return "<"; case TokenKind::LessEqual:return "<="; case TokenKind::Greater:return ">"; case TokenKind::GreaterEqual:return ">="; case TokenKind::EqualEqual:return "=="; case TokenKind::BangEqual:return "!="; case TokenKind::Bang:return "!"; case TokenKind::AndAnd:return "&&"; case TokenKind::OrOr:return "||";
 case TokenKind::DoubleColon:return "::"; case TokenKind::Arrow:return "=>"; case TokenKind::Question:return "?"; case TokenKind::Ampersand:return "&";
 case TokenKind::Newline:return "newline"; case TokenKind::End:return "end";
 default:return "invalid";
 }
}
}
