#include "docmont/vlot_advanced.hpp"
#include <algorithm>
#include <bit>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <functional>
#include <limits>
#include <sstream>
#include <unordered_map>
#include <unordered_set>

namespace fs = std::filesystem;
namespace docmont::vlot {
namespace {
constexpr std::uint64_t kMaxAssetBytes = 64ull * 1024ull * 1024ull;
constexpr std::uint64_t kMaxPackageBytes = 256ull * 1024ull * 1024ull;
constexpr std::uint32_t kMaxFiles = 10000;
std::uint64_t hash_bytes(const std::vector<std::uint8_t>& bytes) {
    std::uint64_t h = 14695981039346656037ull;
    for (auto b : bytes) { h ^= b; h *= 1099511628211ull; }
    return h;
}
bool safe_path(const std::string& p) {
    if (p.empty() || p.front()=='/' || p.find('\\')!=std::string::npos || p.find(':')!=std::string::npos) return false;
    fs::path path(p);
    if (path.is_absolute()) return false;
    for (const auto& part : path) if (part == ".." || part == ".") return false;
    return true;
}
bool read_file(const fs::path& path, std::vector<std::uint8_t>& bytes, std::string& error) {
    std::error_code ec;
    const auto size = fs::file_size(path, ec);
    if (ec) { error = "cannot stat asset: " + path.string(); return false; }
    if (size > kMaxAssetBytes) { error = "asset exceeds 64 MiB limit: " + path.string(); return false; }
    std::ifstream in(path, std::ios::binary);
    if (!in) { error = "cannot read asset: " + path.string(); return false; }
    bytes.assign(std::istreambuf_iterator<char>(in), {});
    if (bytes.size() != size) { error = "short read while loading asset: " + path.string(); return false; }
    return true;
}
template<class T> void put_le(std::ostream& out, T value) {
    for (std::size_t i=0;i<sizeof(T);++i) out.put(static_cast<char>((static_cast<std::uint64_t>(value)>>(i*8))&0xff));
}
template<class T> bool get_le(std::istream& in, T& value) {
    std::uint64_t v=0;
    for (std::size_t i=0;i<sizeof(T);++i) { const int c=in.get(); if(c==EOF)return false; v|=static_cast<std::uint64_t>(static_cast<unsigned char>(c))<<(i*8); }
    value=static_cast<T>(v); return true;
}
float dot(Vec3 a, Vec3 b) { return a.x*b.x+a.y*b.y+a.z*b.z; }
Vec3 normalized(Vec3 v) { const float n=std::sqrt(dot(v,v)); if(n<=1e-8f)return {0,1,0}; return {v.x/n,v.y/n,v.z/n}; }
float clamp01(float x) { return std::clamp(x,0.0f,1.0f); }
std::uint8_t to_channel(float x) { return static_cast<std::uint8_t>(std::lround(clamp01(x)*255.0f)); }
bool finite(Vec3 v) { return std::isfinite(v.x)&&std::isfinite(v.y)&&std::isfinite(v.z); }
}

Result build_asset_catalog(const std::string& project_file, const ProjectConfig& project, AssetCatalog& out) {
    const fs::path project_dir=fs::absolute(fs::path(project_file)).parent_path();
    if (!safe_path(project.asset_root)) return {false,"unsafe asset root"};
    const fs::path root=(project_dir/project.asset_root).lexically_normal();
    std::error_code ec;
    if (!fs::exists(root,ec)) { out={}; return {true,"asset directory is empty or not present"}; }
    if (ec || fs::is_symlink(fs::symlink_status(root,ec))) return {false,"asset root cannot be a symbolic link"};
    if (ec || !fs::is_directory(root,ec)) return {false,"asset root is not a directory"};
    AssetCatalog candidate;
    for (fs::recursive_directory_iterator it(root,fs::directory_options::none,ec), end; it!=end && !ec; it.increment(ec)) {
        const auto status=it->symlink_status(ec);
        if (ec) break;
        if (fs::is_symlink(status)) return {false,"symbolic links are not allowed in packaged assets"};
        if (fs::is_directory(status)) continue;
        if (!fs::is_regular_file(status)) return {false,"asset tree contains a non-regular file"};
        const auto rel=fs::relative(it->path(),project_dir,ec).generic_string();
        if (ec || !safe_path(rel)) return {false,"asset path escapes project root"};
        std::vector<std::uint8_t> data; std::string error;
        if (!read_file(it->path(),data,error)) return {false,error};
        if (candidate.total_bytes > kMaxPackageBytes-data.size()) return {false,"total asset payload exceeds 256 MiB limit"};
        candidate.total_bytes+=data.size();
        candidate.entries.push_back({rel,static_cast<std::uint64_t>(data.size()),hash_bytes(data)});
        if (candidate.entries.size()>kMaxFiles) return {false,"asset count exceeds 10000 files"};
    }
    if (ec) return {false,"failed while scanning asset tree: "+ec.message()};
    std::sort(candidate.entries.begin(),candidate.entries.end(),[](const auto& a,const auto& b){return a.relative_path<b.relative_path;});
    out=std::move(candidate);
    return {true,"asset catalog built"};
}

Result build_package(const std::string& project_file, const std::string& output_file, PackageReport& report) {
    ProjectConfig project; auto loaded=load_project(project_file,project); if(!loaded.ok)return loaded;
    AssetCatalog catalog; auto scanned=build_asset_catalog(project_file,project,catalog); if(!scanned.ok)return scanned;
    const fs::path project_dir=fs::absolute(fs::path(project_file)).parent_path();
    const fs::path output_abs=fs::absolute(output_file).lexically_normal();
    if (output_abs==fs::absolute(fs::path(project_file)).lexically_normal()) return {false,"package output cannot overwrite the project manifest"};
    const fs::path asset_abs=(project_dir/project.asset_root).lexically_normal();
    const auto output_under_assets=output_abs.lexically_relative(asset_abs);
    if (!output_under_assets.empty() && *output_under_assets.begin()!="..") return {false,"package output must be outside the asset directory"};
    std::ofstream out(output_abs,std::ios::binary|std::ios::trunc);
    if(!out)return {false,"cannot create VPAK output: "+output_file};
    out.write("VPAK",4); put_le<std::uint32_t>(out,1); put_le<std::uint32_t>(out,static_cast<std::uint32_t>(catalog.entries.size()+1));
    std::uint64_t total=0;
    {
        std::vector<std::uint8_t> meta; std::string error;
        if(!read_file(fs::absolute(fs::path(project_file)),meta,error)) return {false,error};
        const std::string meta_name="__meta__/"+fs::path(project_file).filename().generic_string();
        put_le<std::uint16_t>(out,static_cast<std::uint16_t>(meta_name.size())); put_le<std::uint64_t>(out,static_cast<std::uint64_t>(meta.size())); put_le<std::uint64_t>(out,hash_bytes(meta));
        out.write(meta_name.data(),static_cast<std::streamsize>(meta_name.size())); if(!meta.empty()) out.write(reinterpret_cast<const char*>(meta.data()),static_cast<std::streamsize>(meta.size()));
        if(!out) return {false,"failed writing VPAK project manifest"};
        total+=meta.size();
    }
    for(const auto& entry:catalog.entries) {
        if(entry.relative_path.size()>65535)return {false,"asset path exceeds 65535 bytes"};
        std::vector<std::uint8_t> data; std::string error;
        if(!read_file(project_dir/entry.relative_path,data,error))return {false,error};
        put_le<std::uint16_t>(out,static_cast<std::uint16_t>(entry.relative_path.size()));
        put_le<std::uint64_t>(out,static_cast<std::uint64_t>(data.size()));
        put_le<std::uint64_t>(out,hash_bytes(data));
        out.write(entry.relative_path.data(),static_cast<std::streamsize>(entry.relative_path.size()));
        if(!data.empty())out.write(reinterpret_cast<const char*>(data.data()),static_cast<std::streamsize>(data.size()));
        if(!out)return {false,"failed writing VPAK entry"};
        total+=data.size();
    }
    out.flush(); if(!out)return {false,"failed flushing VPAK output"};
    report={1,static_cast<std::uint32_t>(catalog.entries.size()+1),total};
    return {true,"VPAK package created"};
}

Result verify_package(const std::string& package_file, PackageReport& report) {
    std::ifstream in(package_file,std::ios::binary); if(!in)return {false,"cannot open VPAK package"};
    char magic[4]{}; in.read(magic,4); if(in.gcount()!=4||std::string(magic,4)!="VPAK")return {false,"invalid VPAK magic"};
    std::uint32_t version=0,count=0; if(!get_le(in,version)||!get_le(in,count))return {false,"truncated VPAK header"};
    if(version!=1)return {false,"unsupported VPAK version"};
    if(count>kMaxFiles)return {false,"VPAK entry count exceeds limit"};
    std::unordered_set<std::string> names; std::uint64_t total=0;
    for(std::uint32_t i=0;i<count;++i) {
        std::uint16_t path_len=0; std::uint64_t size=0,hash=0;
        if(!get_le(in,path_len)||!get_le(in,size)||!get_le(in,hash))return {false,"truncated VPAK entry header"};
        if(path_len==0||path_len>4096||size>kMaxAssetBytes||total>kMaxPackageBytes-size)return {false,"invalid VPAK entry bounds"};
        std::string path(path_len,'\0'); in.read(path.data(),path_len); if(!in)return {false,"truncated VPAK path"};
        if(!safe_path(path)||!names.insert(path).second)return {false,"unsafe or duplicate VPAK path"};
        std::vector<std::uint8_t> data(static_cast<std::size_t>(size)); if(size)in.read(reinterpret_cast<char*>(data.data()),static_cast<std::streamsize>(size));
        if(!in)return {false,"truncated VPAK payload"};
        if(hash_bytes(data)!=hash)return {false,"VPAK checksum mismatch: "+path};
        total+=size;
    }
    if(in.peek()!=EOF)return {false,"trailing bytes after VPAK entries"};
    report={version,count,total}; return {true,"VPAK package verified"};
}

Result load_scene(const std::string& scene_file, Scene& out) {
    std::ifstream in(scene_file); if(!in)return {false,"cannot open scene file: "+scene_file};
    std::string line; std::size_t line_no=0; bool header=false; Scene candidate;
    while(std::getline(in,line)) {
        ++line_no; const auto first=line.find_first_not_of(" \t\r"); if(first==std::string::npos||line[first]=='#')continue; line=line.substr(first);
        if(!header){if(line!="VSCENE 1")return {false,"line "+std::to_string(line_no)+": expected VSCENE 1"};header=true;continue;}
        std::istringstream row(line); std::string keyword; SceneNode node; std::string parent;
        if(!(row>>keyword)||keyword!="node"||!(row>>node.id>>parent>>node.position.x>>node.position.y>>node.position.z>>node.scale.x>>node.scale.y>>node.scale.z>>node.width>>node.height))return {false,"line "+std::to_string(line_no)+": expected node id parent px py pz sx sy sz width height r g b"};
        int r=0,g=0,b=0;std::string extra;if(!(row>>r>>g>>b)||(row>>extra))return {false,"line "+std::to_string(line_no)+": expected exactly three color channels"};
        if(r<0||r>255||g<0||g>255||b<0||b>255)return {false,"line "+std::to_string(line_no)+": color channels must be 0..255"};
        node.parent=parent=="-"?"":parent;node.color={static_cast<std::uint8_t>(r),static_cast<std::uint8_t>(g),static_cast<std::uint8_t>(b)};candidate.nodes.push_back(std::move(node));
        if(candidate.nodes.size()>100000)return {false,"scene exceeds 100000 nodes"};
    }
    if(!header)return {false,"empty scene file"};
    auto checked=validate_scene(candidate);if(!checked.ok)return checked;out=std::move(candidate);return {true,"scene loaded and validated"};
}

Result compile_shader_file(const std::string& source_file,const std::string& material_file) {
    std::ifstream in(source_file);if(!in)return {false,"cannot open shader source"};std::ostringstream text;text<<in.rdbuf();ShaderProgram shader;auto compiled=compile_shader(text.str(),shader);if(!compiled.ok)return compiled;
    if(shader.name.size()>65535)return {false,"shader name too long"};
    std::ofstream out(material_file,std::ios::binary|std::ios::trunc);if(!out)return {false,"cannot create material output"};
    out.write("VSM1",4);put_le<std::uint32_t>(out,1);put_le<std::uint16_t>(out,static_cast<std::uint16_t>(shader.name.size()));out.write(shader.name.data(),static_cast<std::streamsize>(shader.name.size()));out.put(shader.model=="lambert"?1:0);
    for(float v:shader.base_color)put_le<std::uint32_t>(out,static_cast<std::uint32_t>(std::bit_cast<std::uint32_t>(v)));
    put_le<std::uint32_t>(out,std::bit_cast<std::uint32_t>(shader.roughness));put_le<std::uint32_t>(out,std::bit_cast<std::uint32_t>(shader.metallic));put_le<std::uint32_t>(out,std::bit_cast<std::uint32_t>(shader.emission));out.flush();if(!out)return {false,"failed writing compiled material"};return {true,"VSM1 material compiled"};
}
Result verify_material_file(const std::string& material_file) {
    std::ifstream in(material_file,std::ios::binary);if(!in)return {false,"cannot open material file"};char magic[4]{};in.read(magic,4);if(in.gcount()!=4||std::string(magic,4)!="VSM1")return {false,"invalid VSM1 material magic"};
    std::uint32_t version=0;std::uint16_t name_len=0;if(!get_le(in,version)||!get_le(in,name_len)||version!=1||name_len==0||name_len>4096)return {false,"invalid VSM1 header"};std::string name(name_len,'\0');in.read(name.data(),name_len);const int model=in.get();if(!in||name.empty()||(model!=0&&model!=1))return {false,"invalid VSM1 material metadata"};
    for(int i=0;i<6;++i){std::uint32_t bits=0;if(!get_le(in,bits))return {false,"truncated VSM1 parameters"};const float v=std::bit_cast<float>(bits);if(!std::isfinite(v))return {false,"non-finite VSM1 parameter"};if(i<3&&(v<0||v>1))return {false,"invalid VSM1 base color"};if((i==3||i==4)&&(v<0||v>1))return {false,"invalid VSM1 roughness or metallic"};if(i==5&&(v<0||v>16))return {false,"invalid VSM1 emission"};}
    if(in.peek()!=EOF)return {false,"trailing bytes in VSM1 material"};
    return {true,"VSM1 material verified"};
}

Result compile_shader(const std::string& source, ShaderProgram& out) {
    std::istringstream input(source); std::string line; bool header=false; ShaderProgram candidate; std::unordered_set<std::string> keys; std::size_t line_no=0;
    while(std::getline(input,line)) {
        ++line_no; auto first=line.find_first_not_of(" \t\r"); if(first==std::string::npos||line[first]=='#')continue; line=line.substr(first);
        if(!header){if(line!="VSHADER 1")return {false,"line "+std::to_string(line_no)+": expected VSHADER 1"};header=true;continue;}
        const auto eq=line.find('=');if(eq==std::string::npos)return {false,"line "+std::to_string(line_no)+": expected key = value"};
        auto key=line.substr(0,eq), value=line.substr(eq+1); auto trim=[](std::string s){const auto a=s.find_first_not_of(" \t\r\n");if(a==std::string::npos)return std::string{};return s.substr(a,s.find_last_not_of(" \t\r\n")-a+1);}; key=trim(key);value=trim(value);
        if(!keys.insert(key).second)return {false,"duplicate shader property: "+key};
        try {
            if(key=="name")candidate.name=value;
            else if(key=="model"){if(value!="lambert"&&value!="unlit")return {false,"model must be lambert or unlit"};candidate.model=value;}
            else if(key=="base_color") {std::replace(value.begin(),value.end(),',',' ');std::istringstream vals(value);if(!(vals>>candidate.base_color[0]>>candidate.base_color[1]>>candidate.base_color[2]))return {false,"base_color expects three numbers"};std::string extra;if(vals>>extra)return {false,"base_color has too many values"};}
            else if(key=="roughness") {std::size_t used=0;candidate.roughness=std::stof(value,&used);if(used!=value.size())return {false,"invalid roughness"};}
            else if(key=="metallic") {std::size_t used=0;candidate.metallic=std::stof(value,&used);if(used!=value.size())return {false,"invalid metallic"};}
            else if(key=="emission") {std::size_t used=0;candidate.emission=std::stof(value,&used);if(used!=value.size())return {false,"invalid emission"};}
            else return {false,"unknown shader property: "+key};
        } catch(...) { return {false,"invalid numeric value for shader property: "+key}; }
    }
    if(!header||candidate.name.empty())return {false,"shader header and name are required"};
    for(float c:candidate.base_color)if(!std::isfinite(c)||c<0||c>1)return {false,"base_color channels must be within [0,1]"};
    if(!std::isfinite(candidate.roughness)||candidate.roughness<0||candidate.roughness>1)return {false,"roughness must be within [0,1]"};
    if(!std::isfinite(candidate.metallic)||candidate.metallic<0||candidate.metallic>1)return {false,"metallic must be within [0,1]"};
    if(!std::isfinite(candidate.emission)||candidate.emission<0||candidate.emission>16)return {false,"emission must be within [0,16]"};
    out=std::move(candidate);return {true,"VLOT shader compiled to CPU material program"};
}
Color shade_fragment(const ShaderProgram& s, Vec3 normal, Vec3 light_direction, float ambient) {
    const float diffuse=s.model=="unlit"?1.0f:std::max(0.0f,dot(normalized(normal),normalized(light_direction)));
    const float light=std::clamp((s.model=="unlit"?1.0f:clamp01(ambient)+(1.0f-clamp01(ambient))*diffuse)*(1.0f-s.metallic*0.15f)+s.emission,0.0f,16.0f);
    return {to_channel(s.base_color[0]*light),to_channel(s.base_color[1]*light),to_channel(s.base_color[2]*light)};
}
void draw_shaded_triangle(SoftwareRenderer& renderer, Vertex a, Vertex b, Vertex c, const ShaderProgram& shader, Vec3 normal, Vec3 light_direction) {
    const auto color=shade_fragment(shader,normal,light_direction); a.color=color; b.color=color; c.color=color; renderer.triangle(a,b,c);
}
Result render_scene_2d(const Scene& scene, SoftwareRenderer& renderer) {
    std::vector<WorldTransform> transforms; auto result=resolve_world_transforms(scene,transforms); if(!result.ok)return result;
    std::unordered_map<std::string,const SceneNode*> nodes; for(const auto& node:scene.nodes)nodes.emplace(node.id,&node);
    for(const auto& world:transforms){const auto& node=*nodes.at(world.id);renderer.rectangle(world.transform.position.x,world.transform.position.y,node.width*world.transform.scale.x,node.height*world.transform.scale.y,world.transform.position.z,node.color);}
    return {true,"scene rendered by VLOT software renderer"};
}

Result resolve_world_transforms(const Scene& scene,std::vector<WorldTransform>& out) {
    auto valid=validate_scene(scene);if(!valid.ok)return valid;
    std::unordered_map<std::string,const SceneNode*> nodes;for(const auto& n:scene.nodes)nodes.emplace(n.id,&n);
    std::unordered_map<std::string,Transform3> resolved;
    std::function<Transform3(const SceneNode&)> visit=[&](const SceneNode& n)->Transform3 {
        const auto found=resolved.find(n.id);if(found!=resolved.end())return found->second;
        Transform3 t{n.position,n.scale};
        if(!n.parent.empty()){const auto parent=visit(*nodes.at(n.parent));t.position={parent.position.x+n.position.x*parent.scale.x,parent.position.y+n.position.y*parent.scale.y,parent.position.z+n.position.z*parent.scale.z};t.scale={parent.scale.x*n.scale.x,parent.scale.y*n.scale.y,parent.scale.z*n.scale.z};}
        resolved.emplace(n.id,t);return t;
    };
    std::vector<WorldTransform> result;result.reserve(scene.nodes.size());for(const auto& n:scene.nodes)result.push_back({n.id,visit(n)});out=std::move(result);return {true,"world transforms resolved"};
}

Result validate_physics_world(const PhysicsWorld& world) {
    if(!finite(world.gravity))return {false,"gravity must be finite"};
    if(world.bodies.size()>10000)return {false,"physics body count exceeds 10000"};
    std::unordered_set<std::string> ids;
    for(const auto& b:world.bodies){if(b.id.empty()||!ids.insert(b.id).second)return {false,"physics body IDs must be non-empty and unique"};if(!finite(b.position)||!finite(b.velocity)||!finite(b.half_extent))return {false,"body contains non-finite values: "+b.id};if(b.half_extent.x<=0||b.half_extent.y<=0||b.half_extent.z<=0)return {false,"body half extents must be positive: "+b.id};if(!std::isfinite(b.mass)||b.mass<=0||!std::isfinite(b.restitution)||b.restitution<0||b.restitution>1)return {false,"invalid mass or restitution: "+b.id};}
    return {true,"physics world valid"};
}
Result step_physics(PhysicsWorld& world,float dt,unsigned substeps) {
    auto valid=validate_physics_world(world);if(!valid.ok)return valid;if(!std::isfinite(dt)||dt<=0||dt>0.25f||substeps==0||substeps>64)return {false,"delta time must be in (0,0.25] and substeps in [1,64]"};
    const float step=dt/static_cast<float>(substeps);
    for(unsigned s=0;s<substeps;++s){
        for(auto& b:world.bodies)if(!b.is_static){b.velocity.x+=world.gravity.x*step;b.velocity.y+=world.gravity.y*step;b.velocity.z+=world.gravity.z*step;b.position.x+=b.velocity.x*step;b.position.y+=b.velocity.y*step;b.position.z+=b.velocity.z*step;}
        for(std::size_t i=0;i<world.bodies.size();++i)for(std::size_t j=i+1;j<world.bodies.size();++j){auto& a=world.bodies[i];auto& b=world.bodies[j];if(a.is_static&&b.is_static)continue;
            const float px=a.half_extent.x+b.half_extent.x-std::abs(a.position.x-b.position.x),py=a.half_extent.y+b.half_extent.y-std::abs(a.position.y-b.position.y),pz=a.half_extent.z+b.half_extent.z-std::abs(a.position.z-b.position.z);
            if(px<=0||py<=0||pz<=0)continue;
            const float ia=a.is_static?0.0f:1.0f/a.mass,ib=b.is_static?0.0f:1.0f/b.mass,inv=ia+ib;if(inv<=0)continue;
            Vec3 normal{};float penetration=px;if(py<penetration){penetration=py;normal={0,1,0};}else normal={1,0,0};if(pz<penetration){penetration=pz;normal={0,0,1};}
            const float sign=(normal.x!=0?(a.position.x<=b.position.x?-1.0f:1.0f):normal.y!=0?(a.position.y<=b.position.y?-1.0f:1.0f):(a.position.z<=b.position.z?-1.0f:1.0f));normal={normal.x*sign,normal.y*sign,normal.z*sign};
            const float correction=std::max(penetration-0.001f,0.0f)*0.8f/inv;
            if(!a.is_static){a.position.x+=normal.x*correction*ia;a.position.y+=normal.y*correction*ia;a.position.z+=normal.z*correction*ia;}
            if(!b.is_static){b.position.x-=normal.x*correction*ib;b.position.y-=normal.y*correction*ib;b.position.z-=normal.z*correction*ib;}
            const Vec3 rv{b.velocity.x-a.velocity.x,b.velocity.y-a.velocity.y,b.velocity.z-a.velocity.z};const float along=dot(rv,normal);if(along<0){const float e=std::min(a.restitution,b.restitution);const float impulse=-(1+e)*along/inv;if(!a.is_static){a.velocity.x-=normal.x*impulse*ia;a.velocity.y-=normal.y*impulse*ia;a.velocity.z-=normal.z*impulse*ia;}if(!b.is_static){b.velocity.x+=normal.x*impulse*ib;b.velocity.y+=normal.y*impulse*ib;b.velocity.z+=normal.z*impulse*ib;}}
        }
    }
    return {true,"physics step completed"};
}

} // namespace docmont::vlot
