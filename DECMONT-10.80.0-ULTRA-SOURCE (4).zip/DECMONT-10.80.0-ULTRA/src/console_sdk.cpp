#include "docmont/console_sdk.hpp"
#include <filesystem>
#include <fstream>
#include <map>
#include <string_view>
#if !defined(_WIN32)
#include <unistd.h>
#endif
namespace docmont::platform {
namespace fs=std::filesystem;
namespace {
std::string trim(std::string s){auto a=s.find_first_not_of(" \t\r\n");if(a==std::string::npos)return{};auto b=s.find_last_not_of(" \t\r\n");return s.substr(a,b-a+1);}
bool inside(const fs::path& child,const fs::path& root){auto c=fs::weakly_canonical(child),r=fs::weakly_canonical(root);auto ci=c.begin(),ri=r.begin();for(;ri!=r.end();++ri,++ci)if(ci==c.end()||*ci!=*ri)return false;return true;}
bool executable(const fs::path& p){if(!fs::is_regular_file(p))return false;
#if defined(_WIN32)
return p.extension()==".exe";
#else
return ::access(p.c_str(),X_OK)==0;
#endif
}
}
std::string to_string(ConsolePlatform p){return p==ConsolePlatform::PlayStation5?"playstation5":"xbox-series";}
ConsoleSdkProbe probe_console_sdk(ConsolePlatform p,const std::string& manifest){
    ConsoleSdkProbe out;out.platform=p;if(manifest.empty()){out.detail="No official SDK manifest supplied. Install the vendor SDK and pass its adapter manifest.";return out;}
    std::ifstream f(manifest);if(!f){out.detail="SDK manifest cannot be opened";return out;}out.manifest_found=true;
    std::map<std::string,std::string> kv;std::string line;while(std::getline(f,line)){line=trim(line);if(line.empty()||line[0]=='#')continue;auto at=line.find('=');if(at==std::string::npos)continue;kv[trim(line.substr(0,at))]=trim(line.substr(at+1));}
    const auto root_it=kv.find("sdk_root");if(root_it==kv.end()){out.detail="manifest requires sdk_root";return out;}fs::path root=root_it->second;
    out.sdk_root_found=fs::is_directory(root);if(!out.sdk_root_found){out.detail="official SDK root does not exist";return out;}
    const auto platform_it=kv.find("platform");if(platform_it==kv.end()||platform_it->second!=to_string(p)){out.detail="manifest platform identifier does not match requested target";return out;}
    if(auto i=kv.find("sdk_version");i!=kv.end())out.sdk_version=i->second;
    if(auto i=kv.find("license_acknowledged");i!=kv.end())out.license_acknowledged=(i->second=="true");
    auto resolve=[&](const char* key)->fs::path{auto i=kv.find(key);if(i==kv.end())return{};fs::path x=i->second;if(x.is_relative())x=root/x;return x;};
    const auto compiler=resolve("compiler"),cmake=resolve("cmake_toolchain"),headers=resolve("include_dir");
    out.compiler_found=!compiler.empty()&&inside(compiler,root)&&executable(compiler);
    out.cmake_toolchain_found=!cmake.empty()&&inside(cmake,root)&&fs::is_regular_file(cmake);
    out.headers_found=!headers.empty()&&inside(headers,root)&&fs::is_directory(headers);
    out.adapter_configured=out.sdk_root_found&&out.compiler_found&&out.cmake_toolchain_found&&out.headers_found&&out.license_acknowledged;
    if(out.adapter_configured)out.detail="SDK adapter manifest is structurally complete. This is not vendor certification: build, devkit and platform validation must still be performed with the licensed official toolchain.";
    else out.detail="SDK manifest is incomplete, paths escape SDK root, compiler is not executable, or license acknowledgement is missing.";
    return out;
}
} // namespace docmont::platform
