#include "docmont/gpu_runtime.hpp"
#include "gpu_backend_internal.hpp"
#include <array>
#include <cstring>
#include <string>
#if defined(_WIN32)
#include <windows.h>
#else
#include <dlfcn.h>
#endif

namespace docmont::gpu {
namespace {
using U32=std::uint32_t; using Flags=U32; using Result=std::int32_t;
struct Instance_T; struct PhysicalDevice_T; struct Device_T;
using Instance=Instance_T*; using PhysicalDevice=PhysicalDevice_T*; using Device=Device_T*;
struct ApplicationInfo {U32 sType;const void* pNext;const char* app;U32 appVersion;const char* engine;U32 engineVersion;U32 apiVersion;};
struct InstanceCreateInfo {U32 sType;const void* pNext;Flags flags;const ApplicationInfo* app;U32 layerCount;const char* const* layers;U32 extensionCount;const char* const* extensions;};
struct Extent3D {U32 width,height,depth;};
struct QueueFamilyProperties {Flags queueFlags;U32 queueCount;U32 timestampValidBits;Extent3D minImageTransferGranularity;};
struct DeviceQueueCreateInfo {U32 sType;const void* pNext;Flags flags;U32 queueFamilyIndex;U32 queueCount;const float* priorities;};
struct DeviceCreateInfo {U32 sType;const void* pNext;Flags flags;U32 queueInfoCount;const DeviceQueueCreateInfo* queueInfos;U32 layerCount;const char* const* layers;U32 extensionCount;const char* const* extensions;const void* features;};
constexpr U32 ST_APPLICATION_INFO=0,ST_INSTANCE_CREATE=1,ST_DEVICE_QUEUE_CREATE=2,ST_DEVICE_CREATE=3;
constexpr Flags QUEUE_GRAPHICS=0x1,QUEUE_COMPUTE=0x2;
constexpr Result SUCCESS=0;
#if defined(_WIN32)
struct Library {HMODULE h{};void* symbol(const char*n){return reinterpret_cast<void*>(GetProcAddress(h,n));}~Library(){if(h)FreeLibrary(h);}};
#else
struct Library {void* h{};void* symbol(const char*n){return dlsym(h,n);}~Library(){if(h)dlclose(h);}};
#endif
template<class T>T load(Library& l,const char* n){return reinterpret_cast<T>(l.symbol(n));}
}
BackendStatus probe_vulkan(){
    BackendStatus s;s.backend=Backend::Vulkan;
    Library lib;
#if defined(_WIN32)
    lib.h=LoadLibraryA("vulkan-1.dll");
#elif defined(__APPLE__)
    lib.h=dlopen("libvulkan.1.dylib",RTLD_NOW|RTLD_LOCAL);
#else
    lib.h=dlopen("libvulkan.so.1",RTLD_NOW|RTLD_LOCAL);
#endif
    if(!lib.h){s.availability=Availability::MissingRuntime;s.detail="Vulkan loader library not found";return s;}
    s.runtime_present=true;
    using EnumerateVersion=Result(*)(U32*);
    using CreateInstance=Result(*)(const InstanceCreateInfo*,const void*,Instance*);
    using EnumeratePhysical=Result(*)(Instance,U32*,PhysicalDevice*);
    using DestroyInstance=void(*)(Instance,const void*);
    using GetQueueProps=void(*)(PhysicalDevice,U32*,QueueFamilyProperties*);
    using CreateDevice=Result(*)(PhysicalDevice,const DeviceCreateInfo*,const void*,Device*);
    using DestroyDevice=void(*)(Device,const void*);
    using GetDeviceQueue=void(*)(Device,U32,U32,void**);
    auto version=load<EnumerateVersion>(lib,"vkEnumerateInstanceVersion");
    auto create=load<CreateInstance>(lib,"vkCreateInstance");
    auto enumerate=load<EnumeratePhysical>(lib,"vkEnumeratePhysicalDevices");
    auto destroy=load<DestroyInstance>(lib,"vkDestroyInstance");
    auto qprops=load<GetQueueProps>(lib,"vkGetPhysicalDeviceQueueFamilyProperties");
    auto createDevice=load<CreateDevice>(lib,"vkCreateDevice");
    auto destroyDevice=load<DestroyDevice>(lib,"vkDestroyDevice");
    auto getQueue=load<GetDeviceQueue>(lib,"vkGetDeviceQueue");
    if(!create||!enumerate||!destroy||!qprops||!createDevice||!destroyDevice||!getQueue){s.availability=Availability::InitializationFailed;s.detail="Vulkan loader is missing required entry points";return s;}
    if(version){U32 v=0;if(version(&v)==SUCCESS)s.api_version=v;}
    ApplicationInfo app{ST_APPLICATION_INFO,nullptr,"DOCMONT ULTRA",1,"DOCMONT GPU Runtime",1,s.api_version?s.api_version:((1u<<22)|(0u<<12))};
    InstanceCreateInfo ci{ST_INSTANCE_CREATE,nullptr,0,&app,0,nullptr,0,nullptr};Instance instance=nullptr;
    const Result cr=create(&ci,nullptr,&instance);
    if(cr!=SUCCESS||!instance){s.availability=Availability::LoaderOnly;s.detail="Vulkan loader exists but instance creation failed (no compatible ICD/driver may be installed); result="+std::to_string(cr);return s;}
    U32 count=0;Result er=enumerate(instance,&count,nullptr);
    if(er!=SUCCESS){destroy(instance,nullptr);s.availability=Availability::InitializationFailed;s.detail="vkEnumeratePhysicalDevices failed: "+std::to_string(er);return s;}
    s.device_count=count;
    if(count==0){destroy(instance,nullptr);s.availability=Availability::NoDevice;s.detail="Vulkan instance created, but no physical GPU device was exposed by an installed ICD";return s;}
    std::vector<PhysicalDevice> devices(count);er=enumerate(instance,&count,devices.data());
    if(er!=SUCCESS){destroy(instance,nullptr);s.availability=Availability::InitializationFailed;s.detail="physical device enumeration failed";return s;}
    bool logical=false,queue=false;
    for(auto physical:devices){U32 qc=0;qprops(physical,&qc,nullptr);if(!qc)continue;std::vector<QueueFamilyProperties> props(qc);qprops(physical,&qc,props.data());
        for(U32 i=0;i<qc;++i)if(props[i].queueCount&&(props[i].queueFlags&(QUEUE_GRAPHICS|QUEUE_COMPUTE))){const float priority=1.0f;DeviceQueueCreateInfo qi{ST_DEVICE_QUEUE_CREATE,nullptr,0,i,1,&priority};DeviceCreateInfo di{ST_DEVICE_CREATE,nullptr,0,1,&qi,0,nullptr,0,nullptr,nullptr};Device d=nullptr;
            if(createDevice(physical,&di,nullptr,&d)==SUCCESS&&d){logical=true;void* q=nullptr;getQueue(d,i,0,&q);queue=q!=nullptr;destroyDevice(d,nullptr);break;}}
        if(logical)break;
    }
    destroy(instance,nullptr);s.device_available=true;s.queue_available=queue;
    if(logical&&queue){s.availability=Availability::Ready;s.detail="Vulkan instance, physical device, logical device and graphics/compute queue initialized";}
    else{s.availability=Availability::InitializationFailed;s.detail="Vulkan physical device found but logical device/queue initialization failed";}
    return s;
}
BackendStatus probe_direct3d12(){return probe_d3d12_native();}
BackendStatus probe_metal(){return probe_metal_native();}
GpuProbeReport probe_all_backends(){GpuProbeReport r;r.backends={probe_vulkan(),probe_direct3d12(),probe_metal()};BackendStatus cpu;cpu.backend=Backend::Cpu;cpu.runtime_present=true;cpu.device_available=true;cpu.queue_available=true;cpu.availability=Availability::Ready;cpu.detail="CPU software fallback available";r.backends.push_back(cpu);return r;}
std::string to_string(Backend b){switch(b){case Backend::Vulkan:return"Vulkan";case Backend::Direct3D12:return"Direct3D12";case Backend::Metal:return"Metal";case Backend::Cpu:return"CPU";}return"unknown";}
std::string to_string(Availability a){switch(a){case Availability::Ready:return"ready";case Availability::LoaderOnly:return"loader-only";case Availability::UnsupportedPlatform:return"unsupported-platform";case Availability::MissingRuntime:return"missing-runtime";case Availability::NoDevice:return"no-device";case Availability::InitializationFailed:return"initialization-failed";}return"unknown";}
} // namespace docmont::gpu
