#include "docmont/package_manager.hpp"
#include <algorithm>
#include <cctype>
#include <fstream>
#include <functional>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>

namespace docmont::dpm {
namespace {
std::string trim(std::string s){auto a=s.find_first_not_of(" \t\r");if(a==s.npos)return {};auto b=s.find_last_not_of(" \t\r");return s.substr(a,b-a+1);}
bool valid_name(const std::string& s){if(s.empty()||!(std::isalpha(static_cast<unsigned char>(s[0]))||s[0]=='_'))return false;return std::all_of(s.begin()+1,s.end(),[](unsigned char c){return std::isalnum(c)||c=='_'||c=='-'||c=='.';});}
bool valid_version(const std::string& s){int parts=0;std::size_t begin=0;while(begin<s.size()){auto end=s.find('.',begin);if(end==std::string::npos)end=s.size();if(end==begin)return false;for(auto i=begin;i<end;++i)if(!std::isdigit(static_cast<unsigned char>(s[i])))return false;++parts;begin=end+1;}return parts==3;}
std::string unquote(const std::string& s){if(s.size()<2||s.front()!='"'||s.back()!='"')return {};return s.substr(1,s.size()-2);}
std::string fingerprint(const std::string& text){std::uint64_t hash=14695981039346656037ull;for(unsigned char c:text){hash^=c;hash*=1099511628211ull;}std::ostringstream out;out<<"fnv1a64:"<<std::hex<<std::setfill('0')<<std::setw(16)<<hash;return out.str();}
bool within(const std::filesystem::path& root,const std::filesystem::path& path){auto r=root.generic_string(),p=path.generic_string();return p==r||(p.size()>r.size()&&p.compare(0,r.size(),r)==0&&p[r.size()]=='/');}
std::filesystem::path manifest_for(std::filesystem::path path){std::error_code ec;if(std::filesystem::is_directory(path,ec))return path/"docmont.dpm";return path;}
}
LoadResult load_manifest(const std::filesystem::path& path){
 LoadResult result;std::ifstream in(path,std::ios::binary);if(!in){result.diagnostics.push_back({"DPM001","cannot open manifest",0});return result;}
 std::string section,line,raw;std::set<std::string> dependency_names;std::size_t number=0;
 while(std::getline(in,line)){
  ++number;raw+=line;raw+='\n';auto s=trim(line);if(s.empty()||s[0]=='#')continue;
  if(s.front()=='['&&s.back()==']'){section=trim(s.substr(1,s.size()-2));if(section!="package"&&section!="dependencies")result.diagnostics.push_back({"DPM002","unsupported manifest section: "+section,number});continue;}
  auto eq=s.find('=');if(eq==std::string::npos){result.diagnostics.push_back({"DPM003","expected key = value",number});continue;}
  auto key=trim(s.substr(0,eq)),value=trim(s.substr(eq+1));
  if(section=="package"){
   auto parsed=unquote(value);if(parsed.empty()){result.diagnostics.push_back({"DPM004","package values must be quoted strings",number});continue;}
   if(key=="name")result.manifest.name=parsed;else if(key=="version")result.manifest.version=parsed;else if(key=="edition")result.manifest.edition=parsed;else result.diagnostics.push_back({"DPM005","unknown package key: "+key,number});
  } else if(section=="dependencies") {
   if(!valid_name(key)){result.diagnostics.push_back({"DPM006","dependency name is invalid",number});continue;}
   if(!dependency_names.insert(key).second){result.diagnostics.push_back({"DPM007","duplicate dependency: "+key,number});continue;}
   Dependency dependency;dependency.name=key;
   if(value.size()>=2&&value.front()=='"'&&value.back()=='"') dependency.version=unquote(value);
   else if(value.size()>=2&&value.front()=='{'&&value.back()=='}') {
      auto body=trim(value.substr(1,value.size()-2));auto path_key=body.find("path");auto path_eq=body.find('=',path_key==std::string::npos?0:path_key);
      if(path_key==std::string::npos||path_eq==std::string::npos){result.diagnostics.push_back({"DPM012","path dependency must contain path = \"relative/path\"",number});continue;}
      auto path_end=body.find(',',path_eq+1);auto raw_path=trim(body.substr(path_eq+1,path_end==std::string::npos?std::string::npos:path_end-(path_eq+1)));dependency.path=unquote(raw_path);
      if(dependency.path.empty()||dependency.path.is_absolute()){result.diagnostics.push_back({"DPM013","local dependency path must be a non-empty relative path",number});continue;}
      auto version_key=body.find("version");if(version_key!=std::string::npos){auto version_eq=body.find('=',version_key);if(version_eq!=std::string::npos)dependency.version=unquote(trim(body.substr(version_eq+1)));}
      if(dependency.version.empty())dependency.version="0.0.0";
   } else {result.diagnostics.push_back({"DPM006","dependency must be a version string or { path = \"relative/path\" }",number});continue;}
   if(!valid_version(dependency.version)){result.diagnostics.push_back({"DPM006","dependency version must use major.minor.patch",number});continue;}
   result.manifest.dependencies.push_back(std::move(dependency));
  } else result.diagnostics.push_back({"DPM008","key appears outside a supported section",number});
 }
 if(result.manifest.name.empty()||!valid_name(result.manifest.name))result.diagnostics.push_back({"DPM009","[package].name is required and must be a valid package name",0});
 if(!valid_version(result.manifest.version))result.diagnostics.push_back({"DPM010","[package].version must use major.minor.patch",0});
 if(result.manifest.edition!="2026")result.diagnostics.push_back({"DPM011","only package edition 2026 is supported in this release",0});
 std::sort(result.manifest.dependencies.begin(),result.manifest.dependencies.end(),[](const auto&a,const auto&b){return a.name<b.name;});
 result.source_fingerprint=fingerprint(raw);result.ok=result.diagnostics.empty();return result;
}

ResolveResult resolve_local_dependencies(const std::filesystem::path& root_manifest){
 ResolveResult result;std::error_code ec;const auto root=std::filesystem::weakly_canonical(manifest_for(root_manifest),ec);
 if(ec||!std::filesystem::exists(root)){result.diagnostics.push_back({"DPM020","root manifest does not exist",0});return result;}
 const auto workspace=std::filesystem::weakly_canonical(root.parent_path(),ec);std::map<std::string,int> states;std::map<std::string,ResolvedPackage> resolved;std::map<std::string,std::string> versions;
 std::function<void(const std::filesystem::path&,const Manifest&)> visit;
 visit=[&](const std::filesystem::path& parent,const Manifest& manifest){
   for(const auto& dep:manifest.dependencies){
     if(dep.path.empty()) { continue; } // Registry declarations stay pinned as declarations; no network registry is assumed.
     auto path=std::filesystem::weakly_canonical(parent/dep.path,ec);if(ec){result.diagnostics.push_back({"DPM021","cannot resolve path dependency '"+dep.name+"'",0});ec.clear();continue;}
     path=manifest_for(path);path=std::filesystem::weakly_canonical(path,ec);
     if(ec||!within(workspace,path)){result.diagnostics.push_back({"DPM022","path dependency escapes the workspace or has no manifest: "+dep.name,0});ec.clear();continue;}
     auto loaded=load_manifest(path);if(!loaded.ok){for(auto d:loaded.diagnostics){d.message="dependency '"+dep.name+"': "+d.message;result.diagnostics.push_back(std::move(d));}continue;}
     if(loaded.manifest.name!=dep.name){result.diagnostics.push_back({"DPM023","dependency alias '"+dep.name+"' resolves to package '"+loaded.manifest.name+"'",0});continue;}
     if(!dep.version.empty()&&dep.version!="0.0.0"&&dep.version!=loaded.manifest.version){result.diagnostics.push_back({"DPM024","local dependency version mismatch for '"+dep.name+"'",0});continue;}
     const auto state=states[loaded.manifest.name];
     if(state==1){result.diagnostics.push_back({"DPM025","cyclic package dependency involving '"+loaded.manifest.name+"'",0});continue;}
     if(state==2){if(versions[loaded.manifest.name]!=loaded.manifest.version)result.diagnostics.push_back({"DPM026","conflicting versions for package '"+loaded.manifest.name+"'",0});continue;}
     states[loaded.manifest.name]=1;versions[loaded.manifest.name]=loaded.manifest.version;
     visit(path.parent_path(),loaded.manifest);
     states[loaded.manifest.name]=2;
     resolved.emplace(loaded.manifest.name,ResolvedPackage{loaded.manifest.name,loaded.manifest.version,path,loaded.source_fingerprint});
   }
 };
 auto loaded_root=load_manifest(root);if(!loaded_root.ok){result.diagnostics=loaded_root.diagnostics;return result;}
 states[loaded_root.manifest.name]=1;visit(root.parent_path(),loaded_root.manifest);states[loaded_root.manifest.name]=2;
 for(auto& [name,package]:resolved){(void)name;result.packages.push_back(std::move(package));}
 result.ok=result.diagnostics.empty();return result;
}

std::string render_lockfile(const Manifest& manifest,const std::string& fp){std::ostringstream out;out<<"# DOCMONT DPM lockfile v1 - generated; do not edit\n";out<<"lock-version = 1\n";out<<"root-name = \""<<manifest.name<<"\"\n";out<<"root-version = \""<<manifest.version<<"\"\n";out<<"manifest-fingerprint = \""<<fp<<"\"\n";for(const auto& dep:manifest.dependencies){out<<"\n[[package]]\nname = \""<<dep.name<<"\"\nversion = \""<<dep.version<<"\"\nsource = \""<<(dep.path.empty()?"registry-declaration":"path:"+dep.path.generic_string())<<"\"\n";}return out.str();}
bool write_lockfile(const std::filesystem::path& path,const Manifest& manifest,const std::string& fp,std::string& error){std::ofstream out(path,std::ios::binary|std::ios::trunc);if(!out){error="cannot create lockfile: "+path.string();return false;}out<<render_lockfile(manifest,fp);if(!out){error="failed writing lockfile: "+path.string();return false;}return true;}
std::string render_resolved_lockfile(const Manifest& root,const std::string& fp,const std::vector<ResolvedPackage>& packages){std::ostringstream out;out<<"# DOCMONT DPM lockfile v2 - generated; do not edit\nlock-version = 2\nroot-name = \""<<root.name<<"\"\nroot-version = \""<<root.version<<"\"\nmanifest-fingerprint = \""<<fp<<"\"\n";for(const auto& package:packages)out<<"\n[[package]]\nname = \""<<package.name<<"\"\nversion = \""<<package.version<<"\"\nsource = \"path\"\nmanifest = \""<<package.manifest_path.generic_string()<<"\"\nmanifest-fingerprint = \""<<package.source_fingerprint<<"\"\n";for(const auto& dep:root.dependencies)if(dep.path.empty())out<<"\n[[package]]\nname = \""<<dep.name<<"\"\nversion = \""<<dep.version<<"\"\nsource = \"registry-declaration-unfetched\"\n";return out.str();}
bool write_resolved_lockfile(const std::filesystem::path& path,const Manifest& root,const std::string& fp,const std::vector<ResolvedPackage>& packages,std::string& error){std::ofstream out(path,std::ios::binary|std::ios::trunc);if(!out){error="cannot create lockfile: "+path.string();return false;}out<<render_resolved_lockfile(root,fp,packages);if(!out){error="failed writing lockfile: "+path.string();return false;}return true;}
} // namespace docmont::dpm
