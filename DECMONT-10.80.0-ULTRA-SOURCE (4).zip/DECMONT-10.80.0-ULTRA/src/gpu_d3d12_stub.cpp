#include "gpu_backend_internal.hpp"
namespace docmont::gpu {
BackendStatus probe_d3d12_native(){BackendStatus s;s.backend=Backend::Direct3D12;s.availability=Availability::UnsupportedPlatform;s.detail="Direct3D 12 device probing is available only in a Windows build with the Windows SDK";return s;}
}
