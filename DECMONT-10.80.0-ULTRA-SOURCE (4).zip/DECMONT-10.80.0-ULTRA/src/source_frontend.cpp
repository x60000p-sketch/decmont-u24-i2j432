#include "docmont/source_frontend.hpp"
#include <algorithm>
#include <cctype>
#include <functional>
#include <unordered_map>
#include <unordered_set>

namespace docmont::frontend {
namespace {
std::string compact(std::string value) {
    value.erase(std::remove_if(value.begin(), value.end(), [](unsigned char c){ return std::isspace(c); }), value.end());
    return value;
}
std::vector<std::string> split_args(const std::string& text) {
    std::vector<std::string> out; std::size_t begin=0; int depth=0;
    for (std::size_t i=0;i<text.size();++i) {
        if (text[i]=='<') ++depth;
        else if (text[i]=='>') --depth;
        else if (text[i]==',' && depth==0) { out.push_back(text.substr(begin,i-begin)); begin=i+1; }
    }
    if (begin<text.size()) out.push_back(text.substr(begin));
    return out;
}
core::TypeId lower_type(const std::string& raw, core::TypeContext& types,
                        const std::unordered_set<std::string>& generics,
                        const std::unordered_set<std::string>& enums) {
    const auto name=compact(raw);
    if (name.empty() || name=="Void" || name=="void" || name=="Unit") return types.primitive(core::TypeKind::Unit);
    if (name=="Bool" || name=="bool") return types.primitive(core::TypeKind::Bool);
    if (name=="Int" || name=="i64" || name=="Integer") return types.primitive(core::TypeKind::I64);
    if (name=="i32") return types.primitive(core::TypeKind::I32);
    if (name=="u32") return types.primitive(core::TypeKind::U32);
    if (name=="u64") return types.primitive(core::TypeKind::U64);
    if (name=="f32") return types.primitive(core::TypeKind::F32);
    if (name=="f64" || name=="Number") return types.primitive(core::TypeKind::F64);
    if (name=="String" || name=="string" || name=="utf8") return types.primitive(core::TypeKind::String);
    if (generics.contains(name)) return types.generic_parameter(name);
    if (name.rfind("&mut",0)==0) return types.reference(lower_type(name.substr(4),types,generics,enums),true);
    if (!name.empty() && name.front()=='&') return types.reference(lower_type(name.substr(1),types,generics,enums),false);
    const auto angle=name.find('<');
    if (angle!=std::string::npos && name.back()=='>') {
        const auto base=name.substr(0,angle); const auto args=split_args(name.substr(angle+1,name.size()-angle-2));
        if (base=="Option" && args.size()==1) return types.option(lower_type(args[0],types,generics,enums));
        if (base=="Result" && args.size()==2) return types.result(lower_type(args[0],types,generics,enums),lower_type(args[1],types,generics,enums));
        if (base=="Array" && args.size()==1) return types.array(lower_type(args[0],types,generics,enums),0);
        std::vector<core::TypeId> fields; for(const auto& arg:args) fields.push_back(lower_type(arg,types,generics,enums));
        return types.tuple(std::move(fields));
    }
    if (enums.contains(name)) return types.enumeration(name);
    return types.named(name);
}
core::TypeId infer_expr(const std::shared_ptr<Expr>& expr, core::TypeContext& types,
                        const std::unordered_map<std::string,core::TypeId>& vars,
                        const std::unordered_map<std::string,const FunctionDecl*>& functions,
                        const std::unordered_set<std::string>& enums) {
    using K=core::TypeKind;
    if(!expr) return types.primitive(K::Unit);
    switch(expr->kind) {
      case ExprKind::Integer: return types.primitive(K::I64);
      case ExprKind::Boolean: return types.primitive(K::Bool);
      case ExprKind::String: return types.primitive(K::String);
      case ExprKind::Identifier: { auto it=vars.find(expr->text); return it==vars.end()?types.named("inferred"):it->second; }
      case ExprKind::ArrayLiteral: return types.array(expr->elements.empty()?types.named("inferred"):infer_expr(expr->elements.front(),types,vars,functions,enums),expr->elements.size());
      case ExprKind::ObjectLiteral: return types.named("Object");
      case ExprKind::Unary:
        if(expr->op=="&"||expr->op=="&mut") return types.reference(infer_expr(expr->left,types,vars,functions,enums),expr->op=="&mut");
        return infer_expr(expr->left,types,vars,functions,enums);
      case ExprKind::Binary:
        if(expr->op=="=="||expr->op=="!="||expr->op=="<"||expr->op==">"||expr->op=="<="||expr->op==">="||expr->op=="&&"||expr->op=="||") return types.primitive(K::Bool);
        if(expr->op=="+" && expr->left && expr->left->kind==ExprKind::String) return types.primitive(K::String);
        return types.primitive(K::I64);
      case ExprKind::Member: return types.named("inferred-member");
      case ExprKind::Index: return types.named("inferred-element");
      case ExprKind::Try: {
        const auto wrapped=infer_expr(expr->left,types,vars,functions,enums);
        const auto* wt=types.get(wrapped);
        if(wt && (wt->kind==K::Option||wt->kind==K::Result) && !wt->arguments.empty()) return wt->arguments.front();
        return types.named("inferred-try");
      }
      case ExprKind::Call: {
        const auto split=expr->callee.find("::");
        if(split!=std::string::npos) {
          const auto base=expr->callee.substr(0,split), variant=expr->callee.substr(split+2);
          if(base=="Option") return types.option(expr->elements.empty()?types.primitive(K::Unit):infer_expr(expr->elements.front(),types,vars,functions,enums));
          if(base=="Result") {
             const auto payload=expr->elements.empty()?types.named("inferred"):infer_expr(expr->elements.front(),types,vars,functions,enums);
             return variant=="Ok"?types.result(payload,types.named("inferred-error")):types.result(types.named("inferred-ok"),payload);
          }
          if(enums.contains(base)) return types.enumeration(base);
        }
        auto it=functions.find(expr->callee);
        if(it!=functions.end()) {
           std::unordered_set<std::string> generic_names; for(const auto& gp:it->second->type_parameters)generic_names.insert(gp.name);
           return lower_type(it->second->return_type,types,generic_names,enums);
        }
        return types.named("inferred-call");
      }
      case ExprKind::Lambda: return types.named("closure");
    }
    return types.named("inferred");
}
void collect_locals(const std::vector<Statement>& statements, core::TypeContext& types,
                    std::unordered_map<std::string,core::TypeId>& vars,
                    const std::unordered_map<std::string,const FunctionDecl*>& functions,
                    const std::unordered_set<std::string>& enums,
                    std::vector<core::HIRLocal>& locals) {
    for(const auto& st:statements) {
       if(st.kind==Statement::Kind::Let && !vars.contains(st.name)) {
          auto type=infer_expr(st.expression,types,vars,functions,enums);
          vars.emplace(st.name,type); if(std::none_of(locals.begin(),locals.end(),[&](const auto& local){return local.name==st.name;})) locals.push_back({st.name,type,false});
       } else if(st.kind==Statement::Kind::If || st.kind==Statement::Kind::While || st.kind==Statement::Kind::ForEach) {
          collect_locals(st.body,types,vars,functions,enums,locals);
          collect_locals(st.else_body,types,vars,functions,enums,locals);
       } else if(st.kind==Statement::Kind::Match) {
          for(const auto& arm:st.match_arms) if(arm) {
              auto branch=vars;
              if(!arm->binding.empty()) { auto id=types.named("inferred-pattern-payload"); branch.emplace(arm->binding,id); if(std::none_of(locals.begin(),locals.end(),[&](const auto& local){return local.name==arm->binding;})) locals.push_back({arm->binding,id,false}); }
              collect_locals(arm->body,types,branch,functions,enums,locals);
          }
       }
    }
}
void emit_reads(const std::shared_ptr<Expr>& expr, core::MIRBlock& block,
                const std::unordered_map<std::string,core::TypeId>& vars,
                core::TypeContext& types) {
    if(!expr) return;
    if(expr->kind==ExprKind::Identifier) {
       if(vars.contains(expr->text)) block.operations.push_back({core::MIROpKind::Read,expr->text,{},0,0,0});
       return;
    }
    if(expr->kind==ExprKind::Unary && (expr->op=="move"||expr->op=="&"||expr->op=="&mut") && expr->left && expr->left->kind==ExprKind::Identifier) {
       const auto& place=expr->left->text;
       if(expr->op=="move") block.operations.push_back({core::MIROpKind::Move,place,{},0,0,0});
       else block.operations.push_back({expr->op=="&"?core::MIROpKind::BorrowShared:core::MIROpKind::BorrowMutable,place,"__loan_"+place,0,0,0});
       return;
    }
    emit_reads(expr->left,block,vars,types); emit_reads(expr->right,block,vars,types);
    for(const auto& e:expr->elements)emit_reads(e,block,vars,types);
    for(const auto& p:expr->properties)emit_reads(p.second,block,vars,types);
}
struct NativeIntLowering {
    std::vector<core::MIRValueOperation> operations;
    std::unordered_map<std::string,std::string> variables;
    std::uint64_t next_value{0};
    bool returned{false};
    bool ok{true};
    std::string error;
    std::string temp() { return "%v" + std::to_string(next_value++); }
    std::string expression(const std::shared_ptr<Expr>& expr) {
        if(!expr) { ok=false; error="missing expression"; return {}; }
        if(expr->kind==ExprKind::Integer) {
            try {
                const auto value=std::stoll(expr->text);
                const auto name=temp(); operations.push_back({core::MIRValueOpKind::ConstantI64,name,{}, {},value}); return name;
            } catch(...) { ok=false; error="integer literal is outside signed i64 range"; return {}; }
        }
        if(expr->kind==ExprKind::Identifier) {
            const auto it=variables.find(expr->text);
            if(it==variables.end()) { ok=false; error="unknown native integer local '"+expr->text+"'"; return {}; }
            return it->second;
        }
        if(expr->kind==ExprKind::Unary && expr->op=="-") {
            auto rhs=expression(expr->left); if(!ok)return {};
            const auto zero=temp(); operations.push_back({core::MIRValueOpKind::ConstantI64,zero,{}, {},0});
            const auto name=temp(); operations.push_back({core::MIRValueOpKind::SubI64,name,zero,rhs,0}); return name;
        }
        if(expr->kind==ExprKind::Binary && (expr->op=="+"||expr->op=="-"||expr->op=="*")) {
            auto lhs=expression(expr->left); if(!ok)return {};
            auto rhs=expression(expr->right); if(!ok)return {};
            const auto name=temp();
            const auto kind=expr->op=="+"?core::MIRValueOpKind::AddI64:(expr->op=="-"?core::MIRValueOpKind::SubI64:core::MIRValueOpKind::MulI64);
            operations.push_back({kind,name,lhs,rhs,0}); return name;
        }
        ok=false; error="direct LLVM MIR subset supports only i64 literals, locals, unary minus, +, -, and *"; return {};
    }
    bool lower(const FunctionDecl& fn) {
        if(fn.name!="main"||!fn.parameters.empty()) { ok=false; error="direct LLVM MIR backend requires a parameterless main function"; return false; }
        for(const auto& st:fn.body) {
            if(returned) { ok=false; error="statements after return are not supported by direct LLVM MIR backend"; return false; }
            if(st.kind==Statement::Kind::Let) {
                const auto value=expression(st.expression); if(!ok)return false;
                variables[st.name]=value;
            } else if(st.kind==Statement::Kind::Return) {
                const auto value=expression(st.expression); if(!ok)return false;
                operations.push_back({core::MIRValueOpKind::ReturnI64,{},value,{},0}); returned=true;
            } else {
                ok=false; error="direct LLVM MIR backend currently accepts only let and return in main"; return false;
            }
        }
        if(!returned) { const auto zero=temp(); operations.push_back({core::MIRValueOpKind::ConstantI64,zero,{}, {},0}); operations.push_back({core::MIRValueOpKind::ReturnI64,{},zero,{},0}); }
        return ok;
    }
};

}


void visit_expr_calls(const std::shared_ptr<Expr>& expr,
                     const std::function<void(const std::shared_ptr<Expr>&)>& visitor) {
    if(!expr)return;
    if(expr->kind==ExprKind::Call)visitor(expr);
    visit_expr_calls(expr->left,visitor); visit_expr_calls(expr->right,visitor);
    for(const auto& value:expr->elements)visit_expr_calls(value,visitor);
    for(const auto& property:expr->properties)visit_expr_calls(property.second,visitor);
}
void visit_statement_calls(const std::vector<Statement>& statements,
                           const std::function<void(const std::shared_ptr<Expr>&)>& visitor) {
    for(const auto& st:statements) {
        visit_expr_calls(st.expression,visitor); visit_expr_calls(st.target_index,visitor); visit_expr_calls(st.target_member,visitor);
        visit_statement_calls(st.body,visitor); visit_statement_calls(st.else_body,visitor);
        for(const auto& arm:st.match_arms)if(arm)visit_statement_calls(arm->body,visitor);
    }
}
std::string mangle_specialization(const std::string& name,const std::vector<core::TypeId>& args,const core::TypeContext& types) {
    std::string result=name+"__";
    for(std::size_t i=0;i<args.size();++i) {
        if(i)result+="_";
        auto part=types.display(args[i]);
        for(char& c:part)if(!std::isalnum(static_cast<unsigned char>(c)))c='_';
        result+=part;
    }
    return result;
}

LoweredModule lower_to_hir_mir(const Application& app) {
    LoweredModule out; out.hir.name=app.name; out.mir.name=app.name;
    std::unordered_set<std::string> enums; for(const auto& e:app.enums)enums.insert(e.name);
    std::unordered_map<std::string,const FunctionDecl*> functions; for(const auto& f:app.functions)functions.emplace(f.name,&f);
    for(const auto& fn:app.functions) {
       std::unordered_set<std::string> generics; for(const auto& gp:fn.type_parameters)generics.insert(gp.name);
       core::HIRFunction hir; hir.name=fn.name;
       for(const auto& gp:fn.type_parameters) { hir.generic_parameters.push_back(gp.name); for(const auto& bound:gp.trait_bounds)hir.generic_constraints.push_back(gp.name+":"+bound); }
       std::unordered_map<std::string,core::TypeId> vars;
       for(const auto& p:fn.parameters) { auto id=lower_type(p.type,out.types,generics,enums); vars[p.name]=id; hir.parameters.push_back({p.name,id,false}); }
       hir.return_type=lower_type(fn.return_type,out.types,generics,enums); hir.has_return_value=!fn.return_type.empty() && fn.return_type!="Void" && fn.return_type!="void";
       collect_locals(fn.body,out.types,vars,functions,enums,hir.locals);
       out.hir.functions.push_back(std::move(hir));

       core::MIRFunction mir; mir.name=fn.name; mir.entry=0; core::MIRBlock block; block.id=0;
       for(const auto& p:fn.parameters)block.operations.push_back({core::MIROpKind::Declare,p.name,{},vars[p.name],0,0});
       std::function<void(const std::vector<Statement>&)> lower_statements = [&](const std::vector<Statement>& list) {
         for(const auto& st:list) {
            if(st.kind==Statement::Kind::Let) {
              emit_reads(st.expression,block,vars,out.types);
              auto id=vars.contains(st.name)?vars[st.name]:out.types.named("inferred");
              block.operations.push_back({core::MIROpKind::Declare,st.name,{},id,0,0});
            } else if(st.kind==Statement::Kind::Assign) {
              emit_reads(st.expression,block,vars,out.types);
              const auto id=vars.contains(st.name)?vars[st.name]:out.types.named("inferred");
              block.operations.push_back({core::MIROpKind::Write,st.name,{},id,0,0});
            } else if(st.kind==Statement::Kind::Output||st.kind==Statement::Kind::Expression||st.kind==Statement::Kind::Return) {
              emit_reads(st.expression,block,vars,out.types);
              if(st.kind==Statement::Kind::Return)block.operations.push_back({core::MIROpKind::Return,"$return",{},out.types.primitive(core::TypeKind::Unit),0,0});
            } else if(st.kind==Statement::Kind::If||st.kind==Statement::Kind::While||st.kind==Statement::Kind::ForEach) {
              emit_reads(st.expression,block,vars,out.types); lower_statements(st.body); lower_statements(st.else_body);
            } else if(st.kind==Statement::Kind::Match) {
              emit_reads(st.expression,block,vars,out.types); for(const auto& arm:st.match_arms)if(arm)lower_statements(arm->body);
            }
         }
       };
       lower_statements(fn.body); mir.blocks.push_back(std::move(block));
       if(fn.name=="main") { NativeIntLowering native; if(native.lower(fn)) { mir.native_integer_supported=true; mir.native_integer_ops=std::move(native.operations); } }
       out.mir.functions.push_back(std::move(mir));
    }

    // Monomorphize direct generic calls when every declared type parameter is
    // inferable from a parameter whose type is exactly that parameter. The
    // instantiated HIR and MIR bodies receive stable concrete names.
    std::unordered_set<std::string> emitted_specializations;
    const auto original_hir_count=out.hir.functions.size();
    const auto original_mir_count=out.mir.functions.size();
    for(std::size_t caller_index=0;caller_index<app.functions.size();++caller_index) {
        const auto& caller=app.functions[caller_index];
        std::unordered_map<std::string,core::TypeId> caller_vars;
        std::unordered_set<std::string> caller_generics;
        for(const auto& p:caller.parameters)caller_vars[p.name]=lower_type(p.type,out.types,caller_generics,enums);
        std::vector<core::HIRLocal> ignored_locals;
        collect_locals(caller.body,out.types,caller_vars,functions,enums,ignored_locals);
        visit_statement_calls(caller.body,[&](const std::shared_ptr<Expr>& call) {
            const auto target_it=functions.find(call->callee);
            if(target_it==functions.end()||target_it->second->type_parameters.empty())return;
            const auto& generic_fn=*target_it->second;
            std::unordered_map<std::string,core::TypeId> substitutions;
            for(std::size_t p=0;p<generic_fn.parameters.size()&&p<call->elements.size();++p) {
                const auto declared=compact(generic_fn.parameters[p].type);
                const auto gp=std::find_if(generic_fn.type_parameters.begin(),generic_fn.type_parameters.end(),[&](const auto& item){return item.name==declared;});
                if(gp==generic_fn.type_parameters.end())continue;
                const auto concrete=infer_expr(call->elements[p],out.types,caller_vars,functions,enums);
                auto [it,added]=substitutions.emplace(gp->name,concrete);
                if(!added&&it->second!=concrete)return;
            }
            if(substitutions.size()!=generic_fn.type_parameters.size())return;
            std::vector<core::TypeId> concrete_args;
            for(const auto& gp:generic_fn.type_parameters)concrete_args.push_back(substitutions.at(gp.name));
            const auto specialized_name=mangle_specialization(generic_fn.name,concrete_args,out.types);
            if(!emitted_specializations.insert(specialized_name).second)return;
            const auto base_hir=std::find_if(out.hir.functions.begin(),out.hir.functions.begin()+static_cast<std::ptrdiff_t>(original_hir_count),[&](const auto& item){return item.name==generic_fn.name;});
            const auto base_mir=std::find_if(out.mir.functions.begin(),out.mir.functions.begin()+static_cast<std::ptrdiff_t>(original_mir_count),[&](const auto& item){return item.name==generic_fn.name;});
            if(base_hir==out.hir.functions.begin()+static_cast<std::ptrdiff_t>(original_hir_count)||base_mir==out.mir.functions.begin()+static_cast<std::ptrdiff_t>(original_mir_count))return;
            auto specialized_hir=*base_hir; specialized_hir.name=specialized_name; specialized_hir.generic_parameters.clear(); specialized_hir.generic_constraints.clear();
            for(auto& param:specialized_hir.parameters)param.type=out.types.substitute(param.type,substitutions);
            for(auto& local:specialized_hir.locals)local.type=out.types.substitute(local.type,substitutions);
            specialized_hir.return_type=out.types.substitute(specialized_hir.return_type,substitutions);
            auto specialized_mir=*base_mir; specialized_mir.name=specialized_name;
            out.hir.functions.push_back(std::move(specialized_hir));
            out.mir.functions.push_back(std::move(specialized_mir));
        });
    }
    auto hir_errors=core::verify_typed_hir(out.hir,out.types); out.diagnostics.insert(out.diagnostics.end(),hir_errors.begin(),hir_errors.end());
    auto mir_errors=core::verify_mir(out.mir,out.types); out.diagnostics.insert(out.diagnostics.end(),mir_errors.begin(),mir_errors.end());
    return out;
}
} // namespace docmont::frontend
