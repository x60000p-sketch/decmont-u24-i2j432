#include "docmont/skeletal_animation.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <unordered_set>

namespace docmont::animation {
namespace {
bool finite(float v) { return std::isfinite(v); }
bool finite(math::Vec3 v) { return finite(v.x)&&finite(v.y)&&finite(v.z); }
bool finite(math::Quat q) { return finite(q.x)&&finite(q.y)&&finite(q.z)&&finite(q.w); }
math::Quat slerp(math::Quat a, math::Quat b, float t) {
    a=math::normalize(a); b=math::normalize(b);
    float d=math::dot(a,b);
    if(d<0.0f){ b={-b.x,-b.y,-b.z,-b.w}; d=-d; }
    d=std::clamp(d,-1.0f,1.0f);
    if(d>0.9995f) return math::normalize(math::Quat{
        a.x+(b.x-a.x)*t,a.y+(b.y-a.y)*t,a.z+(b.z-a.z)*t,a.w+(b.w-a.w)*t});
    const float theta=std::acos(d), sn=std::sin(theta);
    const float wa=std::sin((1.0f-t)*theta)/sn, wb=std::sin(t*theta)/sn;
    return {a.x*wa+b.x*wb,a.y*wa+b.y*wb,a.z*wa+b.z*wb,a.w*wa+b.w*wb};
}
math::Vec3 sample_vec(const std::vector<VecKey>& keys, float t, math::Vec3 fallback) {
    if(keys.empty()) return fallback;
    if(t<=keys.front().time) return keys.front().value;
    if(t>=keys.back().time) return keys.back().value;
    auto it=std::upper_bound(keys.begin(),keys.end(),t,[](float x,const VecKey& k){return x<k.time;});
    const auto& b=*it; const auto& a=*(it-1);
    const float d=b.time-a.time, u=d>0?(t-a.time)/d:0;
    return a.value*(1.0f-u)+b.value*u;
}
math::Quat sample_quat(const std::vector<QuatKey>& keys, float t, math::Quat fallback) {
    if(keys.empty()) return fallback;
    if(t<=keys.front().time) return math::normalize(keys.front().value);
    if(t>=keys.back().time) return math::normalize(keys.back().value);
    auto it=std::upper_bound(keys.begin(),keys.end(),t,[](float x,const QuatKey& k){return x<k.time;});
    const auto& b=*it; const auto& a=*(it-1);
    const float d=b.time-a.time, u=d>0?(t-a.time)/d:0;
    return slerp(a.value,b.value,u);
}
bool sorted_vec(const std::vector<VecKey>& k,float duration) {
    float last=-1.0f;
    for(const auto& x:k){if(!finite(x.time)||x.time<0||x.time>duration||x.time<last||!finite(x.value))return false;last=x.time;}
    return true;
}
bool sorted_quat(const std::vector<QuatKey>& k,float duration) {
    float last=-1.0f;
    for(const auto& x:k){if(!finite(x.time)||x.time<0||x.time>duration||x.time<last||!finite(x.value)||math::dot(x.value,x.value)<1e-16f)return false;last=x.time;}
    return true;
}
math::Mat4 compose(const Transform& t) {
    return math::Mat4::translation(t.translation)*math::Mat4::rotation(t.rotation)*math::Mat4::scale(t.scale);
}
math::Vec3 transform_direction(const math::Mat4& m,math::Vec3 v){
    const auto r=m*math::Vec4{v.x,v.y,v.z,0}; return {r.x,r.y,r.z};
}
}

bool Skeleton::add_bone(Bone b) {
    if(b.name.empty() || find_bone(b.name) || b.parent>=static_cast<std::int32_t>(bones_.size()) || b.parent< -1) return false;
    if(!finite(b.bind_local.translation)||!finite(b.bind_local.scale)||!finite(b.bind_local.rotation)) return false;
    if(math::dot(b.bind_local.rotation,b.bind_local.rotation)<1e-16f) return false;
    try { b.bind_local.rotation=math::normalize(b.bind_local.rotation); } catch(...) { return false; }
    bones_.push_back(std::move(b)); return true;
}
bool Skeleton::validate(std::string* e) const {
    if(bones_.empty()){if(e)*e="skeleton has no bones";return false;}
    std::unordered_set<std::string> names;
    for(std::size_t i=0;i<bones_.size();++i){const auto& b=bones_[i];
        if(b.name.empty()||!names.insert(b.name).second){if(e)*e="bone names must be non-empty and unique";return false;}
        if(b.parent>=static_cast<std::int32_t>(i)||b.parent< -1){if(e)*e="bone parent must precede its child";return false;}
        if(!finite(b.bind_local.translation)||!finite(b.bind_local.scale)||!finite(b.bind_local.rotation)){if(e)*e="non-finite bind transform";return false;}
        for(float v:b.inverse_bind.m)if(!finite(v)){if(e)*e="non-finite inverse bind matrix";return false;}
    }
    return true;
}
std::optional<std::size_t> Skeleton::find_bone(const std::string& n) const noexcept {
    for (std::size_t i = 0; i < bones_.size(); ++i) {
        if (bones_[i].name == n) return i;
    }
    return std::nullopt;
}

bool Animator::validate_clip(const Skeleton& s,const AnimationClip& c,std::string* e){
    std::string why; if(!s.validate(&why)){if(e)*e=why;return false;}
    if(c.name.empty()||!finite(c.duration)||c.duration<=0){if(e)*e="clip name and positive finite duration are required";return false;}
    std::unordered_set<std::uint32_t> seen;
    for(const auto& t:c.tracks){
        if(t.bone>=s.size()||!seen.insert(t.bone).second){if(e)*e="track bone index is invalid or duplicated";return false;}
        if(!sorted_vec(t.translations,c.duration)||!sorted_quat(t.rotations,c.duration)||!sorted_vec(t.scales,c.duration)){if(e)*e="keys must be finite, sorted, and within clip duration";return false;}
        for(const auto& k:t.scales)if(k.value.x==0||k.value.y==0||k.value.z==0){if(e)*e="bone scale keys cannot contain zero scale";return false;}
    }
    return true;
}
Pose Animator::bind_pose(const Skeleton& s){Pose p;p.local.reserve(s.size());for(std::size_t i=0;i<s.size();++i)p.local.push_back(s.bone(i).bind_local);return p;}
Pose Animator::sample(const Skeleton& s,const AnimationClip& c,float time){
    std::string e;if(!validate_clip(s,c,&e))throw std::invalid_argument(e);
    if(!finite(time))throw std::invalid_argument("animation time must be finite");
    if(c.looping){time=std::fmod(time,c.duration);if(time<0)time+=c.duration;}else time=std::clamp(time,0.0f,c.duration);
    Pose p=bind_pose(s);
    for(const auto& tr:c.tracks){auto& x=p.local[tr.bone];x.translation=sample_vec(tr.translations,time,x.translation);x.rotation=sample_quat(tr.rotations,time,x.rotation);x.scale=sample_vec(tr.scales,time,x.scale);}
    return p;
}
std::optional<Pose> Animator::blend(const Pose& a,const Pose& b,float w,std::string* e){
    if(a.local.size()!=b.local.size()||!finite(w)||w<0||w>1){if(e)*e="poses must have equal bone counts and blend weight in [0,1]";return std::nullopt;}
    Pose r;r.local.resize(a.local.size());
    for(std::size_t i=0;i<r.local.size();++i){const auto& x=a.local[i];const auto& y=b.local[i];auto& z=r.local[i];
        z.translation=x.translation*(1-w)+y.translation*w;
        z.scale=x.scale*(1-w)+y.scale*w;
        try{z.rotation=slerp(x.rotation,y.rotation,w);}catch(...){if(e)*e="invalid rotation in pose";return std::nullopt;}
        if(!finite(z.translation)||!finite(z.scale)){if(e)*e="non-finite blended transform";return std::nullopt;}
    }
    return r;
}
std::optional<SkeletonMatrices> Animator::build_matrices(const Skeleton& s,const Pose& p,std::string* e){
    std::string why;if(!s.validate(&why)){if(e)*e=why;return std::nullopt;}
    if(p.local.size()!=s.size()){if(e)*e="pose bone count does not match skeleton";return std::nullopt;}
    SkeletonMatrices out;out.global.resize(s.size());out.skin.resize(s.size());
    for(std::size_t i=0;i<s.size();++i){const auto& x=p.local[i];if(!finite(x.translation)||!finite(x.scale)||!finite(x.rotation)){if(e)*e="pose contains non-finite transform";return std::nullopt;}
        math::Mat4 local;try{local=compose(x);}catch(...){if(e)*e="invalid pose rotation";return std::nullopt;}
        const auto parent=s.bone(i).parent;
        out.global[i]=parent<0?local:out.global[static_cast<std::size_t>(parent)]*local;
        out.skin[i]=out.global[i]*s.bone(i).inverse_bind;
    }
    return out;
}
std::optional<std::vector<SkinnedVertex>> Animator::skin(const SkeletonMatrices& m,const std::vector<SkinnedVertex>& v,const std::vector<BoneInfluence>& inf,std::string* e){
    if(v.size()!=inf.size()||m.skin.empty()){if(e)*e="vertex and influence counts must match and skin matrices cannot be empty";return std::nullopt;}
    std::vector<SkinnedVertex> out(v.size());
    for(std::size_t i=0;i<v.size();++i){math::Vec3 p{},n{};float sum=0;
        for(std::size_t j=0;j<4;++j){const float w=inf[i].weights[j];if(!finite(w)||w<0){if(e)*e="skin weights must be finite and non-negative";return std::nullopt;}if(w==0)continue;
            const auto bi=inf[i].indices[j];if(bi>=m.skin.size()){if(e)*e="bone influence index out of range";return std::nullopt;}
            const auto q=m.skin[bi]*math::Vec4{v[i].position.x,v[i].position.y,v[i].position.z,1};
            p=p+math::Vec3{q.x,q.y,q.z}*w;n=n+transform_direction(m.skin[bi],v[i].normal)*w;sum+=w;
        }
        if(sum<=1e-8f){if(e)*e="each skinned vertex must have a positive weight";return std::nullopt;}
        p=p/sum;n=n/sum;try{n=math::normalize(n);}catch(...){n={0,1,0};}out[i]={p,n};
    }
    return out;
}
} // namespace docmont::animation
