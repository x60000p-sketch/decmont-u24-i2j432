# DECMONT 10.50.0 changelog

- Expanded Native C11 backend with MakeArray, ArrayGet, ArraySet, ArrayLength,
  ArrayPush and ArrayPop.
- Added bounded generated-C array storage (1,000,000 reserved Value slots).
- Added native runtime checks for array type, index bounds, empty pop and
  allocation/growth failures.
- Added recursive array display support.
- Added native array regression tests and a Clang compile-link-run integration
  test comparing native output for indexing, length, push and pop.
- Updated CLI, CMake project version, VS Code metadata/tests and release docs.
- Preserved language compatibility 3.4.0 and DVM bytecode v1.
