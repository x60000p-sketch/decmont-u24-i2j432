# DECMONT 10.40.0 capability matrix

| Area | 10.40.0 status | Verified scope |
|---|---|---|
| Language compatibility | Available | 3.4.0 grammar/runtime compatibility retained |
| DVM | Available | Bytecode v1; existing VM tests |
| Native C11 lowering | Expanded subset | Push/load/store/print, checked integer arithmetic, branches, boolean not, integer comparisons, logical operations, integer/string equality |
| Native verifier | Available | Jump bounds, reachable stack dataflow, merge-depth consistency, underflow, 4096-slot cap, 1,000,000-instruction cap |
| Native type checks | Available in lowered operations | Integer arithmetic/ordered comparisons and BoolNot; equality supports integer/string and cross-kind unequal |
| Native compiler parity | Not complete | Arrays, objects, functions, closures and other unlowered opcodes remain unsupported by C11 backend |
| CPU backend | Available | Portable C11 output compiled with host Clang in this release test |
| GLES | Existing limited backend | Host runtime detected; this environment uses software rendering, not hardware acceleration |
| Vulkan | Probe/loader scope | No device/queue available in this environment; not a complete renderer |
| D3D12 / Metal | Platform adapters/probes | Not validated on this Linux host; do not infer full renderer support |
| ONNX | Bounded CPU operator subset | General GPU ONNX provider not implemented |
| Game engine | Host-side systems | Production renderer/audio adapters remain platform-dependent/incomplete |
| Windows/macOS/mobile | Not validated here | Separate platform toolchains and CI required |
| PS5/Xbox | Not validated here | Vendor SDK and authorized devkit required |

## Native C11 operation semantics

- `BoolNot`: requires integer; replaces it with 1 when zero, otherwise 0.
- `Equal` / `NotEqual`: integer or string content comparison; different value kinds are unequal.
- `Less`, `LessEqual`, `Greater`, `GreaterEqual`: require integer operands.
- `LogicalAnd` / `LogicalOr`: integer truthiness (`!= 0`); produce normalized 0 or 1.

Native C11 remains a restricted lowering target. The DVM remains the portable execution fallback for programs using unsupported operations.
