# DECMONT 10.30.0 ULTRA — Systems, Native Compilation & Game Development SDK

DECMONT 10.30.0 advances the restricted Native C source backend with a control-flow and operand-stack verifier. It preserves source-language compatibility `3.4.0` and DVM bytecode format `v1`.

- Compiler release: `10.30.0`
- Language compatibility: `3.4.0`
- Bytecode: `DVM-v1`
- Host verification in this package: Linux x86_64, GNU C/C++ 14.2.0, CMake/Ninja.

## New in 10.30.0: native backend verification

Before emitting C11, the native source backend now:

- validates branch targets against the instruction stream;
- performs reachable control-flow stack-depth analysis;
- rejects stack underflow and inconsistent stack depth at merge points;
- rejects positive-growth loops that would invalidate a fixed-size stack allocation;
- computes the required stack capacity from the verified maximum depth;
- reports unsupported opcodes before producing partial C output.

The backend remains a restricted opcode subset, not a complete native compiler for the whole DECMONT language. Use DVM for programs containing unsupported features.

## Quick start

```bash
docmont --version
docmont doctor
docmont doctor --json
docmont --help
```

Build from source:

```bash
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel
ctest --test-dir build --output-on-failure
```

See `DOCMONT-10.30.0-ULTRA-QUICKSTART.txt`, release notes and capability matrix for exact scope.

## Known limitations

- Native C emission supports only its documented integer/string/control-flow opcode subset; arrays, objects, functions, closures and several other opcodes still require DVM or additional native lowerings.
- Vulkan is not a complete production renderer in this build; D3D12 and Metal require their native platform toolchains and runtime validation.
- GLES hardware acceleration depends on the host driver; software rendering is not evidence of hardware GPU acceleration.
- General ONNX GPU execution and production game renderer/audio adapters remain incomplete.
- Windows, macOS, Android, iOS, PS5 and Xbox are not validated by this Linux build. Console builds require licensed vendor SDKs and devkits.
