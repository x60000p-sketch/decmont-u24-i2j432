# DECMONT 10.30.0 Capability Matrix

| Area | 10.30.0 status |
|---|---|
| Language compatibility | 3.4.0 |
| DVM bytecode | v1 retained |
| Native C11 backend | Restricted opcode subset; CFG/stack verification; 4,096-slot stack cap; 1,000,000-instruction cap |
| Native MIR/object | Existing restricted implementation; not full language parity |
| GPU | Existing probes/backends only; no claim of complete Vulkan/D3D12/Metal renderer |
| AI/ONNX | Existing bounded CPU path; general ONNX GPU provider not implemented |
| Game engine | Existing host-side systems; production graphics/audio backends remain incomplete |
| Console targets | Require vendor SDKs/devkits; not validated in this host build |

The limits apply to the native C source-emission verifier, not to all DVM programs.
