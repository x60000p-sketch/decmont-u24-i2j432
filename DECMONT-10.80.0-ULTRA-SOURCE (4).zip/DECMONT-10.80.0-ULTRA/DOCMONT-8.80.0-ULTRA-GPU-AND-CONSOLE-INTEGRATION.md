# GPU and Console Integration — DOCMONT 8.80.0 ULTRA

## GPU backends

### Vulkan

`docmont gpu-info` loads the Vulkan loader and attempts instance creation, physical-device discovery, logical-device creation and a graphics/compute queue request. This build did not find a usable ICD/physical device. Therefore Vulkan swapchain presentation, resource allocation, command buffers, graphics pipelines, compute dispatch and GPU shader validation are not part of the verified feature set yet.

### Direct3D 12 and Metal

They are not native renderer backends in this Linux build. D3D12 must be built with the official Windows SDK and a Windows-native implementation. Metal must be built with Apple SDKs and an Objective-C++ implementation. A status probe is not a renderer.

### Shader references

`shaders/` contains GLSL, HLSL and Metal source references for skinning and PBR. No compiled SPIR-V/DXIL/Metal library is shipped or claimed.

## Console adapters

The files under `platforms/consoles/` are manifest examples only. The SDK validator checks whether a developer-provided SDK root, compiler, CMake toolchain, headers and license acknowledgement are configured. It intentionally does not download, bundle, fabricate or bypass access to proprietary SDKs.

A console target can move to hardware-tested status only when an authorized developer:

1. Obtains the vendor SDK and devkit through the vendor's official program.
2. Configures a manifest with local SDK paths.
3. Builds the platform adapter with the vendor toolchain.
4. Runs platform-specific build and runtime validation on the devkit.
5. Completes any vendor certification or approval processes.

`hardware_validated` remains false in DOCMONT's SDK probe until a future verifiable validation workflow exists.
