# DECMONT 10.10.0 ULTRA — Release Notes

10.10.0 added the machine-readable System Doctor while preserving language compatibility 3.4.0 and DVM bytecode v1.

- `docmont doctor --json` emits schema version 1 JSON.
- Reports host OS, architecture, pointer width and logical CPU count.
- Reports DVM availability and the restricted scope of the Native compiler.
- Reports GLES availability, compute support and hardware acceleration status.
- Reports Vulkan, D3D12, Metal and CPU backend runtime/device/queue states independently.
- Reports game-engine renderer/audio and ONNX CPU/GPU scope.
- Diagnostic output does not claim that probed or listed backends are complete.

Verified host: Linux x86_64 with GNU C/C++ 14.2.0, CMake and Ninja. The release did not validate every desktop/mobile target. Console builds require licensed vendor SDKs and devkits.
