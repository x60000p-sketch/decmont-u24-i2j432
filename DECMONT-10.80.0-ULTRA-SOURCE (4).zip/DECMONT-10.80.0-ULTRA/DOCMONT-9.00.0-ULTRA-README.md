# DOCMONT 9.00.0 ULTRA

A systems-language compiler, portable DVM runtime, game/simulation SDK and developer tooling distribution.

- Compiler: 9.00.0
- Language compatibility: 3.4.0
- DVM bytecode: v1 (unchanged)
- Verified build host: Linux x86_64

Start with `DOCMONT-9.00.0-ULTRA-QUICKSTART.txt` and the root `README.md`.

Release highlights: 23 float32 ONNX CPU operators; direct-MIR native executable builder for a restricted integer subset; shader compiler command router; Vulkan loader/device probe; platform-gated D3D12/Metal device probes; official licensed PS5/Xbox CMake toolchain adapter; Windows/macOS/Android CMake presets; exported CMake SDK package `DOCMONT::docmont_core`.

Test results: CTest 76/76, VS Code LSP 8/8, VS Code JavaScript check passed, installed CMake consumer passed, and installed project lifecycle passed.

Important: platform adapters and presets are not proof of support. Real PS5/Xbox builds need the vendor SDK and devkit; D3D12/Metal need Windows/Apple environments; Android needs NDK; shader builds need actual shader compilers. The current environment did not contain those SDKs/devices. Full GPU renderers, full ONNX, and full-source native game compilation are not claimed.
