'use strict';

const vscode = require('vscode');
const cp = require('node:child_process');
const path = require('node:path');

class LspClient {
  constructor(serverPath, output, onDiagnostics) {
    this.serverPath = serverPath;
    this.output = output;
    this.onDiagnostics = onDiagnostics;
    this.child = null;
    this.buffer = Buffer.alloc(0);
    this.nextId = 1;
    this.pending = new Map();
    this.startPromise = null;
    this.closed = false;
    this.stopPromise = null;
  }

  start(initializeParams) {
    if (this.startPromise) return this.startPromise;
    this.child = cp.spawn(process.execPath, [this.serverPath], { stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true });
    this.child.stdout.on('data', chunk => this.consume(chunk));
    this.child.stderr.on('data', chunk => this.output.appendLine(chunk.toString('utf8').trimEnd()));
    this.child.on('error', error => this.rejectPending(error));
    this.child.on('exit', (code, signal) => {
      this.closed = true;
      this.rejectPending(new Error(`DOCMONT language server exited (${code === null ? signal : code})`));
    });
    this.startPromise = this.initialize(initializeParams);
    return this.startPromise;
  }

  async initialize(params) {
    const result = await this.requestRaw('initialize', params);
    this.notifyRaw('initialized', {});
    this.output.appendLine(`Language server ready: ${result.serverInfo?.name || 'DOCMONT'}`);
    return result;
  }

  rejectPending(error) {
    for (const entry of this.pending.values()) entry.reject(error);
    this.pending.clear();
  }

  send(message) {
    if (!this.child || !this.child.stdin.writable || this.closed) throw new Error('DOCMONT language server is not running');
    const body = Buffer.from(JSON.stringify(message), 'utf8');
    this.child.stdin.write(Buffer.concat([Buffer.from(`Content-Length: ${body.length}\r\n\r\n`), body]));
  }

  requestRaw(method, params) {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      try { this.send({ jsonrpc: '2.0', id, method, params }); }
      catch (error) { this.pending.delete(id); reject(error); }
    });
  }

  notifyRaw(method, params) {
    this.send({ jsonrpc: '2.0', method, params });
  }

  request(method, params) {
    return this.startPromise.then(() => this.requestRaw(method, params));
  }

  notify(method, params) {
    return this.startPromise.then(() => this.notifyRaw(method, params));
  }

  consume(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    while (true) {
      const boundary = this.buffer.indexOf('\r\n\r\n');
      if (boundary < 0) return;
      const header = this.buffer.slice(0, boundary).toString('ascii');
      const match = header.match(/Content-Length:\s*(\d+)/i);
      if (!match) { this.buffer = this.buffer.slice(boundary + 4); continue; }
      const length = Number(match[1]);
      const bodyStart = boundary + 4;
      if (this.buffer.length < bodyStart + length) return;
      const body = this.buffer.slice(bodyStart, bodyStart + length).toString('utf8');
      this.buffer = this.buffer.slice(bodyStart + length);
      let message;
      try { message = JSON.parse(body); }
      catch (error) { this.output.appendLine(`Invalid language-server message: ${error.message}`); continue; }
      if (Object.prototype.hasOwnProperty.call(message, 'id') && this.pending.has(message.id)) {
        const pending = this.pending.get(message.id);
        this.pending.delete(message.id);
        if (message.error) pending.reject(new Error(message.error.message || 'Language server request failed'));
        else pending.resolve(message.result);
      } else if (message.method === 'textDocument/publishDiagnostics') {
        this.onDiagnostics(message.params || {});
      }
    }
  }

  stop() {
    if (this.stopPromise) return this.stopPromise;
    this.stopPromise = (async () => {
      if (!this.child || this.closed) return;
      try { await this.request('shutdown', {}); } catch (_) { /* process may already be stopping */ }
      try { this.notifyRaw('exit', {}); } catch (_) { /* ignore a closed pipe */ }
      if (this.child && this.child.stdin.writable) this.child.stdin.end();
    })();
    return this.stopPromise;
  }
}

let client;
let diagnosticCollection;
let output;
const openedDocuments = new Set();

function settings() {
  const config = vscode.workspace.getConfiguration('docmont');
  return {
    compilerPath: config.get('compilerPath', '${workspaceFolder}/build/docmont'),
    validateOnType: config.get('validateOnType', true),
    validateDelay: config.get('validateDelay', 400)
  };
}

function lspPosition(position) {
  return { line: position.line, character: position.character };
}

function vscodeRange(range) {
  return new vscode.Range(
    new vscode.Position(range.start.line, range.start.character),
    new vscode.Position(range.end.line, range.end.character)
  );
}

function publishDiagnostics(params) {
  const uri = vscode.Uri.parse(params.uri);
  const document = vscode.workspace.textDocuments.find(item => item.uri.toString() === params.uri);
  if (params.version !== undefined && document && document.version !== params.version) return;
  const diagnostics = (params.diagnostics || []).map(item => {
    const diagnostic = new vscode.Diagnostic(vscodeRange(item.range), item.message, item.severity === 2
      ? vscode.DiagnosticSeverity.Warning : item.severity === 3
        ? vscode.DiagnosticSeverity.Information : vscode.DiagnosticSeverity.Error);
    diagnostic.source = item.source || 'DOCMONT';
    if (item.code !== undefined) diagnostic.code = item.code;
    return diagnostic;
  });
  diagnosticCollection.set(uri, diagnostics);
  output.appendLine(`[${uri.fsPath}] ${diagnostics.length} diagnostic(s)`);
}

function openDocument(document) {
  if (!client || document.languageId !== 'docmont') return;
  const key = document.uri.toString();
  if (openedDocuments.has(key)) return;
  openedDocuments.add(key);
  client.notify('textDocument/didOpen', {
    textDocument: { uri: key, languageId: document.languageId, version: document.version, text: document.getText() }
  }).catch(error => output.appendLine(error.message));
}

function changeDocument(document) {
  if (!client || document.languageId !== 'docmont') return;
  const key = document.uri.toString();
  if (!openedDocuments.has(key)) openDocument(document);
  client.notify('textDocument/didChange', {
    textDocument: { uri: key, version: document.version },
    contentChanges: [{ text: document.getText() }]
  }).catch(error => output.appendLine(error.message));
}

function completionKind(kind) {
  const map = {
    1: vscode.CompletionItemKind.Text,
    5: vscode.CompletionItemKind.Field,
    6: vscode.CompletionItemKind.Variable,
    10: vscode.CompletionItemKind.Property,
    12: vscode.CompletionItemKind.Value,
    13: vscode.CompletionItemKind.Enum,
    14: vscode.CompletionItemKind.Keyword,
    15: vscode.CompletionItemKind.Snippet,
    21: vscode.CompletionItemKind.Constant
  };
  return map[kind] || vscode.CompletionItemKind.Text;
}

function registerProviders(context) {
  context.subscriptions.push(vscode.languages.registerCompletionItemProvider('docmont', {
    async provideCompletionItems(document, position) {
      try {
        const response = await client.request('textDocument/completion', {
          textDocument: { uri: document.uri.toString() }, position: lspPosition(position)
        });
        return (response && response.items ? response.items : []).map(entry => {
          const item = new vscode.CompletionItem(entry.label, completionKind(entry.kind));
          item.detail = entry.detail;
          item.sortText = entry.sortText;
          item.filterText = entry.filterText;
          if (entry.documentation) item.documentation = typeof entry.documentation === 'string'
            ? new vscode.MarkdownString(entry.documentation) : new vscode.MarkdownString(entry.documentation.value || '');
          if (entry.textEdit) {
            item.range = vscodeRange(entry.textEdit.range);
            item.insertText = entry.insertTextFormat === 2
              ? new vscode.SnippetString(entry.textEdit.newText)
              : entry.textEdit.newText;
          } else if (entry.insertTextFormat === 2) item.insertText = new vscode.SnippetString(entry.insertText || entry.label);
          else item.insertText = entry.insertText || entry.label;
          return item;
        });
      } catch (error) {
        output.appendLine(`Completion failed: ${error.message}`);
        return [];
      }
    }
  }, '.', '=', ' ', '('));

  context.subscriptions.push(vscode.languages.registerDefinitionProvider('docmont', {
    async provideDefinition(document, position) {
      try {
        const result = await client.request('textDocument/definition', {
          textDocument: { uri: document.uri.toString() }, position: lspPosition(position)
        });
        if (!result) return null;
        const locations = Array.isArray(result) ? result : [result];
        return locations.map(location => new vscode.Location(vscode.Uri.parse(location.uri), vscodeRange(location.range)));
      } catch (error) {
        output.appendLine(`Definition lookup failed: ${error.message}`);
        return null;
      }
    }
  }));

  context.subscriptions.push(vscode.languages.registerHoverProvider('docmont', {
    async provideHover(document, position) {
      try {
        const result = await client.request('textDocument/hover', {
          textDocument: { uri: document.uri.toString() }, position: lspPosition(position)
        });
        if (!result || !result.contents) return null;
        const value = typeof result.contents === 'string' ? result.contents : result.contents.value || '';
        return new vscode.Hover(new vscode.MarkdownString(value), result.range ? vscodeRange(result.range) : undefined);
      } catch (error) {
        output.appendLine(`Hover failed: ${error.message}`);
        return null;
      }
    }
  }));
}

async function activate(context) {
  openedDocuments.clear();
  output = vscode.window.createOutputChannel('DOCMONT Language Server');
  diagnosticCollection = vscode.languages.createDiagnosticCollection('docmont');
  context.subscriptions.push(output, diagnosticCollection);

  const folders = vscode.workspace.workspaceFolders || [];
  const activeDocument = vscode.window.activeTextEditor && vscode.window.activeTextEditor.document;
  const rootUri = folders.length ? folders[0].uri.toString()
    : activeDocument && activeDocument.uri.scheme === 'file'
      ? vscode.Uri.file(path.dirname(activeDocument.uri.fsPath)).toString() : null;
  const workspaceFolders = folders.map(folder => ({ uri: folder.uri.toString(), name: folder.name }));
  client = new LspClient(context.asAbsolutePath('server.js'), output, publishDiagnostics);
  context.subscriptions.push({ dispose: () => { if (client) client.stop(); } });

  context.subscriptions.push(vscode.workspace.onDidOpenTextDocument(openDocument));
  context.subscriptions.push(vscode.workspace.onDidChangeTextDocument(event => changeDocument(event.document)));
  context.subscriptions.push(vscode.workspace.onDidSaveTextDocument(document => {
    if (document.languageId === 'docmont') client.notify('textDocument/didSave', { textDocument: { uri: document.uri.toString() } })
      .catch(error => output.appendLine(error.message));
  }));
  context.subscriptions.push(vscode.workspace.onDidCloseTextDocument(document => {
    if (document.languageId !== 'docmont') return;
    const key = document.uri.toString();
    openedDocuments.delete(key);
    client.notify('textDocument/didClose', { textDocument: { uri: key } }).catch(error => output.appendLine(error.message));
  }));
  context.subscriptions.push(vscode.workspace.onDidChangeConfiguration(event => {
    if (event.affectsConfiguration('docmont')) client.notify('workspace/didChangeConfiguration', { settings: { docmont: settings() } })
      .catch(error => output.appendLine(error.message));
  }));

  context.subscriptions.push(vscode.commands.registerCommand('docmont.checkFile', () => {
    const editor = vscode.window.activeTextEditor;
    if (!editor || editor.document.languageId !== 'docmont') {
      vscode.window.showInformationMessage('Open a .docm file to run DOCMONT Check.');
      return;
    }
    client.notify('docmont/validate', { uri: editor.document.uri.toString() }).catch(error => output.appendLine(error.message));
  }));
  context.subscriptions.push(vscode.commands.registerCommand('docmont.showOutput', () => output.show()));

  registerProviders(context);
  try {
    await client.start({
      processId: process.pid,
      rootUri,
      workspaceFolders,
      capabilities: { workspace: { workspaceFolders: { supported: true, changeNotifications: true } }, textDocument: { completion: { completionItem: { snippetSupport: true } }, definition: {}, hover: {} } },
      initializationOptions: settings()
    });
    for (const document of vscode.workspace.textDocuments) openDocument(document);
  } catch (error) {
    output.appendLine(`Unable to start DOCMONT language server: ${error.message}`);
    vscode.window.showWarningMessage('DOCMONT language server could not start. See the DOCMONT output channel.');
  }
}

async function deactivate() {
  if (client) await client.stop();
  client = undefined;
}

module.exports = { activate, deactivate };
