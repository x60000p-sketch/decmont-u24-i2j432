'use strict';

const cp = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { fileURLToPath } = require('node:url');

const LSP = {
  Error: 1,
  Warning: 2,
  CompletionItemKind: { Text: 1, Field: 5, Variable: 6, Property: 10, Value: 12, Enum: 13, Keyword: 14, Snippet: 15, Constant: 21 }
};

function tokenize(source) {
  const tokens = [];
  let i = 0;
  let line = 0;
  let character = 0;
  const push = (kind, text, start, end, tokenLine, tokenCharacter) => {
    tokens.push({ kind, text, start, end, line: tokenLine, character: tokenCharacter });
  };
  while (i < source.length) {
    const ch = source[i];
    if (ch === '\n') {
      push('newline', '\n', i, i + 1, line, character);
      i += 1; line += 1; character = 0;
      continue;
    }
    if (ch === ' ' || ch === '\t' || ch === '\r') {
      i += 1; character += 1;
      continue;
    }
    const start = i;
    const tokenLine = line;
    const tokenCharacter = character;
    if (/[A-Za-z_!]/.test(ch)) {
      i += 1; character += 1;
      while (i < source.length && /[A-Za-z0-9_!]/.test(source[i])) { i += 1; character += 1; }
      push('identifier', source.slice(start, i), start, i, tokenLine, tokenCharacter);
      continue;
    }
    if (/[0-9]/.test(ch)) {
      i += 1; character += 1;
      while (i < source.length && /[0-9]/.test(source[i])) { i += 1; character += 1; }
      push('number', source.slice(start, i), start, i, tokenLine, tokenCharacter);
      continue;
    }
    if (ch === '"' || ch === "'") {
      const quote = ch;
      i += 1; character += 1;
      while (i < source.length && source[i] !== '\n') {
        if (source[i] === '\\' && i + 1 < source.length) {
          i += 2; character += 2;
          continue;
        }
        const current = source[i];
        i += 1; character += 1;
        if (current === quote) break;
      }
      push('string', source.slice(start, i), start, i, tokenLine, tokenCharacter);
      continue;
    }
    const map = {
      '{': 'lbrace', '}': 'rbrace', '(': 'lparen', ')': 'rparen',
      '=': 'equal', '+': 'operator', '-': 'operator', '*': 'operator', '/': 'operator'
    };
    i += 1; character += 1;
    push(map[ch] || 'other', ch, start, i, tokenLine, tokenCharacter);
  }
  return tokens;
}

function offsetAt(source, position) {
  const wantedLine = Math.max(0, position.line | 0);
  const wantedCharacter = Math.max(0, position.character | 0);
  let offset = 0;
  let line = 0;
  while (line < wantedLine && offset < source.length) {
    const next = source.indexOf('\n', offset);
    if (next < 0) return source.length;
    offset = next + 1;
    line += 1;
  }
  return Math.min(source.length, offset + wantedCharacter);
}

function positionAt(source, offset) {
  const safe = Math.max(0, Math.min(source.length, offset));
  const before = source.slice(0, safe);
  const line = (before.match(/\n/g) || []).length;
  const lastNewline = before.lastIndexOf('\n');
  return { line, character: safe - lastNewline - 1 };
}

function previousSignificant(tokens, index) {
  for (let i = index - 1; i >= 0; i -= 1) if (tokens[i].kind !== 'newline') return i;
  return -1;
}

function classifyBrace(tokens, index) {
  const previous = previousSignificant(tokens, index);
  if (previous < 0) return 'unknown';
  if (tokens[previous].kind === 'equal') {
    const nameIndex = previousSignificant(tokens, previous);
    if (nameIndex >= 0 && tokens[nameIndex].kind === 'identifier') {
      const name = tokens[nameIndex].text;
      if (name === 'application' || name === 'memory' || name === 'compute') return name;
    }
  }
  if (tokens[previous].kind === 'rparen') {
    let depth = 1;
    for (let i = previous - 1; i >= 0; i -= 1) {
      if (tokens[i].kind === 'rparen') depth += 1;
      else if (tokens[i].kind === 'lparen') {
        depth -= 1;
        if (depth === 0) {
          const beforeParen = previousSignificant(tokens, i);
          if (beforeParen >= 0 && tokens[beforeParen].text === 'if') return 'statement';
          break;
        }
      }
    }
  }
  if (tokens[previous].text === 'else') return 'statement';
  return 'unknown';
}

function buildScopes(tokens, sourceLength) {
  const root = { id: 0, kind: 'document', parent: null, start: 0, end: sourceLength, children: [] };
  const scopes = [root];
  const stack = [root];
  let nextId = 1;
  for (let i = 0; i < tokens.length; i += 1) {
    const token = tokens[i];
    if (token.kind === 'lbrace') {
      const scope = {
        id: nextId++, kind: classifyBrace(tokens, i), parent: stack[stack.length - 1],
        start: token.end, end: sourceLength, children: []
      };
      stack[stack.length - 1].children.push(scope);
      scopes.push(scope);
      stack.push(scope);
    } else if (token.kind === 'rbrace' && stack.length > 1) {
      stack[stack.length - 1].end = token.start;
      stack.pop();
    }
  }
  return { root, scopes };
}

function scopeAt(scopes, offset) {
  let selected = scopes[0];
  for (const scope of scopes) {
    if (scope.start <= offset && offset <= scope.end && scopeDepth(scope) > scopeDepth(selected)) selected = scope;
  }
  return selected;
}

function scopeDepth(scope) {
  let depth = 0;
  for (let current = scope; current && current.parent; current = current.parent) depth += 1;
  return depth;
}

function isAncestor(ancestor, scope) {
  for (let current = scope; current; current = current.parent) if (current.id === ancestor.id) return true;
  return false;
}

function analyzeSymbols(source) {
  const tokens = tokenize(source);
  const { scopes } = buildScopes(tokens, source.length);
  const declarations = [];
  for (let i = 0; i < tokens.length; i += 1) {
    const token = tokens[i];
    if (token.kind !== 'identifier' || token.text !== 'let') continue;
    const previous = i > 0 ? tokens[i - 1] : null;
    if (previous && previous.kind !== 'newline' && previous.kind !== 'lbrace') continue;
    const nameToken = tokens[i + 1];
    if (!nameToken || nameToken.kind !== 'identifier') continue;
    const scope = scopeAt(scopes, token.start);
    if (scope.kind !== 'application' && scope.kind !== 'statement') continue;
    declarations.push({ name: nameToken.text, token: nameToken, scope });
  }
  return { tokens, scopes, declarations };
}

function wordTokenAt(tokens, offset) {
  return tokens.find(token => token.kind === 'identifier' && token.start <= offset && offset <= token.end) || null;
}

function resolveSymbol(source, offset, analysis) {
  const token = wordTokenAt(analysis.tokens, offset);
  if (!token) return null;
  const currentScope = scopeAt(analysis.scopes, offset);
  const candidates = analysis.declarations.filter(declaration =>
    declaration.name === token.text && declaration.token.start <= offset && isAncestor(declaration.scope, currentScope)
  );
  candidates.sort((a, b) => b.token.start - a.token.start);
  return candidates[0] || null;
}

function getDefinition(uri, source, position) {
  const offset = offsetAt(source, position);
  const analysis = analyzeSymbols(source);
  const declaration = resolveSymbol(source, offset, analysis);
  if (!declaration) return null;
  return {
    uri,
    range: {
      start: { line: declaration.token.line, character: declaration.token.character },
      end: { line: declaration.token.line, character: declaration.token.character + declaration.token.text.length }
    }
  };
}

function flattenLanguageInfo(info) {
  const known = new Map();
  for (const item of info.topLevel || []) known.set(item.name, item.description);
  for (const item of (info.application && info.application.members) || []) {
    known.set(item.name, item.description);
    for (const property of item.properties || []) {
      known.set(property.name, property.description);
      for (const value of property.values || []) known.set(value, `${property.name}: ${value}. ${property.description}`);
      for (const value of property.suggestions || []) known.set(value, `${property.name} example identifier. ${property.description}`);
    }
  }
  for (const item of info.architectures || []) known.set(item.name, item.description);
  known.set('else', 'Optional alternative branch that follows a completed if statement block.');
  known.set('select', 'Select the target architecture before the application declaration.');
  known.set('!docmont', info.header && info.header.description ? info.header.description : 'DOCMONT source header.');
  return known;
}

function getHover(source, position, info, uri) {
  const offset = offsetAt(source, position);
  const analysis = analyzeSymbols(source);
  const token = wordTokenAt(analysis.tokens, offset);
  if (!token) return null;
  const declaration = resolveSymbol(source, offset, analysis);
  if (declaration) {
    const p = declaration.token;
    return {
      contents: { kind: 'markdown', value: `**${token.text}**\n\nLocal variable declared with \`let\`.\n\nDeclaration: line ${p.line + 1}, column ${p.character + 1}.` },
      range: { start: { line: token.line, character: token.character }, end: { line: token.line, character: token.character + token.text.length } }
    };
  }
  const description = flattenLanguageInfo(info).get(token.text);
  if (!description) return null;
  return {
    contents: { kind: 'markdown', value: `**${token.text}**\n\n${description}` },
    range: { start: { line: token.line, character: token.character }, end: { line: token.line, character: token.character + token.text.length } }
  };
}

function makeCompletion(label, kind, detail, insertText, position, prefixLength, documentation) {
  const start = { line: position.line, character: Math.max(0, position.character - prefixLength) };
  const item = {
    label,
    kind,
    detail: detail || 'DOCMONT 3.4.0 grammar',
    insertText: insertText === undefined ? label : insertText,
    textEdit: { range: { start, end: position }, newText: insertText === undefined ? label : insertText }
  };
  if (documentation) item.documentation = { kind: 'markdown', value: documentation };
  if (String(item.insertText).includes('${')) item.insertTextFormat = 2;
  return item;
}

function getCompletionItems(source, position, info) {
  const offset = offsetAt(source, position);
  const lineStart = source.lastIndexOf('\n', Math.max(0, offset - 1)) + 1;
  const linePrefix = source.slice(lineStart, offset);
  const wordMatch = linePrefix.match(/[A-Za-z_!][A-Za-z0-9_!]*$/);
  const prefix = wordMatch ? wordMatch[0] : '';
  const prefixLength = prefix.length;
  const tokens = tokenize(source.slice(0, offset));
  const frames = [];
  for (let i = 0; i < tokens.length; i += 1) {
    if (tokens[i].kind === 'lbrace') frames.push({ kind: classifyBrace(tokens, i), start: tokens[i].end });
    else if (tokens[i].kind === 'rbrace' && frames.length) frames.pop();
  }
  const frame = frames.length ? frames[frames.length - 1] : null;
  const assignment = linePrefix.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)$/);
  const results = [];
  const seen = new Set();
  const add = (label, kind, detail, insertText, documentation) => {
    if (seen.has(label)) return;
    if (prefix && !label.toLowerCase().startsWith(prefix.toLowerCase())) return;
    seen.add(label);
    results.push(makeCompletion(label, kind, detail, insertText, position, prefixLength, documentation));
  };

  if (/^\s*!docmont\s*\[[^\]]*$/.test(linePrefix)) {
    add('2]', LSP.CompletionItemKind.Constant, 'DOCMONT v2 language header', '2]');
    add('3]', LSP.CompletionItemKind.Constant, 'DOCMONT v3 language header', '3]');
    return { isIncomplete: false, items: results };
  }
  if (/^\s*select\s+architecture\s*=\s*/.test(linePrefix)) {
    for (const architecture of info.architectures || []) add(architecture.name, LSP.CompletionItemKind.Enum, 'Target architecture', architecture.name, architecture.description);
    return { isIncomplete: false, items: results };
  }

  if (frame && (frame.kind === 'memory' || frame.kind === 'compute')) {
    const block = (info.application.members || []).find(item => item.name === frame.kind);
    const properties = block ? block.properties || [] : [];
    if (assignment) {
      const property = properties.find(item => item.name === assignment[1]);
      if (property) {
        for (const value of property.values || []) add(value, LSP.CompletionItemKind.Enum, `${property.name} value`, value, property.description);
        for (const value of property.suggestions || []) add(value, LSP.CompletionItemKind.Value, `${property.name} example`, value, property.description);
      }
    } else {
      const prior = source.slice(frame.start, offset);
      const used = new Set(Array.from(prior.matchAll(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=/gm), match => match[1]));
      for (const property of properties) {
        if (used.has(property.name)) continue;
        const insert = `${property.name} = `;
        add(property.name, LSP.CompletionItemKind.Property, `${frame.kind} property`, insert, property.description);
      }
    }
    return { isIncomplete: false, items: results };
  }

  const expressionContext = /^\s*(?:output\s*=|let\s+[A-Za-z_][A-Za-z0-9_]*\s*=|if\s*\([^)]*)/.test(linePrefix);
  if (expressionContext) {
    const analysis = analyzeSymbols(source.slice(0, offset));
    const currentScope = scopeAt(analysis.scopes, Math.max(0, offset));
    const visible = analysis.declarations.filter(declaration =>
      declaration.token.start < offset && isAncestor(declaration.scope, currentScope)
    );
    const names = new Set();
    for (const declaration of visible) {
      if (names.has(declaration.name)) continue;
      names.add(declaration.name);
      add(declaration.name, LSP.CompletionItemKind.Variable, 'Visible local variable', declaration.name, `Local variable declared with \`let\`.`);
    }
    if (!/^\s*if\s*\(/.test(linePrefix)) add('""', LSP.CompletionItemKind.Snippet, 'String literal', '"${1:text}"');
    add('0', LSP.CompletionItemKind.Constant, 'Integer literal', '0');
    add('1', LSP.CompletionItemKind.Constant, 'Integer literal', '1');
    add('(', LSP.CompletionItemKind.Keyword, 'Parenthesized expression', '(');
    return { isIncomplete: false, items: results };
  }

  if (frame && frame.kind === 'statement') {
    const statements = (info.application.members || []).filter(item => item.kind === 'statement');
    for (const item of statements) {
      let insert = item.name;
      if (item.name === 'let') insert = 'let ${1:name} = ${2:expression}';
      if (item.name === 'if') insert = 'if (${1:condition}) {\n    ${2:output = "..."}\n}';
      if (item.name === 'output') insert = 'output = "${1:text}"';
      add(item.name, item.name === 'let' || item.name === 'if' || item.name === 'output' ? LSP.CompletionItemKind.Keyword : LSP.CompletionItemKind.Text, 'DOCMONT statement', insert, item.description);
    }
    return { isIncomplete: false, items: results };
  }

  if (frame && frame.kind === 'application') {
    const members = info.application.members || [];
    const prior = source.slice(frame.start, offset);
    const used = new Set(Array.from(prior.matchAll(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=/gm), match => match[1]));
    for (const item of members) {
      if (item.kind === 'property' && used.has(item.name)) continue;
      if (item.kind === 'block' && used.has(item.name)) continue;
      let insert = item.name;
      if (item.name === 'name') insert = 'name = "${1:APP_NAME}"';
      if (item.name === 'memory') insert = 'memory = {\n    allocation = automatic\n    management = native\n    bounds = enforced\n}';
      if (item.name === 'compute') insert = 'compute = {\n    algorithm = selkon\n    optimization = O2\n}';
      if (item.name === 'let') insert = 'let ${1:name} = ${2:expression}';
      if (item.name === 'if') insert = 'if (${1:condition}) {\n    ${2:output = "..."}\n}';
      if (item.name === 'output') insert = 'output = "${1:text}"';
      add(item.name, item.kind === 'property' || item.kind === 'block' ? LSP.CompletionItemKind.Property : LSP.CompletionItemKind.Keyword, item.kind || 'DOCMONT member', insert, item.description);
    }
    return { isIncomplete: false, items: results };
  }

  const topLevel = info.topLevel || [];
  if (/^\s*!docmont/.test(linePrefix)) add('!docmont[2]', LSP.CompletionItemKind.Keyword, 'DOCMONT source header', '!docmont[2]');
  for (const item of topLevel) add(item.name, LSP.CompletionItemKind.Keyword, 'Top-level declaration', item.name, item.description);
  add('application', LSP.CompletionItemKind.Keyword, 'Application declaration', 'application = {\n    name = "${1:APP_NAME}"\n    complete\n}', 'Begin the application declaration block.');
  return { isIncomplete: false, items: results };
}

function parseCompilerDiagnostics(output, source) {
  const trimmed = String(output || '').trim();
  if (trimmed.startsWith('{')) {
    try {
      const report = JSON.parse(trimmed);
      if (report && Array.isArray(report.diagnostics)) {
        const sourceLines = source.split(/\r?\n/);
        return report.diagnostics.map(item => {
          const line = Math.max(0, Math.min(sourceLines.length - 1, Number(item.line || 1) - 1));
          const character = Math.max(0, Number(item.column || 1) - 1);
          const text = sourceLines[line] || '';
          const endLine = Math.max(line, Math.min(sourceLines.length - 1, Number(item.endLine || item.line || 1) - 1));
          const endText = sourceLines[endLine] || '';
          const endCharacter = Math.max(0, Math.min(endText.length, Number(item.endColumn || (character + 1)) - 1));
          return {
            range: { start: { line, character }, end: { line: endLine, character: Math.max(endLine === line ? character : 0, endCharacter) } },
            severity: item.severity === 'warning' ? LSP.Warning : LSP.Error,
            code: item.code ? String(item.code) : undefined,
            source: 'DOCMONT compiler', message: String(item.message || 'Compiler diagnostic')
          };
        });
      }
    } catch (_) { /* legacy text parser below handles non-JSON compiler output */ }
  }
  const lines = source.split(/\r?\n/);
  const diagnostics = [];
  for (const line of output.split(/\r?\n/)) {
    const match = line.match(/^(error|warning):(\d+):(\d+):\s*(.*)$/i);
    if (!match) continue;
    const lineNumber = Math.max(0, Math.min(lines.length - 1, Number(match[2]) - 1));
    const lineText = lines[lineNumber] || '';
    const character = Math.max(0, Math.min(lineText.length, Number(match[3]) - 1));
    diagnostics.push({
      range: { start: { line: lineNumber, character }, end: { line: lineNumber, character: Math.min(lineText.length, character + 1) } },
      severity: match[1].toLowerCase() === 'warning' ? LSP.Warning : LSP.Error,
      source: 'DOCMONT compiler',
      message: match[4]
    });
  }
  return diagnostics;
}

function uriPath(uri) {
  try { return fileURLToPath(uri); } catch (_) { return null; }
}

function containsPath(parent, child) {
  const relative = path.relative(parent, child);
  return relative === '' || (!relative.startsWith(`..${path.sep}`) && relative !== '..' && !path.isAbsolute(relative));
}

function createServer() {
  let input = Buffer.alloc(0);
  let nextId = 1;
  let initialized = false;
  let shuttingDown = false;
  const languageInfoCache = new Map();
  let options = { compilerPath: '${workspaceFolder}/build/docmont', validateOnType: true, validateDelay: 400 };
  let workspaceFolders = [];
  const documents = new Map();
  const jobs = new Map();

  function send(message) {
    const body = Buffer.from(JSON.stringify(message), 'utf8');
    process.stdout.write(Buffer.concat([Buffer.from(`Content-Length: ${body.length}\r\n\r\n`), body]));
  }
  function respond(id, result) { send({ jsonrpc: '2.0', id, result }); }
  function fail(id, code, message) { send({ jsonrpc: '2.0', id, error: { code, message } }); }
  function notify(method, params) { send({ jsonrpc: '2.0', method, params }); }
  function log(message) { process.stderr.write(`[DOCMONT LSP] ${message}\n`); }

  function workspaceRoot(uri) {
    const file = uriPath(uri);
    if (!file) return process.cwd();
    const candidates = workspaceFolders.map(folder => ({ folder, file: uriPath(folder.uri) })).filter(item => item.file && containsPath(item.file, file));
    candidates.sort((a, b) => b.file.length - a.file.length);
    return candidates.length ? candidates[0].file : path.dirname(file);
  }

  function compilerFor(uri) {
    const root = workspaceRoot(uri);
    let configured = options.compilerPath || 'docmont';
    if (configured.includes('${workspaceFolder}')) configured = configured.replace(/\$\{workspaceFolder\}/g, root);
    else if (!path.isAbsolute(configured) && configured !== 'docmont') configured = path.resolve(root, configured);
    return configured;
  }

  function cancelJob(uri) {
    const previous = jobs.get(uri);
    if (!previous) return;
    if (previous.timer) clearTimeout(previous.timer);
    if (previous.child && !previous.child.killed) previous.child.kill();
    if (previous.tempDir) {
      try { fs.rmSync(previous.tempDir, { recursive: true, force: true }); } catch (_) { /* best-effort cleanup */ }
    }
    jobs.delete(uri);
  }

  function validate(uri, immediate) {
    const document = documents.get(uri);
    if (!document || document.languageId !== 'docmont') return;
    cancelJob(uri);
    const job = { version: document.version, timer: null, child: null, tempDir: null };
    jobs.set(uri, job);
    const run = () => {
      if (jobs.get(uri) !== job || !documents.has(uri)) return;
      const current = documents.get(uri);
      if (current.version !== job.version) return;
      const exe = compilerFor(uri);
      try {
        job.tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'docmont-lsp-'));
        const tempFile = path.join(job.tempDir, 'buffer.docm');
        fs.writeFileSync(tempFile, current.text, 'utf8');
        job.child = cp.execFile(exe, ['check', '--json', tempFile], {
          cwd: workspaceRoot(uri), timeout: 10000, maxBuffer: 1024 * 1024, windowsHide: true
        }, (error, stdout, stderr) => {
          const output = `${stdout || ''}\n${stderr || ''}`;
          let diagnostics = parseCompilerDiagnostics(output, current.text);
          const stillCurrent = jobs.get(uri) === job && documents.has(uri) && documents.get(uri).version === job.version;
          if (!stillCurrent) {
            if (job.tempDir) {
              try { fs.rmSync(job.tempDir, { recursive: true, force: true }); } catch (_) { /* best-effort cleanup */ }
            }
            if (jobs.get(uri) === job) jobs.delete(uri);
            return;
          }
          if (error && diagnostics.length === 0) {
            const message = error.code === 'ENOENT'
              ? `DOCMONT compiler not found: ${exe}. Set docmont.compilerPath.`
              : `DOCMONT check failed: ${error.message}`;
            diagnostics = [{
              range: { start: { line: 0, character: 0 }, end: { line: 0, character: 0 } },
              severity: LSP.Warning, source: 'DOCMONT language server', message
            }];
            log(message);
          }
          notify('textDocument/publishDiagnostics', { uri, version: job.version, diagnostics });
          if (job.tempDir) {
            try { fs.rmSync(job.tempDir, { recursive: true, force: true }); } catch (_) { /* best-effort cleanup */ }
          }
          jobs.delete(uri);
        });
      } catch (error) {
        const diagnostics = [{
          range: { start: { line: 0, character: 0 }, end: { line: 0, character: 0 } },
          severity: LSP.Warning, source: 'DOCMONT language server', message: `DOCMONT validation setup failed: ${error.message}`
        }];
        notify('textDocument/publishDiagnostics', { uri, version: job.version, diagnostics });
        cancelJob(uri);
      }
    };
    if (immediate || options.validateDelay <= 0) run();
    else job.timer = setTimeout(run, Math.max(100, Math.min(5000, Number(options.validateDelay) || 400)));
  }

  function applyChange(text, change) {
    if (!change.range) return change.text;
    const start = offsetAt(text, change.range.start);
    const end = offsetAt(text, change.range.end);
    return text.slice(0, start) + change.text + text.slice(end);
  }

  function loadLanguageInfo(executable) {
    if (languageInfoCache.has(executable)) return languageInfoCache.get(executable);
    try {
      const raw = cp.execFileSync(executable, ['language-info'], { encoding: 'utf8', timeout: 5000, maxBuffer: 1024 * 1024 });
      const info = JSON.parse(raw);
      languageInfoCache.set(executable, info);
      log(`loaded grammar metadata from ${executable} (${info.version || 'unknown'})`);
      return info;
    } catch (error) {
      const message = `Unable to load DOCMONT grammar metadata from ${executable}: ${error.message}`;
      languageInfoCache.set(executable, null);
      log(message);
      return null;
    }
  }

  function handleRequest(message) {
    const id = message.id;
    const params = message.params || {};
    try {
      if (message.method === 'initialize') {
        options = Object.assign(options, params.initializationOptions || {});
        workspaceFolders = Array.isArray(params.workspaceFolders) ? params.workspaceFolders : [];
        const root = params.rootUri ? (uriPath(params.rootUri) || process.cwd()) : process.cwd();
        initialized = true;
        respond(id, {
          capabilities: {
            textDocumentSync: { openClose: true, change: 1, save: { includeText: false } },
            completionProvider: { resolveProvider: false, triggerCharacters: ['.', '=', ' ', '('] },
            definitionProvider: true,
            hoverProvider: true
          },
          serverInfo: { name: 'DOCMONT Language Server', version: '0.6.0' }
        });
        return;
      }
      if (message.method === 'shutdown') { shuttingDown = true; respond(id, null); return; }
      if (!initialized) { fail(id, -32002, 'Server is not initialized'); return; }
      if (message.method === 'textDocument/completion') {
        const document = documents.get(params.textDocument && params.textDocument.uri);
        const info = document ? loadLanguageInfo(compilerFor(document.uri)) : null;
        if (!document || !info) { respond(id, { isIncomplete: false, items: [] }); return; }
        respond(id, getCompletionItems(document.text, params.position, info));
        return;
      }
      if (message.method === 'textDocument/definition') {
        const document = documents.get(params.textDocument && params.textDocument.uri);
        respond(id, document ? getDefinition(document.uri, document.text, params.position) : null);
        return;
      }
      if (message.method === 'textDocument/hover') {
        const document = documents.get(params.textDocument && params.textDocument.uri);
        const info = document ? loadLanguageInfo(compilerFor(document.uri)) : null;
        respond(id, document && info ? getHover(document.text, params.position, info, document.uri) : null);
        return;
      }
      fail(id, -32601, `Method not found: ${message.method}`);
    } catch (error) {
      fail(id, -32603, error.message);
      log(`request ${message.method} failed: ${error.stack || error.message}`);
    }
  }

  function handleNotification(message) {
    const params = message.params || {};
    if (message.method === 'exit') {
      process.exit(shuttingDown ? 0 : 1);
      return;
    }
    if (message.method === 'initialized') return;
    if (message.method === 'textDocument/didOpen') {
      const item = params.textDocument;
      if (!item) return;
      documents.set(item.uri, { uri: item.uri, languageId: item.languageId, version: item.version, text: item.text });
      validate(item.uri, true);
      return;
    }
    if (message.method === 'textDocument/didChange') {
      const item = params.textDocument;
      const document = item && documents.get(item.uri);
      if (!document) return;
      for (const change of params.contentChanges || []) document.text = applyChange(document.text, change);
      document.version = item.version;
      if (options.validateOnType) validate(item.uri, false);
      return;
    }
    if (message.method === 'textDocument/didSave') {
      const item = params.textDocument;
      if (item && documents.has(item.uri)) validate(item.uri, true);
      return;
    }
    if (message.method === 'textDocument/didClose') {
      const item = params.textDocument;
      if (!item) return;
      cancelJob(item.uri);
      documents.delete(item.uri);
      notify('textDocument/publishDiagnostics', { uri: item.uri, diagnostics: [] });
      return;
    }
    if (message.method === 'docmont/validate') {
      if (params.uri) validate(params.uri, true);
      return;
    }
    if (message.method === 'workspace/didChangeConfiguration') {
      const incoming = params.settings && (params.settings.docmont || params.settings);
      if (incoming && typeof incoming === 'object') options = Object.assign(options, incoming);
      for (const uri of documents.keys()) validate(uri, true);
    }
  }

  function processMessage(message) {
    if (Object.prototype.hasOwnProperty.call(message, 'id')) handleRequest(message);
    else handleNotification(message);
  }

  function consume(chunk) {
    input = Buffer.concat([input, chunk]);
    while (true) {
      const boundary = input.indexOf('\r\n\r\n');
      if (boundary < 0) return;
      const header = input.slice(0, boundary).toString('ascii');
      const lengthMatch = header.match(/Content-Length:\s*(\d+)/i);
      if (!lengthMatch) { input = input.slice(boundary + 4); continue; }
      const length = Number(lengthMatch[1]);
      const bodyStart = boundary + 4;
      if (input.length < bodyStart + length) return;
      const body = input.slice(bodyStart, bodyStart + length).toString('utf8');
      input = input.slice(bodyStart + length);
      try { processMessage(JSON.parse(body)); }
      catch (error) { log(`invalid JSON-RPC message: ${error.message}`); }
    }
  }

  process.stdin.on('data', consume);
  process.stdin.on('end', () => {
    for (const uri of jobs.keys()) cancelJob(uri);
    process.exit(shuttingDown ? 0 : 1);
  });
  process.on('uncaughtException', error => log(`uncaught exception: ${error.stack || error.message}`));
  process.on('unhandledRejection', error => log(`unhandled rejection: ${error && error.stack ? error.stack : error}`));

  return { send, notify, get state() { return { initialized, shuttingDown, documents: documents.size, grammarLoaded: languageInfoCache.size }; } };
}

if (require.main === module) createServer();

module.exports = {
  tokenize, offsetAt, positionAt, buildScopes, analyzeSymbols, resolveSymbol,
  getDefinition, getHover, getCompletionItems, parseCompilerDiagnostics,
  createServer, LSP
};
