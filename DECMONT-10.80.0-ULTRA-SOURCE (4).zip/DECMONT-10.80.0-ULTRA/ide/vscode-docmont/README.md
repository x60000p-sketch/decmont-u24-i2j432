# DOCMONT VS Code Extension 0.6.0

This extension adds a small standalone Language Server Protocol (LSP) server for the implemented DOCMONT 10.80.0 (3.4.0 language compatibility) language subset. It has no npm runtime dependencies; the server uses Node.js built-ins and the real `docmont` executable.

## Implemented

- `.docm` language registration, TextMate highlighting, bracket/indent rules and snippets.
- Compiler diagnostics from `docmont check --json`, using the compiler JSON diagnostic contract (with legacy text parsing retained as fallback).
- Validation of the current **in-memory editor buffer**, not only the last saved disk contents.
- Debounced validation and stale-result rejection by document version.
- Completion based on metadata returned by `docmont language-info`; property/value suggestions are context-sensitive to the implemented grammar.
- Go to Definition for visible local `let` declarations, respecting application and `if`-block scopes.
- Hover documentation from the same compiler-provided language metadata, plus local-variable declaration information.

## Build DOCMONT first

From the DOCMONT 10.80.0 project root:

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j2
ctest --test-dir build --output-on-failure
./build/docmont --version
./build/docmont language-info
```

The extension's default compiler path is `${workspaceFolder}/build/docmont`. If the executable is elsewhere, set **DOCMONT: Compiler Path** to its absolute path.

## Install for development

1. Open `ide/vscode-docmont` as an extension project in VS Code.
2. Press `F5` to launch Extension Development Host.
3. Open the DOCMONT project folder in that window.
4. Open a `.docm` file. Diagnostics, completion, definition and hover are served by the child LSP process.
5. Use **DOCMONT: Check Current File** for immediate compiler validation or **DOCMONT: Show Language Server Output** for server logs.

## Verify the extension package

```bash
npm run check
npm test
```

These checks use Node's built-in test runner and do not require a VS Code installation. A real Extension Development Host launch still requires VS Code on the target machine.

## Language boundaries

The server loads its keyword, block, property, architecture and expression metadata from `docmont language-info`; it does not claim syntax the 3.4.0 language grammar does not accept. The server currently resolves `let` symbols within one document. There is no cross-file import/module system in DOCMONT 10.80.0, so cross-file definition is not implemented. Completion and hover are limited to the implemented grammar subset. Comments are not highlighted as comments because the DOCMONT 10.80.0 lexer does not accept source comments.

## Compatibility and non-goals

- Compiler compatibility target: DOCMONT 10.80.0 (3.4.0 language compatibility).
- The original 0.2.0 extension archive and existing project/VS Code tasks are not overwritten.
- This extension does not add or replace any workspace tasks.
- It is a small LSP implementation, not a full debugger, formatter, refactoring engine or module indexer.
