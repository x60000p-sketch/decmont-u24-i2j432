'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const cp = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const { pathToFileURL } = require('node:url');
const {
  tokenize, positionAt, getCompletionItems, getDefinition, getHover,
  parseCompilerDiagnostics
} = require('../server');

const extensionRoot = path.resolve(__dirname, '..');
const projectRoot = path.resolve(extensionRoot, '../../');
const configuredCompiler = process.env.DOCMONT_EXECUTABLE || process.env.DOCMONT_COMPILER || path.join(projectRoot, 'build', process.platform === 'win32' ? 'docmont.exe' : 'docmont');
const compiler = path.isAbsolute(configuredCompiler) ? configuredCompiler : path.resolve(projectRoot, configuredCompiler);
const serverPath = path.join(extensionRoot, 'server.js');

function compilerLanguageInfo() {
  const output = cp.execFileSync(compiler, ['language-info'], { encoding: 'utf8' });
  return JSON.parse(output);
}

function wait(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }

class LspProcess {
  constructor() {
    this.child = cp.spawn(process.execPath, [serverPath], { stdio: ['pipe', 'pipe', 'pipe'] });
    this.buffer = Buffer.alloc(0);
    this.nextId = 1;
    this.pending = new Map();
    this.notifications = [];
    this.waiters = [];
    this.stderr = '';
    this.child.stdout.on('data', chunk => this.consume(chunk));
    this.child.stderr.on('data', chunk => { this.stderr += chunk.toString('utf8'); });
  }

  send(message) {
    const body = Buffer.from(JSON.stringify(message), 'utf8');
    this.child.stdin.write(Buffer.concat([Buffer.from(`Content-Length: ${body.length}\r\n\r\n`), body]));
  }

  request(method, params) {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      this.pending.set(id, { resolve, reject });
      this.send({ jsonrpc: '2.0', id, method, params });
    });
  }

  notify(method, params) { this.send({ jsonrpc: '2.0', method, params }); }

  consume(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    while (true) {
      const boundary = this.buffer.indexOf('\r\n\r\n');
      if (boundary < 0) return;
      const header = this.buffer.slice(0, boundary).toString('ascii');
      const match = header.match(/Content-Length:\s*(\d+)/i);
      if (!match) { this.buffer = this.buffer.slice(boundary + 4); continue; }
      const length = Number(match[1]);
      const start = boundary + 4;
      if (this.buffer.length < start + length) return;
      const raw = this.buffer.slice(start, start + length).toString('utf8');
      this.buffer = this.buffer.slice(start + length);
      const message = JSON.parse(raw);
      if (Object.prototype.hasOwnProperty.call(message, 'id') && this.pending.has(message.id)) {
        const pending = this.pending.get(message.id);
        this.pending.delete(message.id);
        if (message.error) pending.reject(new Error(message.error.message));
        else pending.resolve(message.result);
      } else if (message.method) {
        this.notifications.push(message);
        this.flushWaiters();
      }
    }
  }

  flushWaiters() {
    for (let i = this.waiters.length - 1; i >= 0; i -= 1) {
      const waiter = this.waiters[i];
      const index = this.notifications.findIndex(waiter.predicate);
      if (index >= 0) {
        const [message] = this.notifications.splice(index, 1);
        this.waiters.splice(i, 1);
        clearTimeout(waiter.timer);
        waiter.resolve(message.params);
      }
    }
  }

  waitNotification(method, predicate = () => true, timeout = 5000) {
    const testPredicate = message => message.method === method && predicate(message.params || {});
    const existing = this.notifications.findIndex(testPredicate);
    if (existing >= 0) return Promise.resolve(this.notifications.splice(existing, 1)[0].params);
    return new Promise((resolve, reject) => {
      const waiter = { predicate: testPredicate, resolve, reject, timer: null };
      waiter.timer = setTimeout(() => {
        this.waiters = this.waiters.filter(item => item !== waiter);
        reject(new Error(`Timed out waiting for ${method}. Server stderr: ${this.stderr}`));
      }, timeout);
      this.waiters.push(waiter);
    });
  }

  async stop() {
    if (this.child.exitCode !== null) return;
    try { await this.request('shutdown', {}); } catch (_) { /* ignore shutdown race */ }
    this.notify('exit', {});
    this.child.stdin.end();
    await Promise.race([new Promise(resolve => this.child.once('exit', resolve)), wait(1500)]);
    if (this.child.exitCode === null) this.child.kill();
  }
}

test('compiler exposes valid grammar metadata and extension manifest is well formed', () => {
  assert.ok(fs.existsSync(compiler), `DOCMONT compiler missing at ${compiler}`);
  const info = compilerLanguageInfo();
  assert.equal(info.version, '3.4.0');
  assert.equal(info.compilerVersion, '10.80.0');
  assert.ok(info.application.members.some(item => item.name === 'let'));
  const memory = info.application.members.find(item => item.name === 'memory');
  assert.deepEqual(memory.properties.find(item => item.name === 'allocation').values, ['automatic', 'manual']);
  const manifest = JSON.parse(fs.readFileSync(path.join(extensionRoot, 'package.json'), 'utf8'));
  assert.equal(manifest.version, '0.9.0');
  assert.equal(manifest.main, './extension.js');
  for (const relative of [manifest.main, './server.js', './language-configuration.json', './syntaxes/docmont.tmLanguage.json', './snippets/docmont.json']) {
    assert.ok(fs.existsSync(path.join(extensionRoot, relative)), `Missing extension path: ${relative}`);
  }
  JSON.parse(fs.readFileSync(path.join(extensionRoot, 'syntaxes/docmont.tmLanguage.json'), 'utf8'));
  JSON.parse(fs.readFileSync(path.join(extensionRoot, 'snippets/docmont.json'), 'utf8'));
  JSON.parse(fs.readFileSync(path.join(extensionRoot, 'language-configuration.json'), 'utf8'));
});

test('language metadata suggestions are accepted by the DOCMONT 10.80.0 checker', () => {
  const info = compilerLanguageInfo();
  const members = info.application.members;
  const memory = members.find(item => item.name === 'memory');
  const compute = members.find(item => item.name === 'compute');
  const architectures = info.architectures.map(item => item.name);
  const allocations = memory.properties.find(item => item.name === 'allocation').values;
  const managementModes = memory.properties.find(item => item.name === 'management').values;
  const bounds = memory.properties.find(item => item.name === 'bounds').values;
  const optimizations = compute.properties.find(item => item.name === 'optimization').values;
  const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'docmont-grammar-check-'));
  const sourceFile = path.join(temp, 'grammar.docm');
  try {
    for (const architecture of architectures) {
      for (const allocation of allocations) {
        for (const management of managementModes) {
          for (const bound of bounds) {
            for (const optimization of optimizations) {
              const source = [
                '!docmont[3]',
                `select architecture = ${architecture}`,
                'application = {',
                '    name = "grammar acceptance"',
                '    memory = {',
                `        allocation = ${allocation}`,
                `        management = ${management}`,
                `        bounds = ${bound}`,
                '    }',
                '    compute = {',
                '        algorithm = selkon',
                `        optimization = ${optimization}`,
                '    }',
                '    let value = 2 * 3 + 4',
                '    if (value) {',
                '        output = "ok"',
                '    } else {',
                '        output = value',
                '    }',
                '    complete',
                '}'
              ].join('\n') + '\n';
              fs.writeFileSync(sourceFile, source, 'utf8');
              cp.execFileSync(compiler, ['check', sourceFile], { encoding: 'utf8' });
            }
          }
        }
      }
    }
    const invalid = '!docmont[2]\napplication = {\n name = "bad"\n memory = {\n allocation = dynamic\n management = native\n }\n complete\n}\n';
    fs.writeFileSync(sourceFile, invalid, 'utf8');
    const rejected = cp.spawnSync(compiler, ['check', sourceFile], { encoding: 'utf8' });
    assert.notEqual(rejected.status, 0);
    assert.match(rejected.stderr, /memory\.allocation/);
  } finally {
    fs.rmSync(temp, { recursive: true, force: true });
  }
});

test('completion is context-sensitive and follows compiler-provided grammar metadata', () => {
  const info = compilerLanguageInfo();
  const source = '!docmont[2]\napplication = {\n    memory = {\n        allocation = ';
  const position = positionAt(source, source.length);
  const response = getCompletionItems(source, position, info);
  const labels = response.items.map(item => item.label);
  assert.deepEqual(labels, ['automatic', 'manual']);
  assert.ok(response.items.every(item => item.textEdit && item.textEdit.newText === item.label));
});

test('completion follows top-level, statement and expression grammar contexts', () => {
  const info = compilerLanguageInfo();
  const architectureSource = '!docmont[2]\nselect architecture = ';
  const architectureItems = getCompletionItems(architectureSource, positionAt(architectureSource, architectureSource.length), info).items.map(item => item.label);
  assert.deepEqual(architectureItems, ['x86_64', 'arm64', 'portable']);

  const applicationSource = '!docmont[2]\napplication = {\n    let count = 4\n    if (count) {\n        output = ';
  const expressionItems = getCompletionItems(applicationSource, positionAt(applicationSource, applicationSource.length), info).items.map(item => item.label);
  assert.ok(expressionItems.includes('count'));
  assert.ok(expressionItems.includes('0'));
  assert.ok(!expressionItems.includes('complete'));

  const statementSource = '!docmont[2]\napplication = {\n    if (1) {\n        ';
  const statementItems = getCompletionItems(statementSource, positionAt(statementSource, statementSource.length), info).items.map(item => item.label);
  assert.ok(statementItems.includes('let'));
  assert.ok(statementItems.includes('output'));
  assert.ok(!statementItems.includes('complete'));
});

test('symbol navigation respects nested if-block scope and hover uses compiler metadata', () => {
  const info = compilerLanguageInfo();
  const source = [
    '!docmont[2]',
    'application = {',
    '    let amount = 7',
    '    if (amount) {',
    '        let inner = amount + 1',
    '        output = inner',
    '    }',
    '    output = amount',
    '    complete',
    '}'
  ].join('\n');
  const reference = source.indexOf('inner', source.indexOf('output = inner'));
  const definition = getDefinition('file:///test.docm', source, positionAt(source, reference));
  assert.ok(definition);
  assert.equal(definition.range.start.line, 4);
  const outsideSource = `${source}\n    output = inner\n`;
  const outside = outsideSource.lastIndexOf('inner');
  assert.equal(getDefinition('file:///test.docm', outsideSource, positionAt(outsideSource, outside)), null);
  const hoverOffset = source.indexOf('if (') + 1;
  const hover = getHover(source, positionAt(source, hoverOffset), info, 'file:///test.docm');
  assert.match(hover.contents.value, /Conditional statement/);
});

test('structured compiler diagnostics preserve stable codes and end ranges', () => {
  const report = JSON.stringify({ diagnostics: [{ severity: 'error', line: 2, column: 8, code: 'DSEM001', endLine: 2, endColumn: 20, message: "Unknown variable 'missing'" }] });
  const diagnostics = parseCompilerDiagnostics(report, 'application = {\noutput = missing\n}');
  assert.equal(diagnostics.length, 1);
  assert.equal(diagnostics[0].code, 'DSEM001');
  assert.deepEqual(diagnostics[0].range, { start: { line: 1, character: 7 }, end: { line: 1, character: 16 } });
});

test('compiler diagnostic mapping clamps positions to the in-memory document', () => {
  const diagnostics = parseCompilerDiagnostics('error:99:200: sample failure\nwarning:1:1: sample warning', 'one\n');
  assert.equal(diagnostics.length, 2);
  assert.equal(diagnostics[0].range.start.line, 1);
  assert.equal(diagnostics[0].range.start.character, 0);
  assert.equal(diagnostics[1].severity, 2);
});

test('LSP protocol validates unsaved buffers and serves completion, definition and hover', async t => {
  assert.ok(fs.existsSync(compiler), `DOCMONT compiler missing at ${compiler}`);
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'docmont-lsp-integration-'));
  const file = path.join(root, 'sample.docm');
  const uri = pathToFileURL(file).toString();
  const validOnDisk = '!docmont[2]\nselect architecture = x86_64\napplication = {\n    name = "disk-valid"\n    complete\n}\n';
  fs.writeFileSync(file, validOnDisk, 'utf8');
  const lsp = new LspProcess();
  t.after(async () => {
    await lsp.stop();
    fs.rmSync(root, { recursive: true, force: true });
  });

  const initialized = await lsp.request('initialize', {
    processId: process.pid,
    rootUri: pathToFileURL(root).toString(),
    workspaceFolders: [{ uri: pathToFileURL(root).toString(), name: 'integration' }],
    initializationOptions: { compilerPath: compiler, validateOnType: true, validateDelay: 100 }
  });
  assert.equal(initialized.serverInfo.name, 'DOCMONT Language Server');
  assert.equal(initialized.capabilities.definitionProvider, true);
  lsp.notify('initialized', {});

  lsp.notify('textDocument/didOpen', {
    textDocument: { uri, languageId: 'docmont', version: 1, text: validOnDisk }
  });
  const initial = await lsp.waitNotification('textDocument/publishDiagnostics', params => params.uri === uri && params.version === 1);
  assert.deepEqual(initial.diagnostics, []);

  const unsavedInvalid = [
    '!docmont[2]',
    'select architecture = x86_64',
    'application = {',
    '    name = "unsaved buffer"',
    '    memory = {',
    '        allocation = nope',
    '        management = native',
    '    }',
    '}'
  ].join('\n') + '\n';
  lsp.notify('textDocument/didChange', {
    textDocument: { uri, version: 2 }, contentChanges: [{ text: unsavedInvalid }]
  });
  const invalid = await lsp.waitNotification('textDocument/publishDiagnostics', params => params.uri === uri && params.version === 2);
  assert.ok(invalid.diagnostics.some(item => /memory\.allocation/.test(item.message)));
  assert.ok(invalid.diagnostics.some(item => /complete terminator/.test(item.message)));

  const memoryCursor = positionAt(unsavedInvalid, unsavedInvalid.indexOf('allocation = ') + 'allocation = '.length);
  const completions = await lsp.request('textDocument/completion', { textDocument: { uri }, position: memoryCursor });
  assert.deepEqual(completions.items.map(item => item.label), ['automatic', 'manual']);

  const scoped = [
    '!docmont[2]',
    'select architecture = x86_64',
    'application = {',
    '    name = "symbols"',
    '    let count = 5',
    '    if (count) {',
    '        let inner = count + 1',
    '        output = inner',
    '    }',
    '    output = count',
    '    complete',
    '}'
  ].join('\n') + '\n';
  lsp.notify('textDocument/didChange', { textDocument: { uri, version: 3 }, contentChanges: [{ text: scoped }] });
  const scopedDiagnostics = await lsp.waitNotification('textDocument/publishDiagnostics', params => params.uri === uri && params.version === 3);
  assert.deepEqual(scopedDiagnostics.diagnostics, []);
  const innerReference = scoped.indexOf('inner', scoped.indexOf('output = inner'));
  const definition = await lsp.request('textDocument/definition', { textDocument: { uri }, position: positionAt(scoped, innerReference) });
  assert.equal(definition.range.start.line, 6);
  const hoverPosition = positionAt(scoped, scoped.indexOf('if (') + 1);
  const hover = await lsp.request('textDocument/hover', { textDocument: { uri }, position: hoverPosition });
  assert.match(hover.contents.value, /Conditional statement/);
});
