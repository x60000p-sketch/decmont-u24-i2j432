# DOCMONT 9.00.0 ULTRA — Release Notes

DOCMONT 9.00.0 adds production-oriented build and integration tools for the previous ULTRA game and systems foundation.

## Highlights

- ONNX CPU operator set expanded to 23 operators, with tests for broadcasting, matrix/tensor shape transforms, reductions, concatenation and activations.
- New `docmont-native-build` links host-native executables from the verified direct MIR subset and supports cross-target object-only output.
- New `docmont-shader-build` integrates glslc/glslangValidator, DXC and Xcode Metal compiler command flows.
- Windows builds now contain D3D12 device/direct-queue initialization code; macOS builds contain Metal device/command-queue initialization code.
- New PS5/Xbox SDK adapter build driver uses only user-installed vendor CMake toolchains and SDK paths.
- New Windows, macOS and Android CMake presets/toolchain wrappers.
- CMake installation exports the `DOCMONT::docmont_core` package target.

## Validation

Linux x86_64 Release build passed. CTest 76/76 passed. VS Code LSP 8/8 and JavaScript checks passed. Native x86_64 executable and AArch64 object tests passed. ONNX operator tests passed. Console/shader adapter orchestration tests passed using fixtures.

## Important boundaries

No Sony SDK/devkit was mounted in this environment, so the console adapter has not produced a real PS5 binary. No GPU ICD/device or shader compiler was available, so GPU rendering and actual SPIR-V/DXIL/AIR outputs are not claimed. D3D12 and Metal sources require Windows/Apple builds. Android/Windows/macOS presets require their SDKs. ONNX remains CPU-only and supports only the listed float32 operator subset. Native executable generation remains limited to the verified MIR subset.
