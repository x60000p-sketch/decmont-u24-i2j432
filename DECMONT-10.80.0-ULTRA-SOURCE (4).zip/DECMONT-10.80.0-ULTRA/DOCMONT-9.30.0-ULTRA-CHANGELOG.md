# Changelog — DOCMONT 9.30.0 ULTRA

## Added
- GLES 3.1+ binary tensor compute API: Add, Subtract, Multiply, Divide, Maximum and Minimum.
- Stable row-wise GLES Softmax compute kernel.
- Detailed RenderGraph compile plan with resource lifetimes, transient allocation slots, aliasing and RAW/WAR/WAW barriers.
- CLI: `gles-info`, `gles-compute-demo`, `gles-render-demo`.
- Automated tensor, render graph and CLI integration tests.

## Changed
- Compiler/CLI/VS Code version contract advanced to 9.30.0.
- Preserved language compatibility 3.4.0 and DVM bytecode v1.

## Fixed
- Serialized EGL/GLES tests to avoid concurrent Mesa driver context races in CI.
- Added GLES stubs for non-Unix builds.

## Limitations
- No full Vulkan/D3D12/Metal renderer, general ONNX GPU provider, or general native compiler is claimed.
