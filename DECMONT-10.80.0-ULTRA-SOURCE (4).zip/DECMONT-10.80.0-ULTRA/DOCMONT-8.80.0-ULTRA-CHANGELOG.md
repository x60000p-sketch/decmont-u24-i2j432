# DOCMONT 8.80.0 ULTRA — Changelog

## Added
- CPU skeletal animation: bone hierarchy, TRS sampling, quaternion SLERP, pose blending, skin matrices, linear blend skinning.
- POSIX IPv4 TCP framed transport and UDP sequenced datagrams with CRC32; bind by IPv4 address or all interfaces; outbound IPv4 name resolution.
- Bounded ONNX protobuf parser and CPU float32 inference for Add, Gemm, Identity, MatMul (2D), Mul, Relu, Sigmoid, Softmax and Tanh.
- ONNX CLI `onnx-info` and `onnx-run` plus tiny MLP sample model.
- Vulkan loader/device/queue probe; explicit D3D12/Metal platform status.
- Localhost DOCMONT Visual Game Studio with editor, safe backups, validation/run, scene preview, asset metadata catalog, render planning and metrics panel.
- Console vendor SDK manifest validator and placeholder PS5/Xbox manifest examples.
- GLSL/HLSL/Metal skeletal/PBR shader source references.
- Expanded CTest coverage and Studio security/API smoke tests.

## Corrected
- ONNX raw_data initializers are sized against declared tensor shape before allocation/copy.
- Studio asset catalog now lists binary model/texture/audio/neural assets without reading them as source text.
- Studio launcher resolves both source-tree and CMake-installed data paths.
- LSP/CLI version contracts updated to compiler 8.80.0.

## Compatibility
- Language compatibility remains 3.4.0.
- DVM remains v1.
