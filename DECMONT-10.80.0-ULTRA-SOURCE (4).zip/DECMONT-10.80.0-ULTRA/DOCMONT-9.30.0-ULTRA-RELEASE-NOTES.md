# DOCMONT 9.30.0 ULTRA — Release Notes

## Highlights

1. OpenGL ES 3.1+ compute tensor operations: binary arithmetic (Add/Subtract/Multiply/Divide/Maximum/Minimum) and numerically stable row-wise Softmax.
2. Extended render graph compilation: resource lifetime intervals, transient allocation planning, non-overlapping lifetime aliasing and explicit resource hazard barriers.
3. CLI diagnostics and demonstrations: `gles-info`, `gles-compute-demo`, and `gles-render-demo <out.ppm>`.
4. Version contracts updated to 9.30.0 while preserving language compatibility 3.4.0 and DVM v1.

## Verification

- Release build: Linux x86_64, GNU C/C++.
- CTest: 80/80 passed.
- VS Code LSP integration: 8/8 passed (included in CTest).
- GLES 3.2 context: Mesa llvmpipe; offscreen triangle rendering passed.
- GLES compute: MatMul/ReLU (inherited), binary tensor kernels and stable row Softmax passed.
- Render graph: deterministic order, transient allocation reuse, aliasing boundaries and invalid read-before-write checks passed.
- Project workflow, Studio, ONNX CPU, native MIR build and SDK-adapter regression tests passed.

## Compatibility

- Compiler: 9.30.0
- Language compatibility: 3.4.0
- DVM bytecode: v1

## Not claimed as complete

No full Vulkan, D3D12 or Metal renderer is included. No general ONNX GPU execution provider is included. The native compiler still supports a restricted MIR subset. Windows/macOS/Android native device builds and console SDK/devkit validation were not performed in this Linux environment. GLES software rendering through llvmpipe is not hardware GPU acceleration.
