# DECMONT 10.20.0 — Capability Matrix

| Area | Status in this release | Evidence / boundary |
|---|---|---|
| Language compatibility | 3.4.0 preserved | Existing language and CLI regression suite |
| DVM bytecode | v1 preserved | Existing VM and bytecode verification tests |
| Native C backend | Restricted subset | Integer/string stack operations, arithmetic, print, conditional/unconditional jumps |
| Native CFG verifier | Implemented | Reachability stack-depth analysis and branch-target validation |
| Native stack sizing | Verified subset | Allocation sized from verified maximum reachable depth |
| Native arrays/objects/functions/closures | Not supported by C emitter | Rejected with explicit diagnostics; use DVM |
| Native MIR direct object path | Existing restricted implementation | Separate backend; not full language parity |
| GLES | Existing platform-dependent implementation | Host driver determines hardware acceleration |
| Vulkan | Probe/partial integration | Not a complete production renderer |
| D3D12 / Metal | Platform adapters/stubs depending on host | Requires native platform build and validation |
| ONNX | Bounded CPU operator subset | General GPU provider not implemented |
| Game engine | Host-side foundations | Production renderer/audio adapters incomplete |
| Windows/macOS/Android/iOS | Not verified by Linux build | Requires target-specific toolchains and devices |
| PS5/Xbox | SDK-gated | Licensed vendor SDK and devkit required |

## Native C verifier details

- The verifier starts at instruction zero and visits reachable control-flow nodes.
- Every branch target must be within `[0, instruction_count]`.
- Each reachable instruction has one required incoming operand-stack depth.
- All incoming paths to a merge point must agree on stack depth.
- Underflow is rejected before code generation.
- Positive stack growth around a loop is rejected when it conflicts with the previously established depth.
- The generated fixed stack uses the maximum verified depth (minimum allocation one slot for empty programs).

The verifier is deliberately conservative. It does not establish semantic equivalence for unsupported opcodes or replace a complete typed IR verifier.
