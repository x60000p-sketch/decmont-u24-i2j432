#!/usr/bin/env python3
"""DOCMONT Visual Game Studio: local-only, dependency-free project workspace."""
from __future__ import annotations
import argparse, hashlib, json, mimetypes, os, shutil, subprocess, tempfile, time, tomllib
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote

ROOT = Path(__file__).resolve().parent
MAX_FILE = 2 * 1024 * 1024
ALLOWED = {'.docm','.dscene','.dproj','.json','.toml','.glsl','.hlsl','.metal','.cpp','.hpp','.h','.c','.md','.txt','.dmat','.danim'}
ASSET_SUFFIXES = {'.png','.jpg','.jpeg','.webp','.bmp','.tga','.dds','.ktx','.ktx2',
                  '.obj','.gltf','.glb','.fbx','.dae','.mesh','.wav','.ogg','.mp3','.flac',
                  '.onnx','.spv','.dmat','.danim','.dscene'}
ASSET_KINDS = {'.png':'texture','.jpg':'texture','.jpeg':'texture','.webp':'texture','.bmp':'texture',
               '.tga':'texture','.dds':'texture','.ktx':'texture','.ktx2':'texture',
               '.obj':'mesh','.gltf':'model','.glb':'model','.fbx':'model','.dae':'model','.mesh':'mesh',
               '.wav':'audio','.ogg':'audio','.mp3':'audio','.flac':'audio','.onnx':'neural-model',
               '.spv':'shader-binary','.dmat':'material','.danim':'animation','.dscene':'scene'}

class StudioServer(ThreadingHTTPServer):
    allow_reuse_address = True
    daemon_threads = True
    def __init__(self, address, handler, workspace: Path, compiler: str):
        self.workspace = workspace.resolve()
        self.compiler = compiler
        super().__init__(address, handler)

class Handler(BaseHTTPRequestHandler):
    server_version = 'DOCMONT-Studio/8.90'
    def log_message(self, fmt, *args):
        # Local editor logs are intentionally quiet; API errors are returned to the UI.
        pass
    def _json(self, code, payload):
        raw = json.dumps(payload, ensure_ascii=False).encode('utf-8')
        self.send_response(code); self.send_header('Content-Type','application/json; charset=utf-8')
        self.send_header('Content-Length',str(len(raw))); self.send_header('Cache-Control','no-store')
        self.end_headers(); self.wfile.write(raw)
    def _body(self):
        n = int(self.headers.get('Content-Length','0'))
        if n <= 0 or n > MAX_FILE + 65536: raise ValueError('request body missing or too large')
        raw = self.rfile.read(n)
        return json.loads(raw.decode('utf-8'))
    def _safe(self, rel, allow_missing=False):
        if not isinstance(rel,str) or not rel or '\x00' in rel or '\\' in rel or ':' in rel: raise ValueError('invalid relative path')
        p = Path(rel)
        if p.is_absolute() or any(part in ('..','') for part in p.parts): raise ValueError('path traversal rejected')
        root = self.server.workspace
        candidate = root / p
        # Resolve existing parents to prevent symlink escapes.
        parent = candidate.parent.resolve()
        if parent != root and root not in parent.parents: raise ValueError('path escapes workspace')
        if candidate.exists() and (candidate.resolve() != root and root not in candidate.resolve().parents): raise ValueError('symlink escapes workspace')
        if not allow_missing and not candidate.is_file(): raise ValueError('file does not exist')
        if candidate.suffix.lower() not in ALLOWED: raise ValueError('file type is not editable in Studio')
        return candidate
    def do_GET(self):
        u = urlparse(self.path)
        if u.path == '/api/health':
            return self._json(200,{'ok':True,'studio':'DOCMONT Visual Game Studio','version':'9.00.0','workspace':str(self.server.workspace),'local_only':True})
        if u.path == '/api/project':
            manifest = self.server.workspace / 'docmont.toml'
            if not manifest.is_file():
                return self._json(200, {'ok':True,'configured':False,'message':'No docmont.toml project manifest in this workspace'})
            try:
                config = tomllib.loads(manifest.read_text(encoding='utf-8'))
                project = config.get('project', {})
                entry = project.get('entry', 'src/main.docm')
                entry_path = self._safe(entry)
                scene_rel = project.get('scene')
                scene_exists = bool(scene_rel and self._safe(scene_rel).is_file())
                source_count = sum(1 for p in self.server.workspace.rglob('*.docm') if not any(x in ('.git','build','dist','node_modules') for x in p.relative_to(self.server.workspace).parts))
                asset_count = sum(1 for p in self.server.workspace.rglob('*') if p.is_file() and p.suffix.lower() in ASSET_SUFFIXES and not any(x in ('.git','build','dist','node_modules') for x in p.relative_to(self.server.workspace).parts))
                return self._json(200, {'ok':True,'configured':True,'name':project.get('name'),'version':project.get('version'),'entry':entry,'entry_exists':entry_path.is_file(),'scene':scene_rel,'scene_exists':scene_exists,'source_count':source_count,'asset_count':asset_count,'engine':config.get('engine',{})})
            except (OSError, UnicodeError, tomllib.TOMLDecodeError, ValueError) as e:
                return self._json(400, {'ok':False,'error':f'project manifest invalid: {e}'})
        if u.path == '/api/files':
            rows=[]
            for p in sorted(self.server.workspace.rglob('*')):
                if len(rows)>=2000: break
                if any(x.startswith('.') or x in ('build','node_modules','target','dist') for x in p.relative_to(self.server.workspace).parts): continue
                if p.is_file() and p.suffix.lower() in ALLOWED:
                    try: rows.append({'path':p.relative_to(self.server.workspace).as_posix(),'size':p.stat().st_size})
                    except OSError: pass
            return self._json(200,{'ok':True,'files':rows})
        if u.path == '/api/assets':
            rows=[]
            for p in sorted(self.server.workspace.rglob('*')):
                if len(rows)>=4000: break
                rel=p.relative_to(self.server.workspace)
                if any(x.startswith('.') or x in ('build','node_modules','target','dist') for x in rel.parts): continue
                if p.is_file() and p.suffix.lower() in ASSET_SUFFIXES:
                    try:
                        resolved=p.resolve()
                        if resolved != self.server.workspace and self.server.workspace not in resolved.parents: continue
                        rows.append({'path':rel.as_posix(),'size':p.stat().st_size,'kind':ASSET_KINDS.get(p.suffix.lower(),'asset'),'extension':p.suffix.lower()})
                    except OSError: pass
            return self._json(200,{'ok':True,'assets':rows})
        if u.path == '/api/read':
            try:
                rel=parse_qs(u.query).get('path',[''])[0]; p=self._safe(rel)
                if p.stat().st_size>MAX_FILE: raise ValueError('file exceeds 2 MiB editor limit')
                return self._json(200,{'ok':True,'path':rel,'content':p.read_text(encoding='utf-8')})
            except (ValueError,OSError,UnicodeError) as e: return self._json(400,{'ok':False,'error':str(e)})
        if u.path == '/' or u.path.startswith('/assets/'):
            rel='index.html' if u.path=='/' else u.path[len('/assets/'):]
            p=(ROOT/'assets'/rel).resolve()
            if ROOT/'assets' not in p.parents and p != ROOT/'assets'/'index.html': return self._json(404,{'ok':False})
            if not p.is_file(): return self._json(404,{'ok':False,'error':'asset not found'})
            raw=p.read_bytes(); typ=mimetypes.guess_type(str(p))[0] or 'application/octet-stream'
            self.send_response(200);self.send_header('Content-Type',typ);self.send_header('Content-Length',str(len(raw)));self.send_header('Cache-Control','no-cache');self.end_headers();self.wfile.write(raw);return
        return self._json(404,{'ok':False,'error':'not found'})
    def do_POST(self):
        origin=self.headers.get('Origin')
        if origin:
            parsed=urlparse(origin)
            allowed={f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}
            if parsed.scheme not in ('http','https') or parsed.netloc not in allowed:
                return self._json(403,{'ok':False,'error':'cross-origin request rejected'})
        u=urlparse(self.path)
        try: data=self._body()
        except Exception as e: return self._json(400,{'ok':False,'error':str(e)})
        project_actions = {'/api/project/check':'check', '/api/project/build':'build',
                           '/api/project/assets':'assets', '/api/project/package':'package'}
        if u.path in project_actions:
            tool = (ROOT.parent / 'tools' / 'docmont-project')
            if not tool.is_file():
                found = shutil.which('docmont-project')
                tool = Path(found) if found else tool
            if not tool.is_file():
                return self._json(503, {'ok':False,'error':'docmont-project tool is not installed'})
            action = project_actions[u.path]
            cmd = [str(tool), action, str(self.server.workspace)]
            if action in ('check','build','package') and self.server.compiler:
                cmd += ['--compiler', self.server.compiler]
            elif action in ('check','package'):
                cmd += ['--no-compiler']
            if action == 'package':
                cmd += ['--output', str(self.server.workspace / 'dist' / 'studio-project.zip')]
            try:
                result = subprocess.run(cmd, cwd=self.server.workspace, capture_output=True, text=True,
                                        timeout=120, shell=False)
                return self._json(200 if result.returncode == 0 else 400,
                                  {'ok':result.returncode == 0,'returncode':result.returncode,
                                   'stdout':result.stdout[-16000:],'stderr':result.stderr[-16000:]})
            except (OSError, subprocess.TimeoutExpired) as e:
                return self._json(400, {'ok':False,'error':str(e)})
        if u.path == '/api/save':
            try:
                rel=data.get('path'); content=data.get('content')
                if not isinstance(content,str) or len(content.encode('utf-8'))>MAX_FILE: raise ValueError('content must be text up to 2 MiB')
                p=self._safe(rel,allow_missing=True);p.parent.mkdir(parents=True,exist_ok=True)
                if p.exists():
                    stamp=time.strftime('%Y%m%d-%H%M%S',time.gmtime())
                    backup=self.server.workspace/'.docmont-backups'/stamp/rel
                    backup.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,backup)
                with tempfile.NamedTemporaryFile('w',encoding='utf-8',dir=p.parent,delete=False) as tmp:
                    tmp.write(content);tmp.flush();os.fsync(tmp.fileno());temp=Path(tmp.name)
                temp.replace(p)
                return self._json(200,{'ok':True,'path':rel,'backup_created':(self.server.workspace/'.docmont-backups').exists()})
            except (ValueError,OSError) as e: return self._json(400,{'ok':False,'error':str(e)})
        if u.path in ('/api/validate','/api/run'):
            try:
                rel=data.get('path');p=self._safe(rel)
                if p.suffix.lower()!='.docm': raise ValueError('only .docm files can be validated or run')
                exe=self.server.compiler
                if not exe or not Path(exe).is_file(): raise ValueError('DOCMONT_EXECUTABLE is not configured; set it to the built compiler path')
                cmd=[exe,'check',str(p)] if u.path=='/api/validate' else [exe,'run',str(p)]
                result=subprocess.run(cmd,cwd=self.server.workspace,capture_output=True,text=True,timeout=20,shell=False)
                return self._json(200,{'ok':result.returncode==0,'returncode':result.returncode,'stdout':result.stdout[-12000:],'stderr':result.stderr[-12000:]})
            except (ValueError,OSError,subprocess.TimeoutExpired) as e: return self._json(400,{'ok':False,'error':str(e)})
        return self._json(404,{'ok':False,'error':'not found'})

def main():
    ap=argparse.ArgumentParser(description='Launch DOCMONT Visual Game Studio on localhost only')
    ap.add_argument('--workspace',default='.',help='project directory')
    ap.add_argument('--port',type=int,default=8787)
    ap.add_argument('--compiler',default=os.environ.get('DOCMONT_EXECUTABLE',''))
    args=ap.parse_args()
    workspace=Path(args.workspace).resolve();workspace.mkdir(parents=True,exist_ok=True)
    compiler=str(Path(args.compiler).resolve()) if args.compiler else ''
    server=StudioServer(('127.0.0.1',args.port),Handler,workspace,compiler)
    print(f'DOCMONT Visual Game Studio 9.00.0: http://127.0.0.1:{server.server_port}/')
    print(f'Workspace: {workspace}')
    print('Localhost-only server. Press Ctrl+C to stop.')
    try: server.serve_forever(poll_interval=0.25)
    except KeyboardInterrupt: pass
    finally: server.server_close()
if __name__=='__main__': main()
