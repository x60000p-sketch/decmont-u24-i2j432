VSHADER 1
name = VLOT_Standard
model = lambert
base_color = 0.82, 0.76, 0.64
roughness = 0.48
metallic = 0.05
emission = 0.0
