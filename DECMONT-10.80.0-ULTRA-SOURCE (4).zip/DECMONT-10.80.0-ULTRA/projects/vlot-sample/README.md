# VLOT sample project

This sample is a project descriptor for DOCMONT's VLOTDEVICEMANT hybrid engine foundation.

```sh
../../build/docmont vlot inspect project.vlot
../../build/docmont vlot plan project.vlot
../../build/docmont vlot-render-demo ../../build/vlot-demo.ppm
```

The project declares PC, Android and PS5 as intended targets. The build planner reports missing SDK requirements instead of claiming unsupported targets are built.
