# DOCMONT 8.70.0 ULTRA — Release Notes

DOCMONT 8.70.0 ULTRA expands the 8.70.0 compiler and runtime source with a tested native C++ game-systems foundation. It retains language compatibility 3.4.0 and DVM bytecode v1.

## New game-development capabilities

- Asset catalog and dependency validation.
- World cell partitioning with Active, SimulationOnly and Dormant tiers.
- Fixed-step AABB physics for static/dynamic rigid bodies.
- Weighted-grid A* navigation.
- Utility AI and Behavior Tree foundation.
- Animation blend-weight normalization.
- In-game day clock and weather settings validation.
- Spatial audio gain and voice-priority budgeting.
- Versioned multiplayer transform snapshot codec with CRC32.
- Forward/Deferred render graph pass planning.
- Device capability-profile API selection with explicit software fallback.
- CPU-reference GGX PBR shading and ACES tone mapping.
- Frame metrics collection, project validation, `game-info`, and `game-demo`.

## Verification

- CTest: **64/64 passed**.
- VS Code LSP tests: **8/8 passed**.
- VS Code JavaScript syntax check: passed.
- ULTRA sample and CLI demo: passed.
- Release executable built for Linux x86_64.

## Compatibility

- Compiler version: 8.70.0 ULTRA package.
- Source language compatibility: 3.4.0.
- DVM bytecode: v1 unchanged.
- Build standard: C++20.

## What this release is not

The release is a functional foundation, not a finished AAA game engine. It does not ship Vulkan/D3D12/Metal drivers, GPU compute, neural inference, full physics, navmesh, skeletal animation, audio-device playback, network transport, a visual game editor, asset importers or console SDK integrations. Consult `DOCMONT-8.70.0-ULTRA-CAPABILITY-MATRIX.md` before relying on a feature.
