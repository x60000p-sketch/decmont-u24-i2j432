# DECMONT 10.20.0 Changelog

- Added CFG-aware operand-stack verification to the restricted Native C emitter.
- Added branch target bounds validation.
- Added stack underflow and control-flow merge consistency diagnostics.
- Rejected positive-growth loops that invalidate fixed stack sizing.
- Sized generated C stack storage from verified maximum reachable depth.
- Added six focused native backend regression checks.
- Preserved language compatibility 3.4.0 and DVM bytecode v1.
