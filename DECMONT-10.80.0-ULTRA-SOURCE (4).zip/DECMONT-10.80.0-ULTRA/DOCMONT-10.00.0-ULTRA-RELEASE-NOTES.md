# DOCMONT 10.00.0 ULTRA — Release Notes

## Release focus
10.00.0 is a platform-readiness and diagnostics milestone built on the 9.30.0 source tree. It preserves the language compatibility level and DVM bytecode format while making host/backend readiness directly inspectable from the CLI.

## Added
- `docmont doctor`: consolidated host, CPU-thread, GLES, GPU-runtime/device/queue, native-compiler-scope, game-engine and ONNX capability report.
- Explicit reporting that distinguishes a portable VM, restricted native MIR object generation, GLES compute primitives, backend device probes and complete production backends.
- CLI and VS Code compiler-version contract updated to 10.00.0.
- CTest coverage for the system doctor command.

## Preserved
- Language compatibility: 3.4.0.
- DVM bytecode: v1.
- Existing parser, typed HIR/MIR, SSA, optimizer, interpreter, package manager, render graph, GLES compute and ONNX CPU subset APIs.

## Important implementation boundaries
- Native code generation remains a restricted MIR subset; this release does not claim full-language native compiler parity.
- Vulkan/D3D12/Metal complete renderers and GPU command submission remain incomplete; backend probes are diagnostics, not renderers.
- GLES compute availability does not imply physical GPU acceleration; software renderers are reported as such.
- ONNX remains a bounded CPU operator subset; a general ONNX GPU execution provider is not included.
- Game engine systems remain a foundation; production audio device playback and full cross-platform rendering require platform adapters.
- Windows, macOS, Android, iOS, consoles and RISC-V require their respective toolchains, SDKs and device validation.

## Build and test
```sh
cmake -S . -B build/release -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build/release -j8
ctest --test-dir build/release --output-on-failure
build/release/docmont --version
build/release/docmont doctor
```
