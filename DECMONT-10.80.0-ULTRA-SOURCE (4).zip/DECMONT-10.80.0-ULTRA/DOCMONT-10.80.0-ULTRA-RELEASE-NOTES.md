# DECMONT 10.80.0 ULTRA — Release Notes

## Native Object Model (restricted C11 lowering)

This release extends the Native C11 backend with a bounded object representation and lowering for `NewObject`, `ObjectSet`, `ObjectGet`, and `ObjectHas`.

- Objects are registered in a per-process cleanup registry and reclaimed at normal process exit through `atexit`.
- Properties use immutable generated C string keys and dynamically grown field arrays.
- Existing property writes replace the value; new properties grow the field storage.
- Property reads reject missing keys and invalid receivers; property tests return integer booleans.
- `ArrayLength` accepts native objects and returns their property count.
- Object field-capacity storage has a 64 MiB aggregate budget, a 1,000,000-field capacity limit, and a 65,536-object registry limit.
- Growth checks arithmetic and resource limits before reallocating; accounting commits only after successful allocation.

This is not a complete object ABI, class/inheritance system, reference-counted runtime, or tracing garbage collector. Objects are process-lifetime allocations in this backend. The Native C11 backend remains a restricted opcode subset; DVM remains the portable full-language runtime.

Language compatibility remains 3.4.0 and DVM bytecode compatibility remains unchanged.
